import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers || {}),
    },
    ...init,
  });
  const json = await res.json();
  if (!res.ok) {
    throw new Error(json?.message || "Request failed");
  }
  return json;
}

export function useWorkspaces() {
  return useQuery({
    queryKey: ["/api/saas/workspaces"],
    queryFn: () => api<any>("/api/saas/workspaces"),
  });
}

export function useAccounts() {
  return useQuery({
    queryKey: ["/api/saas/accounts"],
    queryFn: () => api<any>("/api/saas/accounts"),
  });
}

export function usePlatforms() {
  return useQuery({
    queryKey: ["/api/saas/platforms"],
    queryFn: () => api<any>("/api/saas/platforms"),
  });
}

export function usePlans() {
  return useQuery({
    queryKey: ["/api/saas/plans"],
    queryFn: () => api<any>("/api/saas/plans"),
  });
}

export function useDashboardSummary() {
  return useQuery({
    queryKey: ["/api/saas/dashboard-summary"],
    queryFn: () => api<any>("/api/saas/dashboard-summary"),
  });
}

export function useDailyPicks() {
  return useQuery({
    queryKey: ["/api/saas/daily-picks"],
    queryFn: () => api<any>("/api/saas/daily-picks"),
  });
}

export function useOnboardingChecklist() {
  return useQuery({
    queryKey: ["/api/saas/onboarding-checklist"],
    queryFn: () => api<any>("/api/saas/onboarding-checklist"),
  });
}

export function useAnalyticsSummary() {
  return useQuery({
    queryKey: ["/api/saas/analytics-summary"],
    queryFn: () => api<any>("/api/saas/analytics-summary"),
  });
}

export function useSwitchWorkspace() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (workspaceId: string) =>
      api<any>("/api/saas/current-workspace", {
        method: "PATCH",
        body: JSON.stringify({ workspaceId }),
      }),
    onSuccess: async () => {
      await Promise.all([
        qc.invalidateQueries({ queryKey: ["/api/auth/me"] }),
        qc.invalidateQueries({ queryKey: ["/api/saas/workspaces"] }),
        qc.invalidateQueries({ queryKey: ["/api/saas/accounts"] }),
        qc.invalidateQueries({ queryKey: ["/api/saas/dashboard-summary"] }),
      ]);
    },
  });
}

export function useSwitchAccount() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (accountId: string) =>
      api<any>("/api/saas/current-account", {
        method: "PATCH",
        body: JSON.stringify({ accountId }),
      }),
    onSuccess: async () => {
      await Promise.all([
        qc.invalidateQueries({ queryKey: ["/api/auth/me"] }),
        qc.invalidateQueries({ queryKey: ["/api/saas/accounts"] }),
        qc.invalidateQueries({ queryKey: ["/api/saas/dashboard-summary"] }),
        qc.invalidateQueries({ queryKey: ["/api/saas/daily-picks"] }),
        qc.invalidateQueries({ queryKey: ["/api/saas/onboarding-checklist"] }),
      ]);
    },
  });
}


export function useRiskCockpit() {
  return useQuery({
    queryKey: ["/api/saas/risk-cockpit"],
    queryFn: () => api<any>("/api/saas/risk-cockpit"),
  });
}

export function useConcentrationWarnings() {
  return useQuery({
    queryKey: ["/api/saas/concentration-warnings"],
    queryFn: () => api<any>("/api/saas/concentration-warnings"),
  });
}

export function useSnapshots() {
  return useQuery({
    queryKey: ["/api/saas/snapshots"],
    queryFn: () => api<any>("/api/saas/snapshots"),
  });
}

export function usePortfolioImpact() {
  return useMutation({
    mutationFn: (ticker: string) =>
      api<any>("/api/saas/portfolio-impact", {
        method: "POST",
        body: JSON.stringify({ ticker }),
      }),
  });
}
