import { useMemo } from "react";
import { useAccounts, useSwitchAccount, useSwitchWorkspace, useWorkspaces } from "@/hooks/use-saas";
import { useAuth } from "@/hooks/use-auth";

export function AccountSwitcher() {
  const { data: auth } = useAuth();
  const { data: workspaces } = useWorkspaces();
  const { data: accounts } = useAccounts();
  const switchWorkspace = useSwitchWorkspace();
  const switchAccount = useSwitchAccount();

  const workspaceOptions = useMemo(() => workspaces?.workspaces || [], [workspaces]);
  const accountOptions = useMemo(() => accounts?.accounts || [], [accounts]);

  return (
    <div className="flex flex-wrap items-center gap-2">
      <select
        className="rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-slate-200"
        value={auth?.currentWorkspace?.id || ""}
        onChange={(e) => switchWorkspace.mutate(e.target.value)}
        disabled={switchWorkspace.isPending}
      >
        {workspaceOptions.map((w: any) => (
          <option key={w.id} value={w.id}>{w.name}</option>
        ))}
      </select>

      <select
        className="rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-slate-200"
        value={auth?.currentAccount?.id || ""}
        onChange={(e) => switchAccount.mutate(e.target.value)}
        disabled={switchAccount.isPending}
      >
        {accountOptions.map((a: any) => (
          <option key={a.id} value={a.id}>{a.name}</option>
        ))}
      </select>
    </div>
  );
}
