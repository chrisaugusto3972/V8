import { PageHero } from "@/components/page-hero";
import { SectionCard } from "@/components/section-card";
import { StatCard } from "@/components/stat-card";
import { StatusBadge } from "@/components/status-badge";
import { useDailyPicks } from "@/hooks/use-saas";

export default function PicksPage() {
  const { data, isLoading } = useDailyPicks();
  const picks = data?.picks || [];

  return (
    <>
      <PageHero
        eyebrow="Daily picks"
        title="Institutional Pick Set"
        description="Review the top portfolio-aware trade set selected for the active account. Phase 2 productizes the picks experience so users can trust what V8 is selecting and why."
      />

      <div className="grid gap-4 md:grid-cols-4 mb-6">
        <StatCard label="Selected Picks" value={picks.length || 0} hint="Final trade set" />
        <StatCard label="Regime" value={data?.regime || "—"} hint="Current market state" />
        <StatCard label="VIX" value={data?.vix ?? "—"} hint="Volatility reference" />
        <StatCard label="Portfolio Goal" value={data?.portfolioGoal || "Balance"} hint="Trade-set objective" />
      </div>

      <SectionCard title="Today's Picks" subtitle="Best combination of trades, not just highest raw scores">
        {isLoading ? <div className="text-sm text-slate-400">Loading picks...</div> : null}
        <div className="grid gap-4 lg:grid-cols-3">
          {picks.map((pick: any) => (
            <div key={`${pick.ticker}-${pick.spread}`} className="rounded-xl border border-slate-800 bg-slate-950/60 p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="text-lg font-semibold text-white">{pick.ticker}</div>
                  <div className="text-sm text-slate-400">{pick.spread}</div>
                </div>
                <StatusBadge tone={pick.role === "Anchor" ? "success" : pick.role === "Engine" ? "warning" : "neutral"}>
                  {pick.role}
                </StatusBadge>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                <div className="rounded-lg bg-slate-900 p-3">
                  <div className="text-slate-400">Delta</div>
                  <div className="mt-1 font-medium text-white">{pick.delta}</div>
                </div>
                <div className="rounded-lg bg-slate-900 p-3">
                  <div className="text-slate-400">OTM %</div>
                  <div className="mt-1 font-medium text-white">{pick.otm}</div>
                </div>
                <div className="rounded-lg bg-slate-900 p-3">
                  <div className="text-slate-400">Credit %</div>
                  <div className="mt-1 font-medium text-white">{pick.creditPct}</div>
                </div>
                <div className="rounded-lg bg-slate-900 p-3">
                  <div className="text-slate-400">Score</div>
                  <div className="mt-1 font-medium text-white">{pick.score}</div>
                </div>
              </div>

              <div className="mt-4 text-sm text-slate-300">{pick.rationale}</div>

              <div className="mt-4 rounded-xl border border-slate-800 bg-slate-900/70 p-3">
                <div className="flex items-center justify-between gap-2">
                  <div className="text-xs uppercase tracking-[0.18em] text-slate-400">Portfolio impact before entry</div>
                  <StatusBadge tone={pick.impact?.tone || "neutral"}>{pick.impact?.verdict || "Review"}</StatusBadge>
                </div>
                <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                  <div className="rounded-lg bg-slate-950/70 p-2">
                    <div className="text-slate-500">Δ change</div>
                    <div className="mt-1 text-white">{pick.impact?.deltaChange >= 0 ? "+" : ""}{pick.impact?.deltaChange}</div>
                  </div>
                  <div className="rounded-lg bg-slate-950/70 p-2">
                    <div className="text-slate-500">Θ change</div>
                    <div className="mt-1 text-white">+{pick.impact?.thetaChange}</div>
                  </div>
                </div>
                <div className="mt-3 text-xs text-slate-300">{pick.impact?.concentrationImpact}</div>
                <div className="mt-1 text-xs text-slate-400">{pick.impact?.stressImpact}</div>
              </div>
            </div>
          ))}
        </div>
      </SectionCard>
    </>
  );
}
