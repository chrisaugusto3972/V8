import { Link } from "wouter";
import { PageHero } from "@/components/page-hero";
import { SectionCard } from "@/components/section-card";
import { useAccounts, usePlatforms } from "@/hooks/use-saas";

export default function PlatformsPage() {
  const { data } = usePlatforms();
  const { data: accountData } = useAccounts();

  return (
    <>
      <PageHero
        eyebrow="Broker choice"
        title="Supported Trading Platforms"
        description="Users choose from a controlled compatibility list. Paper Account and Tastytrade launch first. More brokers come later behind one broker abstraction layer."
      />

      <div className="grid gap-6 lg:grid-cols-[1.1fr,0.9fr]">
        <SectionCard title="Compatibility Matrix">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-3 text-left">Platform</th>
                  <th className="py-3 text-left">Status</th>
                  <th className="py-3 text-left">Read-only Sync</th>
                  <th className="py-3 text-left">Assisted Execution</th>
                  <th className="py-3 text-left">Paper Autopilot</th>
                  <th className="py-3 text-left">Live Autopilot</th>
                </tr>
              </thead>
              <tbody>
                {(data?.platforms || []).map((p: any) => (
                  <tr key={p.id} className="border-b border-slate-900 text-slate-200">
                    <td className="py-3">{p.name}</td>
                    <td className="py-3">{p.status}</td>
                    <td className="py-3">{p.readOnlySync ? "Yes" : "No"}</td>
                    <td className="py-3">{p.assistedExecution ? "Yes" : "No"}</td>
                    <td className="py-3">{p.paperAutopilotCompatible ? "Yes" : "No"}</td>
                    <td className="py-3">{p.liveAutopilotCompatible ? "Yes" : "No"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </SectionCard>

        <SectionCard title="Current Account Mix" subtitle="Use paper first, then expand to broker-connected flows">
          <div className="space-y-3">
            {(accountData?.accounts || []).map((a: any) => (
              <div key={a.id} className="rounded-lg border border-slate-800 bg-slate-950/60 p-4">
                <div className="font-medium text-white">{a.name}</div>
                <div className="mt-1 text-sm text-slate-400">{a.platform} • {a.mode}</div>
              </div>
            ))}
          </div>
          <div className="mt-4 text-sm text-slate-400">
            Need help deciding? Start with <strong className="text-slate-200">Paper Account</strong>, then connect <strong className="text-slate-200">Tastytrade</strong> once your workflow is stable.
          </div>
          <Link href="/onboarding"><a className="mt-4 inline-flex rounded-lg border border-slate-700 px-4 py-2 text-sm text-slate-200 hover:bg-slate-900">Open onboarding</a></Link>
        </SectionCard>
      </div>
    </>
  );
}
