
import { PageHero } from "@/components/page-hero";
import { SectionCard } from "@/components/section-card";
import { StatCard } from "@/components/stat-card";
import { StatusBadge } from "@/components/status-badge";
import { useRiskCockpit, useConcentrationWarnings, useSnapshots } from "@/hooks/use-saas";

function Money(v: number) {
  const sign = v >= 0 ? "+" : "-";
  return `${sign}$${Math.abs(v).toFixed(1)}`;
}

export default function RiskCockpitPage() {
  const { data, isLoading } = useRiskCockpit();
  const { data: warningsData } = useConcentrationWarnings();
  const { data: snapshotsData } = useSnapshots();

  const cockpit = data?.cockpit;
  const warnings = warningsData?.warnings || [];
  const snapshots = snapshotsData?.snapshots || [];

  return (
    <>
      <PageHero
        eyebrow="Phase 3"
        title="Risk Cockpit"
        description="This phase productizes V8’s strongest moat: portfolio impact before entry, concentration warnings, and stress-aware positioning for a subscription product that feels institutional."
        actions={<StatusBadge tone="warning">Differentiator Layer</StatusBadge>}
      />

      <div className="grid gap-4 md:grid-cols-4 mb-6">
        <StatCard label="Net Delta" value={cockpit ? `+${cockpit.netDelta.toFixed(2)}` : "—"} hint="Directional lean" />
        <StatCard label="Net Theta" value={cockpit ? `+${cockpit.netTheta.toFixed(1)}` : "—"} hint="Daily decay engine" />
        <StatCard label="Beta-Weighted Delta" value={cockpit ? `+${cockpit.betaWeightedDelta.toFixed(2)}` : "—"} hint="SPY-equivalent lean" />
        <StatCard label="Open Risk" value={cockpit ? `$${cockpit.totalOpenRisk}` : "—"} hint="Defined-risk currently deployed" />
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.05fr,0.95fr]">
        <SectionCard title="Concentration Warnings" subtitle="Tell users what could go wrong before they add risk">
          {isLoading ? <div className="text-sm text-slate-400">Loading risk state...</div> : null}
          <div className="space-y-3">
            {warnings.map((warning: any) => (
              <div key={warning.id} className="rounded-xl border border-slate-800 bg-slate-950/60 p-4">
                <div className="flex items-center justify-between gap-3">
                  <div className="font-medium text-white">{warning.title}</div>
                  <StatusBadge tone={warning.tone}>{warning.tone}</StatusBadge>
                </div>
                <div className="mt-2 text-sm text-slate-300">{warning.message}</div>
              </div>
            ))}
          </div>
        </SectionCard>

        <SectionCard title="Stress Map" subtitle="Portfolio impact under common downside / vol scenarios">
          <div className="space-y-3">
            {(cockpit?.stress?.scenarios || []).map((s: any) => (
              <div key={s.label} className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-950/60 px-4 py-3">
                <div className="text-sm text-slate-300">{s.label}</div>
                <div className={`text-sm font-semibold ${s.estimatedPnl >= 0 ? 'text-emerald-300' : 'text-rose-300'}`}>
                  {Money(s.estimatedPnl)}
                </div>
              </div>
            ))}
          </div>
        </SectionCard>
      </div>

      <div className="grid gap-6 lg:grid-cols-2 mt-6">
        <SectionCard title="Exposure Mix" subtitle="What the portfolio is actually concentrated in">
          <div className="grid gap-3 md:grid-cols-2">
            {Object.entries(cockpit?.riskBySector || {}).map(([name, value]) => (
              <div key={name} className="rounded-xl border border-slate-800 bg-slate-950/60 p-4">
                <div className="text-sm text-slate-400">{name}</div>
                <div className="mt-1 text-xl font-semibold text-white">${Number(value).toFixed(0)}</div>
              </div>
            ))}
          </div>
          <div className="mt-4 flex flex-wrap gap-2 text-xs text-slate-400">
            <span>ETF Risk: ${cockpit?.etfRisk ?? 0}</span>
            <span>•</span>
            <span>Single-Stock Risk: ${cockpit?.singleStockRisk ?? 0}</span>
            <span>•</span>
            <span>High-Beta Risk: ${cockpit?.highBetaRisk ?? 0}</span>
          </div>
        </SectionCard>

        <SectionCard title="Snapshot Trend" subtitle="Track whether the book is getting safer or more crowded over time">
          <div className="space-y-3">
            {snapshots.map((snap: any) => (
              <div key={snap.date} className="grid grid-cols-4 gap-3 rounded-xl border border-slate-800 bg-slate-950/60 p-3 text-sm">
                <div>
                  <div className="text-slate-500">Date</div>
                  <div className="text-white">{snap.date}</div>
                </div>
                <div>
                  <div className="text-slate-500">Risk</div>
                  <div className="text-white">${snap.totalOpenRisk}</div>
                </div>
                <div>
                  <div className="text-slate-500">BWD</div>
                  <div className="text-white">+{Number(snap.betaWeightedDelta).toFixed(2)}</div>
                </div>
                <div>
                  <div className="text-slate-500">SPY -2%</div>
                  <div className="text-rose-300">{Money(Number(snap.stressSpyDown2pct))}</div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 text-xs text-slate-500">
            Greeks source: {snapshotsData?.sourceSummary?.liveGreeksCount || 0} live / {snapshotsData?.sourceSummary?.approxGreeksCount || 0} estimated
          </div>
        </SectionCard>
      </div>
    </>
  );
}
