import { PageHero } from "@/components/page-hero";
import { SectionCard } from "@/components/section-card";
import { usePlans } from "@/hooks/use-saas";

export default function BillingPage() {
  const { data } = usePlans();
  const plans = data?.plans || [];

  return (
    <>
      <PageHero
        eyebrow="Monetization"
        title="Plans and Entitlements"
        description="Phase 2 introduces the subscription structure users will understand later when billing is connected for real. This page focuses on positioning, entitlement shape, and upgrade path clarity."
      />
      <div className="grid gap-6 md:grid-cols-3">
        {plans.map((plan: any) => (
          <SectionCard key={plan.name} title={plan.name} subtitle={`${plan.price}/month`}>
            <ul className="space-y-2 text-sm text-slate-300 list-disc pl-5">
              {plan.features.map((f: string) => <li key={f}>{f}</li>)}
            </ul>
          </SectionCard>
        ))}
      </div>
    </>
  );
}
