import { PageHero } from "@/components/page-hero";
import { SectionCard } from "@/components/section-card";
import { StatCard } from "@/components/stat-card";
import { useAnalyticsSummary } from "@/hooks/use-saas";

export default function AnalyticsPage() {
  const { data } = useAnalyticsSummary();
  const byEngine = data?.byEngine || [];
  const byRegime = data?.byRegime || [];

  return (
    <>
      <PageHero
        eyebrow="Retention layer"
        title="Performance Analytics"
        description="Phase 2 introduces a subscription-ready analytics experience so users can understand whether V8 is improving decision quality, execution quality, and portfolio construction over time."
      />

      <div className="grid gap-4 md:grid-cols-4 mb-6">
        <StatCard label="Win Rate" value={data?.winRate || "—"} hint="Rolling 30-day" />
        <StatCard label="Profit Factor" value={data?.profitFactor || "—"} hint="Avg win / avg loss balance" />
        <StatCard label="Avg Fill Quality" value={data?.avgFillQuality || "—"} hint="Execution alpha trend" />
        <StatCard label="Max Drawdown" value={data?.maxDrawdown || "—"} hint="Rolling period estimate" />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <SectionCard title="Results by Engine" subtitle="See how CORE vs BOOST are behaving">
          <div className="space-y-3">
            {byEngine.map((row: any) => (
              <div key={row.name} className="flex items-center justify-between rounded-lg border border-slate-800 bg-slate-950/60 p-3 text-sm">
                <span className="text-slate-300">{row.name}</span>
                <span className="font-medium text-white">{row.value}</span>
              </div>
            ))}
          </div>
        </SectionCard>

        <SectionCard title="Results by Regime" subtitle="Validate whether regime-aware logic is doing its job">
          <div className="space-y-3">
            {byRegime.map((row: any) => (
              <div key={row.name} className="flex items-center justify-between rounded-lg border border-slate-800 bg-slate-950/60 p-3 text-sm">
                <span className="text-slate-300">{row.name}</span>
                <span className="font-medium text-white">{row.value}</span>
              </div>
            ))}
          </div>
        </SectionCard>
      </div>
    </>
  );
}
