import { PageHero } from "@/components/page-hero";
import { SectionCard } from "@/components/section-card";
import { StatusBadge } from "@/components/status-badge";
import { useOnboardingChecklist } from "@/hooks/use-saas";

export default function OnboardingPage() {
  const { data } = useOnboardingChecklist();
  const steps = data?.steps || [];

  return (
    <>
      <PageHero
        eyebrow="Onboarding"
        title="Get V8 Ready"
        description="Guide new subscribers through the paper-first setup path so they can start using V8 immediately without broker friction."
      />

      <SectionCard title="Checklist" subtitle="Paper mode first. Broker connection later.">
        <div className="space-y-3">
          {steps.map((step: any) => (
            <div key={step.id} className="flex items-center justify-between rounded-lg border border-slate-800 bg-slate-950/60 p-4">
              <div>
                <div className="font-medium text-white">{step.title}</div>
                <div className="mt-1 text-sm text-slate-400">{step.description}</div>
              </div>
              <StatusBadge tone={step.complete ? "success" : "warning"}>
                {step.complete ? "Complete" : "Pending"}
              </StatusBadge>
            </div>
          ))}
        </div>
      </SectionCard>
    </>
  );
}
