
import type { Request, Response, NextFunction, Express } from "express";
import session from "express-session";
import MemoryStoreFactory from "memorystore";
import { randomUUID } from "crypto";

type User = {
  id: string;
  email: string;
  password: string;
  name: string;
  createdAt: string;
};

type Workspace = {
  id: string;
  userId: string;
  name: string;
  createdAt: string;
};

type Account = {
  id: string;
  workspaceId: string;
  name: string;
  platform: "paper" | "tastytrade";
  mode: "manual" | "assisted" | "paper_autopilot";
  createdAt: string;
};

const MemoryStore = MemoryStoreFactory(session);

export function registerSaasSession(app: Express) {
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "v8-phase1-dev-secret",
      resave: false,
      saveUninitialized: false,
      cookie: {
        maxAge: 1000 * 60 * 60 * 24 * 14,
      },
      store: new MemoryStore({
        checkPeriod: 1000 * 60 * 60 * 24,
      }),
    }),
  );
}

declare module "express-session" {
  interface SessionData {
    userId?: string;
    currentWorkspaceId?: string;
    currentAccountId?: string;
  }
}



type RiskWarning = {
  id: string;
  tone: "success" | "warning" | "danger";
  title: string;
  message: string;
};

function buildRiskCockpit(platform: "paper" | "tastytrade", mode: string) {
  const baseRisk = platform === "paper" ? 420 : 610;
  const netDelta = mode === "paper_autopilot" ? 0.34 : 0.46;
  const netTheta = mode === "paper_autopilot" ? 15.8 : 18.2;
  const betaWeightedDelta = mode === "paper_autopilot" ? 0.28 : 0.39;

  const riskBySector = {
    "Index ETF": platform === "paper" ? 190 : 265,
    Technology: platform === "paper" ? 108 : 155,
    "Commodity ETF": platform === "paper" ? 122 : 140,
  } as Record<string, number>;

  const riskByTicker = {
    GLD: platform === "paper" ? 122 : 140,
    QQQ: platform === "paper" ? 138 : 162,
    ORCL: platform === "paper" ? 74 : 82,
    SPY: platform === "paper" ? 52 : 71,
    AMD: platform === "paper" ? 34 : 55,
  } as Record<string, number>;

  const warnings: RiskWarning[] = [
    {
      id: 'concentration',
      tone: 'warning',
      title: 'Tech concentration elevated',
      message: 'Technology-linked risk is above ideal range. Prefer an ETF stabilizer or defensive anchor before adding another single-name engine.',
    },
    {
      id: 'regime',
      tone: 'warning',
      title: 'Elevated-volatility admission active',
      message: 'V8 is using tighter delta ceilings and wider OTM distance floors while VIX remains elevated.',
    },
    {
      id: 'portfolio-fit',
      tone: 'success',
      title: 'Portfolio-fit scoring active',
      message: 'New trades are evaluated against existing macro and sector exposure before selection.',
    },
  ];

  const snapshots = [
    { date: 'T-4', totalOpenRisk: baseRisk - 35, betaWeightedDelta: betaWeightedDelta - 0.04, stressSpyDown2pct: -48 },
    { date: 'T-3', totalOpenRisk: baseRisk - 18, betaWeightedDelta: betaWeightedDelta - 0.02, stressSpyDown2pct: -55 },
    { date: 'T-2', totalOpenRisk: baseRisk - 10, betaWeightedDelta: betaWeightedDelta - 0.01, stressSpyDown2pct: -59 },
    { date: 'T-1', totalOpenRisk: baseRisk + 4, betaWeightedDelta: betaWeightedDelta + 0.02, stressSpyDown2pct: -66 },
    { date: 'Now', totalOpenRisk: baseRisk, betaWeightedDelta, stressSpyDown2pct: -62 },
  ];

  return {
    totalOpenRisk: baseRisk,
    netDelta,
    netTheta,
    betaWeightedDelta,
    riskBySector,
    riskByTicker,
    highBetaRisk: platform === "paper" ? 108 : 155,
    etfRisk: platform === "paper" ? 312 : 405,
    singleStockRisk: platform === "paper" ? 108 : 205,
    warnings,
    stress: {
      scenarios: [
        { label: 'SPY -1%', estimatedPnl: -31.4 },
        { label: 'SPY -2%', estimatedPnl: -62.3 },
        { label: 'SPY -3%', estimatedPnl: -98.7 },
        { label: 'Vol +5', estimatedPnl: -37.8 },
        { label: 'Vol +10', estimatedPnl: -74.4 },
      ],
    },
    sourceSummary: {
      liveGreeksCount: 2,
      approxGreeksCount: 3,
      mode: 'mixed',
    },
    snapshots,
  };
}

function buildImpactForTicker(ticker: string) {
  const t = String(ticker || '').toUpperCase();
  const lookup: Record<string, any> = {
    GLD: {
      verdict: 'Improves diversification',
      tone: 'success',
      deltaChange: -0.06,
      thetaChange: 2.8,
      concentrationImpact: 'Lowers tech concentration',
      stressImpact: '+$8 improvement in SPY -2% scenario',
    },
    QQQ: {
      verdict: 'Neutral stabilizer',
      tone: 'warning',
      deltaChange: 0.04,
      thetaChange: 3.2,
      concentrationImpact: 'Adds macro exposure but stays within ETF limits',
      stressImpact: '-$5 worse in SPY -2% scenario',
    },
    ORCL: {
      verdict: 'Selective premium engine',
      tone: 'warning',
      deltaChange: 0.07,
      thetaChange: 3.9,
      concentrationImpact: 'Adds single-name tech exposure; allowed only because sub-industry overlap stays controlled',
      stressImpact: '-$9 worse in SPY -2% scenario',
    },
    TSLA: {
      verdict: 'Rejected in elevated correlation state',
      tone: 'danger',
      deltaChange: 0.11,
      thetaChange: 4.5,
      concentrationImpact: 'Would increase high-beta clustering beyond preferred range',
      stressImpact: '-$18 worse in SPY -2% scenario',
    },
  };
  return lookup[t] || {
    verdict: 'Requires portfolio review',
    tone: 'warning',
    deltaChange: 0.03,
    thetaChange: 2.1,
    concentrationImpact: 'Portfolio impact depends on current exposure mix',
    stressImpact: 'Marginal effect on current stress profile',
  };
}

const users: User[] = [];
const workspaces: Workspace[] = [];
const accounts: Account[] = [];

function seedDemoUser() {
  if (users.length > 0) return;
  const userId = randomUUID();
  const workspaceId = randomUUID();
  const accountId = randomUUID();

  users.push({
    id: userId,
    email: "demo@v8saas.local",
    password: "demo123",
    name: "Demo User",
    createdAt: new Date().toISOString(),
  });

  workspaces.push({
    id: workspaceId,
    userId,
    name: "Demo Workspace",
    createdAt: new Date().toISOString(),
  });

  accounts.push({
    id: accountId,
    workspaceId,
    name: "Paper Account",
    platform: "paper",
    mode: "paper_autopilot",
    createdAt: new Date().toISOString(),
  });
}

function requireAuth(req: Request, res: Response, next: NextFunction) {
  seedDemoUser();
  if (!req.session.userId) {
    return res.status(401).json({ ok: false, message: "Unauthorized" });
  }
  next();
}

function getUserContext(req: Request) {
  const user = users.find((u) => u.id === req.session.userId) || null;
  const userWorkspaces = workspaces.filter((w) => w.userId === req.session.userId);
  const currentWorkspace =
    userWorkspaces.find((w) => w.id === req.session.currentWorkspaceId) ||
    userWorkspaces[0] ||
    null;

  const workspaceAccounts = currentWorkspace
    ? accounts.filter((a) => a.workspaceId === currentWorkspace.id)
    : [];

  const currentAccount =
    workspaceAccounts.find((a) => a.id === req.session.currentAccountId) ||
    workspaceAccounts[0] ||
    null;

  return {
    user,
    workspaces: userWorkspaces,
    currentWorkspace,
    accounts: workspaceAccounts,
    currentAccount,
  };
}

export function registerSaasFoundationRoutes(app: Express) {
  seedDemoUser();

  app.get("/api/auth/me", (req, res) => {
    if (!req.session.userId) {
      return res.json({ ok: true, authenticated: false });
    }

    const ctx = getUserContext(req);
    return res.json({
      ok: true,
      authenticated: true,
      user: ctx.user,
      currentWorkspace: ctx.currentWorkspace,
      currentAccount: ctx.currentAccount,
    });
  });

  app.post("/api/auth/login", (req, res) => {
    seedDemoUser();
    const email = String(req.body?.email || "").trim().toLowerCase();
    const password = String(req.body?.password || "");

    const user = users.find((u) => u.email.toLowerCase() === email && u.password === password);
    if (!user) {
      return res.status(401).json({ ok: false, message: "Invalid credentials" });
    }

    req.session.userId = user.id;

    const firstWorkspace = workspaces.find((w) => w.userId === user.id) || null;
    req.session.currentWorkspaceId = firstWorkspace?.id;

    const firstAccount = firstWorkspace
      ? accounts.find((a) => a.workspaceId === firstWorkspace.id) || null
      : null;
    req.session.currentAccountId = firstAccount?.id;

    return res.json({
      ok: true,
      authenticated: true,
      user,
      currentWorkspace: firstWorkspace,
      currentAccount: firstAccount,
    });
  });

  app.post("/api/auth/register", (req, res) => {
    const email = String(req.body?.email || "").trim().toLowerCase();
    const password = String(req.body?.password || "");
    const name = String(req.body?.name || "").trim() || "New User";
    const workspaceName = String(req.body?.workspaceName || "").trim() || `${name}'s Workspace`;

    if (!email || !password) {
      return res.status(400).json({ ok: false, message: "Email and password are required" });
    }

    if (users.some((u) => u.email.toLowerCase() === email)) {
      return res.status(409).json({ ok: false, message: "Email already exists" });
    }

    const userId = randomUUID();
    const workspaceId = randomUUID();
    const accountId = randomUUID();

    const user: User = {
      id: userId,
      email,
      password,
      name,
      createdAt: new Date().toISOString(),
    };

    const workspace: Workspace = {
      id: workspaceId,
      userId,
      name: workspaceName,
      createdAt: new Date().toISOString(),
    };

    const account: Account = {
      id: accountId,
      workspaceId,
      name: "Paper Account",
      platform: "paper",
      mode: "manual",
      createdAt: new Date().toISOString(),
    };

    users.push(user);
    workspaces.push(workspace);
    accounts.push(account);

    req.session.userId = user.id;
    req.session.currentWorkspaceId = workspace.id;
    req.session.currentAccountId = account.id;

    return res.json({
      ok: true,
      authenticated: true,
      user,
      currentWorkspace: workspace,
      currentAccount: account,
    });
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy(() => {
      res.json({ ok: true });
    });
  });

  app.get("/api/saas/workspaces", requireAuth, (req, res) => {
    const ctx = getUserContext(req);
    res.json({
      ok: true,
      workspaces: ctx.workspaces,
      currentWorkspace: ctx.currentWorkspace,
    });
  });

  app.post("/api/saas/workspaces", requireAuth, (req, res) => {
    const name = String(req.body?.name || "").trim() || "New Workspace";
    const workspace: Workspace = {
      id: randomUUID(),
      userId: String(req.session.userId),
      name,
      createdAt: new Date().toISOString(),
    };
    workspaces.push(workspace);
    req.session.currentWorkspaceId = workspace.id;
    res.json({ ok: true, workspace });
  });

  app.get("/api/saas/accounts", requireAuth, (req, res) => {
    const ctx = getUserContext(req);
    res.json({
      ok: true,
      accounts: ctx.accounts,
      currentAccount: ctx.currentAccount,
    });
  });

  app.post("/api/saas/accounts", requireAuth, (req, res) => {
    const ctx = getUserContext(req);
    if (!ctx.currentWorkspace) {
      return res.status(400).json({ ok: false, message: "No workspace selected" });
    }

    const name = String(req.body?.name || "").trim() || "New Account";
    const platform = req.body?.platform === "tastytrade" ? "tastytrade" : "paper";
    const mode =
      req.body?.mode === "assisted" || req.body?.mode === "paper_autopilot"
        ? req.body.mode
        : "manual";

    const account: Account = {
      id: randomUUID(),
      workspaceId: ctx.currentWorkspace.id,
      name,
      platform,
      mode,
      createdAt: new Date().toISOString(),
    };

    accounts.push(account);
    req.session.currentAccountId = account.id;
    res.json({ ok: true, account });
  });

  app.patch("/api/saas/current-account", requireAuth, (req, res) => {
    const accountId = String(req.body?.accountId || "");
    const ctx = getUserContext(req);
    const account = ctx.accounts.find((a) => a.id === accountId);
    if (!account) {
      return res.status(404).json({ ok: false, message: "Account not found" });
    }
    req.session.currentAccountId = account.id;
    res.json({ ok: true, currentAccount: account });
  });

  app.patch("/api/saas/current-workspace", requireAuth, (req, res) => {
    const workspaceId = String(req.body?.workspaceId || "");
    const ctx = getUserContext(req);
    const workspace = ctx.workspaces.find((w) => w.id === workspaceId);
    if (!workspace) {
      return res.status(404).json({ ok: false, message: "Workspace not found" });
    }
    req.session.currentWorkspaceId = workspace.id;
    const workspaceAccounts = accounts.filter((a) => a.workspaceId === workspace.id);
    req.session.currentAccountId = workspaceAccounts[0]?.id;
    res.json({
      ok: true,
      currentWorkspace: workspace,
      currentAccount: workspaceAccounts[0] || null,
    });
  });



  app.get("/api/saas/plans", (_req, res) => {
    res.json({
      ok: true,
      plans: [
        {
          name: "Starter",
          price: "$39",
          features: ["Scanner", "Basic analytics", "Paper accounts"],
        },
        {
          name: "Pro",
          price: "$99",
          features: ["Full scanner", "Portfolio risk dashboard", "Analytics and alerts"],
        },
        {
          name: "Elite",
          price: "$179",
          features: ["Paper autopilot", "Broker sync", "Execution analytics"],
        },
      ],
    });
  });

  app.get("/api/saas/dashboard-summary", requireAuth, (req, res) => {
    const ctx = getUserContext(req);
    const platform = ctx.currentAccount?.platform === "tastytrade" ? "Broker-linked" : "Paper-first";
    const mode = ctx.currentAccount?.mode || "manual";

    res.json({
      ok: true,
      systemReady: true,
      regime: "ELEVATED",
      vix: 26.7,
      riskPosture: mode === "paper_autopilot" ? "Systematic" : "Defensive",
      portfolioGoal: platform === "Paper-first" ? "Validation" : "Broker-connected growth",
    });
  });

  app.get("/api/saas/daily-picks", requireAuth, (req, res) => {
    const platform = getUserContext(req).currentAccount?.platform || "paper";
    res.json({
      ok: true,
      regime: "ELEVATED",
      vix: 26.7,
      portfolioGoal: platform === "paper" ? "Validate trade-set logic" : "Assist broker-linked workflow",
      picks: [
        {
          ticker: "GLD",
          spread: "365 / 364",
          delta: "0.10",
          otm: "9.7%",
          creditPct: "35%",
          score: 92,
          role: "Anchor",
          rationale: "Defensive anchor that reduces portfolio correlation and keeps distance wide in elevated volatility.",
       ,
          impact: buildImpactForTicker("GLD"),
        },
        {
          ticker: "QQQ",
          spread: "545 / 544",
          delta: "0.11",
          otm: "6.5%",
          creditPct: "33%",
          score: 88,
          role: "Stabilizer",
          rationale: "Liquid ETF stabilizer with acceptable delta and tighter execution profile than single-stock alternatives.",
       ,
          impact: buildImpactForTicker("QQQ"),
        },
        {
          ticker: "ORCL",
          spread: "130 / 129",
          delta: "0.15",
          otm: "11.6%",
          creditPct: "41%",
          score: 85,
          role: "Engine",
          rationale: "Selective single-name premium engine chosen only after correlation caps and risk admission checks pass.",
       ,
          impact: buildImpactForTicker("ORCL"),
        },
      ],
    });
  });

  app.get("/api/saas/onboarding-checklist", requireAuth, (req, res) => {
    const ctx = getUserContext(req);
    const hasPaper = ctx.accounts.some((a) => a.platform === "paper");
    const hasBroker = ctx.accounts.some((a) => a.platform === "tastytrade");

    res.json({
      ok: true,
      steps: [
        {
          id: "workspace",
          title: "Create workspace",
          description: "Organize V8 around a named workspace before adding multiple accounts.",
          complete: !!ctx.currentWorkspace,
        },
        {
          id: "paper",
          title: "Create paper account",
          description: "Start with paper validation before connecting any broker.",
          complete: hasPaper,
        },
        {
          id: "scanner",
          title: "Review scanner and picks",
          description: "Use the Picks page to validate the trade-set logic and portfolio fit scoring.",
          complete: true,
        },
        {
          id: "broker",
          title: "Connect Tastytrade later",
          description: "Tastytrade is the first supported broker once paper workflow is stable.",
          complete: hasBroker,
        },
      ],
    });
  });

  app.get("/api/saas/analytics-summary", requireAuth, (_req, res) => {
    res.json({
      ok: true,
      winRate: "81%",
      profitFactor: "2.4",
      avgFillQuality: "+0.8%",
      maxDrawdown: "-6.1%",
      byEngine: [
        { name: "CORE", value: "+14.2%" },
        { name: "BOOST", value: "+8.9%" },
      ],
      byRegime: [
        { name: "NORMAL", value: "+11.4%" },
        { name: "ELEVATED", value: "+9.7%" },
        { name: "PANIC", value: "Throttle / low participation" },
      ],
    });
  });


app.get("/api/saas/risk-cockpit", requireAuth, (req, res) => {
  const ctx = getUserContext(req);
  const platform = ctx.currentAccount?.platform === "tastytrade" ? "tastytrade" : "paper";
  const mode = ctx.currentAccount?.mode || "manual";
  res.json({ ok: true, cockpit: buildRiskCockpit(platform, mode) });
});

app.get("/api/saas/concentration-warnings", requireAuth, (req, res) => {
  const ctx = getUserContext(req);
  const platform = ctx.currentAccount?.platform === "tastytrade" ? "tastytrade" : "paper";
  const mode = ctx.currentAccount?.mode || "manual";
  const cockpit = buildRiskCockpit(platform, mode);
  res.json({ ok: true, warnings: cockpit.warnings });
});

app.get("/api/saas/snapshots", requireAuth, (req, res) => {
  const ctx = getUserContext(req);
  const platform = ctx.currentAccount?.platform === "tastytrade" ? "tastytrade" : "paper";
  const mode = ctx.currentAccount?.mode || "manual";
  const cockpit = buildRiskCockpit(platform, mode);
  res.json({ ok: true, snapshots: cockpit.snapshots, sourceSummary: cockpit.sourceSummary });
});

app.post("/api/saas/portfolio-impact", requireAuth, (req, res) => {
  const ticker = String(req.body?.ticker || "");
  res.json({ ok: true, impact: buildImpactForTicker(ticker) });
});

  app.get("/api/saas/platforms", (_req, res) => {
    res.json({
      ok: true,
      platforms: [
        {
          id: "paper",
          name: "Paper Account",
          status: "supported",
          readOnlySync: false,
          assistedExecution: false,
          paperAutopilotCompatible: true,
          liveAutopilotCompatible: false,
        },
        {
          id: "tastytrade",
          name: "Tastytrade",
          status: "supported",
          readOnlySync: true,
          assistedExecution: true,
          paperAutopilotCompatible: true,
          liveAutopilotCompatible: false,
        },
        {
          id: "ibkr",
          name: "Interactive Brokers",
          status: "coming_soon",
          readOnlySync: false,
          assistedExecution: false,
          paperAutopilotCompatible: false,
          liveAutopilotCompatible: false,
        },
        {
          id: "tradier",
          name: "Tradier",
          status: "coming_soon",
          readOnlySync: false,
          assistedExecution: false,
          paperAutopilotCompatible: false,
          liveAutopilotCompatible: false,
        },
      ],
    });
  });
}
