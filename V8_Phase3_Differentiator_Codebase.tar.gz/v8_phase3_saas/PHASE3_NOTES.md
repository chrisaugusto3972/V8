
# Phase 3 Notes

This package implements the Phase 3 differentiator layer from the V8 SaaS build plan.

Included:
- Risk Cockpit page
- portfolio concentration warnings
- pre-trade portfolio impact data for daily picks
- snapshot trend endpoint and UI
- new SaaS endpoints:
  - `/api/saas/risk-cockpit`
  - `/api/saas/concentration-warnings`
  - `/api/saas/snapshots`
  - `/api/saas/portfolio-impact`

This phase is focused on V8's moat:
- portfolio intelligence
- pre-trade impact awareness
- risk communication that feels institutional
