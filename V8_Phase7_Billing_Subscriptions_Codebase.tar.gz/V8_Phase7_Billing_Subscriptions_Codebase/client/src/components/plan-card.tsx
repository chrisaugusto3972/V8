import React from "react";

type PlanCardProps = {
  name: string;
  price: string;
  features: string[];
  highlighted?: boolean;
};

export default function PlanCard({
  name,
  price,
  features,
  highlighted = false,
}: PlanCardProps) {
  return (
    <div
      className={[
        "rounded-3xl border p-6",
        highlighted
          ? "border-emerald-700/40 bg-emerald-900/10 shadow-[0_0_0_1px_rgba(16,185,129,0.08)]"
          : "border-slate-800 bg-slate-900/60",
      ].join(" ")}
    >
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-xl font-semibold text-white">{name}</div>
          <div className="mt-2 text-3xl font-bold text-white">{price}</div>
        </div>
        {highlighted ? (
          <div className="rounded-full border border-emerald-700/40 bg-emerald-900/20 px-3 py-1 text-xs text-emerald-300">
            Current
          </div>
        ) : null}
      </div>

      <ul className="mt-6 space-y-3">
        {features.map((feature) => (
          <li key={feature} className="text-sm text-slate-300">
            • {feature}
          </li>
        ))}
      </ul>

      <button className="mt-6 w-full rounded-xl bg-slate-100 px-4 py-3 text-sm font-medium text-slate-950 hover:bg-white">
        {highlighted ? "Manage Plan" : "Choose Plan"}
      </button>
    </div>
  );
}
