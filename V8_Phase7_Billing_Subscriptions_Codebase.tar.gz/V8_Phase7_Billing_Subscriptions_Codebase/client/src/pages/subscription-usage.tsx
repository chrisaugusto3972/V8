import React from "react";

export default function SubscriptionUsagePage() {
  const entitlements = [
    ["Accounts Used", "2 / 3"],
    ["Full Analytics", "Enabled"],
    ["Autopilot", "Not included in Pro"],
    ["Broker Sync", "Not included in Pro"],
    ["Execution Analytics", "Enabled"],
    ["Notifications", "Enabled"],
  ] as const;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-6">
      <div className="mx-auto max-w-5xl">
        <div className="mb-6 rounded-3xl border border-slate-800 bg-gradient-to-br from-slate-900 to-slate-950 p-6">
          <div className="text-xs uppercase tracking-[0.2em] text-slate-400">Phase 7</div>
          <h1 className="mt-2 text-3xl font-semibold text-white">Subscription Usage</h1>
          <p className="mt-2 max-w-3xl text-sm text-slate-300">
            Review current plan entitlements, usage limits, and which premium features are available in your workspace.
          </p>
        </div>

        <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5">
          <div className="space-y-4">
            {entitlements.map(([label, value]) => (
              <div
                key={label}
                className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-950/40 px-4 py-3"
              >
                <div className="text-sm text-slate-200">{label}</div>
                <div className="text-sm font-medium text-white">{value}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
