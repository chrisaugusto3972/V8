import React from "react";
import PlanCard from "../components/plan-card";

export default function BillingCenterPage() {
  const plans = [
    {
      name: "Starter",
      price: "$39/mo",
      features: [
        "Daily scanner",
        "Basic picks review",
        "Limited analytics",
        "Paper account support",
        "Email summaries",
      ],
      highlighted: false,
    },
    {
      name: "Pro",
      price: "$99/mo",
      features: [
        "Full scanner",
        "Portfolio risk cockpit",
        "Full analytics",
        "Trade set optimization",
        "Advanced alerts",
      ],
      highlighted: true,
    },
    {
      name: "Elite",
      price: "$179/mo",
      features: [
        "Paper autopilot",
        "Broker sync",
        "Execution intelligence",
        "Advanced controls",
        "Multi-account support",
      ],
      highlighted: false,
    },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-6">
      <div className="mx-auto max-w-7xl">
        <div className="mb-6 rounded-3xl border border-slate-800 bg-gradient-to-br from-slate-900 to-slate-950 p-6">
          <div className="text-xs uppercase tracking-[0.2em] text-slate-400">Phase 7</div>
          <h1 className="mt-2 text-3xl font-semibold text-white">Billing Center</h1>
          <p className="mt-2 max-w-3xl text-sm text-slate-300">
            Manage plans, feature access, account limits, and subscription upgrades for your V8 workspace.
          </p>
        </div>

        <div className="mb-6 grid gap-4 md:grid-cols-3">
          <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4">
            <div className="text-xs uppercase tracking-[0.18em] text-slate-400">Current Plan</div>
            <div className="mt-2 text-2xl font-semibold text-white">Pro</div>
          </div>
          <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4">
            <div className="text-xs uppercase tracking-[0.18em] text-slate-400">Billing Cycle</div>
            <div className="mt-2 text-2xl font-semibold text-white">Monthly</div>
          </div>
          <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4">
            <div className="text-xs uppercase tracking-[0.18em] text-slate-400">Renews In</div>
            <div className="mt-2 text-2xl font-semibold text-white">22 days</div>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {plans.map((plan) => (
            <PlanCard
              key={plan.name}
              name={plan.name}
              price={plan.price}
              features={plan.features}
              highlighted={plan.highlighted}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
