import { getPlanByCode, type PlanCode } from "./plans";

export type AccountMode = "paper" | "assisted" | "live";

export type EntitlementCheckInput = {
  planCode: PlanCode;
  feature:
    | "analytics_full"
    | "autopilot"
    | "broker_sync"
    | "execution_analytics"
    | "notifications"
    | "live_mode";
  accountMode?: AccountMode;
};

export function hasEntitlement(input: EntitlementCheckInput): boolean {
  const plan = getPlanByCode(input.planCode);

  switch (input.feature) {
    case "analytics_full":
      return plan.limits.analyticsAccess === "full";
    case "autopilot":
      return plan.limits.autopilot;
    case "broker_sync":
      return plan.limits.brokerSync;
    case "execution_analytics":
      return plan.limits.executionAnalytics;
    case "notifications":
      return plan.limits.notifications;
    case "live_mode":
      return plan.code === "elite" && input.accountMode !== "paper";
    default:
      return false;
  }
}

export function getUsageGuard(planCode: PlanCode, accountCount: number) {
  const plan = getPlanByCode(planCode);
  return {
    maxAccounts: plan.limits.maxAccounts,
    accountCount,
    canCreateAnotherAccount: accountCount < plan.limits.maxAccounts,
  };
}
