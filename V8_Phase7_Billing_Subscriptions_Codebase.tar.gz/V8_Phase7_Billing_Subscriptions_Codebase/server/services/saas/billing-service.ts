import { SAAS_PLANS, getPlanByCode, type PlanCode } from "./plans";

export type SubscriptionStatus = "trialing" | "active" | "past_due" | "canceled";

export type SubscriptionRecord = {
  workspaceId: string;
  planCode: PlanCode;
  status: SubscriptionStatus;
  billingCycle: "monthly" | "yearly";
  currentPeriodEnd: string;
};

export function listPlans() {
  return SAAS_PLANS;
}

export function getCurrentSubscription(): SubscriptionRecord {
  return {
    workspaceId: "default-workspace",
    planCode: "pro",
    status: "active",
    billingCycle: "monthly",
    currentPeriodEnd: new Date(Date.now() + 1000 * 60 * 60 * 24 * 22).toISOString(),
  };
}

export function previewPlanChange(nextPlanCode: PlanCode, billingCycle: "monthly" | "yearly") {
  const plan = getPlanByCode(nextPlanCode);
  return {
    nextPlanCode,
    billingCycle,
    amount: billingCycle === "monthly" ? plan.monthlyPrice : plan.yearlyPrice,
    effectiveImmediately: true,
  };
}

export function createCheckoutSession(nextPlanCode: PlanCode, billingCycle: "monthly" | "yearly") {
  const preview = previewPlanChange(nextPlanCode, billingCycle);
  return {
    checkoutUrl: `/billing/checkout?plan=${preview.nextPlanCode}&cycle=${preview.billingCycle}`,
    preview,
  };
}
