export type PlanCode = "starter" | "pro" | "elite";

export type SaaSPlan = {
  code: PlanCode;
  name: string;
  monthlyPrice: number;
  yearlyPrice: number;
  features: string[];
  limits: {
    maxAccounts: number;
    analyticsAccess: "limited" | "full";
    autopilot: boolean;
    brokerSync: boolean;
    executionAnalytics: boolean;
    notifications: boolean;
    paperOnly: boolean;
  };
};

export const SAAS_PLANS: SaaSPlan[] = [
  {
    code: "starter",
    name: "Starter",
    monthlyPrice: 39,
    yearlyPrice: 390,
    features: [
      "Daily scanner",
      "Basic picks review",
      "Limited analytics",
      "Paper account support",
      "Email summaries",
    ],
    limits: {
      maxAccounts: 1,
      analyticsAccess: "limited",
      autopilot: false,
      brokerSync: false,
      executionAnalytics: false,
      notifications: true,
      paperOnly: true,
    },
  },
  {
    code: "pro",
    name: "Pro",
    monthlyPrice: 99,
    yearlyPrice: 990,
    features: [
      "Full scanner",
      "Portfolio risk cockpit",
      "Full analytics",
      "Trade set optimization",
      "Advanced alerts",
    ],
    limits: {
      maxAccounts: 3,
      analyticsAccess: "full",
      autopilot: false,
      brokerSync: false,
      executionAnalytics: true,
      notifications: true,
      paperOnly: false,
    },
  },
  {
    code: "elite",
    name: "Elite",
    monthlyPrice: 179,
    yearlyPrice: 1790,
    features: [
      "Paper autopilot",
      "Broker sync",
      "Execution intelligence",
      "Advanced controls",
      "Multi-account support",
    ],
    limits: {
      maxAccounts: 10,
      analyticsAccess: "full",
      autopilot: true,
      brokerSync: true,
      executionAnalytics: true,
      notifications: true,
      paperOnly: false,
    },
  },
];

export function getPlanByCode(code: string | null | undefined): SaaSPlan {
  return SAAS_PLANS.find((p) => p.code === code) ?? SAAS_PLANS[0];
}
