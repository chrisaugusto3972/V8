import { Router } from "express";
import { createCheckoutSession, getCurrentSubscription, listPlans, previewPlanChange } from "../services/saas/billing-service";
import { getUsageGuard, hasEntitlement } from "../services/saas/entitlements";

const router = Router();

router.get("/api/billing/plans", async (_req, res) => {
  res.json({
    ok: true,
    plans: listPlans(),
  });
});

router.get("/api/billing/subscription", async (_req, res) => {
  const subscription = getCurrentSubscription();
  res.json({
    ok: true,
    subscription,
    usage: getUsageGuard(subscription.planCode, 2),
    entitlements: {
      analyticsFull: hasEntitlement({ planCode: subscription.planCode, feature: "analytics_full" }),
      autopilot: hasEntitlement({ planCode: subscription.planCode, feature: "autopilot" }),
      brokerSync: hasEntitlement({ planCode: subscription.planCode, feature: "broker_sync" }),
      executionAnalytics: hasEntitlement({ planCode: subscription.planCode, feature: "execution_analytics" }),
      notifications: hasEntitlement({ planCode: subscription.planCode, feature: "notifications" }),
    },
  });
});

router.post("/api/billing/preview-change", async (req, res) => {
  const planCode = req.body?.planCode;
  const billingCycle = req.body?.billingCycle ?? "monthly";
  res.json({
    ok: true,
    preview: previewPlanChange(planCode, billingCycle),
  });
});

router.post("/api/billing/checkout", async (req, res) => {
  const planCode = req.body?.planCode;
  const billingCycle = req.body?.billingCycle ?? "monthly";
  res.json({
    ok: true,
    session: createCheckoutSession(planCode, billingCycle),
  });
});

export default router;
