# V8 Phase 7 — Billing + Subscription Enforcement Codebase

This package contains the Phase 7 billing and subscription-enforcement layer for V8 SaaS.

## Focus
- subscription plan model
- entitlement checks
- billing service scaffolding
- billing routes
- billing page UI
- feature-gating helpers
- upgrade / downgrade workflow scaffolding

## Included
- `server/services/saas/plans.ts`
- `server/services/saas/entitlements.ts`
- `server/services/saas/billing-service.ts`
- `server/routes/billing.ts`
- `client/src/components/plan-card.tsx`
- `client/src/pages/billing-center.tsx`
- `client/src/pages/subscription-usage.tsx`
