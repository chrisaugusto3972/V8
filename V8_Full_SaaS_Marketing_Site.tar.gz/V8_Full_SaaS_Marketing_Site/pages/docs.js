import Layout from '../components/Layout'

export default function Docs() {
  return (
    <Layout>
      <section className="section">
        <div className="container">
          <h2>Docs</h2>
          <p className="sub">Setup guides, broker compatibility, plan comparisons, and onboarding materials live here.</p>
          <div className="faq">
            <div className="faq-item"><strong>How do I start?</strong><div style={{marginTop:8,color:'#94a3b8'}}>Create a workspace, start in Paper Mode, review the dashboard, and inspect your first daily picks.</div></div>
            <div className="faq-item"><strong>Which brokers are supported?</strong><div style={{marginTop:8,color:'#94a3b8'}}>Paper Account and Tastytrade first, with additional brokers added through a controlled compatibility list.</div></div>
          </div>
        </div>
      </section>
    </Layout>
  )
}
