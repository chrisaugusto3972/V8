import Link from 'next/link'
import Layout from '../components/Layout'

export default function Home() {
  return (
    <Layout>
      <div className="hero">
        <div className="container hero-grid">
          <div>
            <div className="eyebrow">Scanner + Risk + Autopilot</div>
            <h1>Find better options trades and stop building fragile portfolios.</h1>
            <p className="lead">
              V8 combines regime-aware scanning, portfolio impact analysis, execution intelligence,
              and paper-first autopilot workflows so traders can act with more structure and less guesswork.
            </p>
            <div className="hero-actions">
              <Link href="/signup" className="btn">Start Free in Paper Mode</Link>
              <Link href="/product" className="btn secondary">See the Product</Link>
            </div>
            <div className="hero-points">
              <div className="mini-card">
                <div className="mini-label">Core Promise</div>
                <div className="mini-value">Better trades</div>
              </div>
              <div className="mini-card">
                <div className="mini-label">Moat</div>
                <div className="mini-value">Portfolio impact</div>
              </div>
              <div className="mini-card">
                <div className="mini-label">Launch Path</div>
                <div className="mini-value">Paper first</div>
              </div>
            </div>
          </div>

          <div className="mock">
            <div className="mock-top">
              <span className="dot"></span><span className="dot"></span><span className="dot"></span>
            </div>
            <div className="mock-grid">
              <div className="metric">
                <div className="mini-label">Today's picks</div>
                <div className="big">3</div>
              </div>
              <div className="metric">
                <div className="mini-label">Regime</div>
                <div className="big">Elevated</div>
              </div>
              <div className="metric">
                <div className="mini-label">Portfolio delta</div>
                <div className="big">+0.42</div>
              </div>
              <div className="metric">
                <div className="mini-label">Theta/day</div>
                <div className="big">$18</div>
              </div>
            </div>

            <div className="ui-shot">
              <div className="mini-label">Portfolio impact before entry</div>
              <div style={{marginTop:10,fontWeight:800}}>TSLA raises high-beta exposure → warning</div>
              <div className="bar"><span style={{width:'72%'}}></span></div>
              <div style={{marginTop:12,fontWeight:800}}>GLD lowers concentration risk → favorable</div>
              <div className="bar"><span style={{width:'38%'}}></span></div>
            </div>
          </div>
        </div>
      </div>

      <section className="section">
        <div className="container">
          <h2>Built to answer the question most trading tools ignore.</h2>
          <p className="sub">
            Is this a good trade is not enough. V8 helps answer whether it is a good trade for your current portfolio, in this market regime, right now.
          </p>
          <div className="cards3">
            <div className="feature">
              <h3>Selection intelligence</h3>
              <p>Choose the best set of trades instead of just the highest individual score.</p>
              <ul>
                <li>trade set optimization</li>
                <li>correlation-aware selection</li>
                <li>defensive anchor + stabilizer logic</li>
              </ul>
            </div>
            <div className="feature">
              <h3>Portfolio risk cockpit</h3>
              <p>See exposure before you add risk, not after the damage is done.</p>
              <ul>
                <li>delta, theta, stress</li>
                <li>sector and ticker concentration</li>
                <li>pre-trade impact analysis</li>
              </ul>
            </div>
            <div className="feature">
              <h3>Execution intelligence</h3>
              <p>Reduce fill leakage and track whether your automation is actually executing well.</p>
              <ul>
                <li>adaptive order policies</li>
                <li>fill quality analytics</li>
                <li>entry vs exit performance</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <h2>What the product looks like</h2>
          <p className="sub">Designed like a real SaaS platform — clean, explainable, and built for trader trust.</p>
          <div className="ui-grid">
            <div className="ui-card">
              <div className="ui-title">Scanner</div>
              <div className="ui-shot">Ranked candidates, rejection breakdowns, portfolio fit score, and selected trade set.</div>
            </div>
            <div className="ui-card">
              <div className="ui-title">Risk cockpit</div>
              <div className="ui-shot">Net delta, theta, directional lean, concentration warnings, and stress scenarios.</div>
            </div>
            <div className="ui-card">
              <div className="ui-title">Autopilot</div>
              <div className="ui-shot">Assisted mode, paper mode, broker compatibility, readiness state, and approval-needed flows.</div>
            </div>
            <div className="ui-card">
              <div className="ui-title">Execution intelligence</div>
              <div className="ui-shot">Fill quality, reprices, time to fill, and policy-aware order handling.</div>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <h2>Simple pricing that maps to real usage</h2>
          <p className="sub">Start in paper mode, grow into analytics, then unlock automation when you're ready.</p>
          <div className="pricing">
            <div className="plan">
              <h3>Starter</h3>
              <div className="price">$39<span className="per">/mo</span></div>
              <ul>
                <li>daily scanner</li>
                <li>basic picks review</li>
                <li>paper account support</li>
                <li>email summaries</li>
              </ul>
              <Link href="/signup" className="btn" style={{marginTop:18}}>Start Free</Link>
            </div>
            <div className="plan popular">
              <div className="badge">Most Popular</div>
              <h3>Pro</h3>
              <div className="price">$99<span className="per">/mo</span></div>
              <ul>
                <li>full scanner</li>
                <li>risk cockpit</li>
                <li>full analytics</li>
                <li>execution intelligence</li>
              </ul>
              <Link href="/signup" className="btn" style={{marginTop:18}}>Choose Pro</Link>
            </div>
            <div className="plan">
              <h3>Elite</h3>
              <div className="price">$179<span className="per">/mo</span></div>
              <ul>
                <li>paper autopilot</li>
                <li>broker sync</li>
                <li>advanced controls</li>
                <li>multi-account support</li>
              </ul>
              <Link href="/signup" className="btn" style={{marginTop:18}}>Choose Elite</Link>
            </div>
          </div>
        </div>
      </section>

      <section className="cta">
        <div className="container">
          <div className="cta-box">
            <h2 style={{marginTop:0}}>Start with a safer workflow.</h2>
            <p className="sub" style={{maxWidth:760}}>
              Create a paper account, review daily picks, inspect portfolio impact, and see whether V8 fits the way you trade before you risk capital.
            </p>
            <div className="hero-actions">
              <Link href="/signup" className="btn">Start Free in Paper Mode</Link>
              <Link href="/pricing" className="btn secondary">View Pricing</Link>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  )
}
