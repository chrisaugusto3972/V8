import Layout from '../components/Layout'
import Link from 'next/link'

export default function Pricing() {
  return (
    <Layout>
      <section className="section">
        <div className="container">
          <h2>Pricing</h2>
          <p className="sub">Choose the level of intelligence and automation that matches where you are now.</p>
          <div className="pricing">
            <div className="plan">
              <h3>Starter</h3>
              <div className="price">$39<span className="per">/mo</span></div>
              <ul><li>Daily scanner</li><li>Basic picks review</li><li>Paper account support</li><li>Email summaries</li></ul>
              <Link href="/signup" className="btn" style={{marginTop:18}}>Start Free</Link>
            </div>
            <div className="plan popular">
              <div className="badge">Best Value</div>
              <h3>Pro</h3>
              <div className="price">$99<span className="per">/mo</span></div>
              <ul><li>Full scanner</li><li>Risk cockpit</li><li>Full analytics</li><li>Execution intelligence</li></ul>
              <Link href="/signup" className="btn" style={{marginTop:18}}>Choose Pro</Link>
            </div>
            <div className="plan">
              <h3>Elite</h3>
              <div className="price">$179<span className="per">/mo</span></div>
              <ul><li>Paper autopilot</li><li>Broker sync</li><li>Advanced controls</li><li>Multi-account support</li></ul>
              <Link href="/signup" className="btn" style={{marginTop:18}}>Choose Elite</Link>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  )
}
