import Layout from '../components/Layout'
import Link from 'next/link'

export default function Login() {
  return (
    <Layout>
      <section className="section">
        <div className="container" style={{maxWidth:560}}>
          <div className="plan">
            <h3>Login</h3>
            <p className="sub" style={{fontSize:16}}>Access your workspace, scanner, and portfolio analytics.</p>
            <div style={{display:'grid',gap:14,marginTop:18}}>
              <input placeholder="Email" />
              <input placeholder="Password" type="password" />
              <button className="btn">Login</button>
            </div>
            <div style={{marginTop:16,color:'#94a3b8'}}>New to V8? <Link href="/signup">Create your account</Link></div>
          </div>
        </div>
      </section>
    </Layout>
  )
}
