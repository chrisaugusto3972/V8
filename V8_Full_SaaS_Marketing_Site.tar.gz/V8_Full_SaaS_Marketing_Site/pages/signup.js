import Layout from '../components/Layout'

export default function Signup() {
  return (
    <Layout>
      <section className="section">
        <div className="container" style={{maxWidth:760}}>
          <div className="plan">
            <h3>Start free in Paper Mode</h3>
            <p className="sub" style={{fontSize:16}}>Create your workspace and begin with a safer onboarding path before connecting a broker.</p>
            <div style={{display:'grid',gap:14,marginTop:18}}>
              <input placeholder="Full name" />
              <input placeholder="Email" />
              <input placeholder="Password" type="password" />
              <select>
                <option>Paper Account</option>
                <option>Tastytrade</option>
              </select>
              <button className="btn">Create Workspace</button>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  )
}
