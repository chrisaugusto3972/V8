import Layout from '../components/Layout'

export default function Product() {
  return (
    <Layout>
      <section className="section">
        <div className="container">
          <h2>The product</h2>
          <p className="sub">V8 is designed as an options intelligence platform, not just another signal feed or toy bot builder.</p>
          <div className="cards3">
            <div className="feature"><h3>Scanner engine</h3><p>Daily ranked candidates with rejection breakdowns and portfolio fit context.</p></div>
            <div className="feature"><h3>Portfolio impact</h3><p>See concentration, delta, theta, and stress changes before adding a trade.</p></div>
            <div className="feature"><h3>Autopilot workflows</h3><p>Assisted and paper-first automation with supported broker compatibility gates.</p></div>
          </div>
        </div>
      </section>
    </Layout>
  )
}
