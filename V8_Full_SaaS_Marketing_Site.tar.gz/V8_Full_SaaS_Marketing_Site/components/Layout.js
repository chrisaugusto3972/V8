import Link from 'next/link'

export default function Layout({children}) {
  return (
    <>
      <div className="nav">
        <div className="container nav-inner">
          <div className="brand">V8</div>
          <div className="nav-links">
            <Link href="/">Home</Link>
            <Link href="/pricing">Pricing</Link>
            <Link href="/product">Product</Link>
            <Link href="/docs">Docs</Link>
            <Link href="/login">Login</Link>
            <Link href="/signup" className="btn">Start Free</Link>
          </div>
        </div>
      </div>
      {children}
      <div className="footer">
        <div className="container">
          V8 — institutional-style options intelligence for self-directed traders.
        </div>
      </div>
    </>
  )
}
