import { Link } from "wouter";
import { PageHero } from "@/components/page-hero";
import { StatCard } from "@/components/stat-card";
import { SectionCard } from "@/components/section-card";
import { StatusBadge } from "@/components/status-badge";
import { useAuth } from "@/hooks/use-auth";
import { useDashboardSummary, useDailyPicks } from "@/hooks/use-saas";

export default function DashboardPage() {
  const { data: auth } = useAuth();
  const { data } = useDashboardSummary();
  const { data: picksData } = useDailyPicks();

  return (
    <>
      <PageHero
        eyebrow="Phase 2"
        title="V8 SaaS Product Core"
        description="This phase turns the foundation into a real subscription product experience: a cleaner dashboard, first-class picks review, analytics visibility, and a more credible paper-first onboarding path."
        actions={<StatusBadge tone={data?.systemReady ? "success" : "warning"}>{data?.systemReady ? "System Ready" : "Needs Setup"}</StatusBadge>}
      />

      <div className="grid gap-4 md:grid-cols-4 mb-6">
        <StatCard label="Workspace" value={auth?.currentWorkspace?.name || "—"} hint="Active workspace" />
        <StatCard label="Account" value={auth?.currentAccount?.name || "—"} hint={`${auth?.currentAccount?.platform || "paper"} • ${auth?.currentAccount?.mode || "manual"}`} />
        <StatCard label="Top Picks" value={picksData?.picks?.length || 0} hint="Today's selected trade set" />
        <StatCard label="Portfolio Goal" value={data?.portfolioGoal || "Balance"} hint="Current product profile" />
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.1fr,0.9fr]">
        <SectionCard title="Today's Command Center" subtitle="What a subscriber should understand in 10 seconds">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4">
              <div className="text-sm text-slate-400">Current regime</div>
              <div className="mt-2 text-2xl font-semibold text-white">{data?.regime || "HIGH VOL"}</div>
              <div className="mt-1 text-sm text-slate-300">VIX {data?.vix || "26.7"}</div>
            </div>
            <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4">
              <div className="text-sm text-slate-400">Risk posture</div>
              <div className="mt-2 text-2xl font-semibold text-white">{data?.riskPosture || "Defensive"}</div>
              <div className="mt-1 text-sm text-slate-300">Portfolio-aware admission active</div>
            </div>
            <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4">
              <div className="text-sm text-slate-400">Paper-first status</div>
              <div className="mt-2 text-2xl font-semibold text-white">{auth?.currentAccount?.platform === "paper" ? "Enabled" : "Broker-linked"}</div>
              <div className="mt-1 text-sm text-slate-300">Start in paper, expand to broker sync later</div>
            </div>
            <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4">
              <div className="text-sm text-slate-400">Next milestone</div>
              <div className="mt-2 text-2xl font-semibold text-white">Tastytrade</div>
              <div className="mt-1 text-sm text-slate-300">Read-only sync then assisted execution</div>
            </div>
          </div>
        </SectionCard>

        <SectionCard title="Next Best Actions" subtitle="Guide the user to the most important subscription flows">
          <div className="space-y-3 text-sm">
            <Link href="/onboarding"><a className="block rounded-lg border border-slate-800 px-4 py-3 hover:bg-slate-900">Complete onboarding checklist</a></Link>
            <Link href="/picks"><a className="block rounded-lg border border-slate-800 px-4 py-3 hover:bg-slate-900">Review today's pick set</a></Link>
            <Link href="/greeks"><a className="block rounded-lg border border-slate-800 px-4 py-3 hover:bg-slate-900">Check portfolio risk cockpit</a></Link>
            <Link href="/platforms"><a className="block rounded-lg border border-slate-800 px-4 py-3 hover:bg-slate-900">Review supported trading platforms</a></Link>
            <Link href="/analytics"><a className="block rounded-lg border border-slate-800 px-4 py-3 hover:bg-slate-900">Open analytics and retention dashboard</a></Link>
          </div>
        </SectionCard>
      </div>
    </>
  );
}
