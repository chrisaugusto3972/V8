# V8 Phase 6 — Notifications + Alerts Codebase

This package contains the Phase 6 notifications and alerts layer for V8 SaaS.

## Focus
- notification engine scaffolding
- in-app alerts center
- email digest scaffolding
- approval-needed and broker-warning event types
- notification settings page
- notification API route stubs

## Included
- `server/services/v8/notification-engine.ts`
- `server/services/v8/notification-templates.ts`
- `server/routes/notifications.ts`
- `client/src/components/alert-item.tsx`
- `client/src/pages/notifications-center.tsx`
- `client/src/pages/notification-settings.tsx`

This phase is designed to fit after:
- Phase 1 SaaS foundation
- Phase 2 product core
- Phase 3 differentiator
- Phase 4 broker layer
- Phase 5 execution intelligence
