import { renderNotificationBody, renderNotificationSubject, type NotificationTemplateType } from "./notification-templates";

export type NotificationSeverity = "info" | "warning" | "danger" | "success";

export type NotificationRecord = {
  id: string;
  type: NotificationTemplateType;
  severity: NotificationSeverity;
  title: string;
  message: string;
  channel: "in_app" | "email";
  createdAt: string;
  acknowledged: boolean;
  payload?: Record<string, any>;
};

function randomId() {
  return Math.random().toString(36).slice(2, 10);
}

export function createInAppNotification(
  type: NotificationTemplateType,
  severity: NotificationSeverity,
  payload: Record<string, any> = {},
): NotificationRecord {
  return {
    id: randomId(),
    type,
    severity,
    title: renderNotificationSubject(type),
    message: renderNotificationBody(type, payload),
    channel: "in_app",
    createdAt: new Date().toISOString(),
    acknowledged: false,
    payload,
  };
}

export function createEmailDigest(
  type: NotificationTemplateType,
  payload: Record<string, any> = {},
) {
  return {
    subject: renderNotificationSubject(type),
    body: renderNotificationBody(type, payload),
    payload,
  };
}

export function summarizeUnread(notifications: NotificationRecord[]) {
  return {
    unreadCount: notifications.filter((n) => !n.acknowledged).length,
    warningCount: notifications.filter((n) => !n.acknowledged && n.severity === "warning").length,
    dangerCount: notifications.filter((n) => !n.acknowledged && n.severity === "danger").length,
  };
}
