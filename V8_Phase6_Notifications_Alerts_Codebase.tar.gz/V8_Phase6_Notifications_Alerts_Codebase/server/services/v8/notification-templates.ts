export type NotificationTemplateType =
  | "daily_picks_digest"
  | "daily_risk_digest"
  | "fill_update"
  | "exit_update"
  | "approval_needed"
  | "broker_disconnect"
  | "autopilot_warning"
  | "concentration_warning";

export function renderNotificationSubject(type: NotificationTemplateType): string {
  switch (type) {
    case "daily_picks_digest":
      return "V8 Daily Picks Digest";
    case "daily_risk_digest":
      return "V8 Daily Risk Summary";
    case "fill_update":
      return "V8 Fill Update";
    case "exit_update":
      return "V8 Exit Update";
    case "approval_needed":
      return "V8 Approval Needed";
    case "broker_disconnect":
      return "V8 Broker Connection Warning";
    case "autopilot_warning":
      return "V8 Autopilot Warning";
    case "concentration_warning":
      return "V8 Portfolio Concentration Warning";
    default:
      return "V8 Notification";
  }
}

export function renderNotificationBody(
  type: NotificationTemplateType,
  payload: Record<string, any>,
): string {
  switch (type) {
    case "daily_picks_digest":
      return `Today's selected picks: ${(payload.picks ?? []).map((p: any) => p.ticker).join(", ") || "none"}.`;
    case "daily_risk_digest":
      return `Portfolio delta: ${payload.delta ?? "n/a"}, theta: ${payload.theta ?? "n/a"}, warnings: ${(payload.warnings ?? []).join(", ") || "none"}.`;
    case "fill_update":
      return `${payload.ticker ?? "Order"} filled at ${payload.fillPrice ?? "n/a"}.`;
    case "exit_update":
      return `${payload.ticker ?? "Position"} exit completed.`;
    case "approval_needed":
      return `Approval required for ${payload.ticker ?? "trade"} (${payload.reason ?? "review needed"}).`;
    case "broker_disconnect":
      return `Broker connection requires attention: ${payload.reason ?? "disconnected"}.`;
    case "autopilot_warning":
      return `Autopilot warning: ${payload.reason ?? "check system status"}.`;
    case "concentration_warning":
      return `Portfolio concentration warning: ${payload.reason ?? "exposure too high"}.`;
    default:
      return JSON.stringify(payload);
  }
}
