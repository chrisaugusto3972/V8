import { Router } from "express";
import { createEmailDigest, createInAppNotification, summarizeUnread } from "../services/v8/notification-engine";

const router = Router();

const mockNotifications = [
  createInAppNotification("approval_needed", "warning", {
    ticker: "SPY",
    reason: "trade requires approval in assisted mode",
  }),
  createInAppNotification("concentration_warning", "danger", {
    reason: "technology exposure exceeds configured threshold",
  }),
  createInAppNotification("fill_update", "success", {
    ticker: "QQQ",
    fillPrice: 0.46,
  }),
];

router.get("/api/notifications", async (_req, res) => {
  res.json({
    ok: true,
    notifications: mockNotifications,
    summary: summarizeUnread(mockNotifications),
  });
});

router.post("/api/notifications/acknowledge", async (req, res) => {
  const id = String(req.body?.id ?? "");
  const found = mockNotifications.find((n) => n.id === id);
  if (found) found.acknowledged = true;

  res.json({
    ok: true,
    acknowledgedId: id,
    summary: summarizeUnread(mockNotifications),
  });
});

router.get("/api/notifications/daily-picks-digest", async (_req, res) => {
  res.json({
    ok: true,
    digest: createEmailDigest("daily_picks_digest", {
      picks: [{ ticker: "GLD" }, { ticker: "QQQ" }, { ticker: "ORCL" }],
    }),
  });
});

router.get("/api/notifications/daily-risk-digest", async (_req, res) => {
  res.json({
    ok: true,
    digest: createEmailDigest("daily_risk_digest", {
      delta: 0.42,
      theta: 18.4,
      warnings: ["Technology concentration elevated"],
    }),
  });
});

router.get("/api/notification-settings", async (_req, res) => {
  res.json({
    ok: true,
    settings: {
      emailDailyPicks: true,
      emailDailyRisk: true,
      fillAlerts: true,
      exitAlerts: true,
      approvalAlerts: true,
      brokerAlerts: true,
      autopilotWarnings: true,
      concentrationWarnings: true,
    },
  });
});

export default router;
