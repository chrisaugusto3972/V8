import React from "react";
import AlertItem from "../components/alert-item";

export default function NotificationsCenterPage() {
  const mock = [
    {
      title: "Approval Needed",
      message: "SPY trade requires approval in assisted mode.",
      severity: "warning" as const,
      time: "2m ago",
    },
    {
      title: "Portfolio Concentration Warning",
      message: "Technology exposure exceeds configured threshold.",
      severity: "danger" as const,
      time: "6m ago",
    },
    {
      title: "Fill Update",
      message: "QQQ entry filled at 0.46.",
      severity: "success" as const,
      time: "18m ago",
    },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-6">
      <div className="mx-auto max-w-7xl">
        <div className="mb-6 rounded-3xl border border-slate-800 bg-gradient-to-br from-slate-900 to-slate-950 p-6">
          <div className="text-xs uppercase tracking-[0.2em] text-slate-400">Phase 6</div>
          <h1 className="mt-2 text-3xl font-semibold text-white">Notifications Center</h1>
          <p className="mt-2 max-w-3xl text-sm text-slate-300">
            Review in-app alerts for approvals, fills, exits, broker health, autopilot warnings, and concentration risks.
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4">
            <div className="text-xs uppercase tracking-[0.18em] text-slate-400">Unread</div>
            <div className="mt-2 text-2xl font-semibold text-white">3</div>
          </div>
          <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4">
            <div className="text-xs uppercase tracking-[0.18em] text-slate-400">Warnings</div>
            <div className="mt-2 text-2xl font-semibold text-amber-300">1</div>
          </div>
          <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4">
            <div className="text-xs uppercase tracking-[0.18em] text-slate-400">Critical</div>
            <div className="mt-2 text-2xl font-semibold text-rose-300">1</div>
          </div>
        </div>

        <div className="mt-6 space-y-4">
          {mock.map((n) => (
            <AlertItem
              key={`${n.title}-${n.time}`}
              title={n.title}
              message={n.message}
              severity={n.severity}
              time={n.time}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
