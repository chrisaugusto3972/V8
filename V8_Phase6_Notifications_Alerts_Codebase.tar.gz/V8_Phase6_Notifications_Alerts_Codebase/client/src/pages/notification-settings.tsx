import React from "react";

export default function NotificationSettingsPage() {
  const settings = [
    ["Daily picks email", true],
    ["Daily risk summary email", true],
    ["Fill alerts", true],
    ["Exit alerts", true],
    ["Approval-needed alerts", true],
    ["Broker connection alerts", true],
    ["Autopilot warnings", true],
    ["Concentration warnings", true],
  ] as const;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-6">
      <div className="mx-auto max-w-5xl">
        <div className="mb-6 rounded-3xl border border-slate-800 bg-gradient-to-br from-slate-900 to-slate-950 p-6">
          <div className="text-xs uppercase tracking-[0.2em] text-slate-400">Phase 6</div>
          <h1 className="mt-2 text-3xl font-semibold text-white">Notification Settings</h1>
          <p className="mt-2 max-w-3xl text-sm text-slate-300">
            Configure daily digests, in-app alerts, approval notifications, and broker / autopilot warnings.
          </p>
        </div>

        <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5">
          <div className="space-y-4">
            {settings.map(([label, enabled]) => (
              <div
                key={label}
                className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-950/40 px-4 py-3"
              >
                <div className="text-sm text-slate-200">{label}</div>
                <div
                  className={[
                    "rounded-full px-3 py-1 text-xs font-medium",
                    enabled
                      ? "bg-emerald-900/30 text-emerald-300 border border-emerald-700/40"
                      : "bg-slate-800 text-slate-300 border border-slate-700",
                  ].join(" ")}
                >
                  {enabled ? "Enabled" : "Disabled"}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
