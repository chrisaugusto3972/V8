import React from "react";

type AlertItemProps = {
  title: string;
  message: string;
  severity?: "info" | "warning" | "danger" | "success";
  time?: string;
};

export default function AlertItem({
  title,
  message,
  severity = "info",
  time,
}: AlertItemProps) {
  const tone =
    severity === "success"
      ? "border-emerald-700/40 bg-emerald-900/20 text-emerald-200"
      : severity === "warning"
        ? "border-amber-700/40 bg-amber-900/20 text-amber-200"
        : severity === "danger"
          ? "border-rose-700/40 bg-rose-900/20 text-rose-200"
          : "border-slate-700 bg-slate-900/60 text-slate-200";

  return (
    <div className={`rounded-2xl border p-4 ${tone}`}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="font-semibold">{title}</div>
          <div className="mt-1 text-sm opacity-90">{message}</div>
        </div>
        {time ? <div className="text-xs opacity-70">{time}</div> : null}
      </div>
    </div>
  );
}
