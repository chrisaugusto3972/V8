// This file is informational only.
// Autopilot routes are registered in server/autopilot-init.ts and server/index.ts.
