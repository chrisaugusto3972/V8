import { db } from "./db";
import { eq, inArray } from "drizzle-orm";
import { positions, journalEntries, scannerSettings } from "@shared/schema";

export async function seedDatabase() {
  const DEFAULT_TICKERS = "SPY,QQQ,IWM,DIA,EEM,EWZ,XLE,XLF,SMH,TLT,GLD,SLV,AAPL,MSFT,GOOGL,AMZN,META,TSLA,NVDA,JPM,BAC,WMT,DIS,NFLX,AMD,CRM,ORCL,INTC,COIN,PLTR,KO,PG,JNJ,PEP,MCD,XOM,CVX,GS,UNH,COST";

  const SAMPLE_JOURNAL_IDS = [
    "7928e9c5-25e3-43d2-a5b7-f14b11ebd277",
    "ed0002d8-161e-4cbe-9a32-fb158bf66ab4",
    "8e00c845-90cf-41f2-a471-e892d614bd61",
    "1a867388-63f7-4cf4-b8c6-90ce6eab7f5f",
    "13062b14-a020-4411-9348-6e9f34bac210",
    "f3c87e29-ec06-4f37-97d3-01d5ff46f873",
    "63050d52-a3de-4f09-9ddf-773b6013f243",
    "6380f14d-5690-4b52-a7be-075eac0d572e",
  ];
  const SAMPLE_POSITION_IDS = [
    "245b8f49-2861-48db-9534-73c0d387cc55",
    "2d6722c5-5127-4aca-8bdc-a1d593876d67",
    "b072bfd1-fdee-47aa-b8a5-812459cb0000",
  ];
  await db.delete(journalEntries).where(inArray(journalEntries.id, SAMPLE_JOURNAL_IDS));
  await db.delete(positions).where(inArray(positions.id, SAMPLE_POSITION_IDS));

  const existingSettings = await db.select().from(scannerSettings);
  if (existingSettings.length > 0) {
    const s = existingSettings[0];
    const updates: Record<string, any> = {};
    if (s.tickers === "SPY") updates.tickers = DEFAULT_TICKERS;
    if (s.accountSize === "standard") updates.accountSize = "micro";
    if (s.deltaRange === "0.16-0.25" || s.deltaRange === "0.18-0.25") updates.deltaRange = "0.15-0.25";
    if (s.dteRange === "30-45") updates.dteRange = "14-45";
    if (s.minCreditPct === 20) updates.minCreditPct = 12;
    if (s.minDistancePct === 5) updates.minDistancePct = 7;
    if (s.minOI === 100) updates.minOI = 25;
    if (s.maxSpread === 0.2 || s.maxSpread === 0.08 || s.maxSpread === 0.45) updates.maxSpread = 0.75;
    if (Object.keys(updates).length > 0) {
      await db.update(scannerSettings).set(updates).where(eq(scannerSettings.id, s.id));
    }
  }

  if (existingSettings.length === 0) {
    await db.insert(scannerSettings).values({
      tickers: DEFAULT_TICKERS,
      dteRange: "14-45",
      deltaRange: "0.15-0.25",
      accountSize: "micro",
      spreadWidth: 2,
      minCredit: 0.3,
      minCreditPct: 12,
      minDistancePct: 7,
      minOI: 25,
      minVolume: 0,
      maxSpread: 0.75,
      minIVPercentile: 25,
      maxResults: 20,
      refreshInterval: 5,
      notifyNewTrades: true,
      notifyProfitTargets: true,
      maxPositionSize: 5000,
      maxPortfolioRisk: 5,
      maxRiskPerTrade: 500,
      maxSlippageRatio: 1.5,
      vixLowThreshold: 15,
      vixHighThreshold: 25,
      useVixRegime: true,
    });
  }
}
