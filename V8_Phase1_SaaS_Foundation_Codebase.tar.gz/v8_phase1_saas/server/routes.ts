import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertPositionSchema, insertJournalEntrySchema, autopilotState, manualActions, systemEvents, orderIntents, portfolioSnapshots, executionAnalytics, positions, brokerOrders } from "@shared/schema";
import { TastytradeBroker } from "./brokers/tastytrade";
import { z } from "zod";
import { desc, gte, lte, and, eq } from "drizzle-orm";
import { db } from "./db";
import { calculateFillAnalyticsLookback } from "./services/v8/fill-analytics";
import { getSystemReadiness } from "./services/v8/diagnostics";
import { getOpenPositionsWithGreeks, computePortfolioGreeks } from "./services/v8/portfolio-greeks";
import { computePortfolioStressTest } from "./services/v8/portfolio-stress";
import { capturePortfolioSnapshot } from "./services/v8/portfolio-snapshots";
import { getExecutionQualitySummary } from "./services/v8/execution-analytics";
import { getMarketSnapshot } from "./services/v8/market-state";
import { DEFAULT_V8_SMALL_ACCOUNT_PRODUCTION } from "./services/v8/default-settings";
import { generatePerformanceFeedback } from "./services/v8/performance-feedback";
import { computeStrategyHealthFromHistory } from "./services/v8/strategy-health";
import { registerSaasFoundationRoutes } from "./saas-foundation";
import {
  cancelAllOrders,
  disableTicker,
  enableTicker,
  flattenAllPositions,
  getAppSettings,
  pauseAutopilot,
  resumeAutopilot,
  setAutopilotMode,
  setExitStrategyMode,
} from "./services/v8/operator-controls";

const closePositionSchema = z.object({
  exitPrice: z.number().positive(),
});

const updateSettingsSchema = z.object({
  tickers: z.string().optional(),
  dteRange: z.string().optional(),
  deltaRange: z.string().optional(),
  minCredit: z.number().min(0).optional(),
  maxSpread: z.number().min(0).optional(),
  maxResults: z.number().int().min(1).max(50).optional(),
  refreshInterval: z.number().int().min(1).optional(),
  notifyNewTrades: z.boolean().optional(),
  notifyProfitTargets: z.boolean().optional(),
  maxPositionSize: z.number().int().min(0).optional(),
  maxPortfolioRisk: z.number().int().min(1).max(100).optional(),
  accountSize: z.string().optional(),
  minCreditPct: z.number().min(0).max(100).optional(),
  minDistancePct: z.number().min(0).max(100).optional(),
  minOI: z.number().int().min(0).optional(),
  vixLowThreshold: z.number().min(0).optional(),
  vixHighThreshold: z.number().min(0).optional(),
  useVixRegime: z.boolean().optional(),
  maxRiskPerTrade: z.number().int().min(0).optional(),
  maxSlippageRatio: z.number().min(1).max(3).optional(),
  profileJson: z.string().optional(),
});

type Mode = "micro" | "standard" | "aggressive" | "v7" | "v8";

function getScannerBroker(): TastytradeBroker {
  return new TastytradeBroker();
}

// Ticker normalization for data providers that use dashes instead of dots.
// (Reduces noPrice failures for tickers like BRK.B, BF.B, etc.)
function normalizeTicker(raw: string): string {
  const map: Record<string, string> = {
    "BRK.B": "BRK-B",
    "BF.B": "BF-B",
  };
  const t = String(raw || "").toUpperCase().trim();
  return map[t] || t.replaceAll(".", "-");
}

type ScanRequest = {
  tickers?: Array<{ ticker: string; sector?: string }>;
  mode?: Mode;
  accountSize?: number;
  riskPerTradePct?: number;
  maxPortfolioRiskPct?: number;
  topNPerSector?: number;
  maxTradesTotal?: number;

  minDTE?: number;
  maxDTE?: number;
  deltaMin?: number;
  deltaMax?: number;

  microWidths?: number[];
  standardWidths?: number[];
  aggressiveWidths?: number[];

  minCreditPctWidth?: number;
  minDistancePct?: number;
  minOI?: number;
  maxLegBidAskAbs?: number;
  maxLegBidAskPctUnderlying?: number;
  maxLegBidAskPctPremium?: number; // (ask-bid)/ask
  minShortBid?: number;
  maxSlippageRatio?: number;

  // Regime controls (optional; if omitted, server defaults are used)
  useVixRegime?: boolean;
  vixLowThreshold?: number;
  vixHighThreshold?: number;

  // Micro realism / safety guards
  minLongAsk?: number;
  maxCreditPctWidth?: number;
};


const scanRequestSchema = z.object({
  tickers: z.array(z.object({
    ticker: z.string().min(1),
    sector: z.string().optional(),
  })).optional(),
  mode: z.enum(["micro", "standard", "aggressive", "v7", "v8"]).optional(),
  accountSize: z.number().positive().optional(),
  riskPerTradePct: z.number().positive().optional(),
  maxPortfolioRiskPct: z.number().positive().optional(),
  topNPerSector: z.number().int().min(1).optional(),
  maxTradesTotal: z.number().int().min(1).optional(),
  minDTE: z.number().int().min(0).optional(),
  maxDTE: z.number().int().min(0).optional(),
  deltaMin: z.number().min(0).max(1).optional(),
  deltaMax: z.number().min(0).max(1).optional(),
  microWidths: z.array(z.number().positive()).optional(),
  standardWidths: z.array(z.number().positive()).optional(),
  aggressiveWidths: z.array(z.number().positive()).optional(),
  minCreditPctWidth: z.number().min(0).max(1).optional(),
  minDistancePct: z.number().min(0).max(1).optional(),
  minOI: z.number().int().min(0).optional(),
  maxLegBidAskAbs: z.number().min(0).optional(),
  maxLegBidAskPctUnderlying: z.number().min(0).max(1).optional(),
  maxLegBidAskPctPremium: z.number().min(0).max(10).optional(),
  minShortBid: z.number().min(0).optional(),
  maxSlippageRatio: z.number().min(1).max(5).optional(),
  useVixRegime: z.boolean().optional(),
  vixLowThreshold: z.number().min(0).optional(),
  vixHighThreshold: z.number().min(0).optional(),
  minLongAsk: z.number().min(0).optional(),
  maxCreditPctWidth: z.number().min(0).max(1).optional(),
}).superRefine((v, ctx) => {
  if (v.minDTE !== undefined && v.maxDTE !== undefined && v.minDTE > v.maxDTE) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, message: "minDTE cannot exceed maxDTE", path: ["minDTE"] });
  }
  if (v.deltaMin !== undefined && v.deltaMax !== undefined && v.deltaMin > v.deltaMax) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, message: "deltaMin cannot exceed deltaMax", path: ["deltaMin"] });
  }
  if (v.vixLowThreshold !== undefined && v.vixHighThreshold !== undefined && v.vixLowThreshold >= v.vixHighThreshold) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, message: "vixLowThreshold must be less than vixHighThreshold", path: ["vixLowThreshold"] });
  }
});


type ChainRow = {
  strike: number;
  bid: number;
  ask: number;
  deltaAbs: number;
  oi: number | null;
  dte: number | null;
  expiration: string | null;
  iv: number | null;
};

type Pick = {
  ticker: string;
  sector: string;
  price: number;
  expiration: string;
  dte: number | null;

  // V7 hybrid engine label (CORE vs BOOST). For legacy modes this is "LEGACY".
  engine: "CORE" | "BOOST" | "LEGACY";

  spreadType: "PUT_CREDIT_SPREAD_MICRO";
  shortPut: number;
  longPut: number;
  width: number;

  shortBid: number;
  longAsk: number;

  credit: number;
  creditPctWidth: number;
  distancePct: number;
  shortDeltaAbs: number;

  maxLoss: number;
  rorPct: number;

  contracts: number;
  tradeRisk: number;

  optimisticCredit: number;
  conservativeCredit: number;
  slippageRatio: number;

  confidence: number;
};

type UnderlyingSnapshot = {
  price: number | null;
  changePct: number | null;
  bid: number | null;
  ask: number | null;
};

const logger = {
  info(event: string, data: Record<string, any> = {}) {
    console.log(JSON.stringify({ level: "info", event, ts: new Date().toISOString(), ...data }));
  },
  warn(event: string, data: Record<string, any> = {}) {
    console.warn(JSON.stringify({ level: "warn", event, ts: new Date().toISOString(), ...data }));
  },
  error(event: string, data: Record<string, any> = {}) {
    console.error(JSON.stringify({ level: "error", event, ts: new Date().toISOString(), ...data }));
  },
};

function parseJsonEnv<T>(key: string, fallback: T): T {
  const raw = process.env[key];
  if (!raw) return fallback;
  try {
    return { ...(fallback as any), ...(JSON.parse(raw) as any) };
  } catch {
    logger.warn("config_parse_failed", { key });
    return fallback;
  }
}

const STRATEGY_CONFIG = parseJsonEnv("SCANNER_STRATEGY_CONFIG", {
  scanConcurrency: 3,
  earningsLookaheadDays: 14,
  recentSurvivorBonus: {
    TSLA: 1.0,
    NVDA: 1.0,
    AMD: 1.0,
    AMZN: 1.0,
  } as Record<string, number>,
  scoreWeights: {
    distance: 0.26,
    relativeStrength: 0.17,
    slippage: 0.14,
    liquidity: 0.12,
    persistence: 0.08,
    credit: 0.06,
    delta: 0.05,
    dte: 0.04,
    iv: 0.08,
  },
  scorePenalties: {
    highCreditPct: 55,
    highSlip: 1.45,
    lowDistancePct: 8,
    lowOI: 5,
    weakRelativeStrength: -1.0,
  },
});

function getPersistenceBonus(ticker: string): number {
  return STRATEGY_CONFIG.recentSurvivorBonus[ticker] ?? 0;
}


type CacheEntry<T> = { ts: number; data: T };
const CACHE_TTL_MS = 2 * 60 * 1000;

const quoteSnapshotCache = new Map<string, CacheEntry<UnderlyingSnapshot>>();
const chainCache = new Map<string, CacheEntry<any>>();
const vixCache = new Map<string, CacheEntry<number>>();
const earningsCache = new Map<string, CacheEntry<Map<string, string>>>();

function cacheGet<T>(m: Map<string, CacheEntry<T>>, k: string): T | null {
  const e = m.get(k);
  if (!e) return null;
  if (Date.now() - e.ts > CACHE_TTL_MS) return null;
  return e.data;
}

function cacheSet<T>(m: Map<string, CacheEntry<T>>, k: string, data: T) {
  m.set(k, { ts: Date.now(), data });
}

async function mapWithConcurrency<T, R>(
  items: T[],
  concurrency: number,
  worker: (item: T, index: number) => Promise<R>,
  interItemDelayMs = 150
): Promise<R[]> {
  const results: R[] = new Array(items.length);
  let nextIndex = 0;

  async function runOne() {
    while (true) {
      const current = nextIndex++;
      if (current >= items.length) return;
      results[current] = await worker(items[current], current);
      if (interItemDelayMs > 0 && current < items.length - 1) {
        await new Promise(res => setTimeout(res, interItemDelayMs));
      }
    }
  }

  const runners = Array.from({ length: Math.max(1, Math.min(concurrency, items.length || 1)) }, () => runOne());
  await Promise.all(runners);
  return results;
}

async function fetchWithTimeout(url: string, headers: Record<string, string>, timeoutMs: number): Promise<globalThis.Response> {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), timeoutMs);

  try {
    return await fetch(url, { headers, signal: controller.signal });
  } finally {
    clearTimeout(t);
  }
}


function sf(x: any, d = 0): number {
  const n = Number(x);
  return Number.isFinite(n) ? n : d;
}
function si(x: any, d: number | null = null): number | null {
  const n = Number(x);
  if (!Number.isFinite(n)) return d;
  return Math.trunc(n);
}
function round2(n: number): number {
  return Math.round(n * 100) / 100;
}
function clamp(n: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, n));
}

function nowISODateUTC(): string {
  const d = new Date();
  const yyyy = d.getUTCFullYear();
  const mm = String(d.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(d.getUTCDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}
function dteFromYMD(expYmd: string): number {
  const today = new Date(`${nowISODateUTC()}T00:00:00Z`);
  const exp = new Date(`${expYmd}T00:00:00Z`);
  const ms = exp.getTime() - today.getTime();
  return Math.floor(ms / (24 * 3600 * 1000));
}

function unique<T>(arr: T[]): T[] {
  return Array.from(new Set(arr));
}

function resolveBestExpiration(
  puts: ChainRow[],
  engMinDTE: number,
  engMaxDTE: number,
  reject: Record<string, number>
): { exp: string | null; dte: number | null } {
  const exps = unique(
    puts.map(p => p.expiration).filter((x): x is string => !!x && x !== "unknown")
  );

  if (!exps.length) {
    return { exp: null, dte: null };
  }

  const expWithDte = exps
    .map(exp => ({ exp, dte: dteFromYMD(exp) }))
    .filter(x => Number.isFinite(x.dte));

  const inWindow = expWithDte
    .filter(x => x.dte >= engMinDTE && x.dte <= engMaxDTE)
    .sort((a, b) => a.dte - b.dte);

  if (inWindow.length) return { exp: inWindow[0].exp, dte: inWindow[0].dte };

  const usable = expWithDte
    .filter(x => x.dte >= 10)
    .sort((a, b) => a.dte - b.dte);

  if (usable.length) {
    reject.dteFiltered++;
    return { exp: usable[0].exp, dte: usable[0].dte };
  }

  reject.dteFiltered++;
  return { exp: null, dte: null };
}


function addDaysYmd(start: string, days: number): string {
  const dt = new Date(`${start}T00:00:00Z`);
  dt.setUTCDate(dt.getUTCDate() + days);
  return dt.toISOString().slice(0, 10);
}

function getEarningsApiKey(): string | null {
  const key = (process.env.FMP_API_KEY || process.env.FINANCIALMODELINGPREP_API_KEY || "").trim();
  return key || null;
}

async function getEarningsCalendarMap(lookaheadDays: number): Promise<Map<string, string>> {
  const apiKey = getEarningsApiKey();
  if (!apiKey) return new Map();

  const cacheKey = `${nowISODateUTC()}_${lookaheadDays}`;
  const cached = cacheGet(earningsCache, cacheKey);
  if (cached) return cached;

  const from = nowISODateUTC();
  const to = addDaysYmd(from, lookaheadDays);
  const url = `https://financialmodelingprep.com/api/v3/earning_calendar?from=${from}&to=${to}&apikey=${apiKey}`;

  try {
    const r = await fetchWithTimeout(url, { Accept: "application/json" }, 8000);
    if (!r.ok) return new Map();
    const data = await r.json();
    const out = new Map<string, string>();
    if (Array.isArray(data)) {
      for (const row of data) {
        const sym = String((row as any)?.symbol || "").toUpperCase().trim();
        const date = String((row as any)?.date || "").slice(0, 10);
        if (sym && date) out.set(sym, date);
      }
    }
    cacheSet(earningsCache, cacheKey, out);
    return out;
  } catch {
    return new Map();
  }
}

function hasUpcomingEarnings(
  ticker: string,
  earningsMap: Map<string, string>,
  lookaheadDays: number
): boolean {
  const date = earningsMap.get(ticker);
  if (!date) return false;
  const dte = dteFromYMD(date);
  return dte >= 0 && dte <= lookaheadDays;
}

async function getUnderlyingSnapshot(ticker: string): Promise<UnderlyingSnapshot> {
  const cached = cacheGet(quoteSnapshotCache, ticker);
  if (cached) return cached;

  try {
    const broker = getScannerBroker();
    const quotes = await broker.getEquityQuotes([ticker]);
    const d = quotes[0];
    if (!d) {
      return { price: null, changePct: null, bid: null, ask: null };
    }

    const bid = sf(d.bid, NaN);
    const ask = sf(d.ask, NaN);
    const bidVal = Number.isFinite(bid) && bid > 0 ? bid : null;
    const askVal = Number.isFinite(ask) && ask > 0 ? ask : null;
    const midFallback = bidVal !== null && askVal !== null && askVal >= bidVal ? (bidVal + askVal) / 2 : null;

    const last = sf(d.last, NaN);
    const mid = sf(d.mid, NaN);
    const close = sf(d.close, NaN);
    const mark = sf(d.mark, NaN);
    const price =
      (Number.isFinite(last) && last > 0 ? last : null) ??
      (Number.isFinite(mark) && mark > 0 ? mark : null) ??
      (Number.isFinite(mid) && mid > 0 ? mid : null) ??
      (Number.isFinite(close) && close > 0 ? close : null) ??
      midFallback;

    const prevClose = sf(d["prev-close"], NaN);
    let changePct: number | null = null;
    if (price && Number.isFinite(prevClose) && prevClose > 0) {
      changePct = ((price - prevClose) / prevClose) * 100;
    }

    const out: UnderlyingSnapshot = {
      price: price && price > 0 ? price : null,
      changePct,
      bid: bidVal,
      ask: askVal,
    };
    cacheSet(quoteSnapshotCache, ticker, out);
    return out;
  } catch (e: any) {
    logger.warn("quote_fetch_failed", { ticker, error: String(e?.message || e) });
    return { price: null, changePct: null, bid: null, ask: null };
  }
}


async function getVix(): Promise<number> {
  const cached = cacheGet(vixCache, "VIX");
  if (cached !== null) return cached;
  try {
    const broker = getScannerBroker();
    const d = await broker.getIndexQuote("VIX");
    if (!d) {
      cacheSet(vixCache, "VIX", 20);
      return 20;
    }
    const v = sf(d.last, 0) || sf(d.mark, 0) || sf(d.mid, 0) || sf(d.close, 0);
    const out = v > 0 ? v : 20;
    cacheSet(vixCache, "VIX", out);
    return out;
  } catch {
    cacheSet(vixCache, "VIX", 20);
    return 20;
  }
}

function applyVixRegime(cfg: Required<ScanRequest>, vix: number) {
  // Crash-aware but trade-producing micro defaults.
  // - High vol: tighten delta, require more distance, slightly raise min credit/width, reduce portfolio risk.
  // - Low vol: allow slightly higher delta to keep credits reasonable.
  const low = cfg.vixLowThreshold;
  const high = cfg.vixHighThreshold;

  let deltaMin = cfg.deltaMin;
  let deltaMax = cfg.deltaMax;
  let minDistancePct = cfg.minDistancePct;
  let minCreditPctWidth = cfg.minCreditPctWidth;
  let maxPortfolioRiskPct = cfg.maxPortfolioRiskPct;

  if (vix >= high) {
    deltaMin = Math.max(0.10, Math.min(deltaMin, 0.16));
    deltaMax = Math.max(deltaMin + 0.04, Math.min(deltaMax, 0.22));
    minDistancePct = clamp(minDistancePct + 0.02, 0.06, 0.20);
    minCreditPctWidth = clamp(minCreditPctWidth + 0.02, 0.08, 0.35);
    maxPortfolioRiskPct = clamp(maxPortfolioRiskPct * 0.75, 0.04, 0.25);
  } else if (vix <= low) {
    // Low vol: premiums thin; let delta drift up a bit to keep fills viable.
    deltaMin = clamp(Math.min(deltaMin, 0.18), 0.08, 0.30);
    deltaMax = clamp(Math.max(deltaMax, 0.25), deltaMin + 0.04, 0.35);
    minCreditPctWidth = clamp(minCreditPctWidth - 0.01, 0.06, 0.25);
  }

  return { deltaMin, deltaMax, minDistancePct, minCreditPctWidth, maxPortfolioRiskPct };
}

function scoreConfidence(p: {
  creditPctWidth: number;
  distancePct: number;
  shortDeltaAbs: number;
  slippageRatio: number;
  shortBid: number;
  longAsk: number;
  width: number;
  oiShort?: number | null;
  oiLong?: number | null;
  dte?: number | null;
  relativeStrengthPct?: number | null;
  persistenceBonus?: number;
  ivRank?: number | null;
  bullishTrend?: boolean;
  sectorIsEtf?: boolean;
}): number {
  const creditPct = clamp(p.creditPctWidth, 0, 100);
  const dist = clamp(p.distancePct, 0, 50);
  const delta = clamp(p.shortDeltaAbs, 0, 1);
  const slip = clamp(p.slippageRatio, 1, 3);
  const ivRank = p.ivRank ?? 50;

  let distScore = 0;
  if (dist < 5) distScore = 0;
  else if (dist >= 8 && dist <= 12) distScore = 1.0;
  else if (dist > 12) distScore = 0.9;
  else distScore = 0.7;

  let deltaScore = 0;
  if (delta <= 0.16) deltaScore = 1.0;
  else if (delta <= 0.22) deltaScore = 0.75;
  else deltaScore = 0.35;

  const slipScore = clamp((1.7 - slip) / 0.7, 0, 1);

  let creditScore = 0;
  if (creditPct < 3) creditScore = 0;
  else if (creditPct <= 30) creditScore = 1.0;
  else if (creditPct <= 45) creditScore = 0.75;
  else creditScore = 0.35;

  const oiShort = p.oiShort ?? 0;
  const oiLong = p.oiLong ?? 0;
  const minOI = Math.min(oiShort, oiLong);
  const oiScore = clamp(minOI / 30, 0, 1);

  const dte = p.dte ?? 0;
  let dteScore = 0.5;
  if (dte >= 5 && dte <= 21) dteScore = 1.0;
  else if (dte > 21 && dte <= 35) dteScore = 0.7;

  const rs = p.relativeStrengthPct ?? 0;
  let rsScore = 0.5;
  if (rs >= 1.0) rsScore = 1.0;
  else if (rs >= 0.3) rsScore = 0.8;
  else if (rs >= 0) rsScore = 0.65;
  else if (rs >= -0.5) rsScore = 0.4;
  else rsScore = 0.2;

  const persistenceScore = clamp(p.persistenceBonus ?? 0, 0, 1);

  let ivScore = 0.5;
  if (ivRank >= 50) ivScore = 1.0;
  else if (ivRank >= 30) ivScore = 0.75;
  else if (ivRank >= 20) ivScore = 0.5;
  else ivScore = 0.2;

  const bullish = p.bullishTrend ?? true;
  const isEtf = p.sectorIsEtf ?? false;

  let trendScore = 1.0;
  if (!bullish && !isEtf) trendScore = 0.35;

  const raw =
    0.24 * distScore +
    0.16 * rsScore +
    0.14 * slipScore +
    0.12 * oiScore +
    0.10 * ivScore +
    0.08 * trendScore +
    0.06 * persistenceScore +
    0.05 * creditScore +
    0.03 * deltaScore +
    0.02 * dteScore;

  let penalty = 0;
  if (creditPct > 55) penalty += 0.10;
  if (slip > 1.55 && creditPct < 8) penalty += 0.18;
  if (dist < 5) penalty += 0.20;
  if (!bullish && !isEtf) penalty += 0.12;
  if (ivRank < 20 && creditPct < 8) penalty += 0.12;

  return Math.round(clamp(raw - penalty, 0, 1) * 100);
}

async function getStockPrice(ticker: string): Promise<number | null> {
  const snap = await getUnderlyingSnapshot(ticker);
  return snap.price;
}

async function getDailyChangePct(ticker: string): Promise<number | null> {
  const snap = await getUnderlyingSnapshot(ticker);
  return snap.changePct;
}

async function getDailyCloses(_ticker: string, _count: number = 260): Promise<number[] | null> {
  return null;
}

async function isBullishTrend(ticker: string, currentPrice: number, sector: string): Promise<boolean> {
  if (sector.includes("ETF")) return true;
  const closes = await getDailyCloses(ticker, 260);
  if (!closes || closes.length < 200) return true;
  const sma200 = closes.slice(-200).reduce((a, b) => a + b, 0) / 200;
  return currentPrice >= sma200;
}

async function getNextEarningsDate(ticker: string): Promise<string | null> {
  try {
    const map = await getEarningsCalendarMap(60);
    const date = map.get(ticker.toUpperCase());
    if (date && date.length >= 10) return date.slice(0, 10);
  } catch {}
  return null;
}

function shiftTradingDays(ymd: string, days: number): string {
  const d = new Date(`${ymd}T00:00:00Z`);
  let moved = 0;
  const dir = days >= 0 ? 1 : -1;
  const target = Math.abs(days);
  while (moved < target) {
    d.setUTCDate(d.getUTCDate() + dir);
    const wd = d.getUTCDay();
    if (wd !== 0 && wd !== 6) moved++;
  }
  return d.toISOString().slice(0, 10);
}

async function isEarningsRisk(
  ticker: string,
  expirationDate: string | null,
  forcedExitDte: number = 7
): Promise<boolean> {
  const nextEarningsDate = await getNextEarningsDate(ticker);
  if (!nextEarningsDate) return false;

  const today = nowISODateUTC();

  let plannedExit = today;
  if (expirationDate && expirationDate !== "unknown") {
    const expDte = dteFromYMD(expirationDate);
    const exitDays = Math.max(0, expDte - forcedExitDte);
    plannedExit = shiftTradingDays(today, exitDays);
  }

  const safeCutoff = shiftTradingDays(nextEarningsDate, -2);
  return safeCutoff <= plannedExit || safeCutoff <= today;
}

async function getIvRankProxy(ticker: string): Promise<number | null> {
  try {
    const closes = await getDailyCloses(ticker, 252);
    if (!closes || closes.length < 80) return null;

    const vols: number[] = [];
    for (let i = 20; i < closes.length; i++) {
      const window = closes.slice(i - 20, i);
      const rets: number[] = [];
      for (let j = 1; j < window.length; j++) {
        const r = Math.log(window[j] / window[j - 1]);
        if (Number.isFinite(r)) rets.push(r);
      }
      if (rets.length >= 10) {
        const stdev = (rets.reduce((s, x) => s + x * x, 0) / rets.length) ** 0.5;
        vols.push(stdev);
      }
    }

    if (!vols.length) return null;
    const current = vols[vols.length - 1];
    const minV = Math.min(...vols);
    const maxV = Math.max(...vols);
    if (maxV <= minV) return 50;

    return clamp(((current - minV) / (maxV - minV)) * 100, 0, 100);
  } catch {}
  return null;
}

function adjustForIvRank(
  base: { minCreditPctWidth: number; minDistancePct: number; deltaMax: number },
  ivRank: number | null
) {
  if (ivRank === null) return base;

  if (ivRank >= 60) {
    return {
      minCreditPctWidth: base.minCreditPctWidth,
      minDistancePct: base.minDistancePct + 0.01,
      deltaMax: Math.max(0.10, base.deltaMax - 0.02),
    };
  }

  if (ivRank < 20) {
    return {
      minCreditPctWidth: base.minCreditPctWidth + 0.03,
      minDistancePct: base.minDistancePct + 0.01,
      deltaMax: Math.max(0.12, base.deltaMax - 0.04),
    };
  }

  return base;
}

function checkSectorSaturation(
  candidateSector: string,
  candidateRisk: number,
  currentPortfolio: Pick[],
  maxSectorPct: number = 0.25
): boolean {
  const totalRisk = currentPortfolio.reduce((sum, p) => sum + p.tradeRisk, 0);
  const sectorRisk = currentPortfolio
    .filter(p => p.sector === candidateSector)
    .reduce((sum, p) => sum + p.tradeRisk, 0);

  const projected = totalRisk + candidateRisk;
  if (projected <= 0) return true;

  return (sectorRisk + candidateRisk) / projected <= maxSectorPct;
}

interface TastyTradeChainPut {
  strikePrice: number;
  putSymbol: string;
  putStreamerSymbol: string;
  expirationDate: string;
  daysToExpiration: number;
}

function extractPutsFromNestedChain(chainResponse: any, underlyingPrice: number): TastyTradeChainPut[] {
  const items = chainResponse?.data?.items ?? [];
  const puts: TastyTradeChainPut[] = [];

  for (const chain of items) {
    const expirations = chain?.expirations ?? [];
    for (const exp of expirations) {
      const expDate = exp?.["expiration-date"];
      const dte = exp?.["days-to-expiration"];
      if (!expDate || dte === undefined) continue;
      if (dte < 0 || dte > 90) continue;

      const strikes = exp?.strikes ?? [];
      for (const s of strikes) {
        const strikePrice = sf(s?.["strike-price"], 0);
        const putSymbol = s?.put;
        const putStreamerSymbol = s?.["put-streamer-symbol"] ?? "";
        if (!putSymbol || strikePrice <= 0) continue;
        if (strikePrice >= underlyingPrice || strikePrice < underlyingPrice * 0.4) continue;

        puts.push({
          strikePrice,
          putSymbol,
          putStreamerSymbol,
          expirationDate: String(expDate).slice(0, 10),
          daysToExpiration: Number(dte),
        });
      }
    }
  }

  return puts;
}

function mergeChainWithQuotes(
  puts: TastyTradeChainPut[],
  quoteMap: Map<string, any>
): ChainRow[] {
  const rows: ChainRow[] = [];

  for (const p of puts) {
    const q = quoteMap.get(p.putSymbol);
    const bid = q ? sf(q.bid, 0) : 0;
    const ask = q ? sf(q.ask, 0) : 0;
    const deltaRaw = q ? sf(q.delta, 0) : 0;
    const deltaAbs = Math.abs(deltaRaw);
    const oiRaw = q ? q["open-interest"] ?? q.openInterest : null;
    const oi = oiRaw !== null && oiRaw !== undefined ? si(oiRaw, null) : null;
    const ivRaw = q ? sf(q["implied-volatility"] ?? q.impliedVolatility, NaN) : NaN;

    rows.push({
      strike: p.strikePrice,
      bid,
      ask,
      deltaAbs,
      oi,
      dte: p.daysToExpiration,
      expiration: p.expirationDate,
      iv: Number.isFinite(ivRaw) ? ivRaw : null,
    });
  }

  return rows;
}

function legSanity(
  row: ChainRow,
  underlying: number,
  minOI: number,
  maxLegBidAskAbs: number,
  maxLegBidAskPctUnderlying: number,
  maxLegBidAskPctPremium: number,
  minShortBid: number,
  reject: Record<string, number>,
  isShortLeg: boolean
): boolean {
  if (!(row.strike > 0)) return (reject.badStrike++, false);
  if (!(row.bid > 0 && row.ask > 0 && row.ask >= row.bid)) return (reject.noQuote++, false);
  if (isShortLeg && row.bid < minShortBid) return (reject.shortBidTooLow++, false);

  const spread = row.ask - row.bid;

  const pctUnderlying = underlying > 0 ? spread / underlying : 0;
  const pctPremium = row.ask > 0 ? spread / row.ask : 1;

  if (underlying > 0 && pctUnderlying > maxLegBidAskPctUnderlying) {
    return (reject.legWidePct++, false);
  }

  if (spread > maxLegBidAskAbs && pctPremium > maxLegBidAskPctPremium) {
    return (reject.legWideAbs++, false);
  }

  if (row.deltaAbs <= 0) return (reject.noDelta++, false);

  if (row.oi !== null && row.oi < minOI && row.bid < 0.05) {
    return (reject.lowOI++, false);
  }

  return true;
}

function findCandidateShortPuts(
  puts: ChainRow[],
  price: number,
  deltaMin: number,
  deltaMax: number,
  minOI: number,
  maxLegBidAskAbs: number,
  maxLegBidAskPctUnderlying: number,
  maxLegBidAskPctPremium: number,
  minShortBid: number,
  reject: Record<string, number>,
  maxCandidates: number = 5
): ChainRow[] {
  const out: ChainRow[] = [];
  const target = (deltaMin + deltaMax) / 2;

  for (const r of puts) {
    if (r.strike >= price) continue;
    if (r.deltaAbs < deltaMin || r.deltaAbs > deltaMax) continue;
    if (!legSanity(
      r, price, minOI, maxLegBidAskAbs, maxLegBidAskPctUnderlying,
      maxLegBidAskPctPremium, minShortBid, reject, true
    )) continue;
    out.push(r);
  }

  out.sort((a, b) => {
    const da = Math.abs(a.deltaAbs - target);
    const db = Math.abs(b.deltaAbs - target);
    if (da !== db) return da - db;
    return b.bid - a.bid;
  });

  return out.slice(0, maxCandidates);
}

function resolveCandidateExpirations(
  puts: ChainRow[],
  engMinDTE: number,
  engMaxDTE: number
): Array<{ exp: string | null; dte: number | null }> {
  const exps = unique(puts.map(p => p.expiration).filter((x): x is string => !!x && x !== "unknown"));
  if (!exps.length) return [{ exp: null, dte: null }];

  const expWithDte = exps
    .map(exp => ({ exp, dte: dteFromYMD(exp) }))
    .filter(x => Number.isFinite(x.dte));

  const primary = expWithDte
    .filter(x => x.dte >= engMinDTE && x.dte <= engMaxDTE)
    .sort((a, b) => a.dte - b.dte);

  const fallback = expWithDte
    .filter(x => x.dte >= Math.max(3, engMinDTE - 10) && x.dte <= engMaxDTE + 14)
    .sort((a, b) => a.dte - b.dte);

  const seen = new Set<string>();
  const combined: Array<{ exp: string | null; dte: number | null }> = [];

  for (const x of [...primary, ...fallback]) {
    if (!seen.has(x.exp)) {
      seen.add(x.exp);
      combined.push(x);
    }
    if (combined.length >= 2) break;
  }

  return combined.length ? combined : [{ exp: null, dte: null }];
}

function buildWidthCandidates(baseWidths: number[], sector: string): number[] {
  const v8w = DEFAULT_V8_SMALL_ACCOUNT_PRODUCTION.spreads;
  const widths = new Set<number>(baseWidths.length ? baseWidths : [v8w.preferredWidthMin, v8w.preferredWidthMax]);
  if (v8w.allowWidth3 && !widths.has(3)) widths.add(3);
  const result = Array.from(widths).filter(w => w <= v8w.maxWidth).sort((a, b) => a - b);
  return result.length ? result : [1, 2];
}

function minAbsoluteCreditForWidth(width: number): number {
  const v8c = DEFAULT_V8_SMALL_ACCOUNT_PRODUCTION.credit;
  if (width <= 1) return v8c.minAbsoluteCreditWidth1;
  if (width <= 2) return v8c.minAbsoluteCreditWidth2;
  return v8c.minAbsoluteCreditWidth2 * 1.5;
}

function scoreKey(p: Pick): [number, number, number, number, number] {
  return [p.confidence, p.creditPctWidth, p.credit, p.distancePct, -p.shortDeltaAbs];
}

function pickShortPut(
  puts: ChainRow[],
  price: number,
  deltaMin: number,
  deltaMax: number,
  minOI: number,
  maxLegBidAskAbs: number,
  maxLegBidAskPctUnderlying: number,
  maxLegBidAskPctPremium: number,
  minShortBid: number,
  reject: Record<string, number>
): ChainRow | null {
  const target = (deltaMin + deltaMax) / 2;
  let best: ChainRow | null = null;
  let bestKey: [number, number] | null = null;

  for (const r of puts) {
    if (r.strike >= price) continue;
    if (r.deltaAbs < deltaMin || r.deltaAbs > deltaMax) continue;
    if (!legSanity(r, price, minOI, maxLegBidAskAbs, maxLegBidAskPctUnderlying, maxLegBidAskPctPremium, minShortBid, reject, true)) continue;

    const key: [number, number] = [Math.abs(r.deltaAbs - target), -r.bid];
    if (!best || !bestKey || key[0] < bestKey[0] || (key[0] === bestKey[0] && key[1] < bestKey[1])) {
      best = r;
      bestKey = key;
    }
  }
  return best;
}

function pickShortPutCandidates(
  puts: ChainRow[],
  price: number,
  deltaMin: number,
  deltaMax: number,
  minOI: number,
  maxLegBidAskAbs: number,
  maxLegBidAskPctUnderlying: number,
  maxLegBidAskPctPremium: number,
  minShortBid: number,
  reject: Record<string, number>,
  maxCandidates = 4
): ChainRow[] {
  const target = (deltaMin + deltaMax) / 2;
  const scored: Array<{ row: ChainRow; score: number }> = [];

  for (const r of puts) {
    if (r.strike >= price) continue;
    if (r.deltaAbs < deltaMin || r.deltaAbs > deltaMax) continue;
    if (!legSanity(r, price, minOI, maxLegBidAskAbs, maxLegBidAskPctUnderlying, maxLegBidAskPctPremium, minShortBid, reject, true)) continue;

    const score =
      Math.abs(r.deltaAbs - target) * 100 -
      r.bid * 0.5 -
      (r.oi ?? 0) * 0.002;
    scored.push({ row: r, score });
  }

  scored.sort((a, b) => a.score - b.score);
  return scored.slice(0, maxCandidates).map(x => x.row);
}

function findLongLeg(
  puts: ChainRow[],
  longStrike: number,
  price: number,
  minOI: number,
  maxLegBidAskAbs: number,
  maxLegBidAskPctUnderlying: number,
  maxLegBidAskPctPremium: number,
  reject: Record<string, number>
): ChainRow | null {
  for (const r of puts) {
    if (Math.abs(r.strike - longStrike) < 1e-9) {
      if (legSanity(r, price, minOI, maxLegBidAskAbs, maxLegBidAskPctUnderlying, maxLegBidAskPctPremium, 0, reject, false)) return r;
    }
  }
  let best: ChainRow | null = null;
  let bestDist = Infinity;
  for (const r of puts) {
    if (r.strike > longStrike) continue;
    if (!legSanity(r, price, minOI, maxLegBidAskAbs, maxLegBidAskPctUnderlying, maxLegBidAskPctPremium, 0, reject, false)) continue;
    const dist = Math.abs(r.strike - longStrike);
    if (dist < bestDist) {
      bestDist = dist;
      best = r;
    }
  }
  return best;
}

function inferExpirationAndDTE(shortLeg: ChainRow): { exp: string; dte: number | null } {
  let exp = shortLeg.expiration ?? "unknown";
  let dte: number | null = shortLeg.dte ?? null;
  if ((dte === null || dte === undefined) && exp !== "unknown") {
    try {
      dte = dteFromYMD(exp);
    } catch {
      dte = null;
    }
  }
  return { exp, dte };
}

function defaultUniverse(): Array<{ ticker: string; sector: string }> {
  return [
    { ticker: "SPY", sector: "Index ETF" },
    { ticker: "QQQ", sector: "Index ETF" },
    { ticker: "IWM", sector: "Index ETF" },
    { ticker: "DIA", sector: "Index ETF" },
    { ticker: "TLT", sector: "Rates ETF" },
    { ticker: "GLD", sector: "Commodity ETF" },
    { ticker: "SLV", sector: "Commodity ETF" },
    { ticker: "EEM", sector: "International ETF" },
    { ticker: "XLF", sector: "Financials ETF" },
    { ticker: "XLK", sector: "Technology ETF" },
    { ticker: "XLV", sector: "Healthcare ETF" },
    { ticker: "XLE", sector: "Energy ETF" },
    { ticker: "XLY", sector: "Consumer Discretionary ETF" },
    { ticker: "XLP", sector: "Consumer Staples ETF" },
    { ticker: "XLI", sector: "Industrials ETF" },
    { ticker: "XLU", sector: "Utilities ETF" },
    { ticker: "XLB", sector: "Materials ETF" },
    { ticker: "SMH", sector: "Semiconductor ETF" },
    { ticker: "KRE", sector: "Regional Banks ETF" },
    { ticker: "GDX", sector: "Gold Miners ETF" },

    { ticker: "AAPL", sector: "Technology" },
    { ticker: "MSFT", sector: "Technology" },
    { ticker: "NVDA", sector: "Technology" },
    { ticker: "AMD", sector: "Technology" },
    { ticker: "AVGO", sector: "Technology" },
    { ticker: "QCOM", sector: "Technology" },
    { ticker: "MU", sector: "Technology" },
    { ticker: "INTC", sector: "Technology" },
    { ticker: "ORCL", sector: "Technology" },
    { ticker: "CRM", sector: "Technology" },
    { ticker: "ADBE", sector: "Technology" },
    { ticker: "NOW", sector: "Technology" },
    { ticker: "CSCO", sector: "Technology" },
    { ticker: "IBM", sector: "Technology" },
    { ticker: "ANET", sector: "Technology" },
    { ticker: "META", sector: "Communication" },
    { ticker: "GOOGL", sector: "Communication" },
    { ticker: "GOOG", sector: "Communication" },
    { ticker: "NFLX", sector: "Communication" },
    { ticker: "DIS", sector: "Communication" },
    { ticker: "CMCSA", sector: "Communication" },
    { ticker: "T", sector: "Communication" },
    { ticker: "VZ", sector: "Communication" },

    { ticker: "TSLA", sector: "High Beta" },
    { ticker: "PLTR", sector: "High Beta" },
    { ticker: "CRWD", sector: "High Beta" },
    { ticker: "COIN", sector: "High Beta" },
    { ticker: "SQ", sector: "High Beta" },
    { ticker: "UBER", sector: "High Beta" },
    { ticker: "SNOW", sector: "High Beta" },
    { ticker: "SHOP", sector: "High Beta" },

    { ticker: "JPM", sector: "Financials" },
    { ticker: "BAC", sector: "Financials" },
    { ticker: "WFC", sector: "Financials" },
    { ticker: "C", sector: "Financials" },
    { ticker: "GS", sector: "Financials" },
    { ticker: "MS", sector: "Financials" },
    { ticker: "V", sector: "Financials" },
    { ticker: "MA", sector: "Financials" },
    { ticker: "SCHW", sector: "Financials" },
    { ticker: "AXP", sector: "Financials" },
    { ticker: "BK", sector: "Financials" },
    { ticker: "BLK", sector: "Financials" },

    { ticker: "UNH", sector: "Healthcare" },
    { ticker: "JNJ", sector: "Healthcare" },
    { ticker: "LLY", sector: "Healthcare" },
    { ticker: "ABBV", sector: "Healthcare" },
    { ticker: "MRK", sector: "Healthcare" },
    { ticker: "PFE", sector: "Healthcare" },
    { ticker: "ABT", sector: "Healthcare" },
    { ticker: "TMO", sector: "Healthcare" },
    { ticker: "ISRG", sector: "Healthcare" },
    { ticker: "DHR", sector: "Healthcare" },
    { ticker: "BMY", sector: "Healthcare" },
    { ticker: "AMGN", sector: "Healthcare" },
    { ticker: "CVS", sector: "Healthcare" },

    { ticker: "WMT", sector: "Consumer Staples" },
    { ticker: "COST", sector: "Consumer Staples" },
    { ticker: "PG", sector: "Consumer Staples" },
    { ticker: "KO", sector: "Consumer Staples" },
    { ticker: "PEP", sector: "Consumer Staples" },
    { ticker: "PM", sector: "Consumer Staples" },
    { ticker: "MO", sector: "Consumer Staples" },
    { ticker: "CL", sector: "Consumer Staples" },
    { ticker: "KMB", sector: "Consumer Staples" },
    { ticker: "GIS", sector: "Consumer Staples" },
    { ticker: "TGT", sector: "Consumer Staples" },

    { ticker: "AMZN", sector: "Consumer Discretionary" },
    { ticker: "HD", sector: "Consumer Discretionary" },
    { ticker: "LOW", sector: "Consumer Discretionary" },
    { ticker: "MCD", sector: "Consumer Discretionary" },
    { ticker: "SBUX", sector: "Consumer Discretionary" },
    { ticker: "NKE", sector: "Consumer Discretionary" },
    { ticker: "BKNG", sector: "Consumer Discretionary" },
    { ticker: "TJX", sector: "Consumer Discretionary" },
    { ticker: "CMG", sector: "Consumer Discretionary" },
    { ticker: "MAR", sector: "Consumer Discretionary" },

    { ticker: "XOM", sector: "Energy" },
    { ticker: "CVX", sector: "Energy" },
    { ticker: "COP", sector: "Energy" },
    { ticker: "SLB", sector: "Energy" },
    { ticker: "EOG", sector: "Energy" },
    { ticker: "OXY", sector: "Energy" },
    { ticker: "VLO", sector: "Energy" },

    { ticker: "BA", sector: "Industrials" },
    { ticker: "CAT", sector: "Industrials" },
    { ticker: "GE", sector: "Industrials" },
    { ticker: "HON", sector: "Industrials" },
    { ticker: "UNP", sector: "Industrials" },
    { ticker: "RTX", sector: "Industrials" },
    { ticker: "UPS", sector: "Industrials" },
    { ticker: "DE", sector: "Industrials" },
    { ticker: "LMT", sector: "Industrials" },
    { ticker: "NOC", sector: "Industrials" },
    { ticker: "ETN", sector: "Industrials" },
    { ticker: "PH", sector: "Industrials" },

    { ticker: "FCX", sector: "Materials" },
    { ticker: "NUE", sector: "Materials" },
    { ticker: "LIN", sector: "Materials" },
    { ticker: "APD", sector: "Materials" },
    { ticker: "DOW", sector: "Materials" },
    { ticker: "DD", sector: "Materials" },
    { ticker: "SHW", sector: "Materials" },
    { ticker: "NEM", sector: "Materials" },

    { ticker: "NEE", sector: "Utilities" },
    { ticker: "SO", sector: "Utilities" },
    { ticker: "DUK", sector: "Utilities" },
    { ticker: "AEP", sector: "Utilities" },
    { ticker: "EXC", sector: "Utilities" },

    { ticker: "AMT", sector: "Real Estate" },
    { ticker: "PLD", sector: "Real Estate" },
    { ticker: "O", sector: "Real Estate" },
    { ticker: "SPG", sector: "Real Estate" },
    { ticker: "CCI", sector: "Real Estate" },

    { ticker: "PYPL", sector: "Financials" },
    { ticker: "ADP", sector: "Technology" },
    { ticker: "MDT", sector: "Healthcare" },
    { ticker: "FDX", sector: "Industrials" },
    { ticker: "GM", sector: "Consumer Discretionary" },
    { ticker: "F", sector: "Consumer Discretionary" },
  ];
}

function applyDefaults(body: ScanRequest): Required<ScanRequest> {
  const mode: Mode = (body.mode as Mode) || "v7";

  const microWidths = body.microWidths?.length ? body.microWidths : [1, 2];
  const standardWidths = body.standardWidths?.length ? body.standardWidths : [5, 10];
  const aggressiveWidths = body.aggressiveWidths?.length ? body.aggressiveWidths : [2, 5];

  return {
    tickers: body.tickers ?? defaultUniverse(),
    mode,
    accountSize: sf(body.accountSize, 3000),
    riskPerTradePct: clamp(sf(body.riskPerTradePct, 0.02), 0.0025, 0.08),
    maxPortfolioRiskPct: clamp(sf(body.maxPortfolioRiskPct, 0.50), 0.02, 0.6),
    topNPerSector: Math.max(1, Math.trunc(sf(body.topNPerSector, 2))),
    maxTradesTotal: Math.max(1, Math.trunc(sf(body.maxTradesTotal, 12))),

    minDTE: Math.trunc(sf(body.minDTE, 8)),
    maxDTE: Math.trunc(sf(body.maxDTE, 21)),

    deltaMin: clamp(sf(body.deltaMin, 0.10), 0.05, 0.5),
    deltaMax: clamp(sf(body.deltaMax, 0.15), 0.05, 0.6),

    microWidths,
    standardWidths,
    aggressiveWidths,

    minCreditPctWidth: clamp(sf(body.minCreditPctWidth, 0.25), 0.02, 0.5),
    minDistancePct: clamp(sf(body.minDistancePct, 0.05), 0.0, 0.5),

    minOI: Math.trunc(sf(body.minOI, 100)),
    maxLegBidAskAbs: sf(body.maxLegBidAskAbs, 0.15),
    maxLegBidAskPctUnderlying: sf(body.maxLegBidAskPctUnderlying, 0.01),
    maxLegBidAskPctPremium: sf(body.maxLegBidAskPctPremium, 0.70),
    minShortBid: sf(body.minShortBid, 0.18),
    maxSlippageRatio: sf(body.maxSlippageRatio, 1.5),

    useVixRegime: body.useVixRegime ?? true,
    vixLowThreshold: sf(body.vixLowThreshold, 15),
    vixHighThreshold: sf(body.vixHighThreshold, 25),

    minLongAsk: sf(body.minLongAsk, 0.02),
    maxCreditPctWidth: sf(body.maxCreditPctWidth, 0.80),
  };
}

function mid(bid: number, ask: number): number {
  if (!(bid > 0 && ask > 0 && ask >= bid)) return 0;
  return (bid + ask) / 2;
}

function calcContracts(accountSize: number, riskPerTradePct: number, maxLossPerContract: number): number {
  const maxRisk = accountSize * riskPerTradePct;
  const c = Math.floor(maxRisk / maxLossPerContract);
  if (c < 1 && maxLossPerContract <= maxRisk * 1.60) return 1;
  return Math.max(0, c);
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.get("/api/positions", async (_req, res) => {
    try {
      const positions = await storage.getPositions();
      res.json(positions);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/positions/quotes", async (_req, res) => {
    try {
      const openPos = await storage.getPositions();
      const tickers = [...new Set(openPos.filter(p => p.status === "open").map(p => p.ticker))];
      const quotes: Record<string, number> = {};
      for (const t of tickers) {
        const cached = cacheGet(quoteSnapshotCache, t);
        if (cached?.price && cached.price > 0) { quotes[t] = cached.price; continue; }
      }
      const missing = tickers.filter(t => !quotes[t]);
      if (missing.length > 0) {
        try {
          const broker = getScannerBroker();
          const resp = await (broker as any).request("GET", `/market-data/by-type?equity=${missing.join(",")}`);
          const items = resp?.data?.items ?? [];
          for (const q of items) {
            if (!q?.symbol) continue;
            const sym = normalizeTicker(String(q.symbol));
            const sf = (v: any, fb: number) => { const n = Number(v); return Number.isFinite(n) ? n : fb; };
            const price = sf(q.mark, 0) || sf(q.last, 0) || sf(q.close, 0);
            if (price > 0) { quotes[sym] = price; cacheSet(quoteSnapshotCache, sym, { price, changePct: null, bid: null, ask: null }); }
          }
        } catch {}
      }
      res.json(quotes);
    } catch (e: any) {
      res.status(500).json({ error: String(e?.message || e) });
    }
  });

  app.post("/api/positions", async (req, res) => {
    try {
      const parsed = insertPositionSchema.parse(req.body);
      const position = await storage.createPosition(parsed);
      res.json(position);
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "Invalid position data", details: err.errors });
      }
      res.status(500).json({ error: err.message });
    }
  });

  app.delete("/api/positions/:id", async (req, res) => {
    try {
      await storage.deletePosition(req.params.id);
      res.json({ ok: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/positions/:id/close", async (req, res) => {
    try {
      const { exitPrice } = closePositionSchema.parse(req.body);
      const position = await storage.getPosition(req.params.id);
      if (!position) return res.status(404).json({ error: "Position not found" });

      const pl = (position.credit - exitPrice) * 100 * position.contracts;
      const plPercent = ((position.credit - exitPrice) / position.credit) * 100;

      const journalEntry = await storage.createJournalEntry({
        ticker: position.ticker,
        shortStrike: position.shortStrike,
        longStrike: position.longStrike,
        credit: position.credit,
        contracts: position.contracts,
        expiration: position.expiration,
        entryDate: position.entryDate,
        exitDate: new Date().toISOString().split("T")[0],
        exitPrice,
        pl,
        plPercent,
        maxRisk: position.maxRisk,
        notes: position.notes,
      });

      await storage.deletePosition(position.id);
      res.json(journalEntry);
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "Invalid close data", details: err.errors });
      }
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/journal", async (_req, res) => {
    try {
      const entries = await storage.getJournalEntries();
      res.json(entries);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/v8-profile", (_req, res) => {
    res.json(DEFAULT_V8_SMALL_ACCOUNT_PRODUCTION);
  });

  app.get("/api/settings", async (_req, res) => {
    try {
      let settings = await storage.getSettings();
      if (!settings) {
        settings = await storage.upsertSettings({});
      }
      res.json(settings);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.put("/api/settings", async (req, res) => {
    try {
      const parsed = updateSettingsSchema.parse(req.body);
      const settings = await storage.upsertSettings(parsed);
      res.json(settings);
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "Invalid settings data", details: err.errors });
      }
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/scan", async (req: Request, res: Response) => {
    const scanStartTime = Date.now();
    const SCAN_DEADLINE_MS = 75_000;

    const reject = {
      noPrice: 0,
      chainFail: 0,
      noRows: 0,
      noQuote: 0,
      noDelta: 0,
      lowOI: 0,
      badStrike: 0,
      shortBidTooLow: 0,
      legWideAbs: 0,
      legWidePct: 0,
      noShort: 0,
      noLong: 0,
      dteFiltered: 0,
      creditPctTooLow: 0,
      distanceTooLow: 0,
      slippageTooHigh: 0,
      portfolioCap: 0,
      sectorCap: 0,
      sizingTooSmall: 0,
      earningsBlocked: 0,
      tickerFailed: 0,
      trendFiltered: 0,
      earningsFiltered: 0,
      ivFiltered: 0,
    };

    try {
      const parsedScan = scanRequestSchema.safeParse((req.body ?? {}) as ScanRequest);
      if (!parsedScan.success) {
        return res.status(400).json({ ok: false, error: "Invalid scan request", details: parsedScan.error.flatten() });
      }
      const cfg = applyDefaults(parsedScan.data as ScanRequest);

      if (cfg.minDTE > cfg.maxDTE) return res.status(400).json({ ok: false, error: "minDTE cannot exceed maxDTE" });
      if (cfg.deltaMin > cfg.deltaMax) return res.status(400).json({ ok: false, error: "deltaMin cannot exceed deltaMax" });

      // VIX regime (optional): adapt filters for volatility conditions.
      // Goal: improve survivability in sell-side strategies while still producing micro candidates.
      const vix = cfg.useVixRegime ? await getVix() : 20;
      const adj = cfg.useVixRegime ? applyVixRegime(cfg, vix) : null;
      const deltaMin = adj?.deltaMin ?? cfg.deltaMin;
      const deltaMax = adj?.deltaMax ?? cfg.deltaMax;
      const minDistancePct = adj?.minDistancePct ?? cfg.minDistancePct;
      const minCreditPctWidth = adj?.minCreditPctWidth ?? cfg.minCreditPctWidth;
      const maxPortfolioRiskPct = adj?.maxPortfolioRiskPct ?? cfg.maxPortfolioRiskPct;

      // Crash guard: when volatility is extreme, throttle risk automatically.
      // We still return picks (so you can review), but sizing is reduced.
      const crashMode = cfg.useVixRegime && vix >= 35;
      const riskPerTradePctEff = crashMode ? Math.min(cfg.riskPerTradePct, 0.02) : cfg.riskPerTradePct;
      const maxPortfolioRiskPctEff = crashMode ? Math.min(maxPortfolioRiskPct, 0.08) : maxPortfolioRiskPct;

      const universeRaw = (cfg.tickers ?? []).map((t: any) => {
        if (typeof t === "string") return { ticker: t, sector: "Unknown" };
        if (Array.isArray(t)) return { ticker: t[0], sector: t[1] ?? "Unknown" };
        return { ticker: t.ticker, sector: t.sector ?? "Unknown" };
      });

      for (let i = universeRaw.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [universeRaw[i], universeRaw[j]] = [universeRaw[j], universeRaw[i]];
      }
      const universe = universeRaw;

      logger.info("scan_universe_sample", { sample: universe.slice(0, 10), count: universe.length });

      const widths =
        cfg.mode === "micro" || cfg.mode === "v7" || cfg.mode === "v8"
          ? cfg.microWidths
          : cfg.mode === "aggressive"
            ? cfg.aggressiveWidths
            : cfg.standardWidths;

      const v8 = DEFAULT_V8_SMALL_ACCOUNT_PRODUCTION;
      const v7Engines =
        cfg.mode !== "v7" && cfg.mode !== "v8"
          ? null
          : ([
              {
                engine: "CORE" as const,
                minDTE: v8.dte.primaryMin,
                maxDTE: v8.dte.secondaryMax,
                deltaMin: v8.strikes.deltaTargetMin,
                deltaMax: v8.strikes.deltaTargetMax,
                minDistancePct: v8.strikes.minDistanceOtmPct / 100,
                minCreditPctWidth: v8.credit.minCreditPctOfWidth,
                minOI: v8.liquidity.minOpenInterest,
              },
              {
                engine: "BOOST" as const,
                minDTE: v8.dte.secondaryMin,
                maxDTE: v8.dte.fallbackMax,
                deltaMin: v8.strikes.deltaTargetMax,
                deltaMax: v8.strikes.hardRejectDeltaAbove,
                minDistancePct: v8.strikes.minDistanceOtmPct / 100,
                minCreditPctWidth: v8.credit.minCreditPctOfWidth * 0.80,
                minOI: Math.round(v8.liquidity.minOpenInterest * 0.5),
              },
            ]);

      const candidates: Pick[] = [];
      const warnings: Array<{ ticker: string; reason: string }> = [];
      const earningsMap = await getEarningsCalendarMap(STRATEGY_CONFIG.earningsLookaheadDays);

      try {
        const broker = getScannerBroker();
        const allTickers = universe.map((u: any) => normalizeTicker(String(u.ticker)));
        const batchSize = 20;
        let prefetchCount = 0;
        for (let i = 0; i < allTickers.length; i += batchSize) {
          const batch = allTickers.slice(i, i + batchSize);
          try {
            const res = await Promise.race([
              (broker as any).request("GET", `/market-data/by-type?equity=${batch.join(",")}`),
              new Promise((_, reject) => setTimeout(() => reject(new Error("bulk_timeout")), 6000)),
            ]);
            const items = (res as any)?.data?.items ?? [];
            for (const q of items) {
              if (q?.symbol) {
                const sym = normalizeTicker(String(q.symbol));
                const bid = sf(q.bid, NaN);
                const ask = sf(q.ask, NaN);
                const bidVal = Number.isFinite(bid) && bid > 0 ? bid : null;
                const askVal = Number.isFinite(ask) && ask > 0 ? ask : null;
                const midFallback = bidVal !== null && askVal !== null && askVal >= bidVal ? (bidVal + askVal) / 2 : null;
                const last = sf(q.last, NaN);
                const mid = sf(q.mid, NaN);
                const close = sf(q.close, NaN);
                const mark = sf(q.mark, NaN);
                const price =
                  Number.isFinite(mark) && mark > 0 ? mark :
                  Number.isFinite(mid) && mid > 0 ? mid :
                  Number.isFinite(last) && last > 0 ? last :
                  midFallback ? midFallback :
                  Number.isFinite(close) && close > 0 ? close : null;
                const changePct = q.changePct ?? (close > 0 && price ? ((price - close) / close) * 100 : null);
                cacheSet(quoteSnapshotCache, sym, { price, changePct, bid: bidVal, ask: askVal });
                prefetchCount++;
              }
            }
          } catch {
            break;
          }
        }
        logger.info("bulk_quotes_prefetched", { count: prefetchCount });
      } catch (e: any) {
        logger.warn("bulk_quotes_failed", { error: String(e?.message || e) });
      }

      const spyChangePct = await getDailyChangePct("SPY");

      let consecutiveFails = 0;
      let circuitBroken = false;
      const CIRCUIT_BREAKER_THRESHOLD = 10;

      const perTicker = await mapWithConcurrency(universe, STRATEGY_CONFIG.scanConcurrency, async (u) => {
        const ticker = normalizeTicker(String(u.ticker));
        const sector = String(u.sector || "Unknown");

        if (circuitBroken || Date.now() - scanStartTime > SCAN_DEADLINE_MS) {
          if (!circuitBroken) {
            circuitBroken = true;
            warnings.push({ ticker: "_DEADLINE", reason: `Scan deadline reached after ${Math.round((Date.now() - scanStartTime) / 1000)}s — returning partial results` });
          }
          reject.chainFail++;
          return [];
        }

        try {
          const snap = await getUnderlyingSnapshot(ticker);
          const price = snap.price;
          if (!price || price <= 0) {
            reject.noPrice++;
            warnings.push({ ticker, reason: "no_price" });
            consecutiveFails++;
            if (consecutiveFails >= CIRCUIT_BREAKER_THRESHOLD) {
              circuitBroken = true;
              warnings.push({ ticker: "_CIRCUIT_BREAKER", reason: `Stopped after ${consecutiveFails} consecutive API failures — sandbox likely down` });
            }
            return [];
          }
          consecutiveFails = 0;

          if (hasUpcomingEarnings(ticker, earningsMap, STRATEGY_CONFIG.earningsLookaheadDays) && !sector.endsWith("ETF")) {
            reject.earningsBlocked++;
            warnings.push({ ticker, reason: "earnings_blocked" });
            return [];
          }

          const stockChangePct = await getDailyChangePct(ticker);
          const relativeStrengthPct =
            stockChangePct !== null && spyChangePct !== null
              ? stockChangePct - spyChangePct
              : 0;

          const persistenceBonus = getPersistenceBonus(ticker);
          const bullishTrend = await isBullishTrend(ticker, price, sector);
          const sectorIsEtf = sector.includes("ETF");

          if (!bullishTrend && !sectorIsEtf) {
            reject.trendFiltered++;
            return [];
          }

          const ivRank = await getIvRankProxy(ticker);

          let puts: ChainRow[] | null = cacheGet(chainCache, ticker);
          if (!puts) {
            try {
              const broker = getScannerBroker();
              const chainResponse = await broker.getOptionChainNested(ticker);
              const chainPuts = extractPutsFromNestedChain(chainResponse, price);

              if (!chainPuts.length) {
                reject.noRows++;
                warnings.push({ ticker, reason: "no_rows" });
                return [];
              }

              const putSymbols = chainPuts.map(p => p.putSymbol);
              const streamerSymbols = chainPuts.map(p => p.putStreamerSymbol || "");
              const optionQuotes = await broker.getOptionQuotes(putSymbols, streamerSymbols);
              const quoteMap = new Map<string, any>();
              for (const q of optionQuotes) {
                if (q?.symbol) quoteMap.set(q.symbol, q);
              }

              puts = mergeChainWithQuotes(chainPuts, quoteMap);
              cacheSet(chainCache, ticker, puts);
            } catch (e: any) {
              reject.chainFail++;
              warnings.push({ ticker, reason: `chain_fail:${String(e?.message || e)}` });
              consecutiveFails++;
              if (consecutiveFails >= CIRCUIT_BREAKER_THRESHOLD) {
                circuitBroken = true;
                warnings.push({ ticker: "_CIRCUIT_BREAKER", reason: `Stopped after ${consecutiveFails} consecutive API failures — sandbox likely down` });
              }
              return [];
            }
          }
          consecutiveFails = 0;

          if (!puts.length) {
            reject.noRows++;
            warnings.push({ ticker, reason: "no_rows" });
            return [];
          }
          const tickerPicks: Pick[] = [];
          const earningsCache = new Map<string, boolean>();

          const enginesToTry = v7Engines ?? [
            {
              engine: "LEGACY" as const,
              minDTE: cfg.minDTE,
              maxDTE: cfg.maxDTE,
              deltaMin,
              deltaMax,
              minDistancePct,
              minCreditPctWidth,
              minOI: cfg.minOI,
            },
          ];

          for (const eng of enginesToTry) {
            const ivAdj = adjustForIvRank(
              {
                minCreditPctWidth: eng.minCreditPctWidth,
                minDistancePct: eng.minDistancePct,
                deltaMax: eng.deltaMax,
              },
              ivRank
            );

            const candidateExps = resolveCandidateExpirations(puts, eng.minDTE, eng.maxDTE);
            const dynamicWidths = buildWidthCandidates(widths, sector);

            for (const { exp: chosenExp, dte: chosenDte } of candidateExps) {
              const putsForExp = chosenExp ? puts.filter(r => r.expiration === chosenExp) : puts;
              if (chosenExp && putsForExp.length === 0) continue;

              const shortCandidates = findCandidateShortPuts(
                putsForExp,
                price,
                eng.deltaMin,
                ivAdj.deltaMax,
                eng.minOI,
                cfg.maxLegBidAskAbs,
                cfg.maxLegBidAskPctUnderlying,
                cfg.maxLegBidAskPctPremium,
                cfg.minShortBid,
                reject,
                4
              );
              if (!shortCandidates.length) {
                reject.noShort++;
                continue;
              }

              for (const short of shortCandidates) {
                for (const width of dynamicWidths) {
                  const longStrike = short.strike - width;
                  const long = findLongLeg(
                    putsForExp,
                    longStrike,
                    price,
                    eng.minOI,
                    cfg.maxLegBidAskAbs,
                    cfg.maxLegBidAskPctUnderlying,
                    cfg.maxLegBidAskPctPremium,
                    reject
                  );
                  if (!long) {
                    reject.noLong++;
                    continue;
                  }

                  if (long.ask < cfg.minLongAsk) {
                    reject.noLong++;
                    continue;
                  }

                  const conservativeCredit = short.bid - long.ask;
                  const optimisticCredit = mid(short.bid, short.ask) - mid(long.bid, long.ask);
                  if (!(conservativeCredit > 0)) continue;

                  const credit = round2(conservativeCredit);
                  const minAbsCredit = minAbsoluteCreditForWidth(width);
                  if (short.bid < 0.15 || credit < minAbsCredit) {
                    reject.creditPctTooLow++;
                    continue;
                  }
                  const creditPctWidth = credit / width;
                  if (ivRank !== null && ivRank < 15 && creditPctWidth < 0.05) {
                    reject.ivFiltered++;
                    continue;
                  }
                  if (creditPctWidth < ivAdj.minCreditPctWidth) {
                    reject.creditPctTooLow++;
                    continue;
                  }
                  if (creditPctWidth > cfg.maxCreditPctWidth) {
                    reject.creditPctTooLow++;
                    continue;
                  }

                  const distancePct = (price - short.strike) / price;
                  if (distancePct < ivAdj.minDistancePct) {
                    reject.distanceTooLow++;
                    continue;
                  }

                  const slippageRatio = optimisticCredit > 0 ? optimisticCredit / conservativeCredit : 999;

                  const allowedSlippage =
                    credit < 0.12 ? 1.45 :
                    credit < 0.20 ? 1.60 :
                    credit < 0.30 ? 1.75 :
                    1.90;

                  if (slippageRatio > allowedSlippage) {
                    reject.slippageTooHigh++;
                    continue;
                  }

                  const maxLoss = round2((width - credit) * 100);
                  const contracts = calcContracts(cfg.accountSize, riskPerTradePctEff, maxLoss);
                  if (contracts < 1) {
                    reject.sizingTooSmall++;
                    continue;
                  }

                  const tradeRisk = round2(maxLoss * contracts);
                  const exp = chosenExp ?? (short.expiration ?? "unknown");
                  const dte = chosenDte ?? (short.dte ?? (exp !== "unknown" ? (() => { try { return dteFromYMD(exp); } catch { return null; } })() : null));

                  let earningsDanger = earningsCache.get(exp);
                  if (earningsDanger === undefined) {
                    earningsDanger = await isEarningsRisk(ticker, exp, 7);
                    earningsCache.set(exp, earningsDanger);
                  }
                  if (earningsDanger) {
                    reject.earningsFiltered++;
                    continue;
                  }

                  const pick: Pick = {
                    ticker,
                    sector,
                    price: round2(price),
                    expiration: exp,
                    dte: dte ?? null,
                    engine: eng.engine,
                    spreadType: "PUT_CREDIT_SPREAD_MICRO",
                    shortPut: short.strike,
                    longPut: longStrike,
                    width,
                    shortBid: round2(short.bid),
                    longAsk: round2(long.ask),
                    credit,
                    creditPctWidth: round2(creditPctWidth * 100),
                    distancePct: round2(distancePct * 100),
                    shortDeltaAbs: round2(short.deltaAbs),
                    maxLoss,
                    rorPct: round2((credit * 100) / maxLoss * 100),
                    contracts,
                    tradeRisk,
                    optimisticCredit: round2(optimisticCredit),
                    conservativeCredit: round2(conservativeCredit),
                    slippageRatio: round2(slippageRatio),
                    confidence: scoreConfidence({
                      creditPctWidth: creditPctWidth * 100,
                      distancePct: distancePct * 100,
                      shortDeltaAbs: short.deltaAbs,
                      slippageRatio,
                      shortBid: short.bid,
                      longAsk: long.ask,
                      width,
                      oiShort: short.oi,
                      oiLong: long.oi,
                      dte: dte ?? null,
                      relativeStrengthPct,
                      persistenceBonus,
                      ivRank,
                      bullishTrend,
                      sectorIsEtf,
                    }),
                  };

                  tickerPicks.push(pick);
                }
              }
            }
          }

          tickerPicks.sort((a, b) => {
            const ka = scoreKey(a);
            const kb = scoreKey(b);
            for (let i = 0; i < ka.length; i++) {
              if (ka[i] !== kb[i]) return kb[i] - ka[i];
            }
            return 0;
          });

          return tickerPicks.slice(0, 4);
        } catch (e: any) {
          reject.tickerFailed++;
          warnings.push({ ticker, reason: `ticker_failed:${String(e?.message || e)}` });
          logger.warn("ticker_scan_failed", { ticker, error: String(e?.message || e) });
          return [];
        }
      });

      for (const tickerResults of perTicker) {
        for (const p of tickerResults) {
          candidates.push(p);
        }
      }

      candidates.sort((a, b) => {
        if (b.confidence !== a.confidence) return b.confidence - a.confidence;
        if (b.distancePct !== a.distancePct) return b.distancePct - a.distancePct;
        if (a.shortDeltaAbs !== b.shortDeltaAbs) return a.shortDeltaAbs - b.shortDeltaAbs;
        if (b.creditPctWidth !== a.creditPctWidth) return b.creditPctWidth - a.creditPctWidth;
        return b.credit - a.credit;
      });

      const picks: Pick[] = [];
      const sectorCounts = new Map<string, number>();
      const maxPortfolioRisk = cfg.accountSize * maxPortfolioRiskPctEff;
      let deployed = 0;

      for (const p of candidates) {
        if (picks.length >= cfg.maxTradesTotal) break;

        if (p.sector === "High Beta" && (sectorCounts.get("High Beta") ?? 0) >= 1) {
          reject.sectorCap++;
          continue;
        }

        const count = sectorCounts.get(p.sector) ?? 0;
        if (p.sector === "High Beta" && count >= 1) {
          reject.sectorCap++;
          continue;
        }
        if (count >= cfg.topNPerSector) {
          reject.sectorCap++;
          continue;
        }
        if (deployed + p.tradeRisk > maxPortfolioRisk) {
          reject.portfolioCap++;
          continue;
        }

        if (picks.length >= 2 && !checkSectorSaturation(p.sector, p.tradeRisk, picks, 0.25)) {
          reject.sectorCap++;
          continue;
        }

        picks.push(p);
        deployed += p.tradeRisk;
        sectorCounts.set(p.sector, count + 1);
      }

      logger.info("scan_summary", {
        mode: cfg.mode,
        candidates: candidates.length,
        picks: picks.length,
        deployedRisk: round2(deployed),
        maxPortfolioRisk: round2(maxPortfolioRisk),
        reject,
      });

      res.json({
        ok: true,
        mode: cfg.mode,
        defaultsUsed: {
          vix,
          crashMode,
          delta: [deltaMin, deltaMax],
          dte: [cfg.minDTE, cfg.maxDTE],
          minCreditPctWidth,
          minDistancePct,
          minOI: cfg.minOI,
          widths,
          minLongAsk: cfg.minLongAsk,
          maxCreditPctWidth: cfg.maxCreditPctWidth,
          useVixRegime: cfg.useVixRegime,
          vixLowThreshold: cfg.vixLowThreshold,
          vixHighThreshold: cfg.vixHighThreshold,
          sizing: {
            riskPerTradePct: riskPerTradePctEff,
            maxPortfolioRiskPct: maxPortfolioRiskPctEff,
          },
        },
        deployedRisk: round2(deployed),
        maxPortfolioRisk: round2(maxPortfolioRisk),
        reject,
        warnings,
        picks,
        ...(req.body?.autopilot ? { candidates } : {}),
      });
    } catch (e: any) {
      logger.error("scan_error", { error: String(e?.message || e) });
      res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  });

  app.get("/api/autopilot/health-report", async (_req, res) => {
    try {
      const strategy = await computeStrategyHealthFromHistory();
      const fills = await calculateFillAnalyticsLookback(30);
      const feedback = await generatePerformanceFeedback(60);
      const [state] = await db.select().from(autopilotState).limit(1);

      res.json({
        ok: true,
        state,
        strategy,
        fills,
        feedback,
      });
    } catch (e: any) {
      res.status(500).json({
        ok: false,
        error: String(e?.message || e),
      });
    }
  });

  app.get("/api/autopilot/control-state", async (_req, res) => {
    try {
      const [state] = await db.select().from(autopilotState).limit(1);
      const settings = await getAppSettings();
      const actions = await db
        .select()
        .from(manualActions)
        .orderBy(desc(manualActions.createdAt))
        .limit(50);

      res.json({
        ok: true,
        state,
        settings,
        recentManualActions: actions,
      });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  });

  app.post("/api/autopilot/pause", async (req, res) => {
    try {
      const reason = String(req.body?.reason || "manual_pause");
      const result = await pauseAutopilot(reason);
      res.json({ ok: true, result });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  });

  app.post("/api/autopilot/resume", async (_req, res) => {
    try {
      const result = await resumeAutopilot();
      res.json({ ok: true, result });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  });

  app.post("/api/autopilot/cancel-all-orders", async (_req, res) => {
    try {
      const result = await cancelAllOrders();
      res.json({ ok: true, result });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  });

  app.post("/api/autopilot/flatten-all", async (_req, res) => {
    try {
      const result = await flattenAllPositions();
      res.json({ ok: true, result });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  });

  app.post("/api/autopilot/exit-mode", async (req, res) => {
    try {
      const mode = String(req.body?.mode || "");
      if (!["TAKE_50_ALWAYS", "HOLD_TO_EXPIRATION", "HYBRID_SMART_EXIT"].includes(mode)) {
        return res.status(400).json({ ok: false, error: "invalid_mode" });
      }
      const result = await setExitStrategyMode(mode);
      res.json({ ok: true, result });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  });

  app.post("/api/autopilot/disable-ticker", async (req, res) => {
    try {
      const ticker = String(req.body?.ticker || "").toUpperCase();
      if (!ticker) return res.status(400).json({ ok: false, error: "ticker_required" });
      const result = await disableTicker(ticker);
      res.json({ ok: true, result });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  });

  app.post("/api/autopilot/enable-ticker", async (req, res) => {
    try {
      const ticker = String(req.body?.ticker || "").toUpperCase();
      if (!ticker) return res.status(400).json({ ok: false, error: "ticker_required" });
      const result = await enableTicker(ticker);
      res.json({ ok: true, result });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  });

  app.post("/api/autopilot/reset-for-live", async (req, res) => {
    try {
      const state = await db.select().from(autopilotState).limit(1);
      if (state[0]?.isEnabled) {
        return res.status(400).json({ ok: false, error: "Stop the autopilot before resetting" });
      }

      const deletedPositions = await db.delete(positions).where(eq(positions.status, "open")).returning();
      const deletedIntents = await db.delete(orderIntents).returning();
      const deletedBrokerOrders = await db.delete(brokerOrders).returning();

      await db.update(autopilotState).set({
        mode: "LIVE",
        isPaused: true,
        pauseReason: "reset_for_live",
      });

      await db.insert(systemEvents).values({
        severity: "warn",
        eventType: "reset_for_live",
        message: `Reset for live trading: cleared ${deletedPositions.length} positions, ${deletedIntents.length} intents, ${deletedBrokerOrders.length} broker orders`,
        payload: JSON.stringify({
          positionsCleared: deletedPositions.length,
          intentsCleared: deletedIntents.length,
          brokerOrdersCleared: deletedBrokerOrders.length,
          tickers: [...new Set(deletedPositions.map(p => p.ticker))],
        }),
      });

      res.json({
        ok: true,
        positionsCleared: deletedPositions.length,
        intentsCleared: deletedIntents.length,
        brokerOrdersCleared: deletedBrokerOrders.length,
        message: "All paper data cleared. Mode set to LIVE (paused). Start when ready.",
      });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  });

  app.post("/api/autopilot/set-mode", async (req, res) => {
    try {
      const mode = String(req.body?.mode || "");
      if (!["DRY_RUN", "PAPER", "LIVE"].includes(mode)) {
        return res.status(400).json({ ok: false, error: "invalid_mode. Must be DRY_RUN, PAPER, or LIVE" });
      }
      const result = await setAutopilotMode(mode);
      res.json({ ok: true, result });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  });

  app.get("/api/broker/status", async (_req, res) => {
    try {
      const broker = new TastytradeBroker();
      const creds = broker.credentialsConfigured();
      const health = creds.ok ? await broker.health() : null;
      res.json({
        ok: true,
        env: (process.env.TASTYTRADE_ENV || "sandbox").toLowerCase(),
        credentialsConfigured: creds.ok,
        missingSecrets: creds.missing,
        health,
      });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  });

  app.get("/api/autopilot/events", async (_req, res) => {
    try {
      const events = await db
        .select()
        .from(systemEvents)
        .orderBy(desc(systemEvents.createdAt))
        .limit(100);

      res.json({
        ok: true,
        events,
      });
    } catch (e: any) {
      res.status(500).json({
        ok: false,
        error: String(e?.message || e),
      });
    }
  });

  app.get("/api/autopilot/active-trades", async (_req, res) => {
    try {
      const openPos = await db
        .select()
        .from(positions)
        .where(eq(positions.status, "open"))
        .orderBy(desc(positions.createdAt));
      const recentIntents = await db
        .select()
        .from(orderIntents)
        .orderBy(desc(orderIntents.createdAt))
        .limit(30);

      const tickers = [...new Set(openPos.map(p => p.ticker))];
      const quotes: Record<string, number> = {};
      for (const t of tickers) {
        const cached = cacheGet(quoteSnapshotCache, t);
        if (cached?.price && cached.price > 0) { quotes[t] = cached.price; continue; }
      }
      const missing = tickers.filter(t => !quotes[t]);
      if (missing.length > 0) {
        try {
          const broker = getScannerBroker();
          const resp = await (broker as any).request("GET", `/market-data/by-type?equity=${missing.join(",")}`);
          const items = resp?.data?.items ?? [];
          for (const q of items) {
            if (!q?.symbol) continue;
            const sym = normalizeTicker(String(q.symbol));
            const sf = (v: any, fb: number) => { const n = Number(v); return Number.isFinite(n) ? n : fb; };
            const price = sf(q.mark, 0) || sf(q.last, 0) || sf(q.close, 0);
            if (price > 0) { quotes[sym] = price; cacheSet(quoteSnapshotCache, sym, { price, changePct: null, bid: null, ask: null }); }
          }
        } catch {}
      }

      res.json({ ok: true, positions: openPos, intents: recentIntents, quotes });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  });

  app.get("/api/autopilot/daily-log", async (req, res) => {
    try {
      const date = (req.query.date as string) || new Date().toISOString().slice(0, 10);
      const dayStart = `${date}T00:00:00`;
      const dayEnd = `${date}T23:59:59`;

      const intents = await db
        .select()
        .from(orderIntents)
        .where(and(
          gte(orderIntents.createdAt, dayStart),
          lte(orderIntents.createdAt, dayEnd),
        ))
        .orderBy(desc(orderIntents.createdAt));

      const format = (req.query.format as string) || "csv";

      if (format === "json") {
        res.setHeader("Content-Disposition", `attachment; filename="autopilot-log-${date}.json"`);
        res.setHeader("Content-Type", "application/json");
        const rows = intents.map(i => {
          let meta: any = {};
          try { meta = JSON.parse(i.metadata || "{}"); } catch {}
          return {
            time: i.createdAt,
            ticker: i.ticker,
            sector: i.sector,
            expiration: i.expiration,
            shortStrike: i.shortStrike,
            longStrike: i.longStrike,
            width: i.width,
            credit: i.intendedCredit,
            creditPctOfWidth: i.width > 0 ? ((i.intendedCredit / i.width) * 100).toFixed(1) + "%" : "N/A",
            contracts: i.contracts,
            confidence: i.confidence,
            liquidityScore: i.liquidityScore,
            state: i.state,
            delta: meta.delta ?? meta.shortDelta ?? null,
            dte: meta.dte ?? null,
            bidAskSpread: meta.bidAskSpread ?? null,
            openInterest: meta.openInterest ?? meta.oi ?? null,
          };
        });
        return res.json({ date, count: rows.length, picks: rows });
      }

      const csvHeader = "Time,Ticker,Sector,Expiration,Short Strike,Long Strike,Width,Credit,Credit %,Contracts,Confidence,Liquidity,State,Delta,DTE,Bid-Ask Spread,Open Interest\n";
      const csvRows = intents.map(i => {
        let meta: any = {};
        try { meta = JSON.parse(i.metadata || "{}"); } catch {}
        const creditPct = i.width > 0 ? ((i.intendedCredit / i.width) * 100).toFixed(1) + "%" : "N/A";
        return [
          i.createdAt,
          i.ticker,
          i.sector,
          i.expiration,
          i.shortStrike,
          i.longStrike,
          i.width,
          i.intendedCredit,
          creditPct,
          i.contracts,
          i.confidence,
          i.liquidityScore,
          i.state,
          meta.delta ?? meta.shortDelta ?? "",
          meta.dte ?? "",
          meta.bidAskSpread ?? "",
          meta.openInterest ?? meta.oi ?? "",
        ].join(",");
      }).join("\n");

      res.setHeader("Content-Disposition", `attachment; filename="autopilot-log-${date}.csv"`);
      res.setHeader("Content-Type", "text/csv");
      res.send(csvHeader + csvRows);
    } catch (e: any) {
      res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  });

  app.get("/api/system/ready", async (_req, res) => {
    try {
      const result = await getSystemReadiness();
      res.json({
        ok: true,
        status: result.ready ? "READY" : "NOT_READY",
        ...result,
      });
    } catch (e: any) {
      res.status(500).json({
        ok: false,
        status: "NOT_READY",
        error: String(e?.message || e),
      });
    }
  });

  // ─── Portfolio Greeks Routes ───────────────────────────────────
  app.get("/api/portfolio/greeks", async (_req, res) => {
    try {
      const broker = new TastytradeBroker();
      const market = await getMarketSnapshot(broker);
      const positionsWithGreeks = await getOpenPositionsWithGreeks(market.spyPrice);
      const summary = computePortfolioGreeks(positionsWithGreeks);
      res.json({
        ok: true,
        summary,
        positions: positionsWithGreeks,
        analyticsSourceSummary: {
          liveGreeksCount: summary.liveGreeksCount,
          approxGreeksCount: summary.approxGreeksCount,
        },
      });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  });

  app.get("/api/portfolio/stress", async (_req, res) => {
    try {
      const broker = new TastytradeBroker();
      const market = await getMarketSnapshot(broker);
      const positionsWithGreeks = await getOpenPositionsWithGreeks(market.spyPrice);
      const summary = computePortfolioGreeks(positionsWithGreeks);
      const stress = computePortfolioStressTest(summary, market);
      res.json({ ok: true, stress, market });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  });

  app.get("/api/portfolio/exposure", async (_req, res) => {
    try {
      const broker = new TastytradeBroker();
      const market = await getMarketSnapshot(broker);
      const positionsWithGreeks = await getOpenPositionsWithGreeks(market.spyPrice);
      const summary = computePortfolioGreeks(positionsWithGreeks);
      res.json({
        ok: true,
        sectorExposure: summary.riskBySector,
        tickerExposure: summary.riskByTicker,
        deltaBySector: summary.deltaBySector,
        thetaBySector: summary.thetaBySector,
        highBetaRisk: summary.highBetaRisk,
        singleStockRisk: summary.singleStockRisk,
        etfRisk: summary.etfRisk,
        totalMaxRisk: summary.totalMaxRisk,
      });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  });

  app.get("/api/portfolio/snapshots", async (_req, res) => {
    try {
      const snapshots = await db
        .select()
        .from(portfolioSnapshots)
        .orderBy(desc(portfolioSnapshots.createdAt))
        .limit(50);
      res.json({ ok: true, snapshots });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  });

  app.post("/api/portfolio/snapshot", async (_req, res) => {
    try {
      const result = await capturePortfolioSnapshot();
      res.json({ ok: true, result });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  });

  app.get("/api/portfolio/snapshots/csv", async (_req, res) => {
    try {
      const snapshots = await db
        .select()
        .from(portfolioSnapshots)
        .orderBy(desc(portfolioSnapshots.createdAt))
        .limit(500);

      const headers = [
        "timestamp", "engine_version", "selection_version",
        "open_positions", "total_max_risk", "total_net_delta", "total_net_theta",
        "beta_weighted_delta", "high_beta_risk", "single_stock_risk", "etf_risk",
        "stress_spy_down_1pct", "stress_spy_down_2pct", "stress_spy_down_3pct",
        "stress_vol_up_5", "stress_vol_up_10",
        "sector_exposure", "ticker_exposure",
      ];

      const rows = snapshots.map((s: any) => [
        s.createdAt, s.engineVersion, s.selectionVersion,
        s.openPositionsCount, s.totalMaxRisk, s.totalNetDelta, s.totalNetTheta,
        s.betaWeightedDelta, s.highBetaRisk, s.singleStockRisk, s.etfRisk,
        s.stressSpyDown1pct, s.stressSpyDown2pct, s.stressSpyDown3pct,
        s.stressVolUp5, s.stressVolUp10,
        `"${(s.sectorExposureJson || "").replace(/"/g, '""')}"`,
        `"${(s.tickerExposureJson || "").replace(/"/g, '""')}"`,
      ].join(","));

      const csv = [headers.join(","), ...rows].join("\n");
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename=portfolio_snapshots_${new Date().toISOString().slice(0, 10)}.csv`);
      res.send(csv);
    } catch (e: any) {
      res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  });

  // ─── Execution Quality Routes ───────────────────────────────────
  app.get("/api/execution/quality", async (_req, res) => {
    try {
      const limit = Number(_req.query.limit) || 100;
      const summary = await getExecutionQualitySummary(limit);
      res.json({ ok: true, summary });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  });

  app.get("/api/execution/recent-orders", async (_req, res) => {
    try {
      const limit = Number(_req.query.limit) || 20;
      const recent = await db
        .select()
        .from(executionAnalytics)
        .orderBy(desc(executionAnalytics.createdAt))
        .limit(limit);
      res.json({ ok: true, orders: recent });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  });

  return httpServer;
}