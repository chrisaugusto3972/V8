import WebSocket from "ws";

interface DxLinkQuoteToken {
  token: string;
  url: string;
}

export interface DxLinkQuoteData {
  symbol: string;
  bidPrice?: number;
  askPrice?: number;
  bidSize?: number;
  askSize?: number;
}

export interface DxLinkGreeksData {
  symbol: string;
  delta?: number;
  gamma?: number;
  theta?: number;
  vega?: number;
  rho?: number;
  volatility?: number;
}

export interface DxLinkSummaryData {
  symbol: string;
  openInterest?: number;
  prevDayClosePrice?: number;
  dayHighPrice?: number;
  dayLowPrice?: number;
}

export interface DxLinkTradeData {
  symbol: string;
  price?: number;
  dayVolume?: number;
  size?: number;
}

export interface DxLinkSnapshot {
  quote?: DxLinkQuoteData;
  greeks?: DxLinkGreeksData;
  summary?: DxLinkSummaryData;
  trade?: DxLinkTradeData;
}

export async function fetchQuoteToken(
  baseUrl: string,
  accessToken: string
): Promise<DxLinkQuoteToken> {
  const res = await fetch(`${baseUrl}/api-quote-tokens`, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "User-Agent": "InstitutionalScannerPro/1.0",
      Accept: "application/json",
    },
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`Failed to get quote token: ${res.status} ${text}`);
  }
  const json = await res.json();
  return {
    token: json?.data?.token ?? "",
    url: json?.data?.["dxlink-url"] ?? "",
  };
}

const ALL_EVENT_FIELDS: Record<string, string[]> = {
  Quote: ["eventType", "eventSymbol", "bidPrice", "askPrice", "bidSize", "askSize"],
  Greeks: ["eventType", "eventSymbol", "volatility", "delta", "gamma", "theta", "rho", "vega"],
  Summary: ["eventType", "eventSymbol", "openInterest", "dayOpenPrice", "dayHighPrice", "dayLowPrice", "prevDayClosePrice"],
  Trade: ["eventType", "eventSymbol", "price", "dayVolume", "size"],
};

function parseCompactData(
  eventType: string,
  fields: string[],
  values: any[]
): Record<string, any>[] {
  if (!fields.length || !values.length) return [];
  const chunkSize = fields.length;
  const results: Record<string, any>[] = [];
  for (let i = 0; i < values.length; i += chunkSize) {
    const row: Record<string, any> = {};
    for (let j = 0; j < chunkSize && i + j < values.length; j++) {
      row[fields[j]] = values[i + j];
    }
    row._eventType = eventType;
    results.push(row);
  }
  return results;
}

function num(v: any): number | undefined {
  if (v === "NaN" || v === null || v === undefined) return undefined;
  const n = Number(v);
  return Number.isFinite(n) ? n : undefined;
}

function applyRow(
  results: Map<string, DxLinkSnapshot>,
  row: Record<string, any>,
  eventType: string
) {
  const symbol = row.eventSymbol;
  if (!symbol) return;

  let snap = results.get(symbol);
  if (!snap) {
    snap = {};
    results.set(symbol, snap);
  }

  if (eventType === "Quote") {
    snap.quote = {
      symbol,
      bidPrice: num(row.bidPrice),
      askPrice: num(row.askPrice),
      bidSize: num(row.bidSize),
      askSize: num(row.askSize),
    };
  } else if (eventType === "Greeks") {
    snap.greeks = {
      symbol,
      delta: num(row.delta),
      gamma: num(row.gamma),
      theta: num(row.theta),
      vega: num(row.vega),
      rho: num(row.rho),
      volatility: num(row.volatility),
    };
  } else if (eventType === "Summary") {
    snap.summary = {
      symbol,
      openInterest: num(row.openInterest),
      prevDayClosePrice: num(row.prevDayClosePrice),
      dayHighPrice: num(row.dayHighPrice),
      dayLowPrice: num(row.dayLowPrice),
    };
  } else if (eventType === "Trade") {
    snap.trade = {
      symbol,
      price: num(row.price),
      dayVolume: num(row.dayVolume),
      size: num(row.size),
    };
  }
}

interface PendingRequest {
  symbols: string[];
  eventTypes: string[];
  results: Map<string, DxLinkSnapshot>;
  receivedEvents: Set<string>;
  expectedEvents: number;
  resolve: (v: Map<string, DxLinkSnapshot>) => void;
  timer: ReturnType<typeof setTimeout>;
  done: boolean;
}

const HANDSHAKE_TIMEOUT_MS = 15000;
const MAX_SUBSCRIBED_SYMBOLS = 2000;

class DxLinkPersistentClient {
  private ws: WebSocket | null = null;
  private state: "disconnected" | "connecting" | "ready" = "disconnected";
  private quoteToken: DxLinkQuoteToken | null = null;
  private fieldMap = new Map<string, string[]>();
  private keepaliveTimer: ReturnType<typeof setInterval> | null = null;
  private pendingRequests: PendingRequest[] = [];
  private connectPromise: Promise<void> | null = null;
  private allSubscribedSymbols = new Map<string, Set<string>>();
  private totalSubscribedCount = 0;

  async connect(quoteToken: DxLinkQuoteToken): Promise<void> {
    if (this.state === "ready" && this.ws?.readyState === WebSocket.OPEN) {
      return;
    }

    if (this.connectPromise) {
      return this.connectPromise;
    }

    this.quoteToken = quoteToken;
    this.state = "connecting";
    this.fieldMap.clear();
    this.allSubscribedSymbols.clear();
    this.totalSubscribedCount = 0;

    this.connectPromise = new Promise<void>((resolve, reject) => {
      let handshakeTimer: ReturnType<typeof setTimeout> | null = null;

      const cleanupHandshake = () => {
        if (handshakeTimer) {
          clearTimeout(handshakeTimer);
          handshakeTimer = null;
        }
      };

      handshakeTimer = setTimeout(() => {
        handshakeTimer = null;
        this.disconnect();
        reject(new Error("DxLink handshake timeout"));
      }, HANDSHAKE_TIMEOUT_MS);

      try {
        this.ws = new WebSocket(quoteToken.url);
      } catch (e: any) {
        cleanupHandshake();
        this.state = "disconnected";
        this.connectPromise = null;
        reject(new Error(`DxLink connect failed: ${e?.message}`));
        return;
      }

      this.ws.on("error", () => {
        cleanupHandshake();
        this.disconnect();
        reject(new Error("DxLink WebSocket error during connect"));
      });

      this.ws.on("close", () => {
        cleanupHandshake();
        this.state = "disconnected";
        this.connectPromise = null;
        if (this.keepaliveTimer) clearInterval(this.keepaliveTimer);
        const pending = [...this.pendingRequests];
        this.pendingRequests = [];
        for (const req of pending) {
          if (!req.done) {
            req.done = true;
            clearTimeout(req.timer);
            req.resolve(req.results);
          }
        }
      });

      this.ws.on("open", () => {
        this.ws!.send(
          JSON.stringify({
            type: "SETUP",
            channel: 0,
            version: "0.1-DXF-JS/0.3.0",
            keepaliveTimeout: 60,
            acceptKeepaliveTimeout: 60,
          })
        );
      });

      this.ws.on("message", (raw: WebSocket.Data) => {
        let msg: any;
        try {
          msg = JSON.parse(raw.toString());
        } catch {
          return;
        }

        if (msg.type === "AUTH_STATE" && msg.state !== "AUTHORIZED" && msg.state !== "UNAUTHORIZED") {
          cleanupHandshake();
          this.disconnect();
          reject(new Error(`DxLink auth failed: ${msg.state}`));
          return;
        }

        if (msg.type === "FEED_CONFIG" && msg.channel === 1 && this.state !== "ready") {
          cleanupHandshake();
          this.state = "ready";
          resolve();
        }

        this.handleMessage(msg);
      });
    }).finally(() => {
      this.connectPromise = null;
    });

    return this.connectPromise;
  }

  private handleMessage(msg: any) {
    if (msg.type === "SETUP") {
      this.ws!.send(
        JSON.stringify({
          type: "AUTH",
          channel: 0,
          token: this.quoteToken!.token,
        })
      );
    } else if (msg.type === "AUTH_STATE" && msg.state === "AUTHORIZED") {
      this.ws!.send(
        JSON.stringify({
          type: "CHANNEL_REQUEST",
          channel: 1,
          service: "FEED",
          parameters: { contract: "AUTO" },
        })
      );
    } else if (msg.type === "CHANNEL_OPENED" && msg.channel === 1) {
      const acceptEventFields: Record<string, string[]> = { ...ALL_EVENT_FIELDS };
      for (const [et, flds] of Object.entries(acceptEventFields)) {
        this.fieldMap.set(et, flds);
      }
      this.ws!.send(
        JSON.stringify({
          type: "FEED_SETUP",
          channel: 1,
          acceptAggregationPeriod: 0.1,
          acceptDataFormat: "COMPACT",
          acceptEventFields,
        })
      );
      this.keepaliveTimer = setInterval(() => {
        if (this.ws?.readyState === WebSocket.OPEN) {
          this.ws.send(JSON.stringify({ type: "KEEPALIVE", channel: 0 }));
        }
      }, 25000);
    } else if (msg.type === "FEED_CONFIG" && msg.channel === 1) {
      if (msg.eventFields) {
        for (const [et, flds] of Object.entries(msg.eventFields)) {
          if (Array.isArray(flds)) this.fieldMap.set(et, flds as string[]);
        }
      }
    } else if (msg.type === "FEED_DATA" && msg.channel === 1) {
      this.handleFeedData(msg.data);
    }
  }

  private handleFeedData(dataArr: any) {
    if (!Array.isArray(dataArr)) return;

    const snapshot = this.pendingRequests.length > 0 ? [...this.pendingRequests] : [];

    let i = 0;
    while (i < dataArr.length) {
      const eventType = dataArr[i];
      if (typeof eventType !== "string") {
        i++;
        continue;
      }
      const valuesArr = dataArr[i + 1];
      i += 2;
      if (!Array.isArray(valuesArr)) continue;

      const fields = this.fieldMap.get(eventType);
      if (!fields?.length) continue;

      const rows = parseCompactData(eventType, fields, valuesArr);
      for (const row of rows) {
        for (const req of snapshot) {
          if (req.done) continue;
          if (
            req.eventTypes.includes(eventType) &&
            req.symbols.includes(row.eventSymbol)
          ) {
            applyRow(req.results, row, eventType);
            req.receivedEvents.add(`${row.eventSymbol}:${eventType}`);
            if (req.receivedEvents.size >= req.expectedEvents) {
              this.finishRequest(req);
            }
          }
        }
      }
    }
  }

  private finishRequest(req: PendingRequest) {
    if (req.done) return;
    req.done = true;
    clearTimeout(req.timer);
    const idx = this.pendingRequests.indexOf(req);
    if (idx >= 0) this.pendingRequests.splice(idx, 1);
    req.resolve(req.results);
  }

  private pruneSubscriptionsIfNeeded() {
    if (this.totalSubscribedCount <= MAX_SUBSCRIBED_SYMBOLS) return;

    this.allSubscribedSymbols.clear();
    this.totalSubscribedCount = 0;

    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(
        JSON.stringify({
          type: "FEED_SUBSCRIPTION",
          channel: 1,
          reset: true,
          add: [],
        })
      );
    }
  }

  async requestSnapshots(
    symbols: string[],
    eventTypes: string[],
    timeoutMs: number = 8000
  ): Promise<Map<string, DxLinkSnapshot>> {
    if (!symbols.length) return new Map();
    if (this.state !== "ready" || !this.ws || this.ws.readyState !== WebSocket.OPEN) {
      throw new Error("DxLink not connected");
    }

    this.pruneSubscriptionsIfNeeded();

    const newSubs: Array<{ type: string; symbol: string }> = [];
    for (const sym of symbols) {
      for (const et of eventTypes) {
        const existing = this.allSubscribedSymbols.get(et);
        if (!existing || !existing.has(sym)) {
          newSubs.push({ type: et, symbol: sym });
          if (!this.allSubscribedSymbols.has(et)) {
            this.allSubscribedSymbols.set(et, new Set());
          }
          this.allSubscribedSymbols.get(et)!.add(sym);
          this.totalSubscribedCount++;
        }
      }
    }

    if (newSubs.length > 0) {
      this.ws.send(
        JSON.stringify({
          type: "FEED_SUBSCRIPTION",
          channel: 1,
          reset: false,
          add: newSubs,
        })
      );
    }

    return new Promise<Map<string, DxLinkSnapshot>>((resolve) => {
      const req: PendingRequest = {
        symbols,
        eventTypes,
        results: new Map(),
        receivedEvents: new Set(),
        expectedEvents: symbols.length * eventTypes.length,
        resolve,
        done: false,
        timer: setTimeout(() => {
          this.finishRequest(req);
        }, timeoutMs),
      };
      this.pendingRequests.push(req);
    });
  }

  disconnect() {
    this.state = "disconnected";
    if (this.keepaliveTimer) clearInterval(this.keepaliveTimer);
    try {
      if (this.ws?.readyState === WebSocket.OPEN) this.ws.close();
    } catch {}
    this.ws = null;
    this.fieldMap.clear();
    this.allSubscribedSymbols.clear();
    this.totalSubscribedCount = 0;
    const pending = [...this.pendingRequests];
    this.pendingRequests = [];
    for (const req of pending) {
      if (!req.done) {
        req.done = true;
        clearTimeout(req.timer);
        req.resolve(req.results);
      }
    }
  }

  get isConnected(): boolean {
    return this.state === "ready" && this.ws?.readyState === WebSocket.OPEN;
  }
}

let persistentClient: DxLinkPersistentClient | null = null;

export async function getOrCreateClient(
  quoteToken: DxLinkQuoteToken
): Promise<DxLinkPersistentClient> {
  if (persistentClient?.isConnected) {
    return persistentClient;
  }
  persistentClient = new DxLinkPersistentClient();
  await persistentClient.connect(quoteToken);
  return persistentClient;
}

export async function streamSnapshots(
  quoteToken: DxLinkQuoteToken,
  symbols: string[],
  eventTypes: string[],
  timeoutMs: number = 8000
): Promise<Map<string, DxLinkSnapshot>> {
  if (!symbols.length) return new Map();
  const client = await getOrCreateClient(quoteToken);
  return client.requestSnapshots(symbols, eventTypes, timeoutMs);
}
