/*
  Tastytrade OAuth2 broker adapter.
  Environment variables:
    TASTYTRADE_ENV            – "sandbox" or "production" (default: "sandbox")
    TASTYTRADE_BASE_URL       – override API base (auto-set from ENV if absent)
    TASTYTRADE_ACCOUNT_NUMBER – broker account id
    TASTYTRADE_CLIENT_ID      – OAuth2 client id
    TASTYTRADE_CLIENT_SECRET  – OAuth2 client secret
    TASTYTRADE_REFRESH_TOKEN  – OAuth2 refresh token (long-lived)
*/

import { fetchQuoteToken, streamSnapshots, type DxLinkSnapshot } from "./dxlink-client";
import https from "node:https";

type HeadersMap = Record<string, string>;

type NormalizedOrderStatus =
  | "received"
  | "working"
  | "filled"
  | "cancelled"
  | "rejected"
  | "unknown";

type NormalizedBrokerOrder = {
  id: string;
  status: NormalizedOrderStatus;
  filledQty: number;
  avgFillPrice: number;
  raw: any;
};

type QuoteResult = {
  symbol: string;
  mark?: number;
  last?: number;
  bid?: number;
  ask?: number;
  open?: number;
  close?: number;
  prevClose?: number;
  previousClose?: number;
};

const ENV_URLS: Record<string, string> = {
  sandbox: "https://api.cert.tastyworks.com",
  production: "https://api.tastyworks.com",
};

const TOKEN_URL: Record<string, string> = {
  sandbox: "https://api.cert.tastyworks.com/oauth/token",
  production: "https://api.tastyworks.com/oauth/token",
};

let cachedAccessToken: string | null = null;
let tokenExpiresAt = 0;
let tokenRefreshFailedUntil = 0;
let tokenRefreshInFlight: Promise<string> | null = null;

let cachedQuoteToken: { token: string; url: string } | null = null;
let quoteTokenExpiresAt = 0;
let restMarketDataAvailable: boolean | null = null;

export class TastytradeBroker {
  private readonly env: string;
  private readonly baseUrl: string;
  private readonly accountNumber: string;
  private readonly clientId: string;
  private readonly clientSecret: string;
  private readonly refreshToken: string;

  constructor() {
    this.env = (process.env.TASTYTRADE_ENV || "production").toLowerCase();
    this.baseUrl =
      process.env.TASTYTRADE_BASE_URL || ENV_URLS[this.env] || ENV_URLS.sandbox;
    this.accountNumber = process.env.TASTYTRADE_ACCOUNT_NUMBER || "";
    this.clientId = process.env.TASTYTRADE_CLIENT_ID || "";
    this.clientSecret = process.env.TASTYTRADE_CLIENT_SECRET || "";
    this.refreshToken = process.env.TASTYTRADE_REFRESH_TOKEN || "";
  }

  async warmupToken(retries = 3, delayMs = 3000): Promise<boolean> {
    for (let i = 0; i < retries; i++) {
      try {
        tokenRefreshFailedUntil = 0;
        await this.getAccessToken();
        return true;
      } catch {
        if (i < retries - 1) {
          await new Promise((r) => setTimeout(r, delayMs));
        }
      }
    }
    return false;
  }

  private get hasOAuth(): boolean {
    return !!(this.clientId && this.clientSecret && this.refreshToken);
  }

  private async getAccessToken(): Promise<string> {
    if (cachedAccessToken && Date.now() < tokenExpiresAt) {
      return cachedAccessToken;
    }

    if (Date.now() < tokenRefreshFailedUntil) {
      throw new Error("TastyTrade token refresh on cooldown after recent failure");
    }

    if (tokenRefreshInFlight) {
      return tokenRefreshInFlight;
    }

    if (!this.hasOAuth) {
      throw new Error(
        "TastyTrade OAuth2 credentials not configured. " +
        "Set TASTYTRADE_CLIENT_ID, TASTYTRADE_CLIENT_SECRET, and TASTYTRADE_REFRESH_TOKEN."
      );
    }

    tokenRefreshInFlight = this._doTokenRefresh();
    try {
      return await tokenRefreshInFlight;
    } finally {
      tokenRefreshInFlight = null;
    }
  }

  private async _doTokenRefresh(): Promise<string> {
    const tokenUrl = TOKEN_URL[this.env] || TOKEN_URL.sandbox;

    const payload = JSON.stringify({
      grant_type: "refresh_token",
      client_secret: this.clientSecret,
      refresh_token: this.refreshToken,
    });

    let data: any;
    try {
      const raw = await new Promise<string>((resolve, reject) => {
        const url = new URL(tokenUrl);
        const req = https.request(
          {
            hostname: url.hostname,
            port: 443,
            path: url.pathname,
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Accept": "application/json",
              "User-Agent": "InstitutionalScannerPro/1.0",
              "Content-Length": Buffer.byteLength(payload),
            },
          },
          (res) => {
            let body = "";
            res.on("data", (chunk: Buffer) => (body += chunk.toString()));
            res.on("end", () => {
              if (res.statusCode && res.statusCode >= 200 && res.statusCode < 300) {
                resolve(body);
              } else {
                reject(new Error(`HTTP ${res.statusCode}: ${body.slice(0, 200)}`));
              }
            });
          },
        );
        req.on("error", reject);
        req.write(payload);
        req.end();
      });
      data = JSON.parse(raw);
    } catch (err: any) {
      cachedAccessToken = null;
      tokenExpiresAt = 0;
      tokenRefreshFailedUntil = Date.now() + 5_000;
      console.error(`[TT] token refresh error: ${err?.message || err}`);
      throw new Error(`TastyTrade OAuth2 token refresh failed: ${err?.message || err}`);
    }
    const accessToken = data?.access_token ?? data?.data?.["session-token"] ?? "";
    const expiresIn = data?.expires_in ?? 86400;

    if (!accessToken) {
      throw new Error("TastyTrade OAuth2 response missing access_token");
    }

    cachedAccessToken = accessToken;
    tokenExpiresAt = Date.now() + (expiresIn - 60) * 1000;
    tokenRefreshFailedUntil = 0;

    return accessToken;
  }

  private async headers(): Promise<HeadersMap> {
    const token = await this.getAccessToken();
    return {
      "Content-Type": "application/json",
      Accept: "application/json",
      Authorization: `Bearer ${token}`,
      "User-Agent": "InstitutionalScannerPro/1.0",
    };
  }

  private async request(method: string, path: string, body?: any, opts?: { timeoutMs?: number; maxAttempts?: number }): Promise<any> {
    const url = `${this.baseUrl}${path}`;
    const isMarketData = path.includes("/market-data") || path.includes("/option-chains");
    const maxAttempts = opts?.maxAttempts ?? (isMarketData ? 1 : 3);
    const timeoutMs = opts?.timeoutMs ?? (isMarketData ? 8000 : 20000);
    const retryableStatuses = [429, 500, 502, 503, 504];

    for (let attempt = 0; attempt < maxAttempts; attempt++) {
      const hdrs = await this.headers();
      const fetchOpts: RequestInit = { method, headers: hdrs };
      if (body) fetchOpts.body = JSON.stringify(body);

      let r: Response;
      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), timeoutMs);
        r = await fetch(url, { ...fetchOpts, signal: controller.signal });
        clearTimeout(timer);
      } catch (e: any) {
        const isAbort = e?.name === "AbortError" || e?.message?.includes("aborted");
        if (!isAbort && attempt < maxAttempts - 1) {
          await new Promise(res => setTimeout(res, 500 * (attempt + 1)));
          continue;
        }
        throw new Error(`Tastytrade ${method} ${path} network error: ${e?.message || e}`);
      }

      if (r.ok) return r.json().catch(() => ({}));

      if (r.status === 401 && cachedAccessToken) {
        cachedAccessToken = null;
        tokenExpiresAt = 0;
        continue;
      }

      if (retryableStatuses.includes(r.status) && attempt < maxAttempts - 1) {
        await new Promise(res => setTimeout(res, 600 * (attempt + 1)));
        continue;
      }

      const text = await r.text().catch(() => "");
      throw new Error(`Tastytrade ${method} ${path} failed ${r.status}: ${text}`);
    }

    throw new Error(`Tastytrade ${method} ${path} failed after ${maxAttempts} attempts`);
  }

  private safeNum(v: any, fallback = 0) {
    const n = Number(v);
    return Number.isFinite(n) ? n : fallback;
  }

  private extractOrderId(body: any): string | undefined {
    const id =
      body?.data?.order?.id ??
      body?.data?.id ??
      body?.order?.id ??
      body?.id ??
      "";
    return id ? String(id) : undefined;
  }

  normalizeOrderStatus(raw: any): NormalizedOrderStatus {
    const s = String(raw?.status ?? raw?.state ?? "").toLowerCase();

    if (["received", "queued", "routing"].includes(s)) return "received";
    if (["working", "live", "open"].includes(s)) return "working";
    if (["filled", "executed", "complete", "completed"].includes(s)) {
      return "filled";
    }
    if (["cancelled", "canceled", "expired"].includes(s)) return "cancelled";
    if (["rejected", "failed", "error"].includes(s)) return "rejected";
    return "unknown";
  }

  normalizeOrder(raw: any): NormalizedBrokerOrder {
    return {
      id: String(raw?.id ?? raw?.order_id ?? ""),
      status: this.normalizeOrderStatus(raw),
      filledQty: Math.abs(
        this.safeNum(
          raw?.filled_quantity ??
            raw?.filled_qty ??
            raw?.quantity ??
            raw?.qty ??
            0,
          0,
        ),
      ),
      avgFillPrice: this.safeNum(
        raw?.avg_fill_price ??
          raw?.average_fill_price ??
          raw?.filled_avg_price ??
          raw?.price ??
          0,
        0,
      ),
      raw,
    };
  }

  credentialsConfigured(): { ok: boolean; missing: string[] } {
    const missing: string[] = [];
    if (!this.accountNumber) missing.push("TASTYTRADE_ACCOUNT_NUMBER");
    if (!this.clientId) missing.push("TASTYTRADE_CLIENT_ID");
    if (!this.clientSecret) missing.push("TASTYTRADE_CLIENT_SECRET");
    if (!this.refreshToken) missing.push("TASTYTRADE_REFRESH_TOKEN");
    return { ok: missing.length === 0, missing };
  }

  async health() {
    const creds = this.credentialsConfigured();
    if (!creds.ok) return { ok: false, reason: "missing_credentials", missing: creds.missing, env: this.env };
    try {
      const r = await this.request("GET", `/accounts/${this.accountNumber}/balances`);
      return { ok: true, env: this.env, balances: r?.data ?? r };
    } catch (e: any) {
      return { ok: false, reason: String(e?.message || e), env: this.env };
    }
  }

  async getBalances() {
    return this.request("GET", `/accounts/${this.accountNumber}/balances`);
  }

  async getPositions() {
    return this.request("GET", `/accounts/${this.accountNumber}/positions`);
  }

  async getOrders() {
    return this.request("GET", `/accounts/${this.accountNumber}/orders/live`);
  }

  async getOrder(orderId: string): Promise<any> {
    const res = await this.request(
      "GET",
      `/accounts/${this.accountNumber}/orders/${orderId}`,
    );
    return res?.data ?? res;
  }

  async getNormalizedOrder(orderId: string): Promise<NormalizedBrokerOrder> {
    const raw = await this.getOrder(orderId);
    return this.normalizeOrder(raw);
  }

  async getOrderStatus(orderId: string): Promise<NormalizedBrokerOrder | null> {
    try {
      return await this.getNormalizedOrder(orderId);
    } catch {
      return null;
    }
  }

  async submitVerticalCreditSpread(input: {
    ticker: string;
    expiration: string;
    shortStrike: number;
    longStrike: number;
    quantity: number;
    limitPrice: number;
  }) {
    const payload = {
      order_type: "Limit",
      price: input.limitPrice.toFixed(2),
      time_in_force: "Day",
      legs: [
        {
          instrument_type: "Equity Option",
          action: "Sell to Open",
          symbol: input.ticker,
          quantity: input.quantity,
          expiration_date: input.expiration,
          strike_price: input.shortStrike,
          option_type: "P",
        },
        {
          instrument_type: "Equity Option",
          action: "Buy to Open",
          symbol: input.ticker,
          quantity: input.quantity,
          expiration_date: input.expiration,
          strike_price: input.longStrike,
          option_type: "P",
        },
      ],
    };

    const body = await this.request(
      "POST",
      `/accounts/${this.accountNumber}/orders`,
      payload,
    );

    const brokerOrderId = this.extractOrderId(body);
    const status = String(
      body?.data?.order?.status ?? body?.data?.status ?? body?.status ?? "submitted",
    ).toLowerCase();

    return {
      ok: !!brokerOrderId,
      brokerOrderId,
      status,
      body,
    };
  }

  async submitCloseVerticalSpread(input: {
    ticker: string;
    expiration: string;
    shortStrike: number;
    longStrike: number;
    quantity: number;
    limitPrice: number;
  }) {
    const payload = {
      order_type: "Limit",
      price: input.limitPrice.toFixed(2),
      time_in_force: "Day",
      legs: [
        {
          instrument_type: "Equity Option",
          action: "Buy to Close",
          symbol: input.ticker,
          quantity: input.quantity,
          expiration_date: input.expiration,
          strike_price: input.shortStrike,
          option_type: "P",
        },
        {
          instrument_type: "Equity Option",
          action: "Sell to Close",
          symbol: input.ticker,
          quantity: input.quantity,
          expiration_date: input.expiration,
          strike_price: input.longStrike,
          option_type: "P",
        },
      ],
    };

    const body = await this.request(
      "POST",
      `/accounts/${this.accountNumber}/orders`,
      payload,
    );

    const brokerOrderId = this.extractOrderId(body);
    const status = String(
      body?.data?.order?.status ?? body?.data?.status ?? body?.status ?? "submitted",
    ).toLowerCase();

    return {
      ok: !!brokerOrderId,
      brokerOrderId,
      status,
      body,
    };
  }

  async getQuote(symbol: string): Promise<QuoteResult> {
    try {
      const res = await this.request("GET", `/market-data/quotes/${symbol}`);
      const body = res?.data ?? res ?? {};

      return {
        symbol,
        mark: this.safeNum(
          body?.mark ?? body?.mark_price,
          undefined as any,
        ),
        last: this.safeNum(
          body?.last ?? body?.last_price,
          undefined as any,
        ),
        bid: this.safeNum(body?.bid, undefined as any),
        ask: this.safeNum(body?.ask, undefined as any),
        open: this.safeNum(
          body?.open ?? body?.open_price,
          undefined as any,
        ),
        close: this.safeNum(
          body?.close ?? body?.close_price,
          undefined as any,
        ),
        prevClose: this.safeNum(
          body?.prevClose ?? body?.prev_close ?? body?.previous_close,
          undefined as any,
        ),
        previousClose: this.safeNum(
          body?.previousClose ?? body?.previous_close ?? body?.prev_close,
          undefined as any,
        ),
      };
    } catch {
      return { symbol };
    }
  }

  private async getQuoteToken(): Promise<{ token: string; url: string }> {
    if (cachedQuoteToken && Date.now() < quoteTokenExpiresAt) {
      return cachedQuoteToken;
    }
    const accessToken = await this.getAccessToken();
    const qt = await fetchQuoteToken(this.baseUrl, accessToken);
    if (!qt.token || !qt.url) {
      throw new Error("Failed to get DxLink quote token");
    }
    cachedQuoteToken = qt;
    quoteTokenExpiresAt = Date.now() + 23 * 3600 * 1000;
    return qt;
  }

  private async tryRestMarketData(path: string): Promise<any | null> {
    if (restMarketDataAvailable === false) return null;
    try {
      const res = await this.request("GET", path);
      restMarketDataAvailable = true;
      return res;
    } catch (e: any) {
      if (e?.message?.includes("503") || e?.message?.includes("502")) {
        restMarketDataAvailable = false;
        return null;
      }
      throw e;
    }
  }

  private snapshotToQuoteObj(symbol: string, snap: DxLinkSnapshot): any {
    return {
      symbol,
      "instrument-type": "Equity",
      bid: snap.quote?.bidPrice ?? null,
      ask: snap.quote?.askPrice ?? null,
      mid:
        snap.quote?.bidPrice != null && snap.quote?.askPrice != null
          ? (snap.quote.bidPrice + snap.quote.askPrice) / 2
          : null,
      mark:
        snap.quote?.bidPrice != null && snap.quote?.askPrice != null
          ? (snap.quote.bidPrice + snap.quote.askPrice) / 2
          : null,
      last: snap.trade?.price ?? null,
      close: snap.summary?.prevDayClosePrice ?? null,
      "prev-close": snap.summary?.prevDayClosePrice ?? null,
      volume: snap.trade?.dayVolume ?? null,
      "day-high-price": snap.summary?.dayHighPrice ?? null,
      "day-low-price": snap.summary?.dayLowPrice ?? null,
    };
  }

  private snapshotToOptionObj(symbol: string, snap: DxLinkSnapshot): any {
    return {
      symbol,
      "instrument-type": "Equity Option",
      bid: snap.quote?.bidPrice ?? null,
      ask: snap.quote?.askPrice ?? null,
      mid:
        snap.quote?.bidPrice != null && snap.quote?.askPrice != null
          ? (snap.quote.bidPrice + snap.quote.askPrice) / 2
          : null,
      last: snap.trade?.price ?? null,
      delta: snap.greeks?.delta ?? null,
      gamma: snap.greeks?.gamma ?? null,
      theta: snap.greeks?.theta ?? null,
      vega: snap.greeks?.vega ?? null,
      "implied-volatility": snap.greeks?.volatility ?? null,
      "open-interest": snap.summary?.openInterest ?? null,
      "prev-close": snap.summary?.prevDayClosePrice ?? null,
      volume: snap.trade?.dayVolume ?? null,
    };
  }

  async getEquityQuotes(symbols: string[]): Promise<any[]> {
    if (!symbols.length) return [];

    const batchSize = 20;
    const firstBatch = symbols.slice(0, batchSize);
    const restResult = await this.tryRestMarketData(
      `/market-data/by-type?equity=${firstBatch.join(",")}`
    );

    if (restResult && restMarketDataAvailable) {
      const allResults: any[] = [...(restResult?.data?.items ?? [])];
      for (let i = batchSize; i < symbols.length; i += batchSize) {
        const batch = symbols.slice(i, i + batchSize);
        const res = await this.request("GET", `/market-data/by-type?equity=${batch.join(",")}`);
        allResults.push(...(res?.data?.items ?? []));
      }
      return allResults;
    }

    try {
      const dxlinkResult = await Promise.race([
        (async () => {
          const qt = await this.getQuoteToken();
          return streamSnapshots(qt, symbols, ["Quote", "Trade", "Summary"], 8000);
        })(),
        new Promise<Map<string, any>>((_, reject) =>
          setTimeout(() => reject(new Error("dxlink_equity_quotes_timeout")), 12000)
        ),
      ]);
      return symbols
        .filter((s) => dxlinkResult.has(s))
        .map((s) => this.snapshotToQuoteObj(s, dxlinkResult.get(s)!));
    } catch {
      return [];
    }
  }

  async getIndexQuote(symbol: string): Promise<any> {
    const restResult = await this.tryRestMarketData(
      `/market-data/by-type?index=${symbol}`
    );
    if (restResult) {
      const items = restResult?.data?.items ?? [];
      return items[0] ?? null;
    }

    try {
      const dxResult = await Promise.race([
        (async () => {
          const qt = await this.getQuoteToken();
          return streamSnapshots(qt, [symbol], ["Quote", "Trade", "Summary"], 6000);
        })(),
        new Promise<Map<string, any>>((_, reject) =>
          setTimeout(() => reject(new Error("dxlink_index_timeout")), 10000)
        ),
      ]);
      const snap = dxResult.get(symbol);
      if (!snap) return null;
      return this.snapshotToQuoteObj(symbol, snap);
    } catch {
      return null;
    }
  }

  async getOptionChainNested(underlyingSymbol: string): Promise<any> {
    return this.request(
      "GET",
      `/option-chains/${encodeURIComponent(underlyingSymbol)}/nested`
    );
  }

  async getOptionQuotes(
    optionSymbols: string[],
    streamerSymbolsHint?: string[]
  ): Promise<any[]> {
    if (!optionSymbols.length) return [];

    const restResult = await this.tryRestMarketData(
      `/market-data/by-type?equity-option=${optionSymbols
        .slice(0, 20)
        .map((s) => encodeURIComponent(s))
        .join(",")}`
    );

    if (restResult && restMarketDataAvailable) {
      const allResults: any[] = [];
      const batchSize = 20;
      allResults.push(...(restResult?.data?.items ?? []));
      for (let i = batchSize; i < optionSymbols.length; i += batchSize) {
        const batch = optionSymbols.slice(i, i + batchSize);
        const encoded = batch.map((s) => encodeURIComponent(s)).join(",");
        const res = await this.request(
          "GET",
          `/market-data/by-type?equity-option=${encoded}`
        );
        allResults.push(...(res?.data?.items ?? []));
      }
      return allResults;
    }

    try {
      const dxlinkResult = await Promise.race([
        (async () => {
          const qt = await this.getQuoteToken();

          const convertOccToStreamer = (s: string): string => {
            const match = s.match(/^(\w+)\s+(\d{6})([CP])(\d{8})$/);
            if (match) {
              const [, root, dateStr, cp, priceStr] = match;
              const yr = dateStr.slice(0, 2);
              const mo = dateStr.slice(2, 4);
              const dy = dateStr.slice(4, 6);
              const strike = parseInt(priceStr, 10) / 1000;
              const strikeStr =
                strike % 1 === 0
                  ? String(strike)
                  : strike.toFixed(strike % 0.5 === 0 ? 1 : 2);
              return `.${root}${yr}${mo}${dy}${cp}${strikeStr}`;
            }
            return s;
          };

          const streamerSymbols = optionSymbols.map((occ, i) => {
            const hint = streamerSymbolsHint?.[i];
            return hint && hint.length > 0 ? hint : convertOccToStreamer(occ);
          });

          const symMap = new Map<string, string>();
          for (let i = 0; i < optionSymbols.length; i++) {
            symMap.set(streamerSymbols[i], optionSymbols[i]);
          }

          const batchSize = 100;
          const allResults: any[] = [];

          for (let i = 0; i < streamerSymbols.length; i += batchSize) {
            const batch = streamerSymbols.slice(i, i + batchSize);
            const snapshots = await streamSnapshots(
              qt,
              batch,
              ["Quote", "Greeks", "Summary", "Trade"],
              6000
            );
            snapshots.forEach((snap, streamerSym) => {
              const origSym = symMap.get(streamerSym) ?? streamerSym;
              allResults.push(this.snapshotToOptionObj(origSym, snap));
            });
          }

          return allResults;
        })(),
        new Promise<any[]>((_, reject) =>
          setTimeout(() => reject(new Error("dxlink_option_quotes_timeout")), 15000)
        ),
      ]);
      return dxlinkResult;
    } catch {
      return [];
    }
  }

  async cancelOrder(orderId: string): Promise<any> {
    return await this.request(
      "DELETE",
      `/accounts/${this.accountNumber}/orders/${orderId}`,
    );
  }

  async cancelAllOrders(): Promise<any[]> {
    const orders = await this.getOrders();
    const items = Array.isArray((orders as any)?.items)
      ? (orders as any).items
      : Array.isArray(orders)
        ? (orders as any)
        : [];

    const results = [];
    for (const o of items) {
      const id = String(o?.id ?? o?.order_id ?? "");
      if (!id) continue;
      try {
        results.push(await this.cancelOrder(id));
      } catch (e: any) {
        results.push({ id, error: String(e?.message || e) });
      }
    }
    return results;
  }

  async flattenSymbol(symbol: string): Promise<any> {
    const positions = await this.getPositions();
    const items = Array.isArray((positions as any)?.items)
      ? (positions as any).items
      : Array.isArray(positions)
        ? (positions as any)
        : [];

    const matching = items.filter((p: any) => {
      const sym =
        p?.symbol ??
        p?.underlying_symbol ??
        p?.instrument?.underlying_symbol ??
        "";
      return String(sym).toUpperCase() === String(symbol).toUpperCase();
    });

    return {
      symbol,
      brokerPositions: matching,
    };
  }
}
