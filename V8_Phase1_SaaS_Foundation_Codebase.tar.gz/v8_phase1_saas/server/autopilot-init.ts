import type { Express } from "express";
import { autopilotEngine, registerAutopilotRoutes } from "./services/v8/autopilot-engine";

export async function initAutopilot(app: Express) {
  registerAutopilotRoutes(app);
  await autopilotEngine.init();
  if (process.env.AUTOPILOT_AUTO_START === "true" || autopilotEngine.enabled) {
    await autopilotEngine.start();
  }
}
