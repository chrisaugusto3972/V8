import { positions, journalEntries, scannerSettings, type Position, type InsertPosition, type JournalEntry, type InsertJournalEntry, type ScannerSettings, type InsertScannerSettings } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getPositions(): Promise<Position[]>;
  getPosition(id: string): Promise<Position | undefined>;
  createPosition(position: InsertPosition): Promise<Position>;
  deletePosition(id: string): Promise<void>;
  updatePositionStatus(id: string, status: string): Promise<void>;

  getJournalEntries(): Promise<JournalEntry[]>;
  createJournalEntry(entry: InsertJournalEntry): Promise<JournalEntry>;

  getSettings(): Promise<ScannerSettings | undefined>;
  upsertSettings(settings: Partial<InsertScannerSettings>): Promise<ScannerSettings>;
}

export class DatabaseStorage implements IStorage {
  async getPositions(): Promise<Position[]> {
    return db.select().from(positions);
  }

  async getPosition(id: string): Promise<Position | undefined> {
    const [result] = await db.select().from(positions).where(eq(positions.id, id));
    return result;
  }

  async createPosition(position: InsertPosition): Promise<Position> {
    const [result] = await db.insert(positions).values(position).returning();
    return result;
  }

  async deletePosition(id: string): Promise<void> {
    await db.delete(positions).where(eq(positions.id, id));
  }

  async updatePositionStatus(id: string, status: string): Promise<void> {
    await db.update(positions).set({ status }).where(eq(positions.id, id));
  }

  async getJournalEntries(): Promise<JournalEntry[]> {
    return db.select().from(journalEntries);
  }

  async createJournalEntry(entry: InsertJournalEntry): Promise<JournalEntry> {
    const [result] = await db.insert(journalEntries).values(entry).returning();
    return result;
  }

  async getSettings(): Promise<ScannerSettings | undefined> {
    const results = await db.select().from(scannerSettings);
    return results[0];
  }

  async upsertSettings(updates: Partial<InsertScannerSettings>): Promise<ScannerSettings> {
    const existing = await this.getSettings();
    if (existing) {
      const [result] = await db.update(scannerSettings).set(updates).where(eq(scannerSettings.id, existing.id)).returning();
      return result;
    } else {
      const [result] = await db.insert(scannerSettings).values(updates as InsertScannerSettings).returning();
      return result;
    }
  }
}

export const storage = new DatabaseStorage();
