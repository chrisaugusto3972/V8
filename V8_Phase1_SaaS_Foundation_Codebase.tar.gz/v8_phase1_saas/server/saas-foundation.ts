
import type { Request, Response, NextFunction, Express } from "express";
import session from "express-session";
import MemoryStoreFactory from "memorystore";
import { randomUUID } from "crypto";

type User = {
  id: string;
  email: string;
  password: string;
  name: string;
  createdAt: string;
};

type Workspace = {
  id: string;
  userId: string;
  name: string;
  createdAt: string;
};

type Account = {
  id: string;
  workspaceId: string;
  name: string;
  platform: "paper" | "tastytrade";
  mode: "manual" | "assisted" | "paper_autopilot";
  createdAt: string;
};

const MemoryStore = MemoryStoreFactory(session);

export function registerSaasSession(app: Express) {
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "v8-phase1-dev-secret",
      resave: false,
      saveUninitialized: false,
      cookie: {
        maxAge: 1000 * 60 * 60 * 24 * 14,
      },
      store: new MemoryStore({
        checkPeriod: 1000 * 60 * 60 * 24,
      }),
    }),
  );
}

declare module "express-session" {
  interface SessionData {
    userId?: string;
    currentWorkspaceId?: string;
    currentAccountId?: string;
  }
}

const users: User[] = [];
const workspaces: Workspace[] = [];
const accounts: Account[] = [];

function seedDemoUser() {
  if (users.length > 0) return;
  const userId = randomUUID();
  const workspaceId = randomUUID();
  const accountId = randomUUID();

  users.push({
    id: userId,
    email: "demo@v8saas.local",
    password: "demo123",
    name: "Demo User",
    createdAt: new Date().toISOString(),
  });

  workspaces.push({
    id: workspaceId,
    userId,
    name: "Demo Workspace",
    createdAt: new Date().toISOString(),
  });

  accounts.push({
    id: accountId,
    workspaceId,
    name: "Paper Account",
    platform: "paper",
    mode: "paper_autopilot",
    createdAt: new Date().toISOString(),
  });
}

function requireAuth(req: Request, res: Response, next: NextFunction) {
  seedDemoUser();
  if (!req.session.userId) {
    return res.status(401).json({ ok: false, message: "Unauthorized" });
  }
  next();
}

function getUserContext(req: Request) {
  const user = users.find((u) => u.id === req.session.userId) || null;
  const userWorkspaces = workspaces.filter((w) => w.userId === req.session.userId);
  const currentWorkspace =
    userWorkspaces.find((w) => w.id === req.session.currentWorkspaceId) ||
    userWorkspaces[0] ||
    null;

  const workspaceAccounts = currentWorkspace
    ? accounts.filter((a) => a.workspaceId === currentWorkspace.id)
    : [];

  const currentAccount =
    workspaceAccounts.find((a) => a.id === req.session.currentAccountId) ||
    workspaceAccounts[0] ||
    null;

  return {
    user,
    workspaces: userWorkspaces,
    currentWorkspace,
    accounts: workspaceAccounts,
    currentAccount,
  };
}

export function registerSaasFoundationRoutes(app: Express) {
  seedDemoUser();

  app.get("/api/auth/me", (req, res) => {
    if (!req.session.userId) {
      return res.json({ ok: true, authenticated: false });
    }

    const ctx = getUserContext(req);
    return res.json({
      ok: true,
      authenticated: true,
      user: ctx.user,
      currentWorkspace: ctx.currentWorkspace,
      currentAccount: ctx.currentAccount,
    });
  });

  app.post("/api/auth/login", (req, res) => {
    seedDemoUser();
    const email = String(req.body?.email || "").trim().toLowerCase();
    const password = String(req.body?.password || "");

    const user = users.find((u) => u.email.toLowerCase() === email && u.password === password);
    if (!user) {
      return res.status(401).json({ ok: false, message: "Invalid credentials" });
    }

    req.session.userId = user.id;

    const firstWorkspace = workspaces.find((w) => w.userId === user.id) || null;
    req.session.currentWorkspaceId = firstWorkspace?.id;

    const firstAccount = firstWorkspace
      ? accounts.find((a) => a.workspaceId === firstWorkspace.id) || null
      : null;
    req.session.currentAccountId = firstAccount?.id;

    return res.json({
      ok: true,
      authenticated: true,
      user,
      currentWorkspace: firstWorkspace,
      currentAccount: firstAccount,
    });
  });

  app.post("/api/auth/register", (req, res) => {
    const email = String(req.body?.email || "").trim().toLowerCase();
    const password = String(req.body?.password || "");
    const name = String(req.body?.name || "").trim() || "New User";
    const workspaceName = String(req.body?.workspaceName || "").trim() || `${name}'s Workspace`;

    if (!email || !password) {
      return res.status(400).json({ ok: false, message: "Email and password are required" });
    }

    if (users.some((u) => u.email.toLowerCase() === email)) {
      return res.status(409).json({ ok: false, message: "Email already exists" });
    }

    const userId = randomUUID();
    const workspaceId = randomUUID();
    const accountId = randomUUID();

    const user: User = {
      id: userId,
      email,
      password,
      name,
      createdAt: new Date().toISOString(),
    };

    const workspace: Workspace = {
      id: workspaceId,
      userId,
      name: workspaceName,
      createdAt: new Date().toISOString(),
    };

    const account: Account = {
      id: accountId,
      workspaceId,
      name: "Paper Account",
      platform: "paper",
      mode: "manual",
      createdAt: new Date().toISOString(),
    };

    users.push(user);
    workspaces.push(workspace);
    accounts.push(account);

    req.session.userId = user.id;
    req.session.currentWorkspaceId = workspace.id;
    req.session.currentAccountId = account.id;

    return res.json({
      ok: true,
      authenticated: true,
      user,
      currentWorkspace: workspace,
      currentAccount: account,
    });
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy(() => {
      res.json({ ok: true });
    });
  });

  app.get("/api/saas/workspaces", requireAuth, (req, res) => {
    const ctx = getUserContext(req);
    res.json({
      ok: true,
      workspaces: ctx.workspaces,
      currentWorkspace: ctx.currentWorkspace,
    });
  });

  app.post("/api/saas/workspaces", requireAuth, (req, res) => {
    const name = String(req.body?.name || "").trim() || "New Workspace";
    const workspace: Workspace = {
      id: randomUUID(),
      userId: String(req.session.userId),
      name,
      createdAt: new Date().toISOString(),
    };
    workspaces.push(workspace);
    req.session.currentWorkspaceId = workspace.id;
    res.json({ ok: true, workspace });
  });

  app.get("/api/saas/accounts", requireAuth, (req, res) => {
    const ctx = getUserContext(req);
    res.json({
      ok: true,
      accounts: ctx.accounts,
      currentAccount: ctx.currentAccount,
    });
  });

  app.post("/api/saas/accounts", requireAuth, (req, res) => {
    const ctx = getUserContext(req);
    if (!ctx.currentWorkspace) {
      return res.status(400).json({ ok: false, message: "No workspace selected" });
    }

    const name = String(req.body?.name || "").trim() || "New Account";
    const platform = req.body?.platform === "tastytrade" ? "tastytrade" : "paper";
    const mode =
      req.body?.mode === "assisted" || req.body?.mode === "paper_autopilot"
        ? req.body.mode
        : "manual";

    const account: Account = {
      id: randomUUID(),
      workspaceId: ctx.currentWorkspace.id,
      name,
      platform,
      mode,
      createdAt: new Date().toISOString(),
    };

    accounts.push(account);
    req.session.currentAccountId = account.id;
    res.json({ ok: true, account });
  });

  app.patch("/api/saas/current-account", requireAuth, (req, res) => {
    const accountId = String(req.body?.accountId || "");
    const ctx = getUserContext(req);
    const account = ctx.accounts.find((a) => a.id === accountId);
    if (!account) {
      return res.status(404).json({ ok: false, message: "Account not found" });
    }
    req.session.currentAccountId = account.id;
    res.json({ ok: true, currentAccount: account });
  });

  app.patch("/api/saas/current-workspace", requireAuth, (req, res) => {
    const workspaceId = String(req.body?.workspaceId || "");
    const ctx = getUserContext(req);
    const workspace = ctx.workspaces.find((w) => w.id === workspaceId);
    if (!workspace) {
      return res.status(404).json({ ok: false, message: "Workspace not found" });
    }
    req.session.currentWorkspaceId = workspace.id;
    const workspaceAccounts = accounts.filter((a) => a.workspaceId === workspace.id);
    req.session.currentAccountId = workspaceAccounts[0]?.id;
    res.json({
      ok: true,
      currentWorkspace: workspace,
      currentAccount: workspaceAccounts[0] || null,
    });
  });

  app.get("/api/saas/platforms", (_req, res) => {
    res.json({
      ok: true,
      platforms: [
        {
          id: "paper",
          name: "Paper Account",
          status: "supported",
          readOnlySync: false,
          assistedExecution: false,
          paperAutopilotCompatible: true,
          liveAutopilotCompatible: false,
        },
        {
          id: "tastytrade",
          name: "Tastytrade",
          status: "supported",
          readOnlySync: true,
          assistedExecution: true,
          paperAutopilotCompatible: true,
          liveAutopilotCompatible: false,
        },
        {
          id: "ibkr",
          name: "Interactive Brokers",
          status: "coming_soon",
          readOnlySync: false,
          assistedExecution: false,
          paperAutopilotCompatible: false,
          liveAutopilotCompatible: false,
        },
        {
          id: "tradier",
          name: "Tradier",
          status: "coming_soon",
          readOnlySync: false,
          assistedExecution: false,
          paperAutopilotCompatible: false,
          liveAutopilotCompatible: false,
        },
      ],
    });
  });
}
