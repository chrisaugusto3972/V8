import { desc, gte, sql } from "drizzle-orm";
import { db } from "../../db";
import { positions, systemEvents } from "@shared/schema";

function safeNum(v: any, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

type BucketStats = {
  count: number;
  wins: number;
  losses: number;
  pnl: number;
};

function addBucket(map: Map<string, BucketStats>, key: string, pnl: number) {
  if (!map.has(key)) {
    map.set(key, { count: 0, wins: 0, losses: 0, pnl: 0 });
  }
  const bucket = map.get(key)!;
  bucket.count += 1;
  bucket.pnl += pnl;
  if (pnl >= 0) bucket.wins += 1;
  else bucket.losses += 1;
}

function deltaBucket(delta: number) {
  if (delta < 0.10) return "<0.10";
  if (delta < 0.15) return "0.10-0.15";
  if (delta < 0.20) return "0.15-0.20";
  if (delta < 0.30) return "0.20-0.30";
  return "0.30+";
}

function dteBucket(dte: number) {
  if (dte <= 7) return "<=7";
  if (dte <= 10) return "8-10";
  if (dte <= 14) return "11-14";
  if (dte <= 21) return "15-21";
  return "22+";
}

function widthBucket(width: number) {
  if (width <= 1) return "1";
  if (width <= 2) return "2";
  if (width <= 3) return "3";
  return "4+";
}

export type FeedbackReport = {
  totalTrades: number;
  totalPnl: number;
  winRate: number;
  byTicker: Record<string, BucketStats>;
  bySector: Record<string, BucketStats>;
  byDelta: Record<string, BucketStats>;
  byDte: Record<string, BucketStats>;
  byWidth: Record<string, BucketStats>;
};

export async function generatePerformanceFeedback(
  days = 60,
): Promise<FeedbackReport> {
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();

  const closed = await db
    .select()
    .from(positions)
    .where(
      sql`${positions.status} = 'closed' and ${positions.closedAt} is not null and ${positions.closedAt} >= ${since}`,
    )
    .orderBy(desc(positions.closedAt));

  const byTicker = new Map<string, BucketStats>();
  const bySector = new Map<string, BucketStats>();
  const byDelta = new Map<string, BucketStats>();
  const byDte = new Map<string, BucketStats>();
  const byWidth = new Map<string, BucketStats>();

  let totalPnl = 0;
  let wins = 0;

  for (const p of closed) {
    const pnl = safeNum((p as any).realizedPnl, 0);
    const ticker = String((p as any).ticker ?? "").toUpperCase();
    const sector = String((p as any).sector ?? "UNKNOWN").toUpperCase();
    const delta = safeNum((p as any).entryDelta, 0.15);
    const dte = safeNum((p as any).entryDte, 10);
    const width = safeNum((p as any).width, 1);

    totalPnl += pnl;
    if (pnl >= 0) wins += 1;

    addBucket(byTicker, ticker, pnl);
    addBucket(bySector, sector, pnl);
    addBucket(byDelta, deltaBucket(delta), pnl);
    addBucket(byDte, dteBucket(dte), pnl);
    addBucket(byWidth, widthBucket(width), pnl);
  }

  const totalTrades = closed.length;
  const report: FeedbackReport = {
    totalTrades,
    totalPnl,
    winRate: totalTrades ? wins / totalTrades : 0,
    byTicker: Object.fromEntries(byTicker.entries()),
    bySector: Object.fromEntries(bySector.entries()),
    byDelta: Object.fromEntries(byDelta.entries()),
    byDte: Object.fromEntries(byDte.entries()),
    byWidth: Object.fromEntries(byWidth.entries()),
  };

  await db.insert(systemEvents).values({
    severity: "info",
    eventType: "performance_feedback_snapshot",
    message: `Generated performance feedback on ${totalTrades} trades`,
    payload: JSON.stringify(report),
  });

  return report;
}
