V8 merged autopilot services.

This merged build keeps your existing /api/scan route as the scan provider.
The autopilot scheduler calls that route internally and then applies V8 risk,
liquidity, participation, weekend, and execution logic.

Important:
- DRY_RUN: creates intents but never submits broker orders.
- PAPER: simulates fills using the existing positions table.
- LIVE: uses tastytrade adapter.

Before LIVE:
1. Apply the schema migration / db push.
2. Set TASTYTRADE_* env vars.
3. Start in DRY_RUN, then PAPER, then tiny LIVE.
