import type { RuntimeMode } from "./types";

export type V8Config = {
  mode: RuntimeMode;
  scanIntervalMs: number;
  executionIntervalMs: number;
  positionIntervalMs: number;
  reconIntervalMs: number;
  healthIntervalMs: number;
  entryStartHourET: number;
  entryStopHourET: number;
  mondayResumeHourET: number;
  maxTradesPerDay: number;
  participationRate: number;
  staleQuoteSecondsScan: number;
  staleQuoteSecondsEntry: number;
  staleQuoteSecondsExit: number;
  scanTimeoutMs: number;
  riskPerTradePct: number;
  maxPortfolioRiskPct: number;
  softPortfolioRiskPct: number;
  weekendDeltaThreshold: number;
  maxHighBetaRiskPct: number;
  accountSizeMode: "SMALL" | "STANDARD";
};

export const defaultV8Config: V8Config = {
  mode: (process.env.AUTOPILOT_MODE as RuntimeMode) || "DRY_RUN",
  scanIntervalMs: Number(process.env.AUTOPILOT_SCAN_INTERVAL_MS || 3 * 60 * 1000),
  executionIntervalMs: Number(process.env.AUTOPILOT_EXECUTION_INTERVAL_MS || 15 * 1000),
  positionIntervalMs: Number(process.env.AUTOPILOT_POSITION_INTERVAL_MS || 60 * 1000),
  reconIntervalMs: Number(process.env.AUTOPILOT_RECON_INTERVAL_MS || 5 * 60 * 1000),
  healthIntervalMs: Number(process.env.AUTOPILOT_HEALTH_INTERVAL_MS || 15 * 60 * 1000),
  entryStartHourET: Number(process.env.AUTOPILOT_ENTRY_START_HOUR_ET || 10),
  entryStopHourET: Number(process.env.AUTOPILOT_ENTRY_STOP_HOUR_ET || 15),
  mondayResumeHourET: Number(process.env.AUTOPILOT_MONDAY_RESUME_HOUR_ET || 10),
  maxTradesPerDay: Number(process.env.AUTOPILOT_MAX_TRADES_PER_DAY || 2),
  participationRate: Number(process.env.AUTOPILOT_PARTICIPATION_RATE || 0.35),
  staleQuoteSecondsScan: Number(process.env.AUTOPILOT_STALE_SCAN_SECONDS || 60),
  staleQuoteSecondsEntry: Number(process.env.AUTOPILOT_STALE_ENTRY_SECONDS || 20),
  staleQuoteSecondsExit: Number(process.env.AUTOPILOT_STALE_EXIT_SECONDS || 20),
  scanTimeoutMs: Number(process.env.AUTOPILOT_SCAN_TIMEOUT_MS || 25000),
  riskPerTradePct: Number(process.env.AUTOPILOT_RISK_PER_TRADE_PCT || 0.02),
  maxPortfolioRiskPct: Number(process.env.AUTOPILOT_MAX_PORTFOLIO_RISK_PCT || 0.50),
  softPortfolioRiskPct: Number(process.env.AUTOPILOT_SOFT_PORTFOLIO_RISK_PCT || 0.35),
  weekendDeltaThreshold: Number(process.env.AUTOPILOT_WEEKEND_DELTA_THRESHOLD || 0.25),
  maxHighBetaRiskPct: Number(process.env.AUTOPILOT_MAX_HIGH_BETA_RISK_PCT || 0.10),
  accountSizeMode: (process.env.AUTOPILOT_ACCOUNT_SIZE_MODE as "SMALL" | "STANDARD") || "SMALL",
};
