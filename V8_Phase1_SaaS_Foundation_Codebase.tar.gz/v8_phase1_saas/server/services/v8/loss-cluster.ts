import { desc, eq, sql } from "drizzle-orm";
import { db } from "../../db";
import { autopilotState, positions, systemEvents } from "@shared/schema";

export async function evaluateLossCluster(): Promise<{
  pause: boolean;
  reason?: string;
  consecutiveLosses: number;
}> {
  const recentClosed = await db
    .select()
    .from(positions)
    .where(sql`${positions.status} = 'closed' and ${positions.closedAt} is not null`)
    .orderBy(desc(positions.closedAt))
    .limit(10);

  let consecutiveLosses = 0;
  for (const p of recentClosed) {
    const pnl = Number((p as any).realizedPnl ?? 0);
    if (pnl < 0) {
      consecutiveLosses += 1;
    } else {
      break;
    }
  }

  if (consecutiveLosses >= 3) {
    return {
      pause: true,
      reason: "loss_cluster_3",
      consecutiveLosses,
    };
  }

  return {
    pause: false,
    consecutiveLosses,
  };
}

export async function applyLossClusterPauseIfNeeded() {
  const cluster = await evaluateLossCluster();
  if (!cluster.pause) return cluster;

  const [state] = await db.select().from(autopilotState).limit(1);
  const pausedUntil = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();

  if (state) {
    await db
      .update(autopilotState)
      .set({
        isPaused: true,
        pauseReason: cluster.reason!,
        pausedUntil,
        updatedAt: new Date().toISOString(),
      } as any)
      .where(eq(autopilotState.id, state.id));
  }

  await db.insert(systemEvents).values({
    severity: "warn",
    eventType: "loss_cluster_pause",
    message: `Autopilot paused for 24h after ${cluster.consecutiveLosses} consecutive losses`,
    payload: JSON.stringify(cluster),
  });

  return cluster;
}
