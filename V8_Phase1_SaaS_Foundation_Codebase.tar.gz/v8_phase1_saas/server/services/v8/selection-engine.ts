export type SnapshotRegime =
  | "LOW_VOL"
  | "NORMAL"
  | "ELEVATED"
  | "PANIC"
  | "SLOW_BEAR";

export type CandidateLike = {
  ticker: string;
  sector?: string | null;
  subIndustry?: string | null;
  engine?: string | null;
  confidence?: number | null;
  delta?: number | null;
  distanceOtmPct?: number | null;
  creditPctOfWidth?: number | null;
  dte?: number | null;
  slippageRatio?: number | null;
  maxRisk?: number | null;
  tradeRisk?: number | null;
};

export type ExistingPositionLike = {
  ticker?: string | null;
  sector?: string | null;
  subIndustry?: string | null;
  maxRisk?: number | null;
};

export type SelectionContext = {
  vix: number;
  regime: SnapshotRegime;
  existingPositions?: ExistingPositionLike[];
  maxCount?: number;
};

type MacroBucket =
  | "SPY_COMPLEX"
  | "QQQ_TECH"
  | "DOW_DEFENSIVE"
  | "GOLD_DEFENSIVE"
  | "HIGH_BETA"
  | "SINGLE_STOCK"
  | "OTHER";

function safeNum(v: any, fallback = 0): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function upper(s?: string | null): string {
  return String(s ?? "").toUpperCase();
}

function lower(s?: string | null): string {
  return String(s ?? "").toLowerCase();
}

function isEtf(candidate: CandidateLike | ExistingPositionLike): boolean {
  return lower(candidate.sector).includes("etf");
}

function isCommodityDefensive(candidate: CandidateLike | ExistingPositionLike): boolean {
  const s = lower(candidate.sector);
  return (
    s.includes("commodity") ||
    s.includes("gold") ||
    s.includes("utilities") ||
    s.includes("consumer defensive") ||
    s.includes("staples")
  );
}

function isHighBeta(candidate: CandidateLike | ExistingPositionLike): boolean {
  const s = lower(candidate.sector);
  const si = lower(candidate.subIndustry);

  return (
    s.includes("high beta") ||
    s.includes("technology") ||
    si.includes("semiconductor") ||
    si.includes("software") ||
    si.includes("crypto") ||
    si.includes("internet")
  );
}

function isIndexEtfTicker(ticker: string): boolean {
  const t = upper(ticker);
  return ["SPY", "QQQ", "IWM", "DIA"].includes(t);
}

function inferMacroBucket(candidate: CandidateLike | ExistingPositionLike): MacroBucket {
  const t = upper(candidate.ticker);

  if (["SPY", "IWM"].includes(t)) return "SPY_COMPLEX";
  if (["QQQ", "NVDA", "AMD", "MSFT", "ORCL", "CRM", "TSLA", "GOOG", "GOOGL"].includes(t)) {
    return isHighBeta(candidate) ? "QQQ_TECH" : "SINGLE_STOCK";
  }
  if (["DIA"].includes(t)) return "DOW_DEFENSIVE";
  if (["GLD", "GDX", "IAU", "SLV"].includes(t) || isCommodityDefensive(candidate)) {
    return "GOLD_DEFENSIVE";
  }
  if (isHighBeta(candidate)) return "HIGH_BETA";
  if (isEtf(candidate)) return "OTHER";
  return "SINGLE_STOCK";
}

function countBy<T>(
  items: T[],
  predicate: (x: T) => boolean,
): number {
  return items.reduce((sum, x) => sum + (predicate(x) ? 1 : 0), 0);
}

function countSameTicker(
  positions: ExistingPositionLike[],
  ticker?: string | null,
): number {
  const t = upper(ticker);
  return countBy(positions, (p) => upper(p.ticker) === t);
}

function countSameSector(
  positions: ExistingPositionLike[],
  sector?: string | null,
): number {
  const s = lower(sector);
  return countBy(positions, (p) => lower(p.sector) === s);
}

function countSameSubIndustry(
  positions: ExistingPositionLike[],
  subIndustry?: string | null,
): number {
  const si = lower(subIndustry);
  if (!si) return 0;
  return countBy(positions, (p) => lower(p.subIndustry) === si);
}

function countByMacroBucket(
  positions: ExistingPositionLike[],
  bucket: MacroBucket,
): number {
  return countBy(positions, (p) => inferMacroBucket(p) === bucket);
}

function desiredDeltaCeiling(vix: number, regime: SnapshotRegime): number {
  if (regime === "PANIC") return 0.12;
  if (vix >= 25 || regime === "ELEVATED" || regime === "SLOW_BEAR") return 0.15;
  return 0.18;
}

function desiredDistanceFloor(vix: number, regime: SnapshotRegime): number {
  if (regime === "PANIC") return 7.0;
  if (vix >= 25 || regime === "ELEVATED" || regime === "SLOW_BEAR") return 6.0;
  return 5.0;
}

function normalizeRisk(candidate: CandidateLike): number {
  return safeNum(candidate.tradeRisk, safeNum(candidate.maxRisk, 0));
}

function shouldRequireDefensiveName(vix: number, regime: SnapshotRegime): boolean {
  return vix >= 25 || regime === "ELEVATED" || regime === "PANIC" || regime === "SLOW_BEAR";
}

export function scoreCandidateForSelection(
  candidate: CandidateLike,
  context: SelectionContext,
): number {
  const positions = context.existingPositions ?? [];
  const vix = safeNum(context.vix, 18);
  const regime = context.regime;

  const confidence = safeNum(candidate.confidence, 0);
  const delta = safeNum(candidate.delta, 0.15);
  const distance = safeNum(candidate.distanceOtmPct, 0);
  const creditPct = safeNum(candidate.creditPctOfWidth, 0);
  const dte = safeNum(candidate.dte, 10);
  const slippage = safeNum(candidate.slippageRatio, 1.2);
  const risk = normalizeRisk(candidate);
  const bucket = inferMacroBucket(candidate);

  const highVol = shouldRequireDefensiveName(vix, regime);
  const deltaCeiling = desiredDeltaCeiling(vix, regime);
  const distanceFloor = desiredDistanceFloor(vix, regime);

  let score = confidence;

  score += Math.max(0, distance - 5) * 3.0;
  score += Math.max(0, 0.18 - delta) * 100;
  score += Math.max(0, creditPct - 25) * 0.35;
  score -= Math.max(0, slippage - 1.2) * 14;

  if (upper(candidate.engine) === "CORE") score += 5;
  if (dte >= 8 && dte <= 10) score += 6;
  else if (dte >= 11 && dte <= 14) score += 2;
  else if (dte > 14) score -= 2;
  else if (dte < 7) score -= 10;

  if (risk > 0 && risk <= 75) score += 4;
  else if (risk > 75) score -= 8;

  if (highVol) {
    score += distance * 2.0;
    score += Math.max(0, deltaCeiling - delta) * 120;

    if (distance < distanceFloor) score -= 22;
    if (delta > deltaCeiling) score -= 18;

    if (isCommodityDefensive(candidate)) score += 16;
    if (isEtf(candidate)) score += 6;

    if (isHighBeta(candidate)) score -= 6;
    if (bucket === "SPY_COMPLEX" && distance < 6) score -= 8;
  }

  score -= countSameTicker(positions, candidate.ticker) * 100;
  score -= countSameSubIndustry(positions, candidate.subIndustry) * 18;
  score -= countSameSector(positions, candidate.sector) * 9;
  score -= countByMacroBucket(positions, bucket) * 16;

  if (highVol) {
    if (bucket === "SPY_COMPLEX" && countByMacroBucket(positions, "SPY_COMPLEX") > 0) {
      score -= 18;
    }
    if (bucket === "QQQ_TECH" && countByMacroBucket(positions, "QQQ_TECH") > 0) {
      score -= 18;
    }
    if (isHighBeta(candidate) && countBy(positions, (p) => isHighBeta(p)) > 0) {
      score -= 24;
    }
  }

  if (countSameSector(positions, candidate.sector) === 0) score += 6;
  if (countSameSubIndustry(positions, candidate.subIndustry) === 0) score += 4;
  if (countByMacroBucket(positions, bucket) === 0) score += 8;

  return score;
}

function candidatePassesInstitutionalHardRules(
  candidate: CandidateLike,
  context: SelectionContext,
  hypotheticalPortfolio: ExistingPositionLike[],
): boolean {
  const vix = safeNum(context.vix, 18);
  const regime = context.regime;
  const highVol = shouldRequireDefensiveName(vix, regime);
  const delta = safeNum(candidate.delta, 0.15);
  const distance = safeNum(candidate.distanceOtmPct, 0);
  const dte = safeNum(candidate.dte, 10);
  const bucket = inferMacroBucket(candidate);

  const deltaCeiling = desiredDeltaCeiling(vix, regime);
  const distanceFloor = desiredDistanceFloor(vix, regime);

  if (countSameTicker(hypotheticalPortfolio, candidate.ticker) >= 2) return false;
  if (delta > deltaCeiling) return false;
  if (distance < distanceFloor) return false;
  if (dte < 7) return false;

  if (highVol && isHighBeta(candidate)) {
    if (countBy(hypotheticalPortfolio, (p) => isHighBeta(p)) >= 3) return false;
  }

  const macroComplexCount =
    countByMacroBucket(hypotheticalPortfolio, "SPY_COMPLEX") +
    countByMacroBucket(hypotheticalPortfolio, "QQQ_TECH") +
    countByMacroBucket(hypotheticalPortfolio, "DOW_DEFENSIVE");

  if (highVol && isIndexEtfTicker(candidate.ticker) && macroComplexCount >= 4) {
    return false;
  }

  if (countSameSubIndustry(hypotheticalPortfolio, candidate.subIndustry) >= 2) return false;

  if (highVol) {
    const spyCount = countByMacroBucket(hypotheticalPortfolio, "SPY_COMPLEX");
    const qqqCount = countByMacroBucket(hypotheticalPortfolio, "QQQ_TECH");
    if (bucket === "SPY_COMPLEX" && spyCount >= 2) return false;
    if (bucket === "QQQ_TECH" && qqqCount >= 2) return false;
  }

  return true;
}

export function sortCandidatesForSelection<T extends CandidateLike>(
  candidates: T[],
  context: SelectionContext,
): T[] {
  const positions = [...(context.existingPositions ?? [])];
  const remaining = [...candidates];
  const selected: T[] = [];

  while (remaining.length > 0) {
    const scored = remaining
      .filter((candidate) =>
        candidatePassesInstitutionalHardRules(candidate, context, [
          ...positions,
          ...selected,
        ]),
      )
      .map((candidate) => ({
        candidate,
        score: scoreCandidateForSelection(candidate, {
          ...context,
          existingPositions: [...positions, ...selected],
        }),
      }))
      .sort((a, b) => b.score - a.score);

    const winner = scored[0]?.candidate;
    if (!winner) break;

    selected.push(winner);

    const idx = remaining.findIndex(
      (c) =>
        upper(c.ticker) === upper(winner.ticker) &&
        safeNum(c.dte, 0) === safeNum(winner.dte, 0) &&
        safeNum(c.delta, 0) === safeNum(winner.delta, 0),
    );

    if (idx >= 0) remaining.splice(idx, 1);
    else break;
  }

  return selected;
}

export function takeInstitutionalPicks<T extends CandidateLike>(
  candidates: T[],
  context: SelectionContext,
): T[] {
  const maxCount = Math.max(1, safeNum(context.maxCount, 3));
  const ranked = sortCandidatesForSelection(candidates, context);

  const highVol = shouldRequireDefensiveName(context.vix, context.regime);
  if (!highVol) return ranked.slice(0, maxCount);

  const defensive = ranked.find((c) => isCommodityDefensive(c));
  const stabilizer = ranked.find(
    (c) =>
      isEtf(c) &&
      !isCommodityDefensive(c) &&
      inferMacroBucket(c) !== "HIGH_BETA",
  );
  const engine = ranked.find(
    (c) =>
      isHighBeta(c) &&
      safeNum(c.delta, 1) <= desiredDeltaCeiling(context.vix, context.regime) &&
      safeNum(c.distanceOtmPct, 0) >= desiredDistanceFloor(context.vix, context.regime),
  );

  const chosen: T[] = [];
  const seen = new Set<string>();

  for (const c of [defensive, stabilizer, engine]) {
    if (!c) continue;
    const t = upper(c.ticker);
    if (seen.has(t)) continue;
    chosen.push(c);
    seen.add(t);
    if (chosen.length >= maxCount) return chosen;
  }

  for (const c of ranked) {
    const t = upper(c.ticker);
    if (seen.has(t)) continue;
    chosen.push(c);
    seen.add(t);
    if (chosen.length >= maxCount) break;
  }

  return chosen;
}

export function takeBestUniqueTickers<T extends CandidateLike>(
  ranked: T[],
  maxCount: number,
): T[] {
  const seen = new Set<string>();
  const out: T[] = [];

  for (const c of ranked) {
    const t = upper(c.ticker);
    if (seen.has(t)) continue;
    seen.add(t);
    out.push(c);
    if (out.length >= maxCount) break;
  }

  return out;
}
