import { db } from "../../db";
import { positions } from "@shared/schema";
import { eq } from "drizzle-orm";

function safeNum(v: any, fallback = 0): number {
  if (v === null || v === undefined) return fallback;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

const KNOWN_BETAS: Record<string, number> = {
  SPY: 1.0, QQQ: 1.2, IWM: 1.25, DIA: 0.9,
  AAPL: 1.2, MSFT: 1.1, GOOG: 1.1, GOOGL: 1.1, AMZN: 1.3, META: 1.4, NVDA: 1.8, AMD: 1.7,
  TSLA: 2.0, NFLX: 1.4, CRM: 1.3, ORCL: 1.1, AVGO: 1.3, INTC: 1.1,
  PLTR: 2.1, MARA: 3.5, COIN: 3.0, SOFI: 1.8, HOOD: 2.0, RIVN: 2.2,
  SHOP: 2.0, SQ: 2.2, SNAP: 1.9, UBER: 1.5, ABNB: 1.6, ROKU: 2.0,
  JPM: 1.1, BAC: 1.3, GS: 1.3, MS: 1.4, WFC: 1.2, C: 1.3,
  XOM: 0.9, CVX: 0.9, COP: 1.1,
  JNJ: 0.6, PFE: 0.7, UNH: 0.8, ABBV: 0.7, MRK: 0.6, LLY: 0.8, BMY: 0.6,
  KO: 0.6, PEP: 0.65, PG: 0.4, WMT: 0.5, COST: 0.7, MCD: 0.7,
  V: 0.95, MA: 1.0, PYPL: 1.5,
  BA: 1.5, CAT: 1.1, GE: 1.2, HON: 1.0, UPS: 1.0,
  DIS: 1.3, CMCSA: 1.0, T: 0.7, VZ: 0.6,
  GLD: 0.1, SLV: 0.3, GDX: 0.6,
  XLE: 1.1, XLF: 1.1, XLK: 1.15, XLV: 0.7, XLP: 0.55, XLU: 0.5,
  XLI: 1.0, XLB: 1.05, XLRE: 0.8, XLC: 1.0, XLY: 1.15,
  SMH: 1.4, EEM: 0.9, EWZ: 1.1, TLT: -0.2, HYG: 0.4, LQD: 0.1,
  NKE: 1.1, SBUX: 0.9, LOW: 1.05, HD: 1.0, TGT: 1.1, F: 1.4, GM: 1.3,
  MU: 1.5, QCOM: 1.4, AMAT: 1.5, LRCX: 1.4, KLAC: 1.3, MRVL: 1.6,
  PANW: 1.2, CRWD: 1.3, ZS: 1.3, NET: 1.8, DDOG: 1.5, SNOW: 1.6, MDB: 1.7,
  ARM: 1.8, SMCI: 2.5, TSM: 1.3, ASML: 1.4,
};

function lookupBeta(ticker: string, dbBeta: any): number {
  const stored = safeNum(dbBeta, 0);
  if (stored > 0 && stored !== 1) return stored;
  return KNOWN_BETAS[ticker.toUpperCase()] ?? 1.0;
}

export function lookupBetaForTicker(ticker: string): number {
  return KNOWN_BETAS[ticker.toUpperCase()] ?? 1.0;
}

function isEtf(ticker: string): boolean {
  const etfs = new Set([
    "SPY","QQQ","IWM","DIA","EEM","EWZ","XLE","XLF","SMH","TLT","GLD","SLV",
    "XLK","XLV","XLP","XLU","XLI","XLB","XLRE","XLC","XLY","VIX","HYG","LQD",
  ]);
  return etfs.has(ticker.toUpperCase());
}

function isHighBeta(beta: number, sector?: string | null, subIndustry?: string | null): boolean {
  if (beta >= 1.35) return true;
  const s = String(sector ?? "").toLowerCase();
  const si = String(subIndustry ?? "").toLowerCase();
  return (
    s.includes("high beta") ||
    si.includes("semiconductor") ||
    si.includes("crypto")
  );
}

export type PositionWithGreeks = {
  id: string;
  ticker: string;
  expiration: string;
  shortStrike: number;
  longStrike: number;
  contracts: number;
  credit: number;
  currentMark: number;
  maxRisk: number;
  status: string;
  sector: string | null;
  subIndustry: string | null;
  beta: number;
  entryDelta: number;
  entryDte: number | null;
  underlyingPrice: number;
  shortDelta: number;
  longDelta: number;
  netDelta: number;
  shortTheta: number;
  longTheta: number;
  netTheta: number;
  betaWeightedDelta: number;
  isApproximated: boolean;
  greeksSource: "live" | "approx";
  isEtf: boolean;
};

function getTrustedMaxRisk(pos: any): number {
  const shortStrike = safeNum(pos.shortStrike, 0);
  const longStrike = safeNum(pos.longStrike, 0);
  const contracts = Math.max(1, safeNum(pos.contracts, 1));
  const credit = safeNum(pos.credit, safeNum(pos.entryCredit, 0));
  const width = Math.abs(shortStrike - longStrike);
  if (width > 0) {
    return Math.max(0, (width - credit) * 100 * contracts);
  }
  return Math.max(0, safeNum(pos.maxRisk, 0));
}

function approximateGreeks(pos: any, spyPrice: number): {
  shortDelta: number;
  longDelta: number;
  netDelta: number;
  shortTheta: number;
  longTheta: number;
  netTheta: number;
  betaWeightedDelta: number;
} {
  const entryDelta = clamp(safeNum(pos.entryDelta, 0.15), 0.01, 0.50);
  const contracts = Math.max(1, safeNum(pos.contracts, 1));
  const beta = safeNum(pos.beta, 1);
  const width = Math.abs(safeNum(pos.shortStrike, 0) - safeNum(pos.longStrike, 0));
  const underlyingPrice = safeNum(pos.underlyingPrice, 0);
  const dte = Math.max(1, safeNum(pos.entryDte, 10));
  const distance = Math.max(0, safeNum(pos.distanceOtmPct, 6));

  const distanceAdjustment = clamp(1 - (distance - 5) * 0.05, 0.55, 1.15);
  const timeAdjustment = clamp(1 + (10 - dte) * 0.03, 0.80, 1.25);

  const shortDeltaAbs = clamp(entryDelta * distanceAdjustment * timeAdjustment, 0.01, 0.60);
  const longDeltaAbs = clamp(shortDeltaAbs * 0.28, 0.002, shortDeltaAbs * 0.60);

  const netDeltaPerSpread = Math.max(0.001, shortDeltaAbs - longDeltaAbs);
  const netDelta = netDeltaPerSpread * contracts;

  const baseThetaPerSpread = clamp((Math.max(1, width) * 0.7) / Math.sqrt(dte), 0.03, 0.35);
  const shortTheta = baseThetaPerSpread * contracts;
  const longTheta = baseThetaPerSpread * 0.35 * contracts;
  const netTheta = Math.max(0.001, shortTheta - longTheta);

  const effectiveSpyPrice = Math.max(1, safeNum(spyPrice, 1));
  const betaWeightedDelta = netDelta * beta * (underlyingPrice > 0 ? underlyingPrice / effectiveSpyPrice : 1);

  return {
    shortDelta: shortDeltaAbs,
    longDelta: longDeltaAbs,
    netDelta,
    shortTheta,
    longTheta,
    netTheta,
    betaWeightedDelta,
  };
}

function useLiveGreeksIfValid(pos: any, spyPrice: number): {
  shortDelta: number;
  longDelta: number;
  netDelta: number;
  shortTheta: number;
  longTheta: number;
  netTheta: number;
  betaWeightedDelta: number;
} | null {
  const shortDelta = safeNum(pos.shortDelta, NaN);
  const longDelta = safeNum(pos.longDelta, NaN);
  const netDelta = safeNum(pos.netDelta, NaN);
  const shortTheta = safeNum(pos.shortTheta, NaN);
  const longTheta = safeNum(pos.longTheta, NaN);
  const netTheta = safeNum(pos.netTheta, NaN);

  const hasAll =
    Number.isFinite(shortDelta) &&
    Number.isFinite(longDelta) &&
    Number.isFinite(netDelta) &&
    Number.isFinite(shortTheta) &&
    Number.isFinite(longTheta) &&
    Number.isFinite(netTheta);

  if (!hasAll) return null;

  const beta = safeNum(pos.beta, 1);
  const underlyingPrice = safeNum(pos.underlyingPrice, 0);
  const effectiveSpyPrice = Math.max(1, safeNum(spyPrice, 1));

  const normalizedNetDelta = Math.abs(netDelta);
  const normalizedShortDelta = Math.abs(shortDelta);
  const normalizedLongDelta = Math.abs(longDelta);

  const betaWeightedDelta =
    normalizedNetDelta * beta * (underlyingPrice > 0 ? underlyingPrice / effectiveSpyPrice : 1);

  return {
    shortDelta: normalizedShortDelta,
    longDelta: normalizedLongDelta,
    netDelta: normalizedNetDelta,
    shortTheta: Math.abs(shortTheta),
    longTheta: Math.abs(longTheta),
    netTheta: Math.abs(netTheta),
    betaWeightedDelta,
  };
}

export async function getOpenPositionsWithGreeks(spyPrice = 500): Promise<PositionWithGreeks[]> {
  const openPositions = await db
    .select()
    .from(positions)
    .where(eq(positions.status, "open"));

  return openPositions.map((pos) => {
    const beta = lookupBeta(pos.ticker, pos.beta);
    const posWithBeta = { ...pos, beta };

    const liveGreeks = useLiveGreeksIfValid(posWithBeta, spyPrice);
    const greeks = liveGreeks ?? approximateGreeks(posWithBeta, spyPrice);
    const isApproximated = !liveGreeks;

    const shortStrike = safeNum(pos.shortStrike, 0);
    const longStrike = safeNum(pos.longStrike, 0);
    const contracts = safeNum(pos.contracts, 1);
    const credit = safeNum(pos.credit, 0);
    const computedMaxRisk = getTrustedMaxRisk(pos);

    return {
      id: pos.id,
      ticker: pos.ticker,
      expiration: pos.expiration,
      shortStrike,
      longStrike,
      contracts,
      credit,
      currentMark: safeNum(pos.currentMark, 0),
      maxRisk: computedMaxRisk,
      status: pos.status,
      sector: pos.sector ?? null,
      subIndustry: pos.subIndustry ?? null,
      beta,
      entryDelta: safeNum(pos.entryDelta, 0.12),
      entryDte: pos.entryDte ?? null,
      underlyingPrice: safeNum(pos.underlyingPrice, 0),
      ...greeks,
      isApproximated,
      greeksSource: isApproximated ? "approx" as const : "live" as const,
      isEtf: isEtf(pos.ticker),
    };
  });
}

export type PortfolioGreeksSummary = {
  totalNetDelta: number;
  totalNetTheta: number;
  betaWeightedDelta: number;
  totalMaxRisk: number;
  openPositionsCount: number;
  deltaBySector: Record<string, number>;
  thetaBySector: Record<string, number>;
  riskBySector: Record<string, number>;
  riskByTicker: Record<string, number>;
  highBetaRisk: number;
  singleStockRisk: number;
  etfRisk: number;
  topDeltaContributors: { ticker: string; netDelta: number }[];
  topThetaContributors: { ticker: string; netTheta: number }[];
  liveGreeksCount: number;
  approxGreeksCount: number;
};

export function computePortfolioGreeks(positionsWithGreeks: PositionWithGreeks[]): PortfolioGreeksSummary {
  let totalNetDelta = 0;
  let totalNetTheta = 0;
  let betaWeightedDelta = 0;
  let totalMaxRisk = 0;
  let highBetaRisk = 0;
  let singleStockRisk = 0;
  let etfRisk = 0;
  let liveGreeksCount = 0;
  let approxGreeksCount = 0;

  const deltaBySector: Record<string, number> = {};
  const thetaBySector: Record<string, number> = {};
  const riskBySector: Record<string, number> = {};
  const riskByTicker: Record<string, number> = {};

  for (const p of positionsWithGreeks) {
    totalNetDelta += p.netDelta;
    totalNetTheta += p.netTheta;
    betaWeightedDelta += p.betaWeightedDelta;
    totalMaxRisk += p.maxRisk;

    const sector = p.sector ?? "Unknown";
    deltaBySector[sector] = (deltaBySector[sector] ?? 0) + p.netDelta;
    thetaBySector[sector] = (thetaBySector[sector] ?? 0) + p.netTheta;
    riskBySector[sector] = (riskBySector[sector] ?? 0) + p.maxRisk;
    riskByTicker[p.ticker] = (riskByTicker[p.ticker] ?? 0) + p.maxRisk;

    if (isHighBeta(p.beta, p.sector, p.subIndustry)) highBetaRisk += p.maxRisk;
    if (p.isEtf) etfRisk += p.maxRisk;
    else singleStockRisk += p.maxRisk;

    if (p.greeksSource === "live") liveGreeksCount++;
    else approxGreeksCount++;
  }

  const topDeltaContributors = [...positionsWithGreeks]
    .sort((a, b) => Math.abs(b.netDelta) - Math.abs(a.netDelta))
    .slice(0, 5)
    .map((p) => ({ ticker: p.ticker, netDelta: p.netDelta }));

  const topThetaContributors = [...positionsWithGreeks]
    .sort((a, b) => Math.abs(b.netTheta) - Math.abs(a.netTheta))
    .slice(0, 5)
    .map((p) => ({ ticker: p.ticker, netTheta: p.netTheta }));

  return {
    totalNetDelta: Math.round(totalNetDelta * 1000) / 1000,
    totalNetTheta: Math.round(totalNetTheta * 100) / 100,
    betaWeightedDelta: Math.round(betaWeightedDelta * 1000) / 1000,
    totalMaxRisk: Math.round(totalMaxRisk * 100) / 100,
    openPositionsCount: positionsWithGreeks.length,
    deltaBySector,
    thetaBySector,
    riskBySector,
    riskByTicker,
    highBetaRisk: Math.round(highBetaRisk * 100) / 100,
    singleStockRisk: Math.round(singleStockRisk * 100) / 100,
    etfRisk: Math.round(etfRisk * 100) / 100,
    topDeltaContributors,
    topThetaContributors,
    liveGreeksCount,
    approxGreeksCount,
  };
}
