import type { PortfolioGreeksSummary } from "./portfolio-greeks";

export type StressScenario = {
  label: string;
  estimatedPnl: number;
};

export type PortfolioStressResult = {
  spyDown1pct: number;
  spyDown2pct: number;
  spyDown3pct: number;
  volUp5: number;
  volUp10: number;
  scenarios: StressScenario[];
};

function safeNum(v: any, fallback = 0): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

export function computePortfolioStressTest(
  greeks: PortfolioGreeksSummary,
  marketSnapshot: { vix: number; spyPrice: number },
): PortfolioStressResult {
  const bwd = safeNum(greeks.betaWeightedDelta, 0);
  const totalRisk = safeNum(greeks.totalMaxRisk, 0);
  const highBetaRisk = safeNum(greeks.highBetaRisk, 0);
  const effectiveSpyPrice = Math.max(1, safeNum(marketSnapshot.spyPrice, 1));

  function directionalShock(movePct: number): number {
    return bwd * effectiveSpyPrice * movePct * -1;
  }

  function convexityPenalty(movePct: number): number {
    const absMove = Math.abs(movePct);
    const penaltyPct =
      absMove <= 0.01 ? 0.005 :
      absMove <= 0.02 ? 0.015 :
      0.035;
    return totalRisk * penaltyPct;
  }

  function stressForMove(movePct: number): number {
    const directional = directionalShock(movePct);
    const penalty = convexityPenalty(movePct);
    return directional - penalty;
  }

  function volShock(points: number): number {
    const hbWeight = totalRisk > 0 ? highBetaRisk / totalRisk : 0;
    const basePenaltyPct = 0.01 * points;
    const highBetaAmplifier = 1 + hbWeight * 0.75;
    return -(totalRisk * basePenaltyPct * highBetaAmplifier);
  }

  const spyDown1pct = stressForMove(0.01);
  const spyDown2pct = stressForMove(0.02);
  const spyDown3pct = stressForMove(0.03);
  const volUp5 = volShock(5);
  const volUp10 = volShock(10);

  return {
    spyDown1pct: Math.round(spyDown1pct * 100) / 100,
    spyDown2pct: Math.round(spyDown2pct * 100) / 100,
    spyDown3pct: Math.round(spyDown3pct * 100) / 100,
    volUp5: Math.round(volUp5 * 100) / 100,
    volUp10: Math.round(volUp10 * 100) / 100,
    scenarios: [
      { label: "SPY -1%", estimatedPnl: Math.round(spyDown1pct * 100) / 100 },
      { label: "SPY -2%", estimatedPnl: Math.round(spyDown2pct * 100) / 100 },
      { label: "SPY -3%", estimatedPnl: Math.round(spyDown3pct * 100) / 100 },
      { label: "VIX +5", estimatedPnl: Math.round(volUp5 * 100) / 100 },
      { label: "VIX +10", estimatedPnl: Math.round(volUp10 * 100) / 100 },
    ],
  };
}
