import { eq, inArray } from "drizzle-orm";
import { db } from "../../db";
import {
  appSettings,
  autopilotState,
  brokerOrders,
  manualActions,
  orderIntents,
  positions,
  systemEvents,
} from "@shared/schema";
import { TastytradeBroker } from "../../brokers/tastytrade";

function safeParseArray(input?: string | null): string[] {
  if (!input) return [];
  try {
    const parsed = JSON.parse(input);
    return Array.isArray(parsed) ? parsed.map((x) => String(x).toUpperCase()) : [];
  } catch {
    return [];
  }
}

export async function getAppSettings() {
  const [row] = await db.select().from(appSettings).limit(1);
  if (row) return row;

  const [created] = await db
    .insert(appSettings)
    .values({})
    .returning();

  return created;
}

export async function setExitStrategyMode(mode: string) {
  const settings = await getAppSettings();

  const [updated] = await db
    .update(appSettings)
    .set({
      exitStrategyMode: mode,
      updatedAt: new Date(),
    } as any)
    .where(eq(appSettings.id, settings.id))
    .returning();

  await db.insert(manualActions).values({
    actionType: "set_exit_strategy_mode",
    target: mode,
    payload: JSON.stringify({ mode }),
  });

  return updated;
}

export async function disableTicker(ticker: string) {
  const settings = await getAppSettings();
  const current = safeParseArray(settings.disabledTickersJson);
  const next = Array.from(new Set([...current, ticker.toUpperCase()]));

  const [updated] = await db
    .update(appSettings)
    .set({
      disabledTickersJson: JSON.stringify(next),
      updatedAt: new Date(),
    } as any)
    .where(eq(appSettings.id, settings.id))
    .returning();

  await db.insert(manualActions).values({
    actionType: "disable_ticker",
    target: ticker.toUpperCase(),
    payload: JSON.stringify({ ticker: ticker.toUpperCase() }),
  });

  return updated;
}

export async function enableTicker(ticker: string) {
  const settings = await getAppSettings();
  const current = safeParseArray(settings.disabledTickersJson);
  const next = current.filter((t) => t !== ticker.toUpperCase());

  const [updated] = await db
    .update(appSettings)
    .set({
      disabledTickersJson: JSON.stringify(next),
      updatedAt: new Date(),
    } as any)
    .where(eq(appSettings.id, settings.id))
    .returning();

  await db.insert(manualActions).values({
    actionType: "enable_ticker",
    target: ticker.toUpperCase(),
    payload: JSON.stringify({ ticker: ticker.toUpperCase() }),
  });

  return updated;
}

export async function setAutopilotMode(mode: string) {
  const [state] = await db.select().from(autopilotState).limit(1);
  if (!state) throw new Error("autopilot_state not initialized");

  const previousMode = String(state.mode ?? "");
  const modeChanged = previousMode !== mode;

  if (modeChanged && previousMode) {
    const openPositions = await db
      .select()
      .from(positions)
      .where(eq(positions.status, "open"));

    const modeTag = previousMode === "PAPER" ? "PAPER_AUTOPILOT" : previousMode === "DRY_RUN" ? "DRY_RUN" : "LIVE_AUTOPILOT";
    const positionsToClose = openPositions.filter((p) => {
      const notes = String((p as any).notes ?? "");
      return notes.includes(modeTag) || (!notes.includes("LIVE_AUTOPILOT") && !notes.includes("PAPER_AUTOPILOT") && previousMode !== "LIVE");
    });

    let closedCount = 0;
    for (const pos of positionsToClose) {
      await db
        .update(positions)
        .set({
          status: "closed",
          closedAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          notes: String((pos as any).notes ?? "") + ` | closed_by_mode_switch:${previousMode}->${mode}`,
        } as any)
        .where(eq(positions.id, pos.id));
      closedCount++;
    }

    const pendingIntents = await db
      .select()
      .from(orderIntents)
      .where(
        inArray(orderIntents.state, ["RISK_APPROVED", "ORDER_INTENT_CREATED"] as any),
      );

    let cancelledCount = 0;
    for (const intent of pendingIntents) {
      await db
        .update(orderIntents)
        .set({
          state: "CANCELLED",
          updatedAt: new Date(),
        } as any)
        .where(eq(orderIntents.id, intent.id));
      cancelledCount++;
    }

    if (closedCount > 0 || cancelledCount > 0) {
      await db.insert(systemEvents).values({
        severity: "warn",
        eventType: "mode_switch_cleanup",
        message: `Mode switch ${previousMode} → ${mode}: closed ${closedCount} positions, cancelled ${cancelledCount} pending intents`,
        payload: JSON.stringify({
          previousMode,
          newMode: mode,
          closedPositions: closedCount,
          cancelledIntents: cancelledCount,
          closedTickers: positionsToClose.map((p) => p.ticker),
        }),
      });
    }
  }

  const [updated] = await db
    .update(autopilotState)
    .set({
      mode,
    } as any)
    .where(eq(autopilotState.id, state.id))
    .returning();

  await db.insert(manualActions).values({
    actionType: "set_autopilot_mode",
    target: mode,
    payload: JSON.stringify({ mode, previousMode }),
  });

  await db.insert(systemEvents).values({
    severity: "warn",
    eventType: "autopilot_mode_changed",
    message: `Autopilot mode changed from ${previousMode} to ${mode}`,
    payload: JSON.stringify({ mode, previousMode }),
  });

  return updated;
}

export async function pauseAutopilot(reason = "manual_pause") {
  const [state] = await db.select().from(autopilotState).limit(1);
  if (!state) throw new Error("autopilot_state not initialized");

  const [updated] = await db
    .update(autopilotState)
    .set({
      isPaused: true,
      pauseReason: reason,
    } as any)
    .where(eq(autopilotState.id, state.id))
    .returning();

  await db.insert(manualActions).values({
    actionType: "pause_autopilot",
    target: reason,
    payload: JSON.stringify({ reason }),
  });

  return updated;
}

export async function resumeAutopilot() {
  const [state] = await db.select().from(autopilotState).limit(1);
  if (!state) throw new Error("autopilot_state not initialized");

  const [updated] = await db
    .update(autopilotState)
    .set({
      isPaused: false,
      pauseReason: null,
      pausedUntil: null,
    } as any)
    .where(eq(autopilotState.id, state.id))
    .returning();

  await db.insert(manualActions).values({
    actionType: "resume_autopilot",
    payload: JSON.stringify({ resumed: true }),
  });

  return updated;
}

export async function cancelAllOrders() {
  const broker = new TastytradeBroker();
  const result = await broker.cancelAllOrders();

  await db.insert(manualActions).values({
    actionType: "cancel_all_orders",
    payload: JSON.stringify(result),
  });

  await db.insert(systemEvents).values({
    severity: "warn",
    eventType: "manual_cancel_all_orders",
    message: "Operator canceled all broker orders",
    payload: JSON.stringify(result),
  });

  return result;
}

export async function flattenAllPositions() {
  const broker = new TastytradeBroker();
  const open = await db.select().from(positions).where(eq(positions.status, "open"));

  const results = [];
  for (const pos of open as any[]) {
    try {
      const limitPrice = Number(pos.currentMark ?? pos.entryCredit ?? pos.credit ?? 0) || 0.05;

      const closeResult = await broker.submitCloseVerticalSpread({
        ticker: pos.ticker,
        expiration: pos.expiration,
        shortStrike: Number(pos.shortStrike),
        longStrike: Number(pos.longStrike),
        quantity: Number(pos.contracts),
        limitPrice,
      });

      await db.insert(brokerOrders).values({
        orderIntentId: null,
        positionId: pos.id,
        brokerOrderId: closeResult.brokerOrderId ?? null,
        ticker: pos.ticker,
        side: "exit",
        status: closeResult.status || "submitted",
        requestedPrice: limitPrice,
        rawResponse: JSON.stringify(closeResult.body),
        rawJson: JSON.stringify(closeResult.body),
        createdAt: new Date(),
        updatedAt: new Date(),
      } as any);

      results.push({
        ticker: pos.ticker,
        ok: closeResult.ok,
        brokerOrderId: closeResult.brokerOrderId,
        status: closeResult.status,
      });
    } catch (e: any) {
      results.push({
        ticker: pos.ticker,
        ok: false,
        error: String(e?.message || e),
      });
    }
  }

  await db.insert(manualActions).values({
    actionType: "flatten_all_positions",
    payload: JSON.stringify(results),
  });

  await db.insert(systemEvents).values({
    severity: "critical",
    eventType: "manual_flatten_all",
    message: "Operator requested flatten all positions",
    payload: JSON.stringify(results),
  });

  return results;
}
