import type { Express } from "express";
import { db } from "../../db";
import { autopilotState, brokerOrders, orderIntents, positions, systemEvents } from "@shared/schema";
import { and, desc, eq, inArray, sql } from "drizzle-orm";
import { defaultV8Config } from "./config";
import { v8log } from "./logger";
import type { RuntimeMode, ScanPick, ScanResponse } from "./types";
import { evaluateCandidate } from "./risk-sentinel";
import { TastytradeBroker } from "../../brokers/tastytrade";
import { reconcileBrokerState, flattenMismatchSymbols } from "./reconciliation";
import { resolveModifierPriority } from "./modifiers";
import { applyLossClusterPauseIfNeeded } from "./loss-cluster";
import { healthSnapshot } from "./health-monitor";
import { syncLiveOrdersAndCreatePositions } from "./live-sync";
import { getAppSettings } from "./operator-controls";
import { takeInstitutionalPicks } from "./selection-engine";
import { lookupBetaForTicker } from "./portfolio-greeks";
import { normalizePositionMetadata } from "./position-metadata";
import { ENGINE_VERSION, SELECTION_VERSION } from "./version";
import { checkDeploymentGuard } from "./deployment-guard";
import { getEventControls } from "./event-guard";
import {
  getLiveManagedPositions,
  logPositionDecision,
  shouldCloseForRisk,
} from "./position-manager";
import { getMarketSnapshot, isFridayCloseWindow } from "./market-state";
import { getRegimeControls } from "./regime-controls";

import { computeStrategyHealthFromHistory } from "./strategy-health";
import { writeFillAnalyticsEvent } from "./fill-analytics";
import { generatePerformanceFeedback } from "./performance-feedback";
import { capturePortfolioSnapshot } from "./portfolio-snapshots";
import { getOpenPositionsWithGreeks, computePortfolioGreeks } from "./portfolio-greeks";
import { monitorWorkingOrders, submitAdaptiveEntry } from "./execution-alpha";

const activeLocks = { scan: false, execute: false, position: false, recon: false, health: false };

class AutopilotEngine {
  private enabled = false;
  private paused = true;
  private mode: RuntimeMode = defaultV8Config.mode;
  private intervals: NodeJS.Timeout[] = [];
  private appPort = Number(process.env.PORT || 5000);
  private broker = new TastytradeBroker();

  async init() {
    const [state] = await db.select().from(autopilotState).limit(1);
    if (!state) {
      await db.insert(autopilotState).values({ mode: this.mode, isEnabled: false, isPaused: true, pauseReason: "init" });
    } else {
      this.mode = (state.mode as RuntimeMode) || this.mode;
      this.enabled = state.isEnabled;
      this.paused = state.isPaused;
    }
  }

  async setState(update: Partial<{ mode: RuntimeMode; isEnabled: boolean; isPaused: boolean; pauseReason: string | null; pausedUntil: string | null; warmModeUntil: string | null; activeModifiersJson: string | null }>) {
    const [state] = await db.select().from(autopilotState).limit(1);
    if (!state) return;
    await db.update(autopilotState).set({
      mode: update.mode ?? state.mode,
      isEnabled: update.isEnabled ?? state.isEnabled,
      isPaused: update.isPaused ?? state.isPaused,
      pauseReason: update.pauseReason === undefined ? state.pauseReason : update.pauseReason,
      pausedUntil: update.pausedUntil === undefined ? state.pausedUntil : update.pausedUntil,
      warmModeUntil: update.warmModeUntil === undefined ? state.warmModeUntil : update.warmModeUntil,
      activeModifiersJson: update.activeModifiersJson === undefined ? state.activeModifiersJson : update.activeModifiersJson,
    }).where(eq(autopilotState.id, state.id));
    this.mode = (update.mode ?? state.mode) as RuntimeMode;
    this.enabled = update.isEnabled ?? state.isEnabled;
    this.paused = update.isPaused ?? state.isPaused;
  }

  async start() {
    await this.init();
    await applyLossClusterPauseIfNeeded();
    const [state] = await db.select().from(autopilotState).limit(1);
    const warmModeActive =
      !!state?.warmModeUntil &&
      new Date(state.warmModeUntil).getTime() > Date.now();

    if (warmModeActive) {
      await db.insert(systemEvents).values({
        severity: "info",
        eventType: "warm_mode_active",
        message: "autopilot starting in warm mode",
        payload: JSON.stringify({ warmModeUntil: state?.warmModeUntil }),
      });
    }
    await this.setState({ isEnabled: true, isPaused: false, pauseReason: null });
    this.stopIntervals();
    this.intervals.push(setInterval(() => void this.scanLoop(), defaultV8Config.scanIntervalMs));
    this.intervals.push(setInterval(() => void this.executionLoop(), defaultV8Config.executionIntervalMs));
    this.intervals.push(setInterval(() => void this.positionLoop(), defaultV8Config.positionIntervalMs));
    this.intervals.push(setInterval(() => void this.reconLoop(), defaultV8Config.reconIntervalMs));
    this.intervals.push(setInterval(() => void this.healthLoop(), defaultV8Config.healthIntervalMs));
    v8log("info", "autopilot_started", { mode: this.mode });
    setTimeout(() => {
      void this.scanLoop();
      void this.executionLoop();
    }, 10_000);
  }

  async stop(reason = "manual") {
    this.stopIntervals();
    await this.setState({ isEnabled: false, isPaused: true, pauseReason: reason });
    v8log("warn", "autopilot_stopped", { reason });
  }

  private stopIntervals() {
    for (const t of this.intervals) clearInterval(t);
    this.intervals = [];
  }

  async status() {
    const [state] = await db.select().from(autopilotState).limit(1);
    const recentEvents = await db.select().from(systemEvents).orderBy(desc(systemEvents.createdAt)).limit(20);
    return { enabled: this.enabled, paused: this.paused, mode: this.mode, state, recentEvents };
  }

  private async currentThrottleState() {
    const [state] = await db.select().from(autopilotState).limit(1);

    const warmModeActive =
      !!state?.warmModeUntil &&
      new Date(state.warmModeUntil).getTime() > Date.now();

    const pausedUntilActive =
      !!state?.pausedUntil &&
      new Date(state.pausedUntil).getTime() > Date.now();

    const market = await getMarketSnapshot(this.broker);

    const mappedRegime =
      market.regime === "PANIC"
        ? "SEVERE"
        : market.regime === "ELEVATED" || market.regime === "SLOW_BEAR"
          ? "UNSTABLE"
          : "NORMAL";

    const regimeControls = getRegimeControls({
      regime: mappedRegime,
      vix: market.vix,
      vixShortMa: market.vixShortMa,
      vixSlope: market.vixSlope,
    });

    const fridayWindow = isFridayCloseWindow(new Date());

    let healthThrottle = 1;
    try {
      const active = state?.activeModifiersJson
        ? JSON.parse(String(state.activeModifiersJson))
        : {};
      if (active?.healthMode === "reduced") healthThrottle = 0.8;
      if (active?.healthMode === "defensive") healthThrottle = 0.5;
      if (active?.healthMode === "paused") healthThrottle = 0;
    } catch {
      healthThrottle = 1;
    }

    const modifier = resolveModifierPriority({
      killSwitch: false,
      reconciliationPause:
        !!state?.isPaused && state?.pauseReason === "broker_mismatch",
      hardRiskLimit: false,
      weekendThrottle: fridayWindow,
      regimeThrottle: regimeControls.throttle,
      opportunityThrottle: 1,
      participationThrottle: warmModeActive ? 0.5 : 1,
      healthThrottle,
    });

    return {
      warmModeActive,
      pausedUntilActive,
      modifier,
      market,
      regimeControls,
      fridayWindow,
      healthThrottle,
    };
  }

  private async scanCandidates(): Promise<ScanPick[]> {
    const now = new Date();
    const day = now.getUTCDay();
    const hourEtApprox = (now.getUTCHours() - 4 + 24) % 24;
    if (day === 1 && hourEtApprox < defaultV8Config.mondayResumeHourET) return [];
    if (day === 5 && hourEtApprox >= 12) return [];
    if (hourEtApprox < defaultV8Config.entryStartHourET || hourEtApprox >= defaultV8Config.entryStopHourET) return [];

    const tokenOk = await this.broker.warmupToken(3, 3000);
    if (!tokenOk) {
      v8log("warn", "scan_loop_token_warmup_failed", {});
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), Math.min(defaultV8Config.scanTimeoutMs * 4, 90_000));
    let data: ScanResponse;
    try {
      v8log("info", "scan_loop_fetch_start", { port: this.appPort });
      const scanReq = await fetch(`http://127.0.0.1:${this.appPort}/api/scan`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode: "v8", autopilot: true }),
        signal: controller.signal,
      });
      data = (await scanReq.json()) as ScanResponse;
      const candidatePool = (data as any).candidates;
      v8log("info", "scan_loop_fetch_done", { ok: data.ok, picks: data.picks?.length ?? 0, candidates: candidatePool?.length ?? 0, reject: data.reject });
    } catch (e: any) {
      v8log("warn", "scan_loop_fetch_failed", { error: String(e?.message || e) });
      return [];
    } finally {
      clearTimeout(timeout);
    }
    if (!data.ok || !Array.isArray(data.picks)) return [];

    const fullPool: ScanPick[] = Array.isArray((data as any).candidates) ? (data as any).candidates : data.picks;

    const scanSettings = await getAppSettings();
    const disabledTickers: string[] = (() => {
      try { return JSON.parse(scanSettings?.disabledTickersJson || "[]").map((t: string) => t.toUpperCase()); } catch { return []; }
    })();

    const currentPositions = await db.select().from(positions).where(eq(positions.status, "open"));
    const existingPicks: ScanPick[] = currentPositions.map((p) => ({
      ticker: p.ticker, sector: (p as any).sector || "Unknown", price: 0, expiration: p.expiration, dte: p.entryDte ?? null,
      engine: "LIVE", shortPut: p.shortStrike, longPut: p.longStrike, width: p.entryWidth ?? Math.abs(p.shortStrike - p.longStrike),
      shortBid: 0, longAsk: 0, credit: p.credit, creditPctWidth: 0, distancePct: 10, shortDeltaAbs: p.entryDelta ?? 0.1,
      maxLoss: p.maxRisk, rorPct: 0, contracts: p.contracts, tradeRisk: p.maxRisk, slippageRatio: 1, confidence: p.entryConfidence ?? 80,
      beta: p.beta ?? 1,
    }));

    const filteredPicks = fullPool.filter((pick) => !disabledTickers.includes(pick.ticker.toUpperCase()));
    const qualified: ScanPick[] = [];
    for (const pick of filteredPicks) {
      const decision = await evaluateCandidate(existingPicks, pick, day === 5 ? "weekend" : "weekday");
      v8log("info", "scan_loop_risk_eval", {
        ticker: pick.ticker, allow: decision.allow, reason: decision.reason ?? null,
        confidence: pick.confidence, credit: pick.credit, distancePct: pick.distancePct,
        delta: pick.shortDeltaAbs, slippageRatio: pick.slippageRatio, liquidityScore: decision.liquidityScore,
      });
      if (decision.allow) qualified.push(pick);
    }

    return qualified;
  }

  private async processCandidate(pick: ScanPick) {
    const now = new Date();
    const day = now.getUTCDay();
    const dedupeKey = `${pick.ticker}|${pick.expiration}|${pick.shortPut}|${pick.longPut}|sell_put_spread`;
    const dup = await db.select().from(orderIntents).where(and(eq(orderIntents.dedupeKey, dedupeKey), inArray(orderIntents.state, ["RISK_APPROVED", "ORDER_SUBMITTED", "ORDER_INTENT_CREATED", "FILLED"] as any))).limit(1);
    if (dup.length) return;

    const currentPositions = await db.select().from(positions).where(eq(positions.status, "open"));
    const existingPicks: ScanPick[] = currentPositions.map((p) => ({
      ticker: p.ticker, sector: (p as any).sector || "Unknown", price: 0, expiration: p.expiration, dte: p.entryDte ?? null,
      engine: "LIVE", shortPut: p.shortStrike, longPut: p.longStrike, width: p.entryWidth ?? Math.abs(p.shortStrike - p.longStrike),
      shortBid: 0, longAsk: 0, credit: p.credit, creditPctWidth: 0, distancePct: 10, shortDeltaAbs: p.entryDelta ?? 0.1,
      maxLoss: p.maxRisk, rorPct: 0, contracts: p.contracts, tradeRisk: p.maxRisk, slippageRatio: 1, confidence: p.entryConfidence ?? 80,
      beta: p.beta ?? 1,
    }));

    const decision = await evaluateCandidate(existingPicks, pick, day === 5 ? "weekend" : "weekday");
    v8log("info", "candidate_evaluated", {
      ticker: pick.ticker,
      allow: decision.allow,
      reason: decision.reason ?? null,
      credit: pick.credit,
      distancePct: pick.distancePct,
      delta: pick.shortDeltaAbs,
      confidence: pick.confidence,
      liquidityScore: decision.liquidityScore,
    });
    if (!decision.allow) return;

    await db.insert(orderIntents).values({
      dedupeKey,
      ticker: pick.ticker,
      sector: pick.sector,
      expiration: pick.expiration,
      shortStrike: pick.shortPut,
      longStrike: pick.longPut,
      width: pick.width,
      intendedCredit: pick.credit,
      contracts: Math.max(1, pick.contracts),
      confidence: pick.confidence,
      liquidityScore: decision.liquidityScore || 0,
      state: "RISK_APPROVED",
      metadata: JSON.stringify(pick),
    });
  }

  private async scanLoop() {
    if (!this.enabled || activeLocks.scan) return;
    activeLocks.scan = true;
    v8log("info", "scan_loop_start", { enabled: this.enabled, mode: this.mode });
    try {
      const [state] = await db.select().from(autopilotState).limit(1);

      if (
        state?.isPaused &&
        state?.pausedUntil &&
        new Date(state.pausedUntil).getTime() <= Date.now()
      ) {
        await this.setState({
          isPaused: false,
          pauseReason: null,
          pausedUntil: null,
        });
      }

      const throttleState = await this.currentThrottleState();
      v8log("info", "scan_loop_throttle", {
        paused: throttleState.modifier.paused,
        allowNewTrades: throttleState.regimeControls.allowNewTrades,
        regime: throttleState.regimeControls.effectiveRegime,
        throttle: throttleState.modifier.effectiveThrottle,
      });

      if (this.mode === "LIVE") {
        if (!throttleState.market?.spyReference || !throttleState.market?.vix) return;
      }

      if (throttleState.modifier.paused) return;
      if (!throttleState.regimeControls.allowNewTrades) {
        if (state) {
          await db
            .update(autopilotState)
            .set({
              lastScanAt: new Date(),
              activeModifiersJson: JSON.stringify({
                activeModifier: "regime",
                regime: throttleState.regimeControls.effectiveRegime,
                throttle: throttleState.regimeControls.throttle,
                reason: throttleState.regimeControls.reason,
                warmMode: throttleState.warmModeActive,
                spyChangePct: throttleState.market.spyChangePct,
                vix: throttleState.market.vix,
              }),
            } as any)
            .where(eq(autopilotState.id, state.id));
        }
        return;
      }

      const effectiveThrottle = throttleState.modifier.effectiveThrottle;

      const scanResult = await this.scanCandidates();
      const allCandidates = Array.isArray(scanResult) ? scanResult : [];

      const allowedCount = Math.max(
        0,
        Math.floor(allCandidates.length * effectiveThrottle),
      );

      const preselectedCandidates = allCandidates.slice(0, allowedCount);

      const existingOpenPositions = await db
        .select()
        .from(positions)
        .where(eq(positions.status, "open"))
        .catch(() => []);

      const mappedForSelection = preselectedCandidates.map((c) => ({
        ...c,
        delta: c.shortDeltaAbs,
        distanceOtmPct: c.distancePct,
        creditPctOfWidth: c.creditPctWidth,
        maxRisk: c.maxLoss,
      }));

      const candidates = takeInstitutionalPicks(mappedForSelection as any[], {
        vix: throttleState.market.vix,
        regime: throttleState.market.regime,
        existingPositions: existingOpenPositions.map((p) => ({
          ticker: p.ticker,
          sector: (p as any).sector || null,
          subIndustry: (p as any).subIndustry || null,
          maxRisk: p.maxRisk,
        })),
        maxCount: throttleState.regimeControls.maxTradesToday,
      });

      await db.insert(systemEvents).values({
        severity: "info",
        eventType: "institutional_selection_ranked",
        message: `Institutional selector chose ${candidates.length} candidates`,
        engineVersion: ENGINE_VERSION,
        payload: JSON.stringify(
          candidates.slice(0, 10).map((c: any) => ({
            ticker: c.ticker,
            sector: c.sector,
            subIndustry: c.subIndustry,
            confidence: c.confidence,
            delta: c.delta ?? c.shortDeltaAbs,
            distanceOtmPct: c.distanceOtmPct ?? c.distancePct,
            creditPctOfWidth: c.creditPctOfWidth ?? c.creditPctWidth,
            dte: c.dte,
            engine: c.engine,
          })),
        ),
      } as any);

      if (state) {
        await db
          .update(autopilotState)
          .set({
            lastScanAt: new Date(),
            activeModifiersJson: JSON.stringify({
              activeModifier: throttleState.modifier.activeModifier,
              regime: throttleState.regimeControls.effectiveRegime,
              throttle: effectiveThrottle,
              reason: throttleState.regimeControls.reason,
              warmMode: throttleState.warmModeActive,
              maxTradesToday: throttleState.regimeControls.maxTradesToday,
              spyChangePct: throttleState.market.spyChangePct,
              vix: throttleState.market.vix,
              vixShortMa: throttleState.market.vixShortMa,
              vixSlope: throttleState.market.vixSlope,
            }),
          } as any)
          .where(eq(autopilotState.id, state.id));
      }

      const todaysApprovedCount = await db
        .select()
        .from(orderIntents)
        .where(
          sql`${orderIntents.createdAt} >= date_trunc('day', now()) and ${orderIntents.state} in ('ORDER_SUBMITTED','FILLED')`,
        )
        .then((r) => r.length)
        .catch(() => 0);

      if (todaysApprovedCount >= throttleState.regimeControls.maxTradesToday) {
        return;
      }

      v8log("info", "scan_loop_candidates", {
        rawCount: allCandidates.length,
        throttledCount: candidates.length,
        throttle: effectiveThrottle,
        todaysApprovedCount,
        maxTradesToday: throttleState.regimeControls.maxTradesToday,
      });

      let greeksGovernance = { allowed: true, reason: "" };
      try {
        const posWithGreeks = await getOpenPositionsWithGreeks(throttleState.market?.spyPrice ?? 500);
        const portfolioGreeks = computePortfolioGreeks(posWithGreeks);
        if (Math.abs(portfolioGreeks.betaWeightedDelta) > 3.0) {
          greeksGovernance = { allowed: false, reason: `beta-weighted delta ${portfolioGreeks.betaWeightedDelta.toFixed(3)} exceeds ±3.0 limit` };
        }
      } catch (greeksErr: any) {
        v8log("warn", "greeks_governance_check_failed", { error: greeksErr?.message || String(greeksErr) });
      }

      if (!greeksGovernance.allowed) {
        v8log("warn", "greeks_governance_blocked", { reason: greeksGovernance.reason });
        await db.insert(systemEvents).values({
          severity: "warn",
          eventType: "greeks_governance_blocked",
          message: greeksGovernance.reason,
          engineVersion: ENGINE_VERSION,
        } as any);
        return;
      }

      for (const candidate of candidates as any[]) {
        const isEtf = String(candidate.sector ?? "").toLowerCase().includes("etf");

        const eventControls = await getEventControls({
          ticker: candidate.ticker,
          isEtf,
          liveMode: this.mode === "LIVE",
        });

        if (eventControls.macroBlackout && eventControls.etfOnly && !isEtf) {
          continue;
        }

        if (eventControls.singleStockBlackout) {
          continue;
        }

        const openPositionsRaw = await db
          .select()
          .from(positions)
          .where(eq(positions.status, "open"))
          .catch(() => []);

        const openPositions = openPositionsRaw.map((p) => {
          const width = Math.abs(p.shortStrike - p.longStrike);
          return {
            ...p,
            maxRisk: width > 0 ? (width - p.credit) * 100 * p.contracts : (p.maxRisk ?? 0),
          };
        });

        const deployment = checkDeploymentGuard(
          openPositions as any[],
          {
            ticker: candidate.ticker,
            sector: candidate.sector,
            projectedRisk: Number(candidate.tradeRisk ?? candidate.maxRisk ?? 0),
            isHighBeta: String(candidate.sector ?? "").toLowerCase().includes("high beta"),
          },
          {
            accountEquity: Number(candidate.accountEquity ?? 3000),
            targetDeploymentPct: 0.35,
            hardMaxDeploymentPct: 0.50,
            maxRiskPerTradeHardCap: 75,
            sectorCapPct: 0.20,
            highBetaCapPct: 0.10,
          },
        );

        if (!deployment.allowed) {
          continue;
        }

        await this.processCandidate(candidate);
      }

      capturePortfolioSnapshot(this.broker).catch((err: any) =>
        v8log("warn", "snapshot_capture_failed", { error: err?.message }),
      );
    } catch (e: any) {
      await db.insert(systemEvents).values({
        severity: "critical",
        eventType: "scan_loop_failed",
        message: String(e?.message || e),
      });
    } finally {
      activeLocks.scan = false;
    }
  }

  private async submitIntent(intent: any) {
    if (this.mode === "DRY_RUN") {
      await db.update(orderIntents).set({ state: "ORDER_INTENT_CREATED" }).where(eq(orderIntents.id, intent.id));
      return;
    }
    if (this.mode === "PAPER") {
      const pickMeta = (() => { try { return JSON.parse(intent.metadata || "{}"); } catch { return {}; } })();
      await db.insert(positions).values({
        ticker: intent.ticker,
        shortStrike: intent.shortStrike,
        longStrike: intent.longStrike,
        credit: intent.intendedCredit,
        contracts: intent.contracts,
        expiration: intent.expiration,
        entryDate: new Date().toISOString().slice(0, 10),
        maxRisk: Math.max(1, ((intent.width - intent.intendedCredit) * 100) * intent.contracts),
        notes: JSON.stringify({ source: "PAPER_AUTOPILOT", intentId: intent.id, confidence: intent.confidence, liquidityScore: intent.liquidityScore }),
        status: "open",
        entryConfidence: intent.confidence,
        entryLiquidityScore: intent.liquidityScore,
        entryWidth: intent.width,
        entryDte: pickMeta.dte ?? null,
        entryDelta: pickMeta.shortDeltaAbs ?? null,
        sector: normalizePositionMetadata({ ticker: intent.ticker, sector: intent.sector || pickMeta.sector }).sector,
        subIndustry: normalizePositionMetadata({ ticker: intent.ticker, subIndustry: pickMeta.subIndustry }).subIndustry,
        beta: normalizePositionMetadata({ ticker: intent.ticker, beta: pickMeta.beta }).beta,
        engineVersion: ENGINE_VERSION,
        selectionVersion: SELECTION_VERSION,
      } as any);
      await db.update(orderIntents).set({ state: "FILLED", engineVersion: ENGINE_VERSION, selectionVersion: SELECTION_VERSION } as any).where(eq(orderIntents.id, intent.id));
      await db.insert(brokerOrders).values({ orderIntentId: intent.id, status: "paper_filled", requestedPrice: intent.intendedCredit, fillPrice: intent.intendedCredit, engineVersion: ENGINE_VERSION, selectionVersion: SELECTION_VERSION } as any);
      return;
    }
    const health = await this.broker.health();
    if (!health.ok) {
      await this.setState({ isPaused: true, pauseReason: "broker_health_failed" });
      return;
    }

    const submit = await submitAdaptiveEntry(this.broker, intent, "NORMAL");

    if (!submit) {
      await db.update(orderIntents).set({ state: "ERROR", updatedAt: new Date(), engineVersion: ENGINE_VERSION, selectionVersion: SELECTION_VERSION } as any).where(eq(orderIntents.id, intent.id));
      return;
    }

    await db.insert(brokerOrders).values({
      orderIntentId: intent.id,
      brokerOrderId: submit.brokerOrderId ?? null,
      ticker: intent.ticker,
      side: "entry",
      status: submit.status || "submitted",
      requestedPrice: Number(intent.intendedCredit ?? 0),
      rawResponse: JSON.stringify(submit.body),
      rawJson: JSON.stringify(submit.body),
      createdAt: new Date(),
      updatedAt: new Date(),
      engineVersion: ENGINE_VERSION,
      selectionVersion: SELECTION_VERSION,
      executionPolicy: submit.policy?.policyName ?? null,
      initialLimit: submit.initialLimit ?? null,
    } as any);

    await db
      .update(orderIntents)
      .set({
        state: submit.ok ? "ORDER_SUBMITTED" : "ERROR",
        updatedAt: new Date(),
        engineVersion: ENGINE_VERSION,
        selectionVersion: SELECTION_VERSION,
      } as any)
      .where(eq(orderIntents.id, intent.id));
  }

  private async executionLoop() {
    if (!this.enabled || activeLocks.execute) return;
    activeLocks.execute = true;
    try {
      if (this.mode === "LIVE") {
        await syncLiveOrdersAndCreatePositions(this.broker);
        await monitorWorkingOrders(this.broker).catch((err: any) =>
          v8log("warn", "monitor_working_orders_failed", { error: err?.message }),
        );
      }

      const throttleState = await this.currentThrottleState();
      if (throttleState.modifier.paused) return;
      if (!throttleState.regimeControls.allowNewTrades) return;

      const [state] = await db.select().from(autopilotState).limit(1);
      if (state?.isPaused) return;

      const intents = await db
        .select()
        .from(orderIntents)
        .where(eq(orderIntents.state, "RISK_APPROVED"));

      const baseCap = throttleState.regimeControls.maxTradesToday;
      const healthAdjustedCap =
        throttleState.healthThrottle <= 0
          ? 0
          : Math.max(0, Math.floor(baseCap * throttleState.healthThrottle));

      const executionCap = throttleState.warmModeActive
        ? Math.min(1, healthAdjustedCap)
        : healthAdjustedCap;

      const limitedIntents = intents.slice(0, executionCap);

      for (const intent of limitedIntents) {
        const duplicateEntry = await db
          .select()
          .from(brokerOrders)
          .where(
            sql`${brokerOrders.ticker} = ${intent.ticker}
                and ${brokerOrders.side} = 'entry'
                and ${brokerOrders.status} in ('submitted','received','working','live','open')`,
          )
          .limit(1);

        if (duplicateEntry.length > 0) {
          continue;
        }

        await this.submitIntent(intent);
      }
    } catch (e: any) {
      await db.insert(systemEvents).values({
        severity: "critical",
        eventType: "execution_loop_failed",
        message: String(e?.message || e),
      });

      if (this.mode === "LIVE") {
        await this.setState({
          isPaused: true,
          pauseReason: "execution_loop_failed",
        });
      }
    } finally {
      activeLocks.execute = false;
    }
  }

  private async positionLoop() {
    if (!this.enabled || activeLocks.position) return;
    activeLocks.position = true;
    try {
      const [state] = await db.select().from(autopilotState).limit(1);

      const snapshot = await getMarketSnapshot(this.broker);
      const marketState = {
        regime: snapshot.regime,
        isFridayCloseWindow: isFridayCloseWindow(new Date()),
      };

      const appSettings = await getAppSettings();
      const settings = {
        exitStrategyMode:
          appSettings?.exitStrategyMode || "HYBRID_SMART_EXIT",
      };

      const snapshots = await getLiveManagedPositions(this.broker);

      for (const snap of snapshots) {
        const decision = shouldCloseForRisk(snap, marketState, settings);
        await logPositionDecision(snap, decision);

        if (!decision.close) continue;

        if (this.mode === "DRY_RUN") {
          await db.insert(systemEvents).values({
            severity: "info",
            eventType: "dry_run_close_signal",
            message: `${snap.ticker} close signaled in DRY_RUN`,
            payload: JSON.stringify(decision),
          });
          continue;
        }

        if (this.mode === "PAPER") {
          await db
            .update(positions)
            .set({
              status: "closed",
              closedAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            } as any)
            .where(eq(positions.id, snap.positionId as any));

          await db.insert(systemEvents).values({
            severity: "info",
            eventType: "paper_position_closed",
            message: `${snap.ticker} closed in PAPER mode`,
            payload: JSON.stringify(decision),
          });
          continue;
        }

        const existingLiveExit = await db
          .select()
          .from(brokerOrders)
          .where(
            sql`${brokerOrders.positionId} = ${snap.positionId}
                and ${brokerOrders.side} = 'exit'
                and ${brokerOrders.status} in ('submitted','received','working','live','open')`,
          )
          .limit(1);

        if (existingLiveExit.length > 0) {
          await db.insert(systemEvents).values({
            severity: "info",
            eventType: "exit_order_already_working",
            message: `${snap.ticker} already has a live exit order`,
            engineVersion: ENGINE_VERSION,
            payload: JSON.stringify({
              positionId: snap.positionId,
              brokerOrderId: existingLiveExit[0].brokerOrderId,
            }),
          } as any);
          continue;
        }

        const closeResult = await this.broker.submitCloseVerticalSpread({
          ticker: snap.ticker,
          expiration: snap.expiration,
          shortStrike: Number(snap.shortStrike),
          longStrike: Number(snap.longStrike),
          quantity: Number(snap.contracts),
          limitPrice: Number(snap.currentMark || 0.05),
        });

        await db.insert(brokerOrders).values({
          orderIntentId: null,
          positionId: snap.positionId,
          brokerOrderId: closeResult.brokerOrderId ?? null,
          ticker: snap.ticker,
          side: "exit",
          status: closeResult.status || "submitted",
          requestedPrice: Number(snap.currentMark || 0.05),
          rawResponse: JSON.stringify(closeResult.body),
          rawJson: JSON.stringify(closeResult.body),
          createdAt: new Date(),
          updatedAt: new Date(),
          engineVersion: ENGINE_VERSION,
          selectionVersion: SELECTION_VERSION,
        } as any);

        await db.insert(systemEvents).values({
          severity: "warn",
          eventType: "live_close_requested",
          message: `${snap.ticker} close order submitted in LIVE mode`,
          payload: JSON.stringify({
            decision,
            closeResult,
            positionId: snap.positionId,
          }),
        });
      }
    } catch (e: any) {
      await db.insert(systemEvents).values({
        severity: "critical",
        eventType: "position_loop_failed",
        message: String(e?.message || e),
      });
    } finally {
      activeLocks.position = false;
    }
  }

  private async reconLoop() {
    if (!this.enabled || activeLocks.recon) return;
    activeLocks.recon = true;
    try {
      const recon = await reconcileBrokerState(this.broker);
      const [state] = await db.select().from(autopilotState).limit(1);

      if (state) {
        await db
          .update(autopilotState)
          .set({ lastReconAt: new Date().toISOString() } as any)
          .where(eq(autopilotState.id, state.id));
      }

      if (!recon.ok) {
        await db.insert(systemEvents).values({
          severity: recon.severity === "warn" ? "warn" : "critical",
          eventType: "broker_mismatch",
          message: recon.reason || "broker/internal state mismatch",
          payload: JSON.stringify(recon),
        });

        if (this.mode === "LIVE") {
          const mismatchSymbols = recon.mismatches
            .map((m: any) =>
              String(
                m?.internal?.ticker ??
                  m?.broker?.symbol ??
                  m?.broker?.underlying_symbol ??
                  "",
              ).toUpperCase(),
            )
            .filter(Boolean);

          if (recon.severity === "flatten_symbol" && mismatchSymbols.length > 0) {
            const flattenResults = await flattenMismatchSymbols(
              mismatchSymbols,
              this.broker,
            );

            await db.insert(systemEvents).values({
              severity: "critical",
              eventType: "mismatch_flatten_symbol",
              message: "flattened mismatch symbols after reconciliation failure",
              payload: JSON.stringify(flattenResults),
            });
          }

          await this.setState({
            isPaused: true,
            pauseReason: recon.reason || "broker_mismatch",
          });
        }
      }
    } catch (e: any) {
      await db.insert(systemEvents).values({
        severity: "critical",
        eventType: "reconciliation_failed",
        message: String(e?.message || e),
      });

      if (this.mode === "LIVE") {
        await this.setState({
          isPaused: true,
          pauseReason: "reconciliation_failed",
        });
      }
    } finally {
      activeLocks.recon = false;
    }
  }

  private async healthLoop() {
    if (!this.enabled || activeLocks.health) return;
    activeLocks.health = true;
    try {
      const health = await healthSnapshot();
      const [state] = await db.select().from(autopilotState).limit(1);

      if (state) {
        await db
          .update(autopilotState)
          .set({
            lastHeartbeatAt: new Date().toISOString(),
            lastHealthAt: new Date().toISOString(),
          } as any)
          .where(eq(autopilotState.id, state.id));
      }

      if (!health.ok) {
        await db.insert(systemEvents).values({
          severity: "warn",
          eventType: "health_degraded",
          message: "autopilot health degraded",
          payload: JSON.stringify(health),
        });

        if (this.mode === "LIVE" && (!health.brokerOk || !health.dbOk || !health.loopsAlive)) {
          await this.setState({
            isPaused: true,
            pauseReason: "health_degraded",
          });
        }
      }

      const strategy = await computeStrategyHealthFromHistory();
      const fills = await writeFillAnalyticsEvent(30);
      const feedback = await generatePerformanceFeedback(60);

      if (state) {
        await db
          .update(autopilotState)
          .set({
            activeModifiersJson: JSON.stringify({
              healthMode: strategy.mode,
              healthScore: strategy.score,
              winRate: strategy.winRate,
              profitFactor: strategy.profitFactor,
              loopsAlive: health.loopsAlive,
              staleDataRateOk: health.staleDataRateOk,
            }),
          } as any)
          .where(eq(autopilotState.id, state.id));
      }

      if (strategy.mode === "paused" && this.mode === "LIVE") {
        await this.setState({
          isPaused: true,
          pauseReason: "strategy_health_paused",
        });
      }

      await db.insert(systemEvents).values({
        severity: "info",
        eventType: "health_loop_summary",
        message: "Health loop completed",
        payload: JSON.stringify({
          health,
          strategy,
          topPoorFillTickers: fills.filter((f) => f.poorFill).slice(0, 10),
          feedbackSummary: {
            totalTrades: feedback.totalTrades,
            totalPnl: feedback.totalPnl,
            winRate: feedback.winRate,
          },
        }),
      });
    } catch (e: any) {
      await db.insert(systemEvents).values({
        severity: "critical",
        eventType: "health_loop_failed",
        message: String(e?.message || e),
      });
    } finally {
      activeLocks.health = false;
    }
  }
}

export const autopilotEngine = new AutopilotEngine();

export function registerAutopilotRoutes(app: Express) {
  app.get("/api/autopilot/status", async (_req, res) => {
    res.json(await autopilotEngine.status());
  });
  app.post("/api/autopilot/start", async (req, res) => {
    if (req.body?.mode) await autopilotEngine.setState({ mode: req.body.mode });
    await autopilotEngine.start();
    res.json({ ok: true });
  });
  app.post("/api/autopilot/stop", async (req, res) => {
    await autopilotEngine.stop(req.body?.reason || "manual");
    res.json({ ok: true });
  });
}
