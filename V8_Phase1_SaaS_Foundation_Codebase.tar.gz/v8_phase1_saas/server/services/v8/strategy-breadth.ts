import type { ScanPick } from "./types";

export function scoreBreadth(candidates: ScanPick[]) {
  const uniqueTickers = new Set(candidates.map((c) => c.ticker));
  const uniqueSectors = new Set(candidates.map((c) => c.sector));
  const uniqueSubs = new Set(candidates.map((c) => c.subIndustry || c.ticker));
  const concentration = Math.max(0, ...Array.from(uniqueSectors).map((s) => candidates.filter((c) => c.sector === s).length / Math.max(1, candidates.length)));
  const breadthScore = Math.round(Math.min(100,
    uniqueTickers.size * 8 + uniqueSectors.size * 12 + uniqueSubs.size * 5 - concentration * 30,
  ));
  return {
    breadthScore,
    uniqueTickerCount: uniqueTickers.size,
    uniqueSectorCount: uniqueSectors.size,
    uniqueSubIndustryCount: uniqueSubs.size,
    concentration,
    deploymentModifier: breadthScore >= 70 ? 1 : breadthScore >= 50 ? 0.85 : breadthScore >= 30 ? 0.65 : 0.5,
    participationModifier: breadthScore >= 70 ? 1 : breadthScore >= 50 ? 0.9 : breadthScore >= 30 ? 0.75 : 0.5,
  };
}
