import type { MarketRegime } from "./types";

export type RegimeOutput = {
  regime: MarketRegime;
  confidenceModifier: number;
  distanceModifier: number;
  riskModifier: number;
  participationModifier: number;
  etfOnly: boolean;
};

export function classifyRegime(vix: number, spyTrendDown: boolean): RegimeOutput {
  if (spyTrendDown && vix > 22) {
    return { regime: "SLOW_BEAR", confidenceModifier: 1.1, distanceModifier: 1.15, riskModifier: 0.7, participationModifier: 0.5, etfOnly: false };
  }
  if (vix > 30) return { regime: "PANIC", confidenceModifier: 1.2, distanceModifier: 1.25, riskModifier: 0.5, participationModifier: 0.25, etfOnly: true };
  if (vix > 22) return { regime: "ELEVATED", confidenceModifier: 1.1, distanceModifier: 1.1, riskModifier: 0.8, participationModifier: 0.7, etfOnly: false };
  if (vix < 14) return { regime: "LOW_VOL", confidenceModifier: 1.0, distanceModifier: 0.95, riskModifier: 1.0, participationModifier: 1.0, etfOnly: false };
  return { regime: "NORMAL", confidenceModifier: 1.0, distanceModifier: 1.0, riskModifier: 1.0, participationModifier: 1.0, etfOnly: false };
}
