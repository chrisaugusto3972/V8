export type MacroEventType = "FOMC" | "CPI" | "JOBS";

export type EventControls = {
  macroBlackout: boolean;
  singleStockBlackout: boolean;
  etfOnly: boolean;
  reason: string | null;
};

const MACRO_BLACKOUT_DATES: Record<string, MacroEventType> = {
};

function toYmd(d: Date) {
  return d.toISOString().slice(0, 10);
}

export async function hasUpcomingEarnings(
  _ticker: string,
  _withinTradingDays = 3,
): Promise<boolean> {
  return false;
}

export function isMacroBlackoutDay(date = new Date()): {
  blackout: boolean;
  type?: MacroEventType;
} {
  const ymd = toYmd(date);
  const type = MACRO_BLACKOUT_DATES[ymd];
  if (type) return { blackout: true, type };
  return { blackout: false };
}

export async function getEventControls(params: {
  ticker: string;
  isEtf: boolean;
  liveMode: boolean;
  date?: Date;
}): Promise<EventControls> {
  const macro = isMacroBlackoutDay(params.date ?? new Date());
  if (macro.blackout) {
    return {
      macroBlackout: true,
      singleStockBlackout: !params.isEtf,
      etfOnly: true,
      reason: `macro_blackout_${macro.type}`,
    };
  }

  if (!params.isEtf) {
    const earningsSoon = await hasUpcomingEarnings(params.ticker, 3);
    if (earningsSoon) {
      return {
        macroBlackout: false,
        singleStockBlackout: true,
        etfOnly: false,
        reason: "earnings_blackout",
      };
    }

    if (params.liveMode === true) {
      return {
        macroBlackout: false,
        singleStockBlackout: false,
        etfOnly: false,
        reason: null,
      };
    }
  }

  return {
    macroBlackout: false,
    singleStockBlackout: false,
    etfOnly: false,
    reason: null,
  };
}
