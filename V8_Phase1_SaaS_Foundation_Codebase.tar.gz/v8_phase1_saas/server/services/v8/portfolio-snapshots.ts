import { db } from "../../db";
import { portfolioSnapshots } from "@shared/schema";
import { getOpenPositionsWithGreeks, computePortfolioGreeks } from "./portfolio-greeks";
import { computePortfolioStressTest } from "./portfolio-stress";
import { getMarketSnapshot } from "./market-state";
import { ENGINE_VERSION, SELECTION_VERSION } from "./version";
import { TastytradeBroker } from "../../brokers/tastytrade";

export async function capturePortfolioSnapshot(broker?: TastytradeBroker) {
  try {
    const market = await getMarketSnapshot(broker ?? new TastytradeBroker());
    const positionsWithGreeks = await getOpenPositionsWithGreeks(market.spyPrice);
    const greeks = computePortfolioGreeks(positionsWithGreeks);
    const stress = computePortfolioStressTest(greeks, market);

    await db.insert(portfolioSnapshots).values({
      engineVersion: ENGINE_VERSION,
      selectionVersion: SELECTION_VERSION,
      openPositionsCount: greeks.openPositionsCount,
      totalMaxRisk: greeks.totalMaxRisk,
      totalNetDelta: greeks.totalNetDelta,
      totalNetTheta: greeks.totalNetTheta,
      betaWeightedDelta: greeks.betaWeightedDelta,
      highBetaRisk: greeks.highBetaRisk,
      singleStockRisk: greeks.singleStockRisk,
      etfRisk: greeks.etfRisk,
      sectorExposureJson: JSON.stringify(greeks.riskBySector),
      tickerExposureJson: JSON.stringify(greeks.riskByTicker),
      stressSpyDown1pct: stress.spyDown1pct,
      stressSpyDown2pct: stress.spyDown2pct,
      stressSpyDown3pct: stress.spyDown3pct,
      stressVolUp5: stress.volUp5,
      stressVolUp10: stress.volUp10,
    } as any);

    return {
      greeks,
      stress,
      analyticsSourceSummary: {
        liveGreeksCount: greeks.liveGreeksCount,
        approxGreeksCount: greeks.approxGreeksCount,
      },
    };
  } catch (e: any) {
    console.error("[portfolio-snapshots] capturePortfolioSnapshot failed:", e?.message);
    return null;
  }
}
