import { desc, sql } from "drizzle-orm";
import { db } from "../../db";
import { positions } from "@shared/schema";

function safeNum(v: any, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

export type StrategyHealthInput = {
  winRate: number;
  profitFactor: number;
  executionScore: number;
  liquidityScore: number;
  participationQuality: number;
};

export type StrategyHealthResult = {
  score: number;
  mode: "normal" | "reduced" | "defensive" | "paused";
  participationThrottle: number;
  riskThrottle: number;
};

export function computeStrategyHealth(
  input: StrategyHealthInput,
): StrategyHealthResult {
  const normalizedProfitFactor = Math.min(1, input.profitFactor / 2);
  const score =
    input.winRate * 0.3 +
    normalizedProfitFactor * 0.25 +
    input.executionScore * 0.2 +
    input.liquidityScore * 0.15 +
    input.participationQuality * 0.1;

  if (score >= 0.8) {
    return {
      score,
      mode: "normal",
      participationThrottle: 1,
      riskThrottle: 1,
    };
  }

  if (score >= 0.65) {
    return {
      score,
      mode: "reduced",
      participationThrottle: 0.8,
      riskThrottle: 0.9,
    };
  }

  if (score >= 0.5) {
    return {
      score,
      mode: "defensive",
      participationThrottle: 0.5,
      riskThrottle: 0.7,
    };
  }

  return {
    score,
    mode: "paused",
    participationThrottle: 0,
    riskThrottle: 0,
  };
}

export async function computeStrategyHealthFromHistory(): Promise<
  StrategyHealthResult & {
    trades: number;
    winRate: number;
    profitFactor: number;
  }
> {
  const closed = await db
    .select()
    .from(positions)
    .where(sql`${positions.status} = 'closed' and ${positions.closedAt} is not null`)
    .orderBy(desc(positions.closedAt))
    .limit(100);

  let wins = 0;
  let grossProfit = 0;
  let grossLossAbs = 0;

  for (const p of closed) {
    const pnl = safeNum((p as any).realizedPnl, 0);
    if (pnl >= 0) {
      wins += 1;
      grossProfit += pnl;
    } else {
      grossLossAbs += Math.abs(pnl);
    }
  }

  const trades = closed.length;
  const winRate = trades ? wins / trades : 0.7;
  const profitFactor =
    grossLossAbs > 0 ? grossProfit / grossLossAbs : grossProfit > 0 ? 2 : 1;

  const executionScore = trades >= 10 ? 0.8 : 0.7;
  const liquidityScore = 0.8;
  const participationQuality = trades >= 10 ? 0.8 : 0.7;

  const result = computeStrategyHealth({
    winRate,
    profitFactor,
    executionScore,
    liquidityScore,
    participationQuality,
  });

  return {
    ...result,
    trades,
    winRate,
    profitFactor,
  };
}
