import { eq } from "drizzle-orm";
import { db } from "../../db";
import { positions, systemEvents } from "@shared/schema";
import { TastytradeBroker } from "../../brokers/tastytrade";

function safeNum(v: any, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function daysToExpiration(expiration?: string | null) {
  if (!expiration) return 0;
  const exp = new Date(expiration);
  if (Number.isNaN(exp.getTime())) return 0;
  return Math.max(0, Math.ceil((exp.getTime() - Date.now()) / 86400000));
}

function computeProfitPct(entryCredit: number, currentMark: number) {
  if (!entryCredit || entryCredit <= 0) return 0;
  return (entryCredit - currentMark) / entryCredit;
}

function normalizeBrokerLeg(raw: any) {
  const symbol =
    raw?.symbol ??
    raw?.underlying_symbol ??
    raw?.instrument?.underlying_symbol ??
    "";
  const expiration =
    raw?.expiration_date ??
    raw?.instrument?.expiration_date ??
    raw?.expires_at ??
    "";
  const strike =
    safeNum(raw?.strike_price ?? raw?.instrument?.strike_price, 0);
  const optionType = String(
    raw?.option_type ?? raw?.instrument?.option_type ?? "",
  ).toLowerCase();
  const quantity = Math.abs(
    safeNum(raw?.quantity ?? raw?.qty ?? raw?.filled_quantity, 0),
  );
  const mark =
    safeNum(raw?.mark ?? raw?.mark_price, NaN) ||
    safeNum(raw?.market_price, NaN) ||
    0;
  const underlyingPrice =
    safeNum(raw?.underlying_price, NaN) ||
    safeNum(raw?.last_price, NaN) ||
    0;

  return {
    symbol: String(symbol).toUpperCase(),
    expiration: String(expiration),
    strike,
    optionType,
    quantity,
    mark,
    underlyingPrice,
    raw,
  };
}

function inferShortDelta(shortStrike: number, underlyingPrice: number, entryDelta = 0.15) {
  if (!shortStrike || !underlyingPrice) return entryDelta;
  const moneynessPct = (underlyingPrice - shortStrike) / shortStrike;

  if (moneynessPct > 0.12) return 0.06;
  if (moneynessPct > 0.08) return 0.10;
  if (moneynessPct > 0.05) return 0.14;
  if (moneynessPct > 0.03) return 0.18;
  if (moneynessPct > 0.01) return 0.24;
  if (moneynessPct > -0.01) return 0.35;
  return 0.55;
}

function assignmentRisk(
  shortStrike: number,
  underlyingPrice: number,
  currentMark: number,
  dte: number,
) {
  const itm = underlyingPrice < shortStrike;
  const lowExtrinsicApprox = currentMark < 0.05;
  return dte <= 3 && itm && lowExtrinsicApprox;
}

export async function getLiveManagedPositions(
  broker = new TastytradeBroker(),
) {
  const actualOpen = await db
    .select()
    .from(positions)
    .where(eq(positions.status, "open"));

  const brokerPositions = await broker.getPositions().catch(() => ({ items: [] }));
  const items = Array.isArray((brokerPositions as any)?.items)
    ? (brokerPositions as any).items
    : Array.isArray(brokerPositions)
      ? (brokerPositions as any)
      : [];

  const brokerLegs = items.map(normalizeBrokerLeg);

  return actualOpen.map((pos: any) => {
    const matchingLegs = brokerLegs.filter(
      (leg: any) =>
        leg.symbol === String(pos.ticker).toUpperCase() &&
        leg.expiration === String(pos.expiration) &&
        leg.optionType.includes("put") &&
        (Number(leg.strike) === Number(pos.shortStrike) ||
          Number(leg.strike) === Number(pos.longStrike)),
    );

    let currentMark = safeNum(pos.currentMark, safeNum(pos.entryCredit, safeNum(pos.credit, 0)));
    let underlyingPrice = 0;

    if (matchingLegs.length >= 2) {
      const shortLeg = matchingLegs.find(
        (l: any) => Number(l.strike) === Number(pos.shortStrike),
      );
      const longLeg = matchingLegs.find(
        (l: any) => Number(l.strike) === Number(pos.longStrike),
      );

      if (shortLeg && longLeg) {
        currentMark = Math.max(0, safeNum(shortLeg.mark, 0) - safeNum(longLeg.mark, 0));
        underlyingPrice =
          safeNum(shortLeg.underlyingPrice, 0) || safeNum(longLeg.underlyingPrice, 0);
      }
    }

    const dte = daysToExpiration(pos.expiration);
    const shortDelta = inferShortDelta(
      safeNum(pos.shortStrike, 0),
      underlyingPrice,
      safeNum(pos.entryDelta, 0.15),
    );

    const assignRisk = assignmentRisk(
      safeNum(pos.shortStrike, 0),
      underlyingPrice,
      currentMark,
      dte,
    );

    return {
      positionId: pos.id,
      ticker: pos.ticker,
      expiration: pos.expiration,
      shortStrike: pos.shortStrike,
      longStrike: pos.longStrike,
      contracts: pos.contracts,
      entryCredit: safeNum(pos.entryCredit, safeNum(pos.credit, 0)),
      currentMark,
      currentProfitPct: computeProfitPct(
        safeNum(pos.entryCredit, safeNum(pos.credit, 0)),
        currentMark,
      ),
      shortDelta,
      dte,
      assignmentRisk: assignRisk,
      hasDividend: false,
      hasEarnings: false,
      beta: safeNum(pos.beta, 1.0),
    };
  });
}

export function shouldCloseForRisk(
  snap: any,
  marketState: { isFridayCloseWindow?: boolean; regime?: string },
  settings: { exitStrategyMode?: string } = {},
) {
  const mode = settings.exitStrategyMode || "HYBRID_SMART_EXIT";

  if (snap.dte <= 2) return { close: true, reason: "dte_hard_exit" };
  if (snap.shortDelta > 0.30) return { close: true, reason: "delta_risk" };
  if (snap.assignmentRisk) return { close: true, reason: "assignment_risk" };

  if (mode === "TAKE_50_ALWAYS") {
    if (snap.currentProfitPct >= 0.5) return { close: true, reason: "take_50" };
    return { close: false };
  }

  if (mode === "HOLD_TO_EXPIRATION") {
    return { close: false };
  }

  if (snap.currentProfitPct >= 0.5) {
    const safeDelta = snap.shortDelta < 0.15;
    const safeDte = snap.dte >= 3;
    const lowBeta = snap.beta < 1.3;
    const calmRegime =
      !marketState.regime ||
      marketState.regime === "LOW_VOL" ||
      marketState.regime === "NORMAL";

    if (safeDelta && safeDte && lowBeta && calmRegime) {
      return { close: false, reason: "hybrid_hold" };
    }

    return { close: true, reason: "hybrid_take_profit" };
  }

  return { close: false };
}

export async function logPositionDecision(snap: any, decision: any) {
  await db.insert(systemEvents).values({
    severity: "info",
    eventType: "position_manager_decision",
    message: `${snap.ticker}: ${decision.close ? "CLOSE" : "HOLD"}`,
    payload: JSON.stringify({
      positionId: snap.positionId,
      ticker: snap.ticker,
      currentMark: snap.currentMark,
      currentProfitPct: snap.currentProfitPct,
      shortDelta: snap.shortDelta,
      dte: snap.dte,
      reason: decision.reason,
    }),
  });
}
