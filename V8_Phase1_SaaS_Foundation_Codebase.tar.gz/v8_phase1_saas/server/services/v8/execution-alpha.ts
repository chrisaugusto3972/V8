import { db } from "../../db";
import { brokerOrders, systemEvents } from "@shared/schema";
import { eq, sql } from "drizzle-orm";
import { TastytradeBroker } from "../../brokers/tastytrade";
import { getExecutionPolicy, type IntentType } from "./execution-policy";
import { recordExecutionAttempt, recordExecutionFill } from "./execution-analytics";
import { ENGINE_VERSION, SELECTION_VERSION } from "./version";

function safeNum(v: any, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

export async function submitAdaptiveEntry(
  broker: TastytradeBroker,
  intent: any,
  regime?: string,
) {
  const quote = await broker.getQuote(intent.ticker).catch(() => null);
  if (!quote) return null;

  const bid = safeNum((quote as any).bid, 0);
  const ask = safeNum((quote as any).ask, 0);
  const midpoint = bid && ask ? (bid + ask) / 2 : safeNum(intent.intendedCredit, 0);

  if (!bid && !ask) return null;

  const policy = getExecutionPolicy({
    side: "entry",
    intentType: "entry",
    bid,
    ask,
    midpoint,
    slippageRatio: safeNum(intent.slippageRatio, 1.2),
    liquidityScore: safeNum(intent.liquidityScore, 50),
    regime,
  });

  const submit = await broker.submitVerticalCreditSpread({
    ticker: intent.ticker,
    expiration: intent.expiration,
    shortStrike: Number(intent.shortStrike),
    longStrike: Number(intent.longStrike),
    quantity: Number(intent.contracts ?? 1),
    limitPrice: policy.initialLimit,
  });

  await recordExecutionAttempt({
    brokerOrderId: submit.brokerOrderId ?? null,
    positionId: null,
    ticker: intent.ticker,
    side: "entry",
    intentType: "entry",
    bid,
    ask,
    midpoint,
    initialLimit: policy.initialLimit,
    regime: regime ?? "NORMAL",
    executionPolicy: policy.policyName,
  });

  return {
    ...submit,
    policy,
    bid,
    ask,
    midpoint,
    initialLimit: policy.initialLimit,
  };
}

export async function submitAdaptiveExit(
  broker: TastytradeBroker,
  position: any,
  exitType: IntentType = "profit_exit",
  regime?: string,
) {
  const quote = await broker.getQuote(position.ticker).catch(() => null);
  const bid = safeNum((quote as any)?.bid, 0);
  const ask = safeNum((quote as any)?.ask, 0);
  const midpoint = bid && ask ? (bid + ask) / 2 : safeNum(position.currentMark, 0.05);

  if (exitType !== "emergency_exit" && !bid && !ask) return null;

  const policy = getExecutionPolicy({
    side: "exit",
    intentType: exitType,
    bid: bid || safeNum(position.currentMark, 0.05),
    ask: ask || safeNum(position.currentMark, 0.05) * 1.1,
    midpoint: midpoint || safeNum(position.currentMark, 0.05),
    regime,
  });

  const closeResult = await broker.submitCloseVerticalSpread({
    ticker: position.ticker,
    expiration: position.expiration,
    shortStrike: Number(position.shortStrike),
    longStrike: Number(position.longStrike),
    quantity: Number(position.contracts),
    limitPrice: policy.initialLimit || safeNum(position.currentMark, 0.05),
  });

  await recordExecutionAttempt({
    brokerOrderId: closeResult.brokerOrderId ?? null,
    positionId: position.id ?? position.positionId ?? null,
    ticker: position.ticker,
    side: "exit",
    intentType: exitType,
    bid,
    ask,
    midpoint,
    initialLimit: policy.initialLimit,
    regime: regime ?? "NORMAL",
    executionPolicy: policy.policyName,
  });

  return {
    ...closeResult,
    policy,
    bid,
    ask,
    midpoint,
    initialLimit: policy.initialLimit,
  };
}

export async function monitorWorkingOrders(broker: TastytradeBroker) {
  const workingOrders = await db
    .select()
    .from(brokerOrders)
    .where(
      sql`${brokerOrders.status} in ('submitted','received','working','live','open')`,
    );

  for (const order of workingOrders) {
    if (!order.brokerOrderId) continue;

    try {
      const brokerStatus = await broker.getOrderStatus(order.brokerOrderId);
      if (!brokerStatus) continue;

      const normalizedStatus = String(brokerStatus.status ?? "").toLowerCase();

      if (normalizedStatus === "filled") {
        await db
          .update(brokerOrders)
          .set({
            status: "filled",
            fillPrice: safeNum(brokerStatus.avgFillPrice, order.requestedPrice ?? 0),
            filledQuantity: safeNum(brokerStatus.filledQty, 1),
            updatedAt: new Date(),
          } as any)
          .where(eq(brokerOrders.id, order.id));

        await recordExecutionFill({
          brokerOrderId: order.brokerOrderId,
          positionId: order.positionId,
          ticker: order.ticker ?? "",
          side: order.side ?? "entry",
          finalFillPrice: safeNum(brokerStatus.avgFillPrice, 0),
          initialLimit: safeNum(order.initialLimit, order.requestedPrice ?? 0),
          repriceCount: safeNum(order.repriceCount, 0),
          bidAtSubmit: 0,
          askAtSubmit: 0,
          midpointAtSubmit: safeNum(order.requestedPrice, 0),
          createdAt: order.createdAt,
        });
      } else if (normalizedStatus === "cancelled" || normalizedStatus === "rejected") {
        await db
          .update(brokerOrders)
          .set({ status: normalizedStatus, updatedAt: new Date() } as any)
          .where(eq(brokerOrders.id, order.id));
      }
    } catch {
      continue;
    }
  }
}
