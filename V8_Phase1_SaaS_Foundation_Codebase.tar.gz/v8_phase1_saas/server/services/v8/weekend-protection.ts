import type { ScanPick } from "./types";
import { isHighBeta } from "./market-math";

export function shouldCloseForWeekend(pick: Partial<ScanPick>, weekendDeltaThreshold = 0.25): boolean {
  const delta = pick.shortDeltaAbs ?? 1;
  const distance = pick.distancePct ?? 0;
  if (delta > weekendDeltaThreshold) return true;
  if (distance < 6) return true;
  if (isHighBeta(pick.beta) && delta > 0.18) return true;
  return false;
}

export function weekendRiskLabel(pick: Partial<ScanPick>): "LOW" | "MEDIUM" | "HIGH" {
  const delta = pick.shortDeltaAbs ?? 1;
  if (delta > 0.25 || isHighBeta(pick.beta)) return "HIGH";
  if (delta > 0.15) return "MEDIUM";
  return "LOW";
}
