import { db } from "../../db";
import { executionAnalytics } from "@shared/schema";
import { desc, sql } from "drizzle-orm";
import { ENGINE_VERSION, SELECTION_VERSION } from "./version";

function safeNum(v: any, fallback = 0): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

export async function recordExecutionAttempt(params: {
  brokerOrderId: string | null;
  positionId: string | null;
  ticker: string;
  side: string;
  intentType: string;
  bid: number;
  ask: number;
  midpoint: number;
  initialLimit: number;
  regime: string;
  executionPolicy?: string;
}) {
  try {
    await db.insert(executionAnalytics).values({
      brokerOrderId: params.brokerOrderId,
      positionId: params.positionId,
      ticker: params.ticker,
      side: params.side,
      intentType: params.intentType,
      bidAtSubmit: params.bid,
      askAtSubmit: params.ask,
      midpointAtSubmit: params.midpoint,
      initialLimit: params.initialLimit,
      regime: params.regime,
      engineVersion: ENGINE_VERSION,
      selectionVersion: SELECTION_VERSION,
    } as any);
  } catch (e: any) {
    console.error("[execution-analytics] recordExecutionAttempt failed:", e?.message);
  }
}

function computeExecutionQuality(params: {
  side: string;
  bid: number;
  ask: number;
  midpoint: number;
  fill: number;
}) {
  const bid = safeNum(params.bid, 0);
  const ask = safeNum(params.ask, 0);
  const midpoint = safeNum(params.midpoint, 0);
  const fill = safeNum(params.fill, 0);
  const spread = Math.max(ask - bid, 0.0001);

  let fillVsMidpointPct = 0;
  let fillVsBidAskPct = 0;

  if (params.side === "exit") {
    fillVsMidpointPct = midpoint > 0 ? ((midpoint - fill) / midpoint) * 100 : 0;
    fillVsBidAskPct = ((ask - fill) / spread) * 100;
  } else {
    fillVsMidpointPct = midpoint > 0 ? ((fill - midpoint) / midpoint) * 100 : 0;
    fillVsBidAskPct = ((fill - bid) / spread) * 100;
  }

  return {
    fillVsMidpointPct: round2(fillVsMidpointPct),
    fillVsBidAskPct: round2(fillVsBidAskPct),
  };
}

function computeTimeToFillSeconds(
  createdAt?: string | Date | null,
  filledAt?: string | Date | null,
): number | null {
  if (!createdAt || !filledAt) return null;
  const diffMs = new Date(filledAt).getTime() - new Date(createdAt).getTime();
  if (!Number.isFinite(diffMs) || diffMs < 0) return null;
  return Math.round(diffMs / 1000);
}

export async function recordExecutionFill(params: {
  brokerOrderId: string | null;
  positionId: string | null;
  ticker: string;
  side: string;
  finalFillPrice: number;
  initialLimit: number | null;
  repriceCount: number;
  bidAtSubmit: number;
  askAtSubmit: number;
  midpointAtSubmit: number;
  createdAt?: string | null;
  filledAt?: string | null;
}) {
  try {
    const mid = safeNum(params.midpointAtSubmit, 0);
    const fill = safeNum(params.finalFillPrice, 0);
    const bid = safeNum(params.bidAtSubmit, 0);
    const ask = safeNum(params.askAtSubmit, 0);

    const quality = computeExecutionQuality({
      side: params.side,
      bid,
      ask,
      midpoint: mid,
      fill,
    });

    const timeToFillSeconds = computeTimeToFillSeconds(params.createdAt, params.filledAt ?? new Date().toISOString());

    await db
      .update(executionAnalytics)
      .set({
        finalFillPrice: fill,
        fillQualityVsMidpoint: quality.fillVsMidpointPct,
        fillQualityVsBidAsk: quality.fillVsBidAskPct,
        timeToFillSeconds,
        repriceCount: params.repriceCount,
        bestPossiblePriceProxy: params.side === "entry" ? ask : bid,
        worstPossiblePriceProxy: params.side === "entry" ? bid : ask,
      } as any)
      .where(
        sql`${executionAnalytics.brokerOrderId} = ${params.brokerOrderId}`,
      );
  } catch (e: any) {
    console.error("[execution-analytics] recordExecutionFill failed:", e?.message);
  }
}

export type ExecutionQualitySummary = {
  totalOrders: number;
  avgFillVsMidpoint: number;
  avgFillVsBidAsk: number;
  avgTimeToFill: number;
  avgReprices: number;
  byRegime: Record<string, { count: number; avgFillVsMidpoint: number }>;
  bySide: Record<string, { count: number; avgFillVsMidpoint: number }>;
  byTicker: Record<string, { count: number; avgFillVsMidpoint: number }>;
};

export async function getExecutionQualitySummary(limit = 100): Promise<ExecutionQualitySummary> {
  const recent = await db
    .select()
    .from(executionAnalytics)
    .orderBy(desc(executionAnalytics.createdAt))
    .limit(limit);

  const filled = recent.filter((r) => r.finalFillPrice !== null);

  if (filled.length === 0) {
    return {
      totalOrders: 0,
      avgFillVsMidpoint: 0,
      avgFillVsBidAsk: 0,
      avgTimeToFill: 0,
      avgReprices: 0,
      byRegime: {},
      bySide: {},
      byTicker: {},
    };
  }

  const avg = (arr: number[]) => arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0;

  const avgFillVsMidpoint = avg(filled.map((r) => safeNum(r.fillQualityVsMidpoint, 0)));
  const avgFillVsBidAsk = avg(filled.map((r) => safeNum(r.fillQualityVsBidAsk, 0)));
  const avgTimeToFill = avg(filled.filter((r) => r.timeToFillSeconds).map((r) => safeNum(r.timeToFillSeconds, 0)));
  const avgReprices = avg(filled.map((r) => safeNum(r.repriceCount, 0)));

  const groupBy = <T>(items: T[], keyFn: (item: T) => string) => {
    const groups: Record<string, T[]> = {};
    for (const item of items) {
      const key = keyFn(item);
      if (!groups[key]) groups[key] = [];
      groups[key].push(item);
    }
    return groups;
  };

  const toStats = (group: Record<string, typeof filled>) => {
    const result: Record<string, { count: number; avgFillVsMidpoint: number }> = {};
    for (const [key, items] of Object.entries(group)) {
      result[key] = {
        count: items.length,
        avgFillVsMidpoint: avg(items.map((r) => safeNum(r.fillQualityVsMidpoint, 0))),
      };
    }
    return result;
  };

  return {
    totalOrders: filled.length,
    avgFillVsMidpoint: Math.round(avgFillVsMidpoint * 100) / 100,
    avgFillVsBidAsk: Math.round(avgFillVsBidAsk * 100) / 100,
    avgTimeToFill: Math.round(avgTimeToFill),
    avgReprices: Math.round(avgReprices * 10) / 10,
    byRegime: toStats(groupBy(filled, (r) => r.regime ?? "NORMAL")),
    bySide: toStats(groupBy(filled, (r) => r.side ?? "entry")),
    byTicker: toStats(groupBy(filled, (r) => r.ticker ?? "UNKNOWN")),
  };
}
