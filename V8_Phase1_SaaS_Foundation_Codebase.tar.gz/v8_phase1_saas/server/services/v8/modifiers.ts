export type ModifierInput = {
  killSwitch?: boolean;
  reconciliationPause?: boolean;
  hardRiskLimit?: boolean;
  weekendThrottle?: boolean;
  regimeThrottle?: number;
  opportunityThrottle?: number;
  participationThrottle?: number;
  healthThrottle?: number;
};

export type ModifierResolution = {
  effectiveThrottle: number;
  activeModifier:
    | "kill_switch"
    | "reconciliation"
    | "hard_risk"
    | "weekend"
    | "regime"
    | "opportunity"
    | "participation"
    | "health"
    | "none";
  paused: boolean;
};

export function resolveModifierPriority(
  input: ModifierInput,
): ModifierResolution {
  if (input.killSwitch) {
    return {
      effectiveThrottle: 0,
      activeModifier: "kill_switch",
      paused: true,
    };
  }

  if (input.reconciliationPause) {
    return {
      effectiveThrottle: 0,
      activeModifier: "reconciliation",
      paused: true,
    };
  }

  if (input.hardRiskLimit) {
    return {
      effectiveThrottle: 0,
      activeModifier: "hard_risk",
      paused: true,
    };
  }

  if (input.weekendThrottle) {
    return {
      effectiveThrottle: 0.5,
      activeModifier: "weekend",
      paused: false,
    };
  }

  const ordered: Array<{
    key: ModifierResolution["activeModifier"];
    value?: number;
  }> = [
    { key: "regime", value: input.regimeThrottle },
    { key: "opportunity", value: input.opportunityThrottle },
    { key: "participation", value: input.participationThrottle },
    { key: "health", value: input.healthThrottle },
  ];

  for (const item of ordered) {
    if (typeof item.value === "number" && item.value < 1) {
      return {
        effectiveThrottle: item.value,
        activeModifier: item.key,
        paused: false,
      };
    }
  }

  return {
    effectiveThrottle: 1,
    activeModifier: "none",
    paused: false,
  };
}
