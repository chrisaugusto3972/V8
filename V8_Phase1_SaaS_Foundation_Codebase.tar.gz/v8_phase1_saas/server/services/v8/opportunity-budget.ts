import type { OpportunityBucketKey, ScanPick } from "./types";

function bucketize(pick: ScanPick): OpportunityBucketKey {
  const d = pick.shortDeltaAbs;
  const deltaBucket = d < 0.15 ? "D_LT_15" : d < 0.2 ? "D_15_20" : d < 0.25 ? "D_20_25" : "D_25_PLUS";
  const t = pick.dte ?? 0;
  const dteBucket = t <= 10 ? "T_8_10" : t <= 14 ? "T_11_14" : "T_15_21";
  const widthBucket = pick.width <= 1 ? "W_1" : pick.width <= 2 ? "W_2" : "W_3_PLUS";
  const c = pick.confidence;
  const confidenceBucket = c < 80 ? "C_LT_80" : c < 90 ? "C_80_89" : "C_90_PLUS";
  const highBetaBucket = (pick.beta ?? 1) >= 1.35 ? "HB_Y" : "HB_N";
  const sectorLower = (pick.sector || "").toLowerCase();
  const isEtf = sectorLower === "index" || sectorLower.includes("etf");
  const assetMixBucket = isEtf ? "ETF" : "STOCK";
  return { deltaBucket, dteBucket, widthBucket, confidenceBucket, highBetaBucket, assetMixBucket };
}

export function bucketKey(pick: ScanPick): string[] {
  const b = bucketize(pick);
  return Object.values(b);
}

export function withinOpportunityBudget(existing: ScanPick[], candidate: ScanPick): boolean {
  const keys = bucketKey(candidate);
  const counts = new Map<string, number>();
  for (const p of existing) {
    for (const k of bucketKey(p)) counts.set(k, (counts.get(k) || 0) + 1);
  }
  const limits: Record<string, number> = {
    D_LT_15: 8, D_15_20: 8, D_20_25: 4, D_25_PLUS: 2,
    T_8_10: 6, T_11_14: 6, T_15_21: 8,
    W_1: 15, W_2: 8, W_3_PLUS: 3,
    C_LT_80: 6, C_80_89: 12, C_90_PLUS: 10,
    HB_Y: 5, HB_N: 15,
    ETF: 8, STOCK: 15,
  };
  return keys.every((k) => (counts.get(k) || 0) < (limits[k] ?? 5));
}
