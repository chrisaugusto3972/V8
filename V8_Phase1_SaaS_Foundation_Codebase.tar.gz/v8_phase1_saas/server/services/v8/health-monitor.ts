import { sql } from "drizzle-orm";
import { db } from "../../db";
import { TastytradeBroker } from "../../brokers/tastytrade";
import { autopilotState, brokerOrders, orderIntents, positions } from "@shared/schema";

export type HealthSnapshot = {
  brokerOk: boolean;
  dbOk: boolean;
  marketDataOk: boolean;
  staleDataRateOk: boolean;
  loopsAlive: boolean;
  ok: boolean;
  details: {
    broker?: any;
    db?: string;
    staleOrderIntents: number;
    staleSubmittedOrders: number;
    openPositions: number;
    lastHeartbeatAt?: string | null;
    lastReconAt?: string | null;
    lastScanAt?: string | null;
    lastHealthAt?: string | null;
  };
};

function minutesSince(iso?: string | null) {
  if (!iso) return Number.POSITIVE_INFINITY;
  const ts = new Date(iso).getTime();
  if (Number.isNaN(ts)) return Number.POSITIVE_INFINITY;
  return (Date.now() - ts) / 60000;
}

export async function healthSnapshot(): Promise<HealthSnapshot> {
  const broker = new TastytradeBroker();

  let brokerHealth: any = { ok: false, reason: "unknown" };
  let dbOk = true;

  try {
    brokerHealth = await broker.health();
  } catch (e: any) {
    brokerHealth = { ok: false, reason: String(e?.message || e) };
  }

  try {
    await db.execute(sql`select 1`);
  } catch (e: any) {
    dbOk = false;
  }

  const [state, staleIntents, staleSubmitted, openPositions] = await Promise.all([
    db.select().from(autopilotState).limit(1).then((r) => r[0] ?? null),
    db
      .select()
      .from(orderIntents)
      .where(sql`${orderIntents.state} = 'SCANNED' and ${orderIntents.createdAt} < now() - interval '20 minutes'`)
      .then((r) => r.length)
      .catch(() => 0),
    db
      .select()
      .from(brokerOrders)
      .where(sql`${brokerOrders.status} in ('submitted','working','live','open','received') and ${brokerOrders.createdAt} < now() - interval '20 minutes'`)
      .then((r) => r.length)
      .catch(() => 0),
    db
      .select()
      .from(positions)
      .where(sql`${positions.status} = 'open'`)
      .then((r) => r.length)
      .catch(() => 0),
  ]);

  const loopsAlive =
    !!state &&
    minutesSince(state.lastHeartbeatAt) < 10 &&
    minutesSince(state.lastHealthAt) < 20 &&
    minutesSince(state.lastReconAt) < 20;

  const staleDataRateOk = staleIntents === 0 && staleSubmitted === 0;

  const ok =
    !!brokerHealth.ok &&
    dbOk &&
    loopsAlive &&
    staleDataRateOk;

  return {
    brokerOk: !!brokerHealth.ok,
    dbOk,
    marketDataOk: true,
    staleDataRateOk,
    loopsAlive,
    ok,
    details: {
      broker: brokerHealth,
      db: dbOk ? "ok" : "failed",
      staleOrderIntents: staleIntents,
      staleSubmittedOrders: staleSubmitted,
      openPositions,
      lastHeartbeatAt: state?.lastHeartbeatAt ?? null,
      lastReconAt: state?.lastReconAt ?? null,
      lastScanAt: state?.lastScanAt ?? null,
      lastHealthAt: state?.lastHealthAt ?? null,
    },
  };
}
