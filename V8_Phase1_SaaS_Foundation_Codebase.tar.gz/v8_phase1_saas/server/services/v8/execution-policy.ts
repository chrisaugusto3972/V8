function safeNum(v: any, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

export type IntentType = "entry" | "profit_exit" | "defensive_exit" | "emergency_exit";

export type ExecutionPolicyParams = {
  side: "entry" | "exit";
  intentType: IntentType;
  bid: number;
  ask: number;
  midpoint: number;
  slippageRatio?: number;
  liquidityScore?: number;
  regime?: string;
  dte?: number;
  isHighBeta?: boolean;
};

export type ExecutionPolicy = {
  initialLimit: number;
  minAcceptableLimit: number;
  maxWaitSeconds: number;
  repriceIntervalSeconds: number;
  maxReprices: number;
  priceStep: number;
  cancelInsteadOfChase: boolean;
  policyName: string;
};

export function getExecutionPolicy(params: ExecutionPolicyParams): ExecutionPolicy {
  const { side, intentType, bid, ask, midpoint } = params;
  const slippageRatio = safeNum(params.slippageRatio, 1.2);
  const liquidityScore = safeNum(params.liquidityScore, 50);
  const spread = Math.abs(ask - bid);
  const isTight = spread < 0.08;

  if (intentType === "emergency_exit") {
    return {
      initialLimit: side === "exit" ? bid * 0.95 : ask * 1.05,
      minAcceptableLimit: side === "exit" ? bid * 0.85 : ask * 1.15,
      maxWaitSeconds: 15,
      repriceIntervalSeconds: 5,
      maxReprices: 2,
      priceStep: spread * 0.5,
      cancelInsteadOfChase: false,
      policyName: "EMERGENCY_EXIT",
    };
  }

  if (intentType === "defensive_exit") {
    return {
      initialLimit: midpoint,
      minAcceptableLimit: side === "exit" ? bid * 0.90 : ask * 1.10,
      maxWaitSeconds: 45,
      repriceIntervalSeconds: 15,
      maxReprices: 3,
      priceStep: spread * 0.25,
      cancelInsteadOfChase: false,
      policyName: "DEFENSIVE_EXIT",
    };
  }

  if (intentType === "profit_exit") {
    const start = isTight ? midpoint : midpoint + spread * 0.1;
    return {
      initialLimit: start,
      minAcceptableLimit: side === "exit" ? bid * 0.95 : ask * 1.05,
      maxWaitSeconds: 90,
      repriceIntervalSeconds: 30,
      maxReprices: 3,
      priceStep: spread * 0.15,
      cancelInsteadOfChase: true,
      policyName: "PROFIT_EXIT_ADAPTIVE",
    };
  }

  const entryStart = isTight || liquidityScore > 70
    ? midpoint
    : midpoint + spread * 0.15;

  const floor = slippageRatio > 1.3
    ? bid * 0.92
    : bid * 0.95;

  return {
    initialLimit: entryStart,
    minAcceptableLimit: floor,
    maxWaitSeconds: 120,
    repriceIntervalSeconds: 30,
    maxReprices: 4,
    priceStep: spread * 0.1,
    cancelInsteadOfChase: slippageRatio > 1.4,
    policyName: isTight ? "ENTRY_MIDPOINT" : "ENTRY_ADAPTIVE",
  };
}
