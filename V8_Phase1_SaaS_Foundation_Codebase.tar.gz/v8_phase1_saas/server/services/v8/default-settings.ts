export const DEFAULT_V8_SMALL_ACCOUNT_PRODUCTION = {
  profileName: "V8_SMALL_ACCOUNT_PRODUCTION",

  account: {
    mode: "small",
    startingAccountSize: 3000,
    riskPerTradePct: 0.02,
    maxRiskPerTradeHardCap: 75,
    targetDeploymentPct: 0.35,
    hardMaxDeploymentPct: 0.50,
    maxTradesPerDay: 2,
    warmModeMaxTradesPerDay: 1,
  },

  dte: {
    primaryMin: 8,
    primaryMax: 10,
    secondaryMin: 11,
    secondaryMax: 14,
    fallbackMin: 15,
    fallbackMax: 21,
  },

  schedule: {
    mondayDefenseUntil: "10:30",
    fridayNoNewEntriesAfter: "12:00",
    fridaySweepTime: "15:30",
    timezone: "America/New_York",
  },

  strikes: {
    deltaTargetMin: 0.10,
    deltaTargetMax: 0.15,
    hardRejectDeltaAbove: 0.18,
    minDistanceOtmPct: 5.0,
    expectedMoveMultiplier: 1.25,
    betaAdjustedDistanceEnabled: true,
    gammaDteFloorEnabled: true,
  },

  spreads: {
    preferredWidthMin: 1,
    preferredWidthMax: 2,
    maxWidth: 2,
    allowWidth3: false,
    enginePriority: "CORE_FIRST",
  },

  credit: {
    minAbsoluteCreditWidth1: 0.18,
    minAbsoluteCreditWidth2: 0.35,
    minCreditPctOfWidth: 0.25,
    useOptimisticCredit: false,
    useConservativeCredit: true,
  },

  liquidity: {
    minOpenInterest: 100,
    maxBidAskSpread: 0.15,
    maxSlippageRatio: 1.5,
    liquidityScoringEnabled: true,
    rejectLegWideAbs: true,
    rejectNoQuote: true,
    rejectChainFail: true,
  },

  portfolio: {
    sectorCapPct: 0.20,
    subIndustryTwinBlocking: true,
    highBetaCapPct: 0.10,
    correlationBlocking: true,
    opportunityBudgeting: true,
    breadthProtection: true,
    preferEtfs: true,
    allowHighBetaStocks: true,
  },

  risk: {
    dailyLossPausePct: 0.03,
    totalDrawdownHaltPct: 0.08,
    lossClusterPauseAfterConsecutiveLosses: 3,
    warmModeHoursAfterRestart: 24,
    warmModeSizeReductionPct: 0.50,
    reconciliationMismatchAction: "PAUSE",
    killSwitchEnabled: true,
  },

  exits: {
    mode: "HYBRID_SMART_EXIT",
    takeProfitPct: 0.50,
    hybridHoldMaxDelta: 0.15,
    hardExitDelta: 0.30,
    hardExitDte: 2,
    assignmentProtectionEnabled: true,
    fridayCloseEnforcement: true,
  },

  instruments: {
    etfFirst: true,
    preferredTickers: ["SPY", "IWM", "QQQ"],
  },
} as const;

export type V8Profile = typeof DEFAULT_V8_SMALL_ACCOUNT_PRODUCTION;

export function getDefaultProfile(): V8Profile {
  return DEFAULT_V8_SMALL_ACCOUNT_PRODUCTION;
}
