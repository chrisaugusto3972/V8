import { TastytradeBroker } from "../../brokers/tastytrade";
import { classifyRegime } from "./regime";

function safeNum(v: any, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

export function isFridayCloseWindow(now = new Date()) {
  const etHour = (now.getUTCHours() - 4 + 24) % 24;
  const etMins = etHour * 60 + now.getUTCMinutes();
  const utcDay = now.getUTCDay();
  const etDay = etHour > now.getUTCHours() ? ((utcDay - 1 + 7) % 7) : utcDay;
  return etDay === 5 && etMins >= 15 * 60 + 30;
}

export type SnapshotRegime =
  | "LOW_VOL"
  | "NORMAL"
  | "ELEVATED"
  | "PANIC"
  | "SLOW_BEAR";

export type MarketSnapshot = {
  vix: number;
  vixShortMa: number;
  vixSlope: number;
  spyPrice: number;
  spyReference: number;
  spyChangePct: number;
  spyTrendDown: boolean;
  regime: SnapshotRegime;
};

export async function getMarketSnapshot(
  broker = new TastytradeBroker(),
): Promise<MarketSnapshot> {
  const [spyQuote, vixQuote] = await Promise.all([
    broker.getQuote("SPY").catch(() => ({ symbol: "SPY" })),
    broker.getQuote("VIX").catch(() => ({ symbol: "VIX" })),
  ]);

  const spyPrice =
    safeNum((spyQuote as any).mark, NaN) ||
    safeNum((spyQuote as any).last, NaN) ||
    safeNum((spyQuote as any).bid, 0);

  const spyReference =
    safeNum((spyQuote as any).prevClose, NaN) ||
    safeNum((spyQuote as any).previousClose, NaN) ||
    safeNum((spyQuote as any).close, NaN) ||
    safeNum((spyQuote as any).open, NaN) ||
    spyPrice;

  const spyChangePct =
    spyReference > 0 ? ((spyPrice - spyReference) / spyReference) * 100 : 0;

  const vix =
    safeNum((vixQuote as any).mark, NaN) ||
    safeNum((vixQuote as any).last, NaN) ||
    18;

  const spyTrendDown = spyChangePct <= -0.75;

  const vixShortMa = vix + (spyChangePct < 0 ? 0.5 : -0.5);
  const vixSlope = spyChangePct <= -0.75 ? 0.5 : spyChangePct >= 0.75 ? -0.5 : 0;

  const regimeResult = classifyRegime(vix, spyTrendDown);

  return {
    vix,
    vixShortMa,
    vixSlope,
    spyPrice,
    spyReference,
    spyChangePct,
    spyTrendDown,
    regime: regimeResult.regime as SnapshotRegime,
  };
}

export async function inferCurrentRegime(
  broker = new TastytradeBroker(),
): Promise<SnapshotRegime> {
  const snap = await getMarketSnapshot(broker);
  return snap.regime;
}
