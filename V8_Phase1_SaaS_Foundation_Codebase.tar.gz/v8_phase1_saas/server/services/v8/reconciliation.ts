import { and, desc, eq, inArray } from "drizzle-orm";
import { db } from "../../db";
import { brokerOrders, orderIntents, positions } from "@shared/schema";
import { TastytradeBroker } from "../../brokers/tastytrade";

export type ReconSeverity =
  | "ok"
  | "warn"
  | "pause"
  | "flatten_symbol"
  | "flatten_all";

export type ReconMismatch = {
  type:
    | "position_missing_internal"
    | "position_missing_broker"
    | "position_quantity_mismatch"
    | "order_missing_internal"
    | "order_missing_broker"
    | "order_status_mismatch";
  key: string;
  internal?: any;
  broker?: any;
};

export type ReconResult = {
  ok: boolean;
  severity: ReconSeverity;
  mismatches: ReconMismatch[];
  summary: {
    internalOpenPositions: number;
    brokerOpenPositions: number;
    internalActiveOrders: number;
    brokerLiveOrders: number;
  };
  reason?: string;
};

function safeArray(value: any): any[] {
  if (Array.isArray(value)) return value;
  if (Array.isArray(value?.data?.items)) return value.data.items;
  if (Array.isArray(value?.items)) return value.items;
  return [];
}

function normalizeBrokerPosition(raw: any) {
  const symbol =
    raw?.symbol ??
    raw?.underlying_symbol ??
    raw?.instrument?.underlying_symbol ??
    raw?.instrument?.symbol ??
    "";

  const quantity = Number(
    raw?.quantity ??
      raw?.quantity_direction ??
      raw?.remaining_quantity ??
      raw?.qty ??
      0,
  );

  const strike =
    Number(raw?.strike_price ?? raw?.instrument?.strike_price ?? 0) || 0;

  const expiration =
    raw?.expiration_date ??
    raw?.instrument?.expiration_date ??
    raw?.expires_at ??
    "";

  const optionType =
    raw?.option_type ?? raw?.instrument?.option_type ?? raw?.type ?? "";

  return {
    raw,
    symbol: String(symbol).toUpperCase(),
    quantity,
    strike,
    expiration: String(expiration),
    optionType: String(optionType).toLowerCase(),
  };
}

function normalizeBrokerOrder(raw: any) {
  const id = String(raw?.id ?? raw?.order_id ?? "");
  const status = String(raw?.status ?? raw?.state ?? "unknown").toLowerCase();

  const legs = Array.isArray(raw?.legs) ? raw.legs : [];
  const firstLeg = legs[0] ?? {};

  const symbol =
    firstLeg?.symbol ??
    raw?.underlying_symbol ??
    raw?.symbol ??
    raw?.instrument?.underlying_symbol ??
    "";

  const expiration =
    firstLeg?.expiration_date ?? raw?.expiration_date ?? raw?.expires_at ?? "";

  return {
    raw,
    id,
    status,
    symbol: String(symbol).toUpperCase(),
    expiration: String(expiration),
  };
}

function internalPositionKey(p: any) {
  return [
    String(p.ticker).toUpperCase(),
    String(p.expiration),
    Number(p.shortStrike).toFixed(2),
    Number(p.longStrike).toFixed(2),
    Number(p.contracts),
  ].join("|");
}

function brokerSpreadKeyFromGrouped(group: {
  symbol: string;
  expiration: string;
  shortStrike: number;
  longStrike: number;
  quantity: number;
}) {
  return [
    group.symbol.toUpperCase(),
    group.expiration,
    Number(group.shortStrike).toFixed(2),
    Number(group.longStrike).toFixed(2),
    Number(group.quantity),
  ].join("|");
}

function groupBrokerOptionPositions(rawBrokerPositions: any[]) {
  const puts = rawBrokerPositions
    .map(normalizeBrokerPosition)
    .filter(
      (p) =>
        p.symbol &&
        p.expiration &&
        p.strike > 0 &&
        p.optionType.includes("put") &&
        p.quantity !== 0,
    );

  const byUnderlying = new Map<string, typeof puts>();

  for (const p of puts) {
    const key = `${p.symbol}|${p.expiration}|${Math.abs(p.quantity)}`;
    if (!byUnderlying.has(key)) byUnderlying.set(key, []);
    byUnderlying.get(key)!.push(p);
  }

  const grouped: Array<{
    symbol: string;
    expiration: string;
    shortStrike: number;
    longStrike: number;
    quantity: number;
  }> = [];

  for (const [key, legs] of Array.from(byUnderlying.entries())) {
    if (legs.length < 2) continue;
    const sorted = [...legs].sort((a, b) => a.strike - b.strike);
    const shortLeg = sorted[sorted.length - 1];
    const longLeg = sorted[0];

    grouped.push({
      symbol: shortLeg.symbol,
      expiration: shortLeg.expiration,
      shortStrike: shortLeg.strike,
      longStrike: longLeg.strike,
      quantity: Math.abs(shortLeg.quantity),
    });
  }

  return grouped;
}

function normalizeInternalOrderStatus(status: string | null | undefined) {
  const s = String(status ?? "").toLowerCase();
  if (["submitted", "working", "live", "open", "received"].includes(s))
    return "live";
  if (["filled", "paper_filled"].includes(s)) return "filled";
  if (["cancelled", "canceled"].includes(s)) return "cancelled";
  if (["rejected", "error", "submit_failed"].includes(s)) return "error";
  return s || "unknown";
}

export async function reconcileBrokerState(
  broker = new TastytradeBroker(),
): Promise<ReconResult> {
  try {
    const [allInternalOpen, internalActiveOrders, brokerPositionsRaw, brokerOrdersRaw] =
      await Promise.all([
        db.select().from(positions).where(eq(positions.status, "open")),
        db
          .select()
          .from(brokerOrders)
          .where(
            inArray(brokerOrders.status, [
              "submitted",
              "working",
              "live",
              "received",
              "open",
            ] as any),
          )
          .orderBy(desc(brokerOrders.createdAt)),
        broker.getPositions().catch(() => ({ items: [] })),
        broker.getOrders().catch(() => ({ items: [] })),
      ]);

    const brokerPositions = safeArray(brokerPositionsRaw);
    const brokerOrdersLive = safeArray(brokerOrdersRaw);

    const mismatches: ReconMismatch[] = [];

    const internalOpenPositions = allInternalOpen.filter((p) => {
      const notes = String(p.notes ?? "");
      const isAutopilot = notes.includes("PAPER_AUTOPILOT") || notes.includes("LIVE_AUTOPILOT");
      const hasBrokerOrder = !!p.brokerOrderId;
      return isAutopilot || hasBrokerOrder;
    });

    const groupedBrokerSpreads = groupBrokerOptionPositions(brokerPositions);
    const internalPositionMap = new Map(
      internalOpenPositions.map((p) => [internalPositionKey(p), p]),
    );
    const brokerPositionMap = new Map(
      groupedBrokerSpreads.map((p) => [brokerSpreadKeyFromGrouped(p), p]),
    );

    for (const [key, internal] of Array.from(internalPositionMap.entries())) {
      if (!brokerPositionMap.has(key)) {
        mismatches.push({
          type: "position_missing_broker",
          key,
          internal,
        });
      }
    }

    for (const [key, brokerPos] of Array.from(brokerPositionMap.entries())) {
      if (!internalPositionMap.has(key)) {
        mismatches.push({
          type: "position_missing_internal",
          key,
          broker: brokerPos,
        });
      }
    }

    const normalizedBrokerOrders = brokerOrdersLive.map(normalizeBrokerOrder);
    const brokerOrderMap = new Map(
      normalizedBrokerOrders
        .filter((o) => o.id)
        .map((o) => [o.id, o]),
    );

    for (const internal of internalActiveOrders) {
      const brokerOrderId = internal.brokerOrderId
        ? String(internal.brokerOrderId)
        : "";

      if (!brokerOrderId) {
        mismatches.push({
          type: "order_missing_broker",
          key: String(internal.id),
          internal,
        });
        continue;
      }

      const brokerLive = brokerOrderMap.get(brokerOrderId);
      if (!brokerLive) {
        mismatches.push({
          type: "order_missing_broker",
          key: brokerOrderId,
          internal,
        });
        continue;
      }

      const internalStatus = normalizeInternalOrderStatus(internal.status);
      const brokerStatus = normalizeInternalOrderStatus(brokerLive.status);

      if (internalStatus !== brokerStatus && brokerStatus !== "filled") {
        mismatches.push({
          type: "order_status_mismatch",
          key: brokerOrderId,
          internal: { id: internal.id, status: internal.status },
          broker: { id: brokerLive.id, status: brokerLive.status },
        });
      }
    }

    let severity: ReconSeverity = "ok";
    let reason = "";

    const hasPositionMismatch = mismatches.some((m) =>
      m.type.startsWith("position_"),
    );
    const hasOrderMismatch = mismatches.some((m) =>
      m.type.startsWith("order_"),
    );

    if (hasPositionMismatch) {
      severity = "pause";
      reason = "position_state_mismatch";
    } else if (hasOrderMismatch) {
      severity = "warn";
      reason = "order_state_mismatch";
    }

    return {
      ok: mismatches.length === 0,
      severity,
      mismatches,
      summary: {
        internalOpenPositions: internalOpenPositions.length,
        brokerOpenPositions: groupedBrokerSpreads.length,
        internalActiveOrders: internalActiveOrders.length,
        brokerLiveOrders: normalizedBrokerOrders.length,
        manualPositionsExcluded: allInternalOpen.length - internalOpenPositions.length,
      },
      reason: reason || undefined,
    };
  } catch (e: any) {
    return {
      ok: false,
      severity: "pause",
      mismatches: [],
      summary: {
        internalOpenPositions: 0,
        brokerOpenPositions: 0,
        internalActiveOrders: 0,
        brokerLiveOrders: 0,
      },
      reason: String(e?.message || e),
    };
  }
}

export async function flattenMismatchSymbols(
  symbols: string[],
  broker: any,
) {
  const unique = Array.from(new Set(symbols.map((s) => String(s).toUpperCase())));
  const results = [];

  for (const symbol of unique) {
    try {
      const flattened = await broker.flattenSymbol(symbol);
      results.push({ symbol, ok: true, flattened });
    } catch (e: any) {
      results.push({ symbol, ok: false, error: String(e?.message || e) });
    }
  }

  return results;
}
