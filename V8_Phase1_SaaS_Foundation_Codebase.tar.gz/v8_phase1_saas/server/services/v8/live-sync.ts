import { and, eq, inArray } from "drizzle-orm";
import { db } from "../../db";
import {
  brokerOrders,
  orderIntents,
  positions,
  systemEvents,
} from "@shared/schema";
import { TastytradeBroker } from "../../brokers/tastytrade";
import { normalizePositionMetadata } from "./position-metadata";

function safeNum(v: any, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

export async function syncLiveOrdersAndCreatePositions(
  broker = new TastytradeBroker(),
) {
  const activeOrders = await db
    .select()
    .from(brokerOrders)
    .where(
      inArray(brokerOrders.status, [
        "submitted",
        "received",
        "working",
        "live",
        "open",
      ] as any),
    );

  for (const bo of activeOrders as any[]) {
    try {
      if (!bo.brokerOrderId) continue;

      const normalized = await broker.getNormalizedOrder(String(bo.brokerOrderId));

      await db
        .update(brokerOrders)
        .set({
          status: normalized.status,
          fillPrice: normalized.avgFillPrice || undefined,
          filledQuantity: normalized.filledQty || undefined,
          rawJson: JSON.stringify(normalized.raw),
          updatedAt: new Date(),
        } as any)
        .where(eq(brokerOrders.id, bo.id));

      if (normalized.status === "cancelled" && bo.orderIntentId) {
        await db
          .update(orderIntents)
          .set({
            state: "CANCELLED",
            updatedAt: new Date(),
          } as any)
          .where(eq(orderIntents.id, bo.orderIntentId));
        continue;
      }

      if (normalized.status === "rejected" && bo.orderIntentId) {
        await db
          .update(orderIntents)
          .set({
            state: "ERROR",
            updatedAt: new Date(),
          } as any)
          .where(eq(orderIntents.id, bo.orderIntentId));
        continue;
      }

      if (normalized.status !== "filled") continue;

      if (bo.side === "entry") {
        const [intent] = await db
          .select()
          .from(orderIntents)
          .where(eq(orderIntents.id, bo.orderIntentId))
          .limit(1);

        if (!intent) continue;

        const [existing] = await db
          .select()
          .from(positions)
          .where(
            and(
              eq(positions.ticker, intent.ticker),
              eq(positions.expiration, intent.expiration),
              eq(positions.shortStrike, intent.shortStrike),
              eq(positions.longStrike, intent.longStrike),
              eq(positions.status, "open"),
            ),
          )
          .limit(1);

        const contracts = normalized.filledQty || safeNum((intent as any).contracts, 1);
        const entryCredit =
          normalized.avgFillPrice ||
          safeNum((intent as any).intendedCredit, 0) ||
          safeNum((intent as any).entryCredit, 0);

        const width =
          safeNum((intent as any).width, 0) ||
          Math.abs(
            safeNum((intent as any).shortStrike, 0) -
              safeNum((intent as any).longStrike, 0),
          );

        const maxRisk = Math.max(0, width - entryCredit) * contracts * 100;

        if (!existing) {
          const meta = normalizePositionMetadata({
            ticker: intent.ticker,
            sector: (intent as any).sector,
            subIndustry: (intent as any).subIndustry,
            beta: (intent as any).beta,
            underlyingPrice: (intent as any).underlyingPrice,
          });

          await db.insert(positions).values({
            ticker: intent.ticker,
            expiration: intent.expiration,
            shortStrike: intent.shortStrike,
            longStrike: intent.longStrike,
            contracts,
            width,

            credit: entryCredit,
            entryCredit,
            currentMark: entryCredit,
            maxRisk,

            entryDate: new Date(),
            openedAt: new Date(),
            status: "open",

            sector: meta.sector,
            subIndustry: meta.subIndustry,
            confidence: (intent as any).confidence ?? null,
            liquidityScore: (intent as any).liquidityScore ?? null,
            entryDelta: (intent as any).shortDelta ?? (intent as any).entryDelta ?? null,
            entryDte: (intent as any).dte ?? (intent as any).entryDte ?? null,
            beta: meta.beta,
            underlyingPrice: meta.underlyingPrice,
            brokerOrderId: bo.brokerOrderId,

            createdAt: new Date(),
            updatedAt: new Date(),
          } as any);

          await db.insert(systemEvents).values({
            severity: "info",
            eventType: "position_created_from_fill",
            message: `${intent.ticker} live position created`,
            payload: JSON.stringify({
              orderIntentId: intent.id,
              brokerOrderId: bo.brokerOrderId,
              entryCredit,
              contracts,
            }),
          });
        }

        await db
          .update(orderIntents)
          .set({
            state: "FILLED",
            updatedAt: new Date(),
          } as any)
          .where(eq(orderIntents.id, intent.id));
      }

      if (bo.side === "exit" && bo.positionId) {
        const [pos] = await db
          .select()
          .from(positions)
          .where(eq(positions.id, bo.positionId))
          .limit(1);

        if (!pos) continue;
        if (String((pos as any).status) !== "open") continue;

        const entryCredit = safeNum((pos as any).entryCredit, safeNum((pos as any).credit, 0));
        const exitDebit = normalized.avgFillPrice || safeNum((bo as any).requestedPrice, 0);
        const contracts = safeNum((pos as any).contracts, 1);

        const realizedPnl = (entryCredit - exitDebit) * contracts * 100;
        const width = Math.abs(safeNum((pos as any).shortStrike, 0) - safeNum((pos as any).longStrike, 0));
        const maxRisk = width > 0
          ? (width - safeNum((pos as any).credit, 0)) * 100 * contracts
          : safeNum((pos as any).maxRisk, 0);
        const realizedPnlPct =
          maxRisk > 0 ? realizedPnl / maxRisk : 0;

        await db
          .update(positions)
          .set({
            status: "closed",
            currentMark: exitDebit,
            closedAt: new Date(),
            realizedPnl,
            realizedPnlPct,
            updatedAt: new Date(),
          } as any)
          .where(eq(positions.id, pos.id));

        await db.insert(systemEvents).values({
          severity: "info",
          eventType: "position_closed_from_fill",
          message: `${(pos as any).ticker} live position closed`,
          payload: JSON.stringify({
            positionId: pos.id,
            brokerOrderId: bo.brokerOrderId,
            exitDebit,
            realizedPnl,
            realizedPnlPct,
          }),
        });
      }

    } catch (e: any) {
      await db.insert(systemEvents).values({
        severity: "critical",
        eventType: "live_order_sync_failed",
        message: String(e?.message || e),
        payload: JSON.stringify({
          brokerOrderId: bo.brokerOrderId,
          side: bo.side,
          positionId: bo.positionId,
        }),
      });
    }
  }
}
