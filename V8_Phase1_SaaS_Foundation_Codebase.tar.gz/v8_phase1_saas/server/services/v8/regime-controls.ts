export type MarketRegime = "NORMAL" | "UNSTABLE" | "SEVERE";

export type RegimeControlInput = {
  regime: MarketRegime;
  vix: number;
  vixShortMa?: number;
  vixSlope?: number;
};

export type RegimeControlResult = {
  effectiveRegime: MarketRegime;
  allowNewTrades: boolean;
  maxTradesToday: number;
  throttle: number;
  reason: string;
};

function safeNum(v: any, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

export function getRegimeControls(
  input: RegimeControlInput,
): RegimeControlResult {
  const regime = input.regime;
  const vix = safeNum(input.vix, 18);
  const vixShortMa = safeNum(input.vixShortMa, vix);
  const vixSlope = safeNum(input.vixSlope, 0);

  const reverting =
    vix >= 20 &&
    vix < vixShortMa &&
    vixSlope < 0;

  if (regime === "SEVERE") {
    if (reverting) {
      return {
        effectiveRegime: "UNSTABLE",
        allowNewTrades: true,
        maxTradesToday: 1,
        throttle: 0.5,
        reason: "severe_softened_by_vol_mean_reversion",
      };
    }

    return {
      effectiveRegime: "SEVERE",
      allowNewTrades: false,
      maxTradesToday: 0,
      throttle: 0,
      reason: "severe_regime_halt",
    };
  }

  if (regime === "UNSTABLE") {
    if (reverting) {
      return {
        effectiveRegime: "UNSTABLE",
        allowNewTrades: true,
        maxTradesToday: 2,
        throttle: 0.75,
        reason: "unstable_but_reverting",
      };
    }

    return {
      effectiveRegime: "UNSTABLE",
      allowNewTrades: true,
      maxTradesToday: 1,
      throttle: 0.5,
      reason: "unstable_regime_throttle",
    };
  }

  return {
    effectiveRegime: "NORMAL",
    allowNewTrades: true,
    maxTradesToday: 2,
    throttle: 1,
    reason: "normal_regime",
  };
}
