import type { LiquidityBreakdown, ScanPick } from "./types";
import { clamp } from "./market-math";

export function scoreLiquidity(pick: ScanPick): LiquidityBreakdown {
  const reasons: string[] = [];
  const oiProxy = Math.max(1, Math.round((pick.optionVolume ?? 100) + 100));
  const width = Math.max(0.01, pick.width || Math.abs(pick.shortPut - pick.longPut));
  const premiumWidth = clamp((pick.credit || 0) / width, 0, 1);

  const slippageRatio = pick.slippageRatio ?? 1.5;
  const tightness = clamp(1 - (slippageRatio - 1) / 1.0, 0, 1);

  const oiScore = clamp(oiProxy / 500, 0, 1);
  const tightnessScore = clamp(tightness, 0, 1);
  const premiumWidthScore = clamp(premiumWidth, 0, 1);

  const exitFrictionScore = clamp(1 - (slippageRatio - 1) / 0.5, 0, 1);

  if (oiScore < 0.2) reasons.push("weak_oi");
  if (tightnessScore < 0.2) reasons.push("wide_market");
  if (premiumWidthScore < 0.15) reasons.push("thin_credit");
  if (exitFrictionScore < 0.2) reasons.push("exit_friction");

  const liquidityScore = Math.round((0.35 * oiScore + 0.30 * tightnessScore + 0.20 * premiumWidthScore + 0.15 * exitFrictionScore) * 100);
  return { oiScore, tightnessScore, premiumWidthScore, exitFrictionScore, liquidityScore, reasons };
}

export function shouldRejectForLiquidity(pick: ScanPick): string | null {
  const score = scoreLiquidity(pick);
  if (score.liquidityScore < 40) return "liquidity_below_floor";
  const slippageRatio = pick.slippageRatio ?? 1.5;
  if (slippageRatio > 2.0) return "spread_elasticity";
  return null;
}
