export function v8log(level: "info" | "warn" | "error", event: string, payload: Record<string, any> = {}) {
  const line = JSON.stringify({ ts: new Date().toISOString(), level, event, ...payload });
  if (level === "error") console.error(line);
  else if (level === "warn") console.warn(line);
  else console.log(line);
}
