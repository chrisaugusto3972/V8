import type { HeatSnapshot, RiskDecision, ScanPick } from "./types";
import { withinOpportunityBudget } from "./opportunity-budget";
import { scoreBreadth } from "./strategy-breadth";
import { scoreLiquidity, shouldRejectForLiquidity } from "./liquidity-engine";
import { betaAdjustedDistancePct, expectedMovePct, gammaDteFloor, gapRiskFloorPct, isHighBeta } from "./market-math";
import { stressCandidate } from "./scenario-stress";
import { getAppSettings } from "./operator-controls";

function buildHeat(existing: ScanPick[]): HeatSnapshot {
  const sectorRisk: Record<string, number> = {};
  const bucketRisk: Record<string, number> = {};
  let totalRisk = 0;
  let shortDeltaExposure = 0;
  let weekendDeltaExposure = 0;
  let highBetaRisk = 0;
  let singleStockRisk = 0;
  let etfRisk = 0;
  for (const p of existing) {
    const risk = p.tradeRisk || p.maxLoss || 0;
    totalRisk += risk;
    shortDeltaExposure += (p.shortDeltaAbs || 0) * risk;
    if ((p.dte ?? 10) <= 3) weekendDeltaExposure += (p.shortDeltaAbs || 0) * risk;
    if (isHighBeta(p.beta)) highBetaRisk += risk;
    if (p.sector === "Index") etfRisk += risk;
    else singleStockRisk += risk;
    sectorRisk[p.sector] = (sectorRisk[p.sector] || 0) + risk;
  }
  return { totalRisk, shortDeltaExposure, weekendDeltaExposure, highBetaRisk, singleStockRisk, etfRisk, sectorRisk, bucketRisk };
}

export async function evaluateCandidate(existing: ScanPick[], candidate: ScanPick, mode: "weekday" | "weekend" = "weekday"): Promise<RiskDecision> {
  const appSettings = await getAppSettings();

  const disabledTickers = (() => {
    try {
      return JSON.parse(appSettings?.disabledTickersJson || "[]");
    } catch {
      return [];
    }
  })().map((t: string) => String(t).toUpperCase());

  if (disabledTickers.includes(String(candidate.ticker).toUpperCase())) {
    return {
      allow: false,
      reason: "ticker_disabled_by_operator",
    };
  }

  const warnings: string[] = [];
  const liquidity = scoreLiquidity(candidate);
  const rejectLiquidity = shouldRejectForLiquidity(candidate);
  if (rejectLiquidity) return { allow: false, reason: rejectLiquidity, liquidityScore: liquidity.liquidityScore };
  if (!withinOpportunityBudget(existing, candidate)) return { allow: false, reason: "opportunity_budget", liquidityScore: liquidity.liquidityScore };

  const dte = candidate.dte ?? 0;
  const beta = candidate.beta ?? 1;
  const distFrac = candidate.distancePct / 100;
  const reqDistance = betaAdjustedDistancePct(0.04, beta);
  const em = Math.max(expectedMovePct(candidate.iv ?? 20, dte), gapRiskFloorPct(beta));
  if (distFrac < reqDistance) return { allow: false, reason: "beta_distance", liquidityScore: liquidity.liquidityScore };
  if (distFrac < em * 1.15) return { allow: false, reason: "expected_move", liquidityScore: liquidity.liquidityScore };
  if (dte < gammaDteFloor(beta)) return { allow: false, reason: "gamma_floor", liquidityScore: liquidity.liquidityScore };
  if (candidate.shortDeltaAbs > 0.30) return { allow: false, reason: "delta_too_high", liquidityScore: liquidity.liquidityScore };
  if (mode === "weekend" && candidate.shortDeltaAbs > 0.25) return { allow: false, reason: "weekend_delta", liquidityScore: liquidity.liquidityScore };
  if (candidate.credit < 0.12) return { allow: false, reason: "credit_too_low", liquidityScore: liquidity.liquidityScore };

  const heat = buildHeat(existing);
  const breadth = scoreBreadth([...existing, candidate]);
  if (breadth.breadthScore < 20) warnings.push("weak_breadth");
  const stress = stressCandidate(heat, candidate);
  if (!stress.allow) return { allow: false, reason: "scenario_stress", liquidityScore: liquidity.liquidityScore, heat };
  if (isHighBeta(beta) && heat.highBetaRisk > Math.max(500, heat.totalRisk * 0.10)) return { allow: false, reason: "high_beta_heat", liquidityScore: liquidity.liquidityScore, heat };
  return { allow: true, liquidityScore: liquidity.liquidityScore, warnings, heat };
}
