import type { HeatSnapshot, ScanPick } from "./types";

export function stressCandidate(heat: HeatSnapshot, candidate: ScanPick) {
  const candidateRisk = candidate.tradeRisk || candidate.maxLoss || ((candidate.width - candidate.credit) * 100 * Math.max(1, candidate.contracts));
  const projectedTotal = heat.totalRisk + candidateRisk;
  const projectedHighBeta = heat.highBetaRisk + ((candidate.beta ?? 1) >= 1.35 ? candidateRisk : 0);
  const fourPctShock = projectedTotal * 0.35 + projectedHighBeta * 0.25;
  return {
    allow: fourPctShock <= Math.max(500, projectedTotal * 0.45),
    estimatedShockLoss: fourPctShock,
  };
}
