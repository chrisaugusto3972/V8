type OpenPositionLike = {
  ticker?: string | null;
  sector?: string | null;
  maxRisk?: number | null;
};

type CandidateRiskLike = {
  ticker: string;
  sector?: string | null;
  projectedRisk: number;
  isHighBeta?: boolean;
};

type DeploymentConfig = {
  accountEquity: number;
  targetDeploymentPct: number;
  hardMaxDeploymentPct: number;
  maxRiskPerTradeHardCap: number;
  sectorCapPct: number;
  highBetaCapPct: number;
};

export type DeploymentDecision = {
  allowed: boolean;
  reason?: string;
};

function safeNum(v: any, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

export function checkDeploymentGuard(
  openPositions: OpenPositionLike[],
  candidate: CandidateRiskLike,
  cfg: DeploymentConfig,
): DeploymentDecision {
  const accountEquity = safeNum(cfg.accountEquity, 0);
  const openRisk = openPositions.reduce(
    (sum, p) => sum + safeNum(p.maxRisk, 0),
    0,
  );

  if (candidate.projectedRisk > cfg.maxRiskPerTradeHardCap) {
    return { allowed: false, reason: "maxRiskPerTradeHardCapExceeded" };
  }

  const projectedTotalRisk = openRisk + safeNum(candidate.projectedRisk, 0);

  if (projectedTotalRisk > accountEquity * cfg.hardMaxDeploymentPct) {
    return { allowed: false, reason: "deploymentHardCapExceeded" };
  }

  if (projectedTotalRisk > accountEquity * cfg.targetDeploymentPct) {
    return { allowed: false, reason: "deploymentTargetExceeded" };
  }

  const sameTickerRisk =
    openPositions
      .filter((p) => String(p.ticker ?? "").toUpperCase() === candidate.ticker.toUpperCase())
      .reduce((sum, p) => sum + safeNum(p.maxRisk, 0), 0) + candidate.projectedRisk;

  if (sameTickerRisk > accountEquity * 0.08) {
    return { allowed: false, reason: "singleTickerCapExceeded" };
  }

  const sameSectorRisk =
    openPositions
      .filter((p) => String(p.sector ?? "").toLowerCase() === String(candidate.sector ?? "").toLowerCase())
      .reduce((sum, p) => sum + safeNum(p.maxRisk, 0), 0) + candidate.projectedRisk;

  if (sameSectorRisk > accountEquity * cfg.sectorCapPct) {
    return { allowed: false, reason: "sectorCapExceeded" };
  }

  if (candidate.isHighBeta && candidate.projectedRisk > accountEquity * cfg.highBetaCapPct) {
    return { allowed: false, reason: "highBetaCapExceeded" };
  }

  return { allowed: true };
}
