import type { ScanPick } from "./types";

export function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

export function expectedMovePct(iv: number | null | undefined, dte: number | null | undefined): number {
  if (!iv || !dte || dte <= 0) return 0;
  return (iv / 100) * Math.sqrt(dte / 365);
}

export function betaAdjustedDistancePct(baseDistancePct: number, beta: number | null | undefined): number {
  const b = beta && beta > 0 ? beta : 1;
  return baseDistancePct * Math.sqrt(b);
}

export function gammaDteFloor(beta: number | null | undefined): number {
  const b = beta && beta > 0 ? beta : 1;
  if (b > 1.5) return 10;
  if (b > 1.3) return 7;
  return 5;
}

export function averageOvernightGapPct(beta: number | null | undefined): number {
  const b = beta && beta > 0 ? beta : 1;
  return clamp(0.01 * Math.sqrt(b), 0.008, 0.04);
}

export function gapRiskFloorPct(beta: number | null | undefined): number {
  return averageOvernightGapPct(beta) * 2;
}

export function isHighBeta(beta: number | null | undefined): boolean {
  return (beta ?? 1) >= 1.35;
}

export function conservativeHoldCheck(pick: Partial<ScanPick>, regime: string): boolean {
  return (pick.shortDeltaAbs ?? 1) < 0.15 && (pick.dte ?? 0) >= 3 && !isHighBeta(pick.beta) && ["LOW_VOL", "NORMAL"].includes(regime);
}
