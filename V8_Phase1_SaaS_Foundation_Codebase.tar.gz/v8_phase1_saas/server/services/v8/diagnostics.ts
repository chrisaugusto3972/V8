import { db } from "../../db";
import { autopilotState } from "@shared/schema";
import { ENGINE_VERSION } from "./version";

export async function getSystemReadiness() {
  const [state] = await db.select().from(autopilotState).limit(1).catch(() => [null]);

  const now = Date.now();
  const heartbeatFresh =
    !!state?.lastHeartbeatAt &&
    now - new Date(state.lastHeartbeatAt).getTime() < 10 * 60 * 1000;

  const reconFresh =
    !!state?.lastReconAt &&
    now - new Date(state.lastReconAt).getTime() < 15 * 60 * 1000;

  const healthFresh =
    !!state?.lastHealthAt &&
    now - new Date(state.lastHealthAt).getTime() < 15 * 60 * 1000;

  const reasons: string[] = [];

  if (!heartbeatFresh) reasons.push("heartbeat_stale");
  if (!reconFresh) reasons.push("recon_stale");
  if (!healthFresh) reasons.push("health_stale");
  if (state?.isPaused) reasons.push(`autopilot_paused:${state.pauseReason ?? "unknown"}`);

  return {
    ready: reasons.length === 0,
    engineVersion: ENGINE_VERSION,
    reasons,
    state,
  };
}
