export type RuntimeMode = "DRY_RUN" | "PAPER" | "LIVE";

export type MarketRegime = "LOW_VOL" | "NORMAL" | "ELEVATED" | "PANIC" | "SLOW_BEAR";

export type ScanPick = {
  ticker: string;
  sector: string;
  price: number;
  expiration: string;
  dte: number | null;
  engine: string;
  shortPut: number;
  longPut: number;
  width: number;
  shortBid: number;
  longAsk: number;
  credit: number;
  creditPctWidth: number;
  distancePct: number;
  shortDeltaAbs: number;
  maxLoss: number;
  rorPct: number;
  contracts: number;
  tradeRisk: number;
  slippageRatio: number;
  confidence: number;
  beta?: number | null;
  iv?: number | null;
  optionVolume?: number | null;
  bidSize?: number | null;
  askSize?: number | null;
  expectedMovePct?: number | null;
  subIndustry?: string | null;
};

export type ScanResponse = {
  ok: boolean;
  mode: string;
  warnings?: string[];
  picks: ScanPick[];
  reject?: Record<string, number>;
};

export type LiquidityBreakdown = {
  oiScore: number;
  tightnessScore: number;
  premiumWidthScore: number;
  exitFrictionScore: number;
  liquidityScore: number;
  reasons: string[];
};

export type OpportunityBucketKey = {
  deltaBucket: string;
  dteBucket: string;
  widthBucket: string;
  confidenceBucket: string;
  highBetaBucket: string;
  assetMixBucket: string;
};

export type HeatSnapshot = {
  totalRisk: number;
  shortDeltaExposure: number;
  weekendDeltaExposure: number;
  highBetaRisk: number;
  singleStockRisk: number;
  etfRisk: number;
  sectorRisk: Record<string, number>;
  bucketRisk: Record<string, number>;
};

export type RiskDecision = {
  allow: boolean;
  reason?: string;
  liquidityScore?: number;
  appliedModifier?: string;
  warnings?: string[];
  heat?: HeatSnapshot;
};

export type StrategyHealthResult = {
  healthScore: number;
  mode: "NORMAL" | "REDUCE_PARTICIPATION" | "DEFENSIVE" | "PAUSE";
  notes: string[];
};
