import { and, desc, eq, gte, sql } from "drizzle-orm";
import { db } from "../../db";
import { brokerOrders, positions, systemEvents } from "@shared/schema";

function safeNum(v: any, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

export type FillAnalyticsSummary = {
  ticker: string;
  trades: number;
  avgEntrySlippagePct: number;
  avgExitSlippagePct: number;
  avgFillMinutes: number;
  poorFill: boolean;
};

export async function calculateFillAnalyticsLookback(
  days = 30,
): Promise<FillAnalyticsSummary[]> {
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();

  const rows = await db
    .select()
    .from(brokerOrders)
    .where(gte(brokerOrders.createdAt, since as any))
    .orderBy(desc(brokerOrders.createdAt));

  const byTicker = new Map<string, any[]>();

  for (const row of rows) {
    const ticker = String((row as any).ticker ?? "").toUpperCase();
    if (!ticker) continue;
    if (!byTicker.has(ticker)) byTicker.set(ticker, []);
    byTicker.get(ticker)!.push(row);
  }

  const results: FillAnalyticsSummary[] = [];

  for (const [ticker, orders] of Array.from(byTicker.entries())) {
    let entrySlipSum = 0;
    let exitSlipSum = 0;
    let fillMinsSum = 0;
    let entryCount = 0;
    let exitCount = 0;
    let fillCount = 0;

    for (const o of orders) {
      const intendedPrice = safeNum((o as any).intendedPrice, 0);
      const avgFillPrice = safeNum((o as any).avgFillPrice, 0);
      const createdAt = new Date((o as any).createdAt).getTime();
      const updatedAt = new Date((o as any).updatedAt ?? (o as any).createdAt).getTime();
      const fillMins =
        Number.isFinite(createdAt) && Number.isFinite(updatedAt)
          ? Math.max(0, (updatedAt - createdAt) / 60000)
          : 0;

      const side = String((o as any).side ?? "").toLowerCase();
      if (intendedPrice > 0 && avgFillPrice > 0) {
        const slipPct = Math.abs(avgFillPrice - intendedPrice) / intendedPrice;

        if (side.includes("open") || side.includes("entry")) {
          entrySlipSum += slipPct;
          entryCount += 1;
        } else {
          exitSlipSum += slipPct;
          exitCount += 1;
        }
      }

      fillMinsSum += fillMins;
      fillCount += 1;
    }

    const avgEntrySlippagePct = entryCount ? entrySlipSum / entryCount : 0;
    const avgExitSlippagePct = exitCount ? exitSlipSum / exitCount : 0;
    const avgFillMinutes = fillCount ? fillMinsSum / fillCount : 0;

    results.push({
      ticker,
      trades: orders.length,
      avgEntrySlippagePct,
      avgExitSlippagePct,
      avgFillMinutes,
      poorFill:
        avgEntrySlippagePct > 0.2 ||
        avgExitSlippagePct > 0.25 ||
        avgFillMinutes > 10,
    });
  }

  return results.sort((a, b) => b.trades - a.trades);
}

export async function writeFillAnalyticsEvent(days = 30) {
  const summary = await calculateFillAnalyticsLookback(days);

  await db.insert(systemEvents).values({
    severity: "info",
    eventType: "fill_analytics_snapshot",
    message: `Calculated fill analytics for ${summary.length} tickers`,
    payload: JSON.stringify(summary.slice(0, 25)),
  });

  return summary;
}
