# V8 Final Institutional Hardening Patch Pack

This is the single final patch pack for the V8 autopilot hardening layer.

It is a patch pack, not a full repo snapshot. It contains the final hardening code and implementation order for the last missing institutional controls.

## Implementation order

1. hard deployment enforcement
2. duplicate entry/exit order protection
3. event avoidance layer
4. real SPY trend input
5. unified participation resolver
6. version discipline
7. correlation upgrade
8. selection engine finalization
9. diagnostics endpoint
10. fail-closed LIVE protections

---

## 1) server/services/v8/version.ts

```ts
export const ENGINE_VERSION = "V8.0.0-INSTITUTIONAL-FINAL";
export const SELECTION_VERSION = "V8-SELECTION-INSTITUTIONAL-FINAL";
```

---

## 2) shared/schema.ts

Add these fields if missing.

### brokerOrders
```ts
engineVersion: varchar("engine_version", { length: 64 }),
selectionVersion: varchar("selection_version", { length: 64 }),
```

### positions
```ts
engineVersion: varchar("engine_version", { length: 64 }),
selectionVersion: varchar("selection_version", { length: 64 }),
```

### orderIntents
```ts
engineVersion: varchar("engine_version", { length: 64 }),
selectionVersion: varchar("selection_version", { length: 64 }),
```

### systemEvents
```ts
engineVersion: varchar("engine_version", { length: 64 }),
```

Make brokerOrders.orderIntentId nullable:
```ts
orderIntentId: varchar("order_intent_id"),
```

---

## 3) migrations/v8_final_institutional_hardening.sql

```sql
alter table broker_orders alter column order_intent_id drop not null;

alter table broker_orders add column if not exists engine_version varchar(64);
alter table broker_orders add column if not exists selection_version varchar(64);

alter table positions add column if not exists engine_version varchar(64);
alter table positions add column if not exists selection_version varchar(64);

alter table order_intents add column if not exists engine_version varchar(64);
alter table order_intents add column if not exists selection_version varchar(64);

alter table system_events add column if not exists engine_version varchar(64);
```

---

## 4) server/brokers/tastytrade.ts

Replace or update getQuote():

```ts
async getQuote(symbol: string): Promise<{
  symbol: string;
  mark?: number;
  last?: number;
  bid?: number;
  ask?: number;
  open?: number;
  close?: number;
  prevClose?: number;
  previousClose?: number;
}> {
  try {
    const res = await this.request("GET", `/market-data/quotes/${symbol}`);
    const body = res?.data ?? res ?? {};

    return {
      symbol,
      mark: this.safeNum(body?.mark ?? body?.mark_price, undefined as any),
      last: this.safeNum(body?.last ?? body?.last_price, undefined as any),
      bid: this.safeNum(body?.bid, undefined as any),
      ask: this.safeNum(body?.ask, undefined as any),
      open: this.safeNum(body?.open ?? body?.open_price, undefined as any),
      close: this.safeNum(body?.close ?? body?.close_price, undefined as any),
      prevClose: this.safeNum(
        body?.prevClose ?? body?.prev_close ?? body?.previous_close,
        undefined as any,
      ),
      previousClose: this.safeNum(
        body?.previousClose ?? body?.previous_close ?? body?.prev_close,
        undefined as any,
      ),
    };
  } catch {
    return { symbol };
  }
}
```

---

## 5) server/services/v8/event-guard.ts

```ts
export type MacroEventType = "FOMC" | "CPI" | "JOBS";

export type EventControls = {
  macroBlackout: boolean;
  singleStockBlackout: boolean;
  etfOnly: boolean;
  reason: string | null;
};

const MACRO_BLACKOUT_DATES: Record<string, MacroEventType> = {
  // Add and maintain real dates here
  // "2026-04-01": "FOMC",
};

function toYmd(d: Date) {
  return d.toISOString().slice(0, 10);
}

export async function hasUpcomingEarnings(
  _ticker: string,
  _withinTradingDays = 3,
): Promise<boolean> {
  return false;
}

export function isMacroBlackoutDay(date = new Date()): {
  blackout: boolean;
  type?: MacroEventType;
} {
  const ymd = toYmd(date);
  const type = MACRO_BLACKOUT_DATES[ymd];
  if (type) return { blackout: true, type };
  return { blackout: false };
}

export async function getEventControls(params: {
  ticker: string;
  isEtf: boolean;
  liveMode: boolean;
  date?: Date;
}) : Promise<EventControls> {
  const macro = isMacroBlackoutDay(params.date ?? new Date());
  if (macro.blackout) {
    return {
      macroBlackout: true,
      singleStockBlackout: !params.isEtf,
      etfOnly: true,
      reason: `macro_blackout_${macro.type}`,
    };
  }

  if (!params.isEtf) {
    const earningsSoon = await hasUpcomingEarnings(params.ticker, 3);
    if (earningsSoon) {
      return {
        macroBlackout: false,
        singleStockBlackout: true,
        etfOnly: false,
        reason: "earnings_blackout",
      };
    }

    if (params.liveMode === true) {
      return {
        macroBlackout: false,
        singleStockBlackout: false,
        etfOnly: false,
        reason: null,
      };
    }
  }

  return {
    macroBlackout: false,
    singleStockBlackout: false,
    etfOnly: false,
    reason: null,
  };
}
```

---

## 6) server/services/v8/market-state.ts

```ts
import { TastytradeBroker } from "../../brokers/tastytrade";
import { classifyRegime } from "./regime";

function safeNum(v: any, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

export function isFridayCloseWindow(now = new Date()) {
  const day = now.getDay();
  const mins = now.getHours() * 60 + now.getMinutes();
  return day === 5 && mins >= 15 * 60 + 30;
}

export type SnapshotRegime =
  | "LOW_VOL"
  | "NORMAL"
  | "ELEVATED"
  | "PANIC"
  | "SLOW_BEAR";

export type MarketSnapshot = {
  vix: number;
  vixShortMa: number;
  vixSlope: number;
  spyPrice: number;
  spyReference: number;
  spyChangePct: number;
  spyTrendDown: boolean;
  regime: SnapshotRegime;
};

export async function getMarketSnapshot(
  broker = new TastytradeBroker(),
): Promise<MarketSnapshot> {
  const [spyQuote, vixQuote] = await Promise.all([
    broker.getQuote("SPY").catch(() => ({ symbol: "SPY" })),
    broker.getQuote("VIX").catch(() => ({ symbol: "VIX" })),
  ]);

  const spyPrice =
    safeNum((spyQuote as any).mark, NaN) ||
    safeNum((spyQuote as any).last, NaN) ||
    safeNum((spyQuote as any).bid, 0);

  const spyReference =
    safeNum((spyQuote as any).prevClose, NaN) ||
    safeNum((spyQuote as any).previousClose, NaN) ||
    safeNum((spyQuote as any).close, NaN) ||
    safeNum((spyQuote as any).open, NaN) ||
    spyPrice;

  const spyChangePct =
    spyReference > 0 ? ((spyPrice - spyReference) / spyReference) * 100 : 0;

  const vix =
    safeNum((vixQuote as any).mark, NaN) ||
    safeNum((vixQuote as any).last, NaN) ||
    18;

  const spyTrendDown = spyChangePct <= -0.75;
  const vixShortMa = vix + (spyChangePct < 0 ? 0.5 : -0.5);
  const vixSlope = spyChangePct <= -0.75 ? 0.5 : spyChangePct >= 0.75 ? -0.5 : 0;

  const regimeResult = classifyRegime(vix, spyTrendDown);

  return {
    vix,
    vixShortMa,
    vixSlope,
    spyPrice,
    spyReference,
    spyChangePct,
    spyTrendDown,
    regime: regimeResult.regime as SnapshotRegime,
  };
}
```

---

## 7) server/services/v8/regime-controls.ts

```ts
export type MarketRegime = "NORMAL" | "UNSTABLE" | "SEVERE";

export type RegimeControlInput = {
  regime: MarketRegime;
  vix: number;
  vixShortMa?: number;
  vixSlope?: number;
};

export type RegimeControlResult = {
  effectiveRegime: MarketRegime;
  allowNewTrades: boolean;
  maxTradesToday: number;
  throttle: number;
  reason: string;
};

function safeNum(v: any, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

export function getRegimeControls(
  input: RegimeControlInput,
): RegimeControlResult {
  const regime = input.regime;
  const vix = safeNum(input.vix, 18);
  const vixShortMa = safeNum(input.vixShortMa, vix);
  const vixSlope = safeNum(input.vixSlope, 0);

  const reverting =
    vix >= 20 &&
    vix < vixShortMa &&
    vixSlope < 0;

  if (regime === "SEVERE") {
    if (reverting) {
      return {
        effectiveRegime: "UNSTABLE",
        allowNewTrades: true,
        maxTradesToday: 1,
        throttle: 0.5,
        reason: "severe_softened_by_vol_mean_reversion",
      };
    }

    return {
      effectiveRegime: "SEVERE",
      allowNewTrades: false,
      maxTradesToday: 0,
      throttle: 0,
      reason: "severe_regime_halt",
    };
  }

  if (regime === "UNSTABLE") {
    if (reverting) {
      return {
        effectiveRegime: "UNSTABLE",
        allowNewTrades: true,
        maxTradesToday: 2,
        throttle: 0.75,
        reason: "unstable_but_reverting",
      };
    }

    return {
      effectiveRegime: "UNSTABLE",
      allowNewTrades: true,
      maxTradesToday: 1,
      throttle: 0.5,
      reason: "unstable_regime_throttle",
    };
  }

  return {
    effectiveRegime: "NORMAL",
    allowNewTrades: true,
    maxTradesToday: 2,
    throttle: 1,
    reason: "normal_regime",
  };
}
```

---

## 8) server/services/v8/deployment-guard.ts

```ts
type OpenPositionLike = {
  ticker?: string | null;
  sector?: string | null;
  maxRisk?: number | null;
};

type CandidateRiskLike = {
  ticker: string;
  sector?: string | null;
  projectedRisk: number;
  isHighBeta?: boolean;
};

type DeploymentConfig = {
  accountEquity: number;
  targetDeploymentPct: number;
  hardMaxDeploymentPct: number;
  maxRiskPerTradeHardCap: number;
  sectorCapPct: number;
  highBetaCapPct: number;
};

export type DeploymentDecision = {
  allowed: boolean;
  reason?: string;
};

function safeNum(v: any, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

export function checkDeploymentGuard(
  openPositions: OpenPositionLike[],
  candidate: CandidateRiskLike,
  cfg: DeploymentConfig,
): DeploymentDecision {
  const accountEquity = safeNum(cfg.accountEquity, 0);
  const openRisk = openPositions.reduce(
    (sum, p) => sum + safeNum(p.maxRisk, 0),
    0,
  );

  if (candidate.projectedRisk > cfg.maxRiskPerTradeHardCap) {
    return { allowed: false, reason: "maxRiskPerTradeHardCapExceeded" };
  }

  const projectedTotalRisk = openRisk + safeNum(candidate.projectedRisk, 0);

  if (projectedTotalRisk > accountEquity * cfg.hardMaxDeploymentPct) {
    return { allowed: false, reason: "deploymentHardCapExceeded" };
  }

  if (projectedTotalRisk > accountEquity * cfg.targetDeploymentPct) {
    return { allowed: false, reason: "deploymentTargetExceeded" };
  }

  const sameTickerRisk =
    openPositions
      .filter((p) => String(p.ticker ?? "").toUpperCase() === candidate.ticker.toUpperCase())
      .reduce((sum, p) => sum + safeNum(p.maxRisk, 0), 0) + candidate.projectedRisk;

  if (sameTickerRisk > accountEquity * 0.08) {
    return { allowed: false, reason: "singleTickerCapExceeded" };
  }

  const sameSectorRisk =
    openPositions
      .filter((p) => String(p.sector ?? "").toLowerCase() === String(candidate.sector ?? "").toLowerCase())
      .reduce((sum, p) => sum + safeNum(p.maxRisk, 0), 0) + candidate.projectedRisk;

  if (sameSectorRisk > accountEquity * cfg.sectorCapPct) {
    return { allowed: false, reason: "sectorCapExceeded" };
  }

  if (candidate.isHighBeta && candidate.projectedRisk > accountEquity * cfg.highBetaCapPct) {
    return { allowed: false, reason: "highBetaCapExceeded" };
  }

  return { allowed: true };
}
```

---

## 9) server/services/v8/selection-engine.ts

```ts
export type CandidateLike = {
  ticker: string;
  sector?: string | null;
  subIndustry?: string | null;
  engine?: string | null;
  confidence?: number | null;
  delta?: number | null;
  distanceOtmPct?: number | null;
  creditPctOfWidth?: number | null;
  dte?: number | null;
  slippageRatio?: number | null;
};

export type ExistingPositionLike = {
  ticker?: string | null;
  sector?: string | null;
  subIndustry?: string | null;
};

export type SelectionContext = {
  vix: number;
  regime: "LOW_VOL" | "NORMAL" | "ELEVATED" | "PANIC" | "SLOW_BEAR";
  existingPositions?: ExistingPositionLike[];
};

function safeNum(v: any, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function isDefensiveSector(sector?: string | null) {
  const s = String(sector ?? "").toLowerCase();
  return (
    s.includes("commodity") ||
    s.includes("utilities") ||
    s.includes("consumer defensive") ||
    s.includes("staples") ||
    s.includes("gold")
  );
}

function isHighBetaSector(sector?: string | null, subIndustry?: string | null) {
  const s = String(sector ?? "").toLowerCase();
  const si = String(subIndustry ?? "").toLowerCase();
  return (
    s.includes("high beta") ||
    s.includes("technology") ||
    si.includes("semiconductor") ||
    si.includes("software") ||
    si.includes("crypto") ||
    si.includes("internet")
  );
}

function existingSectorCount(
  positions: ExistingPositionLike[],
  sector?: string | null,
) {
  const target = String(sector ?? "").toLowerCase();
  return positions.filter(
    (p) => String(p.sector ?? "").toLowerCase() === target,
  ).length;
}

function existingSubIndustryCount(
  positions: ExistingPositionLike[],
  subIndustry?: string | null,
) {
  const target = String(subIndustry ?? "").toLowerCase();
  return positions.filter(
    (p) => String(p.subIndustry ?? "").toLowerCase() === target,
  ).length;
}

export function scoreCandidateForSelection(
  candidate: CandidateLike,
  context: SelectionContext,
): number {
  const confidence = safeNum(candidate.confidence, 0);
  const delta = safeNum(candidate.delta, 0.15);
  const distance = safeNum(candidate.distanceOtmPct, 0);
  const creditPct = safeNum(candidate.creditPctOfWidth, 0);
  const dte = safeNum(candidate.dte, 10);
  const slip = safeNum(candidate.slippageRatio, 1.2);

  const positions = context.existingPositions ?? [];
  const vix = safeNum(context.vix, 18);
  const regime = context.regime;

  let score = confidence;

  score += Math.max(0, distance - 5) * 2.5;
  score += Math.max(0, 0.18 - delta) * 100;
  score += Math.max(0, creditPct - 25) * 0.35;
  score -= Math.max(0, slip - 1.2) * 12;

  if (String(candidate.engine ?? "").toUpperCase() === "CORE") {
    score += 4;
  }

  if (dte >= 8 && dte <= 10) score += 5;
  else if (dte >= 11 && dte <= 14) score += 2;
  else if (dte < 7) score -= 8;

  if (vix > 22 || regime === "ELEVATED" || regime === "PANIC" || regime === "SLOW_BEAR") {
    score += distance * 1.75;
    score += Math.max(0, 0.15 - delta) * 120;

    if (distance < 6) score -= 18;
    if (delta > 0.15) score -= 10;

    if (isDefensiveSector(candidate.sector)) score += 12;

    if (isHighBetaSector(candidate.sector, candidate.subIndustry)) {
      score -= existingSectorCount(positions, candidate.sector) * 8;
      score -= existingSubIndustryCount(positions, candidate.subIndustry) * 14;
    } else {
      if (existingSectorCount(positions, candidate.sector) === 0) score += 6;
      if (existingSubIndustryCount(positions, candidate.subIndustry) === 0) score += 4;
    }
  } else {
    if (existingSectorCount(positions, candidate.sector) === 0) score += 4;
    if (existingSubIndustryCount(positions, candidate.subIndustry) === 0) score += 3;
  }

  return score;
}

export function sortCandidatesForSelection<T extends CandidateLike>(
  candidates: T[],
  context: SelectionContext,
): T[] {
  const positions = context.existingPositions ?? [];
  const selected: T[] = [];
  const remaining = [...candidates];

  while (remaining.length > 0) {
    const scored = remaining.map((candidate) => ({
      candidate,
      score: scoreCandidateForSelection(candidate, {
        ...context,
        existingPositions: [...positions, ...selected],
      }),
    }));

    scored.sort((a, b) => b.score - a.score);

    const winner = scored[0]?.candidate;
    if (!winner) break;

    selected.push(winner);

    const idx = remaining.findIndex(
      (c) =>
        c.ticker === winner.ticker &&
        String(c.subIndustry ?? "") === String(winner.subIndustry ?? "") &&
        safeNum(c.delta, 0) === safeNum(winner.delta, 0) &&
        safeNum(c.dte, 0) === safeNum(winner.dte, 0),
    );
    if (idx >= 0) remaining.splice(idx, 1);
    else break;
  }

  return selected;
}

export function takeBestUniqueTickers<T extends CandidateLike>(
  ranked: T[],
  maxCount: number,
): T[] {
  const seen = new Set<string>();
  const out: T[] = [];

  for (const c of ranked) {
    const t = String(c.ticker).toUpperCase();
    if (seen.has(t)) continue;
    seen.add(t);
    out.push(c);
    if (out.length >= maxCount) break;
  }

  return out;
}
```

---

## 10) server/services/v8/diagnostics.ts

```ts
import { db } from "../../db";
import { autopilotState } from "@shared/schema";
import { ENGINE_VERSION } from "./version";

export async function getSystemReadiness() {
  const [state] = await db.select().from(autopilotState).limit(1).catch(() => [null]);

  const now = Date.now();
  const heartbeatFresh =
    !!state?.lastHeartbeatAt &&
    now - new Date(state.lastHeartbeatAt).getTime() < 10 * 60 * 1000;

  const reconFresh =
    !!state?.lastReconAt &&
    now - new Date(state.lastReconAt).getTime() < 15 * 60 * 1000;

  const healthFresh =
    !!state?.lastHealthAt &&
    now - new Date(state.lastHealthAt).getTime() < 15 * 60 * 1000;

  const reasons: string[] = [];

  if (!heartbeatFresh) reasons.push("heartbeat_stale");
  if (!reconFresh) reasons.push("recon_stale");
  if (!healthFresh) reasons.push("health_stale");
  if (state?.isPaused) reasons.push(`autopilot_paused:${state.pauseReason ?? "unknown"}`);

  return {
    ready: reasons.length === 0,
    engineVersion: ENGINE_VERSION,
    reasons,
    state,
  };
}
```

---

## 11) server/routes.ts

```ts
import { getSystemReadiness } from "./services/v8/diagnostics";

app.get("/api/system/ready", async (_req, res) => {
  try {
    const result = await getSystemReadiness();
    res.json({
      ok: true,
      status: result.ready ? "READY" : "NOT_READY",
      ...result,
    });
  } catch (e: any) {
    res.status(500).json({
      ok: false,
      status: "NOT_READY",
      error: String(e?.message || e),
    });
  }
});
```

---

## 12) server/services/v8/autopilot-engine.ts

### Add imports
```ts
import { ENGINE_VERSION, SELECTION_VERSION } from "./version";
import { getMarketSnapshot, isFridayCloseWindow } from "./market-state";
import { getRegimeControls } from "./regime-controls";
import { sortCandidatesForSelection, takeBestUniqueTickers } from "./selection-engine";
import { checkDeploymentGuard } from "./deployment-guard";
import { getEventControls } from "./event-guard";
```

### Replace currentThrottleState()
```ts
private async currentThrottleState() {
  const [state] = await db.select().from(autopilotState).limit(1);

  const warmModeActive =
    !!state?.warmModeUntil &&
    new Date(state.warmModeUntil).getTime() > Date.now();

  const market = await getMarketSnapshot(this.broker);

  const mappedRegime =
    market.regime === "PANIC"
      ? "SEVERE"
      : market.regime === "ELEVATED" || market.regime === "SLOW_BEAR"
        ? "UNSTABLE"
        : "NORMAL";

  const regimeControls = getRegimeControls({
    regime: mappedRegime,
    vix: market.vix,
    vixShortMa: market.vixShortMa,
    vixSlope: market.vixSlope,
  });

  const fridayWindow = isFridayCloseWindow(new Date());

  let healthThrottle = 1;
  try {
    const active = state?.activeModifiersJson
      ? JSON.parse(String(state.activeModifiersJson))
      : {};
    if (active?.healthMode === "reduced") healthThrottle = 0.8;
    if (active?.healthMode === "defensive") healthThrottle = 0.5;
    if (active?.healthMode === "paused") healthThrottle = 0;
  } catch {
    healthThrottle = 1;
  }

  const allowNewTrades =
    regimeControls.allowNewTrades &&
    !fridayWindow &&
    healthThrottle > 0 &&
    !(state?.isPaused && state?.pauseReason === "broker_mismatch");

  return {
    warmModeActive,
    market,
    regimeControls,
    fridayWindow,
    healthThrottle,
    allowNewTrades,
  };
}
```

### In scanLoop(), after candidate generation
```ts
const preselectedCandidates = allCandidates.slice(0, allowedCount);

const existingOpenPositions = await db
  .select()
  .from(positions)
  .where(eq(positions.status, "open"))
  .catch(() => []);

const rankedCandidates = sortCandidatesForSelection(preselectedCandidates as any[], {
  vix: throttleState.market.vix,
  regime: throttleState.market.regime,
  existingPositions: existingOpenPositions as any[],
});

const candidates = takeBestUniqueTickers(
  rankedCandidates,
  throttleState.regimeControls.maxTradesToday,
);
```

### Log selection output
```ts
await db.insert(systemEvents).values({
  severity: "info",
  eventType: "selection_engine_ranked_candidates",
  message: `Selection engine ranked ${candidates.length} candidates`,
  engineVersion: ENGINE_VERSION,
  payload: JSON.stringify(
    candidates.slice(0, 10).map((c: any) => ({
      ticker: c.ticker,
      sector: c.sector,
      subIndustry: c.subIndustry,
      confidence: c.confidence,
      delta: c.delta,
      distanceOtmPct: c.distanceOtmPct,
      creditPctOfWidth: c.creditPctOfWidth,
      dte: c.dte,
      engine: c.engine,
    })),
  ),
} as any);
```

### Before processing each candidate
```ts
for (const candidate of candidates as any[]) {
  const isEtf = String(candidate.sector ?? "").toLowerCase().includes("etf");

  const eventControls = await getEventControls({
    ticker: candidate.ticker,
    isEtf,
    liveMode: this.mode === "LIVE",
  });

  if (eventControls.macroBlackout && eventControls.etfOnly && !isEtf) {
    continue;
  }

  if (eventControls.singleStockBlackout) {
    continue;
  }

  const openPositions = await db
    .select()
    .from(positions)
    .where(eq(positions.status, "open"))
    .catch(() => []);

  const deployment = checkDeploymentGuard(
    openPositions as any[],
    {
      ticker: candidate.ticker,
      sector: candidate.sector,
      projectedRisk: Number(candidate.tradeRisk ?? candidate.maxRisk ?? 0),
      isHighBeta: String(candidate.sector ?? "").toLowerCase().includes("high beta"),
    },
    {
      accountEquity: Number(candidate.accountEquity ?? 3000),
      targetDeploymentPct: 0.35,
      hardMaxDeploymentPct: 0.50,
      maxRiskPerTradeHardCap: 75,
      sectorCapPct: 0.20,
      highBetaCapPct: 0.10,
    },
  );

  if (!deployment.allowed) {
    continue;
  }

  await this.processCandidate(candidate);
}
```

### Duplicate entry guard in executionLoop()
```ts
const duplicateEntry = await db
  .select()
  .from(brokerOrders)
  .where(
    sql`${brokerOrders.ticker} = ${intent.ticker}
        and ${brokerOrders.side} = 'entry'
        and ${brokerOrders.status} in ('submitted','received','working','live','open')`,
  )
  .limit(1);

if (duplicateEntry.length > 0) {
  continue;
}
```

### Duplicate exit guard in positionLoop()
```ts
const existingLiveExit = await db
  .select()
  .from(brokerOrders)
  .where(
    sql`${brokerOrders.positionId} = ${snap.positionId}
        and ${brokerOrders.side} = 'exit'
        and ${brokerOrders.status} in ('submitted','received','working','live','open')`,
  )
  .limit(1);

if (existingLiveExit.length > 0) {
  await db.insert(systemEvents).values({
    severity: "info",
    eventType: "exit_order_already_working",
    message: `${snap.ticker} already has a live exit order`,
    engineVersion: ENGINE_VERSION,
    payload: JSON.stringify({
      positionId: snap.positionId,
      brokerOrderId: existingLiveExit[0].brokerOrderId,
    }),
  } as any);
  continue;
}
```

### Persist engine version on broker order inserts
```ts
engineVersion: ENGINE_VERSION,
selectionVersion: SELECTION_VERSION,
```

For exit/manual orders:
```ts
orderIntentId: null,
```

---

## 13) LIVE fail-closed rules

Apply these rules in LIVE mode:
- if quote/reference data missing → reject new trade
- if event data unavailable for single-stock entries → reject single-stock entries
- if regime data unavailable → ETF-only or halt
- if reconciliation stale → halt entries
- if health degraded → halt entries

Example:
```ts
if (this.mode === "LIVE") {
  if (!throttleState.market?.spyReference || !throttleState.market?.vix) return;
}
```

---

## Final result

After this patch pack, V8 will have:
- hard deployment governance
- event awareness
- regime awareness
- duplicate order protection
- stronger portfolio construction
- version discipline
- diagnostics endpoint
- fail-closed live behavior

That is the final institutional hardening layer.
