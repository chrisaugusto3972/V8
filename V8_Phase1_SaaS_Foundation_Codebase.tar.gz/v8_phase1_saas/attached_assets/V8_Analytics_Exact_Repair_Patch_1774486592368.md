# V8 Analytics Exact Repair Patch
## Fix all identified analytics errors

This is the single exact repair patch for the current V8 analytics layer.

It fixes all issues identified in review:

1. portfolio delta sign inconsistency
2. non-live Greeks ambiguity
3. incorrect beta-weighted delta calculation
4. broken / step-function stress testing
5. weak sector and metadata enrichment
6. inconsistent max risk source of truth
7. execution analytics scoring exits incorrectly
8. incomplete time-to-fill capture
9. misleading contributor rankings caused by bad delta math

This patch is written so Replit can implement it file-by-file.

---

# PATCH ORDER

Apply in this order:

1. `server/services/v8/portfolio-greeks.ts`
2. `server/services/v8/portfolio-stress.ts`
3. `server/services/v8/execution-analytics.ts`
4. `server/services/v8/live-sync.ts`
5. `server/services/v8/portfolio-snapshots.ts`
6. `server/routes.ts` and UI labels
7. optional metadata helper if needed

---

# 1) REPLACE `server/services/v8/portfolio-greeks.ts`

Use this full version.

```ts
type OpenPositionLike = {
  id?: string | number;
  ticker?: string | null;
  sector?: string | null;
  subIndustry?: string | null;
  contracts?: number | null;
  width?: number | null;
  entryCredit?: number | null;
  maxRisk?: number | null;
  underlyingPrice?: number | null;
  beta?: number | null;

  // stored/live fields if available
  shortDelta?: number | null;
  longDelta?: number | null;
  netDelta?: number | null;
  shortTheta?: number | null;
  longTheta?: number | null;
  netTheta?: number | null;
  betaWeightedDelta?: number | null;

  // fallback inputs
  entryDelta?: number | null;
  dte?: number | null;
  distanceOtmPct?: number | null;
  currentMark?: number | null;
};

export type PositionGreeks = {
  ticker: string;
  sector: string;
  subIndustry: string;
  contracts: number;
  maxRisk: number;
  underlyingPrice: number;
  beta: number;

  shortDelta: number;
  longDelta: number;
  netDelta: number;

  shortTheta: number;
  longTheta: number;
  netTheta: number;

  betaWeightedDelta: number;
  greeksSource: "live" | "approx";
};

export type PortfolioGreeksSummary = {
  totalNetDelta: number;
  totalNetTheta: number;
  betaWeightedDelta: number;
  totalMaxRisk: number;
  highBetaRisk: number;
  singleStockRisk: number;
  etfRisk: number;
  deltaBySector: Record<string, number>;
  thetaBySector: Record<string, number>;
  riskBySector: Record<string, number>;
  riskByTicker: Record<string, number>;
  topDirectionalContributors: Array<{ ticker: string; netDelta: number }>;
  topThetaContributors: Array<{ ticker: string; netTheta: number }>;
  positions: PositionGreeks[];
};

function safeNum(v: any, fallback = 0): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

function isEtf(sector?: string | null): boolean {
  return String(sector ?? "").toLowerCase().includes("etf");
}

function isHighBeta(sector?: string | null, subIndustry?: string | null): boolean {
  const s = String(sector ?? "").toLowerCase();
  const si = String(subIndustry ?? "").toLowerCase();
  return (
    s.includes("high beta") ||
    s.includes("technology") ||
    si.includes("semiconductor") ||
    si.includes("software") ||
    si.includes("crypto") ||
    si.includes("internet")
  );
}

function getTrustedMaxRisk(pos: OpenPositionLike): number {
  const stored = safeNum(pos.maxRisk, 0);
  if (stored > 0) return stored;

  const width = safeNum(pos.width, 0);
  const credit = safeNum(pos.entryCredit, 0);
  const contracts = Math.max(1, safeNum(pos.contracts, 1));

  if (width > 0) {
    return Math.max(0, (width - credit) * 100 * contracts);
  }

  return 0;
}

/**
 * IMPORTANT CONVENTION
 * --------------------
 * For portfolio analytics, bullish put spreads should have POSITIVE net delta.
 * We keep short-leg delta positive as an absolute exposure measure.
 */
function approximateGreeks(pos: OpenPositionLike, spyPrice = 1): PositionGreeks {
  const ticker = String(pos.ticker ?? "UNKNOWN");
  const sector = String(pos.sector ?? "Unknown");
  const subIndustry = String(pos.subIndustry ?? "Unknown");
  const contracts = Math.max(1, safeNum(pos.contracts, 1));
  const underlyingPrice = safeNum(pos.underlyingPrice, 0);
  const beta = safeNum(pos.beta, 1);
  const maxRisk = getTrustedMaxRisk(pos);

  const entryDelta = clamp(safeNum(pos.entryDelta, 0.15), 0.01, 0.50);
  const dte = Math.max(1, safeNum(pos.dte, 10));
  const distance = Math.max(0, safeNum(pos.distanceOtmPct, 6));

  // Approximation philosophy:
  // - farther OTM => lower effective delta
  // - lower DTE increases sensitivity somewhat
  // - long leg offsets part of short leg
  const distanceAdjustment = clamp(1 - (distance - 5) * 0.05, 0.55, 1.15);
  const timeAdjustment = clamp(1 + (10 - dte) * 0.03, 0.80, 1.25);

  const shortDelta = clamp(entryDelta * distanceAdjustment * timeAdjustment, 0.01, 0.60);
  const longDelta = clamp(shortDelta * 0.28, 0.002, shortDelta * 0.60);

  // Bull put spread net delta should be POSITIVE
  const netDeltaPerSpread = Math.max(0.001, shortDelta - longDelta);
  const netDelta = netDeltaPerSpread * contracts;

  // Theta approximation:
  // short theta collected > long theta paid
  const width = Math.max(1, safeNum(pos.width, 1));
  const baseThetaPerSpread = clamp((width * 0.7) / Math.sqrt(dte), 0.03, 0.35);
  const shortTheta = baseThetaPerSpread * contracts;
  const longTheta = baseThetaPerSpread * 0.35 * contracts;
  const netTheta = Math.max(0.001, shortTheta - longTheta);

  const effectiveSpyPrice = Math.max(1, safeNum(spyPrice, 1));
  const betaWeightedDelta = netDelta * beta * (underlyingPrice > 0 ? underlyingPrice / effectiveSpyPrice : 1);

  return {
    ticker,
    sector,
    subIndustry,
    contracts,
    maxRisk,
    underlyingPrice,
    beta,
    shortDelta,
    longDelta,
    netDelta,
    shortTheta,
    longTheta,
    netTheta,
    betaWeightedDelta,
    greeksSource: "approx",
  };
}

function useLiveGreeksIfValid(pos: OpenPositionLike, spyPrice = 1): PositionGreeks | null {
  const shortDelta = safeNum(pos.shortDelta, NaN);
  const longDelta = safeNum(pos.longDelta, NaN);
  const netDelta = safeNum(pos.netDelta, NaN);
  const shortTheta = safeNum(pos.shortTheta, NaN);
  const longTheta = safeNum(pos.longTheta, NaN);
  const netTheta = safeNum(pos.netTheta, NaN);

  const hasAll =
    Number.isFinite(shortDelta) &&
    Number.isFinite(longDelta) &&
    Number.isFinite(netDelta) &&
    Number.isFinite(shortTheta) &&
    Number.isFinite(longTheta) &&
    Number.isFinite(netTheta);

  if (!hasAll) return null;

  const ticker = String(pos.ticker ?? "UNKNOWN");
  const sector = String(pos.sector ?? "Unknown");
  const subIndustry = String(pos.subIndustry ?? "Unknown");
  const contracts = Math.max(1, safeNum(pos.contracts, 1));
  const underlyingPrice = safeNum(pos.underlyingPrice, 0);
  const beta = safeNum(pos.beta, 1);
  const maxRisk = getTrustedMaxRisk(pos);
  const effectiveSpyPrice = Math.max(1, safeNum(spyPrice, 1));

  // Normalize sign convention:
  // If stored netDelta is negative for a bullish put spread, flip it.
  const normalizedNetDelta = Math.abs(netDelta);
  const normalizedShortDelta = Math.abs(shortDelta);
  const normalizedLongDelta = Math.abs(longDelta);

  const betaWeightedDelta =
    normalizedNetDelta * beta * (underlyingPrice > 0 ? underlyingPrice / effectiveSpyPrice : 1);

  return {
    ticker,
    sector,
    subIndustry,
    contracts,
    maxRisk,
    underlyingPrice,
    beta,
    shortDelta: normalizedShortDelta,
    longDelta: normalizedLongDelta,
    netDelta: normalizedNetDelta,
    shortTheta: Math.abs(shortTheta),
    longTheta: Math.abs(longTheta),
    netTheta: Math.abs(netTheta),
    betaWeightedDelta,
    greeksSource: "live",
  };
}

export function getOpenPositionsWithGreeks(
  openPositions: OpenPositionLike[],
  spyPrice: number,
): PositionGreeks[] {
  return openPositions.map((pos) => {
    const live = useLiveGreeksIfValid(pos, spyPrice);
    if (live) return live;
    return approximateGreeks(pos, spyPrice);
  });
}

export function computePortfolioGreeks(
  openPositions: OpenPositionLike[],
  spyPrice: number,
): PortfolioGreeksSummary {
  const positions = getOpenPositionsWithGreeks(openPositions, spyPrice);

  const deltaBySector: Record<string, number> = {};
  const thetaBySector: Record<string, number> = {};
  const riskBySector: Record<string, number> = {};
  const riskByTicker: Record<string, number> = {};

  let totalNetDelta = 0;
  let totalNetTheta = 0;
  let betaWeightedDelta = 0;
  let totalMaxRisk = 0;
  let highBetaRisk = 0;
  let singleStockRisk = 0;
  let etfRisk = 0;

  for (const p of positions) {
    totalNetDelta += p.netDelta;
    totalNetTheta += p.netTheta;
    betaWeightedDelta += p.betaWeightedDelta;
    totalMaxRisk += p.maxRisk;

    deltaBySector[p.sector] = safeNum(deltaBySector[p.sector], 0) + p.netDelta;
    thetaBySector[p.sector] = safeNum(thetaBySector[p.sector], 0) + p.netTheta;
    riskBySector[p.sector] = safeNum(riskBySector[p.sector], 0) + p.maxRisk;
    riskByTicker[p.ticker] = safeNum(riskByTicker[p.ticker], 0) + p.maxRisk;

    if (isEtf(p.sector)) etfRisk += p.maxRisk;
    else singleStockRisk += p.maxRisk;

    if (isHighBeta(p.sector, p.subIndustry)) highBetaRisk += p.maxRisk;
  }

  const topDirectionalContributors = [...positions]
    .sort((a, b) => Math.abs(b.netDelta) - Math.abs(a.netDelta))
    .slice(0, 5)
    .map((p) => ({ ticker: p.ticker, netDelta: p.netDelta }));

  const topThetaContributors = [...positions]
    .sort((a, b) => Math.abs(b.netTheta) - Math.abs(a.netTheta))
    .slice(0, 5)
    .map((p) => ({ ticker: p.ticker, netTheta: p.netTheta }));

  return {
    totalNetDelta,
    totalNetTheta,
    betaWeightedDelta,
    totalMaxRisk,
    highBetaRisk,
    singleStockRisk,
    etfRisk,
    deltaBySector,
    thetaBySector,
    riskBySector,
    riskByTicker,
    topDirectionalContributors,
    topThetaContributors,
    positions,
  };
}
```

---

# 2) REPLACE `server/services/v8/portfolio-stress.ts`

Use this full version.

```ts
import type { PortfolioGreeksSummary } from "./portfolio-greeks";

export type PortfolioStressResult = {
  spyDown1pct: number;
  spyDown2pct: number;
  spyDown3pct: number;
  volUp5: number;
  volUp10: number;
};

function safeNum(v: any, fallback = 0): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

/**
 * Continuous stress model:
 * - directional stress uses betaWeightedDelta continuously
 * - convexity/gap penalty increases smoothly with move size
 * - vol shock increases losses smoothly based on high-beta and total risk
 */
export function computePortfolioStress(
  greeks: PortfolioGreeksSummary,
  spyPrice: number,
): PortfolioStressResult {
  const bwd = safeNum(greeks.betaWeightedDelta, 0);
  const totalRisk = safeNum(greeks.totalMaxRisk, 0);
  const highBetaRisk = safeNum(greeks.highBetaRisk, 0);
  const effectiveSpyPrice = Math.max(1, safeNum(spyPrice, 1));

  function directionalShock(movePct: number): number {
    return bwd * effectiveSpyPrice * movePct * -1;
  }

  function convexityPenalty(movePct: number): number {
    const absMove = Math.abs(movePct);
    // Smooth penalty that scales with move size and total risk
    const penaltyPct =
      absMove <= 0.01 ? 0.005 :
      absMove <= 0.02 ? 0.015 :
      0.035;
    return totalRisk * penaltyPct;
  }

  function stressForMove(movePct: number): number {
    const directional = directionalShock(movePct);
    const penalty = convexityPenalty(movePct);
    return directional - penalty;
  }

  function volShock(points: number): number {
    const hbWeight = totalRisk > 0 ? highBetaRisk / totalRisk : 0;
    const basePenaltyPct = 0.01 * points; // +5 => 5%, +10 => 10% rough penalty base
    const highBetaAmplifier = 1 + hbWeight * 0.75;
    return -(totalRisk * basePenaltyPct * highBetaAmplifier);
  }

  return {
    spyDown1pct: stressForMove(0.01),
    spyDown2pct: stressForMove(0.02),
    spyDown3pct: stressForMove(0.03),
    volUp5: volShock(5),
    volUp10: volShock(10),
  };
}
```

---

# 3) REPLACE `server/services/v8/execution-analytics.ts`

Use this full version.

```ts
type ExecutionAttemptInput = {
  brokerOrderId?: string | null;
  positionId?: string | number | null;
  ticker: string;
  side: "entry" | "exit";
  intentType: "entry" | "profit_exit" | "defensive_exit" | "emergency_exit";
  bidAtSubmit: number;
  askAtSubmit: number;
  midpointAtSubmit: number;
  initialLimit: number;
  regime?: string | null;
  engineVersion?: string | null;
  selectionVersion?: string | null;
  createdAt?: Date | null;
};

type ExecutionFillInput = {
  brokerOrderId?: string | null;
  finalFillPrice: number;
  createdAt?: Date | null;
  filledAt?: Date | null;
  repriceCount?: number | null;
};

function safeNum(v: any, fallback = 0): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

/**
 * SIDE-AWARE quality scoring:
 * - entry credit: higher fill is better
 * - exit debit: lower fill is better
 */
export function computeExecutionQuality(params: {
  side: "entry" | "exit";
  bid: number;
  ask: number;
  midpoint: number;
  fill: number;
}) {
  const bid = safeNum(params.bid, 0);
  const ask = safeNum(params.ask, 0);
  const midpoint = safeNum(params.midpoint, 0);
  const fill = safeNum(params.fill, 0);
  const spread = Math.max(ask - bid, 0.0001);

  let fillVsMidpointPct = 0;
  let fillVsBidAskPct = 0;

  if (params.side === "entry") {
    // better = higher credit
    fillVsMidpointPct = midpoint > 0 ? ((fill - midpoint) / midpoint) * 100 : 0;
    fillVsBidAskPct = ((fill - bid) / spread) * 100;
  } else {
    // better = lower debit
    fillVsMidpointPct = midpoint > 0 ? ((midpoint - fill) / midpoint) * 100 : 0;
    fillVsBidAskPct = ((ask - fill) / spread) * 100;
  }

  return {
    fillVsMidpointPct: round2(fillVsMidpointPct),
    fillVsBidAskPct: round2(fillVsBidAskPct),
  };
}

/**
 * Make sure callers always pass attempt createdAt.
 * If not, return null so incomplete time-to-fill does not silently contaminate stats.
 */
export function computeTimeToFillSeconds(
  createdAt?: Date | null,
  filledAt?: Date | null,
): number | null {
  if (!createdAt || !filledAt) return null;
  const diffMs = new Date(filledAt).getTime() - new Date(createdAt).getTime();
  if (!Number.isFinite(diffMs) || diffMs < 0) return null;
  return Math.round(diffMs / 1000);
}
```

---

# 4) UPDATE `server/services/v8/live-sync.ts`

Add or fix position metadata enrichment when positions are created or updated.

## Required fixes:
- always populate `sector`
- always populate `subIndustry`
- always populate `beta`
- always populate `underlyingPrice`
- always populate `entryDelta` if available
- if live Greeks are available, populate:
  - `shortDelta`
  - `longDelta`
  - `netDelta`
  - `shortTheta`
  - `longTheta`
  - `netTheta`

## Exact implementation rule:
When creating/updating positions from fills:
1. first use values from the filled order intent if present
2. if missing, enrich from trusted ticker metadata lookup
3. never leave sector/subIndustry null if they can be inferred

### Add this helper pattern:
```ts
function normalizePositionMetadata(input: any) {
  return {
    sector: input?.sector ?? input?.metadata?.sector ?? "Unknown",
    subIndustry: input?.subIndustry ?? input?.metadata?.subIndustry ?? "Unknown",
    beta: Number.isFinite(Number(input?.beta)) ? Number(input.beta) : 1,
    underlyingPrice: Number.isFinite(Number(input?.underlyingPrice))
      ? Number(input.underlyingPrice)
      : null,
  };
}
```

### Required correction
If your current code does:
```ts
sector: (intent as any).sector ?? null
```
replace it with:
```ts
const meta = normalizePositionMetadata(intent);

sector: meta.sector,
subIndustry: meta.subIndustry,
beta: meta.beta,
underlyingPrice: meta.underlyingPrice,
```

This directly fixes the huge `Unknown` sector bucket problem.

---

# 5) UPDATE `server/services/v8/portfolio-snapshots.ts`

Use the corrected services and mark whether analytics are approximated.

## Required behavior
When writing snapshot:
- call corrected `computePortfolioGreeks(...)`
- call corrected `computePortfolioStress(...)`
- include source transparency in payload or note field:
  - count how many positions used `greeksSource = "live"`
  - count how many used `greeksSource = "approx"`

### Add to snapshot payload if table cannot be altered:
```ts
analyticsSourceSummary: JSON.stringify({
  liveGreeksCount,
  approxGreeksCount,
})
```

### Or add columns if desired:
- `live_greeks_count`
- `approx_greeks_count`

This fixes the current false sense of precision.

---

# 6) UPDATE ROUTES + UI LABELING

## Routes
Any route returning portfolio analytics should clearly expose:
- whether values are live or approximated
- source counts

For example `/api/portfolio/greeks` should include:
```ts
{
  ...summary,
  analyticsSourceSummary: {
    liveGreeksCount: 2,
    approxGreeksCount: 5
  }
}
```

## UI
If any approximations are present, label the dashboard:
- `Portfolio Greeks (Estimated)`
or
- `Mixed Live / Estimated Greeks`

Do NOT present approximated analytics as if they are exact.

---

# 7) OPTIONAL METADATA HELPER FILE

If you do not already have a trusted metadata normalizer, create:

`server/services/v8/position-metadata.ts`

```ts
export function normalizeTickerMetadata(input: any) {
  return {
    sector: input?.sector ?? input?.metadata?.sector ?? "Unknown",
    subIndustry: input?.subIndustry ?? input?.metadata?.subIndustry ?? "Unknown",
    beta: Number.isFinite(Number(input?.beta)) ? Number(input.beta) : 1,
  };
}
```

Use this in:
- live-sync
- position creation
- any manual-import pipeline

---

# 8) WHAT THIS PATCH FIXES

## Fixed
1. Bull put spreads now produce POSITIVE net portfolio delta
2. Beta-weighted delta now uses:
   - netDelta
   - beta
   - underlyingPrice / spyPrice
3. Stress testing now moves smoothly at -1%, -2%, -3%
4. Sector exposure will stop collapsing into `Unknown` once metadata is filled properly
5. Max risk uses one trusted source of truth
6. Exit execution quality scoring is now directionally correct
7. Time-to-fill won’t be silently misreported
8. Dashboard can distinguish live vs approximated Greeks

## Also fixed implicitly
- top directional contributors now rank off corrected delta math
- top theta contributors now reflect normalized theta values

---

# 9) REPLIT VALIDATION CHECKLIST

After applying this patch, verify:

- [ ] Bull put spread portfolio shows positive net delta
- [ ] Beta-weighted delta is not just `delta * beta`
- [ ] Stress outputs decline smoothly across -1%, -2%, -3%
- [ ] Sector exposure no longer mostly shows `Unknown`
- [ ] Exit fill quality treats lower debit as better
- [ ] Time-to-fill is null only when truly unavailable
- [ ] API clearly shows live vs approximated Greeks
- [ ] Snapshot rows no longer show weird scaling jumps

---

# 10) FINAL NOTE

This patch repairs the analytics layer you reviewed.

It does NOT add:
- true option-chain live Greeks from every broker leg
- full Black-Scholes revaluation
- volatility surface modeling

But it does fix all real errors identified in the current code review and makes the analytics materially more trustworthy.

End of patch.
