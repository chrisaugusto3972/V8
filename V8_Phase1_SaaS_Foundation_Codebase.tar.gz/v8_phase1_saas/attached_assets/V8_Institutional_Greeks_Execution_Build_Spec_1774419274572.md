# V8 Institutional Upgrade Build Spec
## Portfolio Greeks Dashboard + Execution Alpha / Midpoint Hunting
### Single Build Spec for Replit

This document is the full build specification for adding the next two institutional-grade modules into V8:

1. Portfolio Greeks Dashboard
2. Execution Alpha / Midpoint Hunting

This spec is written to be handed directly to Replit for implementation.

It is intentionally thorough and includes:
- objectives
- architecture
- file plan
- data model changes
- service design
- API routes
- UI requirements
- autopilot integration
- fail-safe behavior
- acceptance criteria
- rollout order

This is a build spec, not a marketing summary.

---

# SECTION 1 — OBJECTIVE

## Goal
Upgrade V8 from a trade-by-trade options engine into a more institutional system by adding:

### A. Portfolio Greeks Dashboard
So V8 can understand and display:
- aggregate portfolio delta
- aggregate portfolio theta
- beta-weighted directional lean
- sector / ticker / bucket exposure
- simple stress-test outcomes

### B. Execution Alpha
So V8 can:
- seek better fills
- use adaptive limit prices
- reprice intelligently
- separate entry execution from exit execution
- measure fill quality over time
- feed execution quality back into autopilot controls

## What this upgrade is NOT
This build does NOT attempt to add:
- full options pricing library
- full volatility surface modeling
- Black-Scholes calibration engine
- full Kelly sizing
- high-frequency trading
- exchange-level smart routing

This build is meant to be:
- practical
- production-usable
- consistent with V8 architecture
- safe for staged rollout

---

# SECTION 2 — HIGH-LEVEL ARCHITECTURE

Add two new architecture pillars:

## Pillar 1 — Portfolio Risk Intelligence
New services:
- portfolio-greeks service
- portfolio stress-test service
- portfolio exposure summaries
- snapshot logger

## Pillar 2 — Execution Intelligence
New services:
- execution policy engine
- adaptive entry engine
- adaptive exit engine
- working-order monitor
- execution analytics engine

## Existing systems that must integrate with this build
- autopilot scan loop
- execution loop
- position loop
- live sync
- operator controls
- diagnostics / readiness
- selection engine
- deployment guard
- event guard
- regime controls

---

# SECTION 3 — FILE PLAN

Create or update the following files.

## New files
- `server/services/v8/portfolio-greeks.ts`
- `server/services/v8/portfolio-stress.ts`
- `server/services/v8/execution-policy.ts`
- `server/services/v8/execution-alpha.ts`
- `server/services/v8/execution-analytics.ts`
- `server/services/v8/portfolio-snapshots.ts`

## Updated files
- `shared/schema.ts`
- `server/routes.ts`
- `server/services/v8/autopilot-engine.ts`
- `server/services/v8/live-sync.ts`
- `server/brokers/tastytrade.ts`
- `client/src/pages/` or equivalent dashboard UI files
- any existing diagnostics endpoint if needed

## New migration
- `migrations/v8_portfolio_greeks_and_execution_alpha.sql`

---

# SECTION 4 — DATA MODEL CHANGES

## 4.1 Add fields to positions
Add these fields if they do not already exist, or ensure they can be updated safely.

### Greeks and underlying state
- `underlying_price` (numeric / real)
- `short_delta` (numeric / real)
- `long_delta` (numeric / real)
- `net_delta` (numeric / real)
- `short_theta` (numeric / real)
- `long_theta` (numeric / real)
- `net_theta` (numeric / real)
- `beta_weighted_delta` (numeric / real)

### Execution / mark state
- `entry_midpoint` (numeric / real)
- `entry_bid` (numeric / real)
- `entry_ask` (numeric / real)
- `exit_midpoint` (numeric / real)
- `exit_bid` (numeric / real)
- `exit_ask` (numeric / real)

These can be nullable.

## 4.2 Create a portfolio snapshots table
Create a new table, e.g. `portfolio_snapshots`.

Fields:
- `id`
- `created_at`
- `engine_version`
- `selection_version`
- `open_positions_count`
- `total_max_risk`
- `total_net_delta`
- `total_net_theta`
- `beta_weighted_delta`
- `high_beta_risk`
- `single_stock_risk`
- `etf_risk`
- `sector_exposure_json`
- `ticker_exposure_json`
- `stress_spy_down_1pct`
- `stress_spy_down_2pct`
- `stress_spy_down_3pct`
- `stress_vol_up_5`
- `stress_vol_up_10`

## 4.3 Create an execution analytics table
Create a new table, e.g. `execution_analytics`.

Fields:
- `id`
- `created_at`
- `broker_order_id`
- `position_id`
- `ticker`
- `side` (`entry` / `exit`)
- `intent_type` (`entry`, `profit_exit`, `defensive_exit`, `emergency_exit`)
- `bid_at_submit`
- `ask_at_submit`
- `midpoint_at_submit`
- `initial_limit`
- `final_fill_price`
- `best_possible_price_proxy`
- `worst_possible_price_proxy`
- `fill_quality_vs_midpoint`
- `fill_quality_vs_bid_ask`
- `time_to_fill_seconds`
- `reprice_count`
- `regime`
- `engine_version`
- `selection_version`

## 4.4 Optional but recommended additions to broker_orders
Add:
- `execution_policy`
- `initial_limit`
- `last_limit`
- `reprice_count`
- `intent_type`

These are very useful for execution-alpha auditability.

---

# SECTION 5 — MIGRATION REQUIREMENTS

Create:
`migrations/v8_portfolio_greeks_and_execution_alpha.sql`

Migration should:
1. add any new fields to `positions`
2. add any new fields to `broker_orders`
3. create `portfolio_snapshots`
4. create `execution_analytics`

Migration must be safe on existing data:
- nullable where practical
- no destructive changes

---

# SECTION 6 — PORTFOLIO GREEKS DASHBOARD BUILD

## 6.1 Create `server/services/v8/portfolio-greeks.ts`

This service should expose at minimum:

### `getOpenPositionsWithGreeks()`
Responsibilities:
- load all open positions
- enrich them with:
  - underlying price
  - short delta
  - long delta
  - net delta
  - short theta
  - long theta
  - net theta
  - beta-weighted delta
  - sector
  - sub-industry
  - risk
- if real leg Greeks are unavailable:
  - use broker data if present
  - otherwise use controlled approximations based on:
    - entry delta
    - current distance OTM
    - DTE
    - mark
    - beta
- return standardized objects

### `computePortfolioGreeks()`
Inputs:
- open positions with Greeks

Outputs:
- `totalNetDelta`
- `totalNetTheta`
- `betaWeightedDelta`
- `totalMaxRisk`
- `deltaBySector`
- `thetaBySector`
- `riskBySector`
- `riskByTicker`
- `highBetaRisk`
- `singleStockRisk`
- `etfRisk`
- top directional contributors
- top theta contributors

### Approximation rules
If exact live Greeks are not available:
- use conservative approximation
- never fabricate precision
- document approximated vs direct values

## 6.2 Create `server/services/v8/portfolio-stress.ts`

Expose:
### `computePortfolioStressTest()`

Inputs:
- current positions
- current portfolio Greeks
- current market snapshot

Outputs:
- estimated P/L if SPY drops 1%
- estimated P/L if SPY drops 2%
- estimated P/L if SPY drops 3%
- estimated P/L if vol rises by +5
- estimated P/L if vol rises by +10

This can be a practical approximation, not a perfect options model.

The stress model should be simple and robust:
- use beta-weighted delta for directional move estimate
- use theta as passive daily decay estimate
- use regime / VIX sensitivity multiplier for vol shock estimate

## 6.3 Create `server/services/v8/portfolio-snapshots.ts`

Expose:
### `capturePortfolioSnapshot()`

Responsibilities:
- compute portfolio Greeks
- compute portfolio stress
- write one row to `portfolio_snapshots`

Trigger snapshot on:
- successful scan loop end
- order fill
- position close
- manual flatten
- health loop heartbeat interval (optional every X minutes)

---

# SECTION 7 — PORTFOLIO GREEKS API ROUTES

Add to `server/routes.ts`:

## `/api/portfolio/greeks`
Returns:
- current aggregate delta
- theta
- beta-weighted delta
- exposure by sector / ticker
- top contributors

## `/api/portfolio/stress`
Returns:
- current stress scenario outputs

## `/api/portfolio/exposure`
Returns:
- open positions
- risk by sector
- risk by ticker
- high-beta vs ETF exposure

## `/api/portfolio/snapshots`
Optional but recommended:
- recent portfolio snapshots for trend charting

All routes must be JSON, stable, and safe for UI polling.

---

# SECTION 8 — PORTFOLIO GREEKS DASHBOARD UI

Build a cockpit-style section in the dashboard.

## 8.1 Top summary cards
Display:
- Net Delta
- Net Theta
- Beta-Weighted Delta
- Total Open Risk
- Open Positions Count

## 8.2 Exposure panels
Display:
- sector exposure bar chart
- ticker exposure table
- high-beta vs ETF exposure split

## 8.3 Stress-test cards
Display:
- SPY -1%
- SPY -2%
- SPY -3%
- Vol +5
- Vol +10

## 8.4 Position table enhancements
For each open position show:
- ticker
- strikes
- DTE
- current mark
- net delta
- net theta
- beta-weighted delta contribution
- max risk
- sector / sub-industry

## 8.5 Visual severity cues
Use visual flags when:
- net delta too directional
- beta-weighted delta too large
- one sector dominates
- stress loss breaches internal threshold

---

# SECTION 9 — AUTOPILOT INTEGRATION FOR PORTFOLIO GREEKS

This is mandatory. Without it, Greeks are just reporting.

Use portfolio risk intelligence to influence autopilot.

## 9.1 New autopilot checks
Before approving new trades, autopilot should check:
- portfolio beta-weighted delta too high?
- high-beta risk too concentrated?
- one sector too concentrated?
- stress-test loss exceeds threshold?

If yes:
- reduce max trades
- reject high-beta candidates
- switch to ETF-only mode
- or halt entries

## 9.2 Example governance rules
Examples:
- if `betaWeightedDelta > threshold`:
  - no additional bullish high-beta trades
- if `stress_spy_down_2pct < -allowed_limit`:
  - no new correlated positions
- if sector exposure > threshold:
  - reject same-sector candidates

These should integrate with:
- deployment guard
- selection engine
- regime controls

---

# SECTION 10 — EXECUTION ALPHA BUILD

## 10.1 Create `server/services/v8/execution-policy.ts`

This service defines how to price orders.

Expose:

### `getExecutionPolicy(params)`
Inputs:
- side (`entry` / `exit`)
- intent type (`entry`, `profit_exit`, `defensive_exit`, `emergency_exit`)
- bid
- ask
- midpoint
- slippage ratio
- liquidity score
- sector / symbol type
- regime
- DTE
- whether high-beta

Outputs:
- `initialLimit`
- `minAcceptableLimit`
- `maxWaitSeconds`
- `repriceIntervalSeconds`
- `maxReprices`
- `priceStep`
- `cancelInsteadOfChase`
- `policyName`

## 10.2 Define separate policies

### Entry policy
Goal:
- improve price, but not miss too many trades

Behavior:
- start at midpoint for tight liquid names
- start slightly below midpoint for wider names
- walk toward acceptable floor over time

### Profit exit policy
Goal:
- capture some price improvement, but still exit in reasonable time

Behavior:
- start near midpoint
- smaller repricing steps
- bounded wait

### Defensive exit policy
Goal:
- get out quickly, but not blindly

Behavior:
- more aggressive repricing
- shorter wait
- fewer reprices

### Emergency exit policy
Goal:
- certainty over improvement

Behavior:
- bypass midpoint hunting
- go straight to very executable limit
- minimal delay

---

# SECTION 11 — CREATE EXECUTION MANAGER

## 11.1 Create `server/services/v8/execution-alpha.ts`

Expose:

### `submitAdaptiveEntry(intent)`
Responsibilities:
- gather current quotes
- compute midpoint
- request policy
- submit initial order
- store execution metadata

### `submitAdaptiveExit(position, exitType)`
Responsibilities:
- gather quotes
- determine policy based on:
  - profit exit
  - defensive exit
  - emergency exit
- submit adaptive order
- store metadata

### `monitorWorkingOrders()`
Responsibilities:
- load working broker orders
- track elapsed time
- decide:
  - leave working
  - reprice
  - cancel/replace
  - abort

### `repriceOrderIfNeeded(order)`
Responsibilities:
- evaluate policy
- compare current market to initial market
- perform bounded reprice decision

---

# SECTION 12 — BROKER SUPPORT REQUIREMENTS

Update `server/brokers/tastytrade.ts` as needed.

Required broker methods:
- submit order
- get order
- cancel order
- list live orders
- replace order OR cancel-and-resubmit pattern

If true replace is not implemented cleanly:
- use cancel + submit replacement
- preserve linkage in internal records

Need to store:
- original broker order id
- replacement chain if applicable

---

# SECTION 13 — EXECUTION ANALYTICS

## 13.1 Create `server/services/v8/execution-analytics.ts`

Expose:

### `recordExecutionAttempt()`
Store:
- bid at submit
- ask at submit
- midpoint
- initial limit
- side
- policy
- regime
- intent type

### `recordExecutionFill()`
Store:
- final fill
- time to fill
- reprice count
- fill quality vs midpoint
- fill quality vs bid/ask

### `getExecutionQualitySummary()`
Return:
- avg fill vs midpoint
- avg fill vs natural
- avg time to fill
- avg reprices
- stats by ticker
- stats by engine
- stats by regime
- stats by entry vs exit

---

# SECTION 14 — EXECUTION API ROUTES

Add to `server/routes.ts`:

## `/api/execution/quality`
Returns:
- summary metrics
- rolling averages
- by-regime and by-engine stats

## `/api/execution/recent-orders`
Returns:
- recent order execution records
- policy used
- fill quality
- reprice count
- time to fill

## `/api/execution/stats`
Optional:
- aggregated historical metrics

---

# SECTION 15 — EXECUTION DASHBOARD UI

Add a new dashboard section.

## 15.1 Summary cards
Display:
- average fill vs midpoint
- average time to fill
- average reprices
- average entry improvement
- average exit improvement

## 15.2 Recent execution table
Show:
- ticker
- side
- policy
- midpoint
- initial limit
- fill
- time to fill
- reprices
- quality score

## 15.3 Regime / engine breakdown
Show:
- fill quality by regime
- fill quality by CORE vs BOOST
- fill quality by ticker

---

# SECTION 16 — AUTOPILOT INTEGRATION FOR EXECUTION ALPHA

Execution alpha must feed back into autopilot.

## 16.1 If fill quality degrades
Then autopilot should be able to:
- raise minimum credit %
- reduce max trades per day
- reject wider/sloppier names
- favor ETFs
- throttle high-beta participation

## 16.2 Example governance rules
- if rolling 10-trade execution quality vs midpoint is poor:
  - tighten participation
- if time-to-fill too high:
  - reduce aggressiveness in marginal candidates
- if exits are consistently worse than expected:
  - shorten defensive exit policy delay

This is how analytics becomes real governance.

---

# SECTION 17 — FAIL-SAFE RULES

These are mandatory.

## 17.1 Portfolio Greeks fail-safes
If Greeks data unavailable:
- do not block existing position management
- but mark dashboard values as estimated
- in LIVE mode, if risk analytics unavailable for too long:
  - reduce entries
  - optionally halt high-beta entries

## 17.2 Execution fail-safes
If quotes unavailable:
- do not midpoint-hunt
- either:
  - skip order
  - or use conservative executable limit depending on exit type

If an order has been repriced too many times:
- cancel or abandon
- do not chase indefinitely

If emergency exit:
- skip slow execution improvement logic

## 17.3 Data integrity
Never pretend you have exact Greeks if you only have approximations.
Label calculated values clearly in code and UI.

---

# SECTION 18 — VERSIONING AND AUDITABILITY

All new records should capture:
- `engineVersion`
- `selectionVersion`
- `executionPolicy`
- `intentType`

This must be applied to:
- broker_orders
- execution_analytics
- portfolio_snapshots
- system_events where relevant

This makes the build auditable and commercially credible.

---

# SECTION 19 — ACCEPTANCE CRITERIA

The build is complete only if all of these are true.

## Portfolio Greeks acceptance
- dashboard shows aggregate delta/theta
- dashboard shows sector/ticker exposure
- stress scenarios available via API
- snapshots are stored
- autopilot can consume the outputs for risk governance

## Execution alpha acceptance
- entry orders use policy-driven adaptive limits
- exit orders use policy-driven adaptive limits
- working orders can be repriced
- fill quality is stored and visible
- autopilot can react to degraded execution quality

## Safety acceptance
- emergency exits bypass slow midpoint-hunting behavior
- approximated data is labeled and handled safely
- build passes type check and build
- no existing autopilot lifecycle broken

---

# SECTION 20 — ROLLOUT ORDER

## Phase 1
- schema + migration
- portfolio-greeks service
- execution-policy service

## Phase 2
- portfolio APIs
- execution-alpha service
- execution analytics records

## Phase 3
- UI cockpit pages
- execution dashboard

## Phase 4
- autopilot integration
- governance rules
- fail-safe tightening

## Phase 5
- DRY_RUN validation
- PAPER validation
- tiny LIVE validation

---

# SECTION 21 — WHAT NOT TO DO

Do NOT:
- add full Kelly sizing here
- add complex AI prediction here
- add full volatility surface engine here
- add too many moving parts at once to execution logic
- let midpoint hunting interfere with emergency exits
- fabricate exact Greeks when only approximations are available

---

# SECTION 22 — FINAL BUILD INTENT

After this build, V8 should be able to answer:

## Portfolio intelligence
- How long-delta is the whole book?
- How much theta is the whole book harvesting?
- What happens if SPY drops 2% tomorrow?
- Am I overexposed to one sector or factor?

## Execution intelligence
- Am I getting good fills?
- Am I leaving money on the table?
- Should this order start at midpoint or closer to bid?
- Am I missing fills by being too passive?
- Are exits being handled appropriately for the situation?

That is what makes the system look and behave more institutional.

End of spec.
