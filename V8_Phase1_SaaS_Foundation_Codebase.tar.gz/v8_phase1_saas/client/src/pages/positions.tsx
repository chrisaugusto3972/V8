import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Plus, Trash2, XCircle, ShieldAlert, Briefcase, Download } from "lucide-react";
import type { Position } from "@shared/schema";

export default function PositionsPage() {
  const { toast } = useToast();
  const [showAddModal, setShowAddModal] = useState(false);
  const [closeModal, setCloseModal] = useState<{ position: Position; exitPrice: string } | null>(null);
  const [form, setForm] = useState({
    ticker: "",
    shortStrike: "",
    longStrike: "",
    credit: "",
    contracts: "1",
    expiration: "",
    notes: "",
  });

  const { data: positions, isLoading } = useQuery<Position[]>({
    queryKey: ["/api/positions"],
  });

  const { data: liveQuotes } = useQuery<Record<string, number>>({
    queryKey: ["/api/positions/quotes"],
    refetchInterval: 30000,
  });

  const addPosition = useMutation({
    mutationFn: async () => {
      const shortStrike = parseFloat(form.shortStrike);
      const longStrike = parseFloat(form.longStrike);
      const credit = parseFloat(form.credit);
      const maxRisk = ((shortStrike - longStrike) - credit) * 100 * parseInt(form.contracts);
      const res = await apiRequest("POST", "/api/positions", {
        ticker: form.ticker.toUpperCase(),
        shortStrike,
        longStrike,
        credit,
        contracts: parseInt(form.contracts),
        expiration: form.expiration,
        entryDate: new Date().toISOString().split("T")[0],
        maxRisk,
        notes: form.notes || null,
        status: "open",
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/positions"] });
      setShowAddModal(false);
      setForm({ ticker: "", shortStrike: "", longStrike: "", credit: "", contracts: "1", expiration: "", notes: "" });
      toast({ title: "Position added" });
    },
    onError: (err: Error) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const closePosition = useMutation({
    mutationFn: async ({ id, exitPrice }: { id: string; exitPrice: number }) => {
      const res = await apiRequest("POST", `/api/positions/${id}/close`, { exitPrice });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/positions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/journal"] });
      setCloseModal(null);
      toast({ title: "Position closed" });
    },
    onError: (err: Error) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const deletePosition = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/positions/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/positions"] });
      toast({ title: "Position deleted" });
    },
  });

  const openPositions = positions?.filter(p => p.status === "open") || [];

  const riskDollars = (p: Position) => {
    const width = p.shortStrike - p.longStrike;
    const perShare = width - p.credit;
    return Math.max(0, perShare) * 100 * p.contracts;
  };

  const totalRisk = openPositions.reduce((sum, p) => sum + riskDollars(p), 0);

  const daysHeld = (entryDate: string) => {
    return Math.floor((Date.now() - new Date(entryDate).getTime()) / (1000 * 60 * 60 * 24));
  };

  const exportPositionsCSV = () => {
    if (openPositions.length === 0) return;
    const headers = ["Ticker", "Short Strike", "Long Strike", "Width", "Credit", "Contracts", "Entry Date", "Expiration", "Max Risk", "Max Profit", "Days Held", "Notes"];
    const rows = openPositions.map(p => [
      p.ticker, p.shortStrike, p.longStrike, (p.shortStrike - p.longStrike).toFixed(0), p.credit.toFixed(2), p.contracts, p.entryDate, p.expiration, riskDollars(p).toFixed(2), (p.credit * 100 * p.contracts).toFixed(2), daysHeld(p.entryDate), `"${(p.notes || "").replace(/"/g, '""')}"`
    ]);
    const csv = [headers, ...rows].map(r => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `positions-${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Card className="glass-panel p-6">
          <Skeleton className="h-8 w-48 mb-6" />
          <div className="space-y-4">
            {[1, 2, 3].map(i => <Skeleton key={i} className="h-32 w-full" />)}
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="glass-panel p-6">
        <div className="flex flex-wrap justify-between items-center gap-4 mb-6">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-chart-1" />
            Active Positions
          </h2>
          <div className="flex gap-2">
            <Button variant="outline" onClick={exportPositionsCSV} disabled={openPositions.length === 0} data-testid="button-export-positions-csv">
              <Download className="w-4 h-4" />
              Export CSV
            </Button>
            <Button variant="outline" onClick={() => setShowAddModal(true)} data-testid="button-add-position">
              <Plus className="w-4 h-4" />
              Add Position
            </Button>
          </div>
        </div>

        {openPositions.length === 0 ? (
          <div className="text-center py-12">
            <Briefcase className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-lg text-muted-foreground mb-1">No active positions</p>
            <p className="text-sm text-muted-foreground">Click "Add Position" to track a trade or add from scanner results</p>
          </div>
        ) : (
          <div className="space-y-4">
            {openPositions.map(pos => {
              const held = daysHeld(pos.entryDate);
              const maxProfit = pos.credit * 100 * pos.contracts;
              const target50 = pos.credit * 0.5 * 100 * pos.contracts;
              const maxRiskVal = riskDollars(pos);
              const livePrice = liveQuotes?.[pos.ticker] ?? 0;
              const distanceFromShort = livePrice > 0 ? ((livePrice - pos.shortStrike) / livePrice * 100) : 0;

              return (
                <Card key={pos.id} className="p-5 bg-card border-border" data-testid={`card-position-${pos.id}`}>
                  <div className="flex flex-wrap justify-between items-start gap-4 mb-3">
                    <div>
                      <div className="flex flex-wrap items-center gap-2 mb-2">
                        <Badge className="bg-gradient-to-r from-chart-2 to-chart-3 text-white border-0 font-bold px-4">
                          {pos.ticker}
                        </Badge>
                        <span className="text-xs text-muted-foreground">{pos.contracts}x</span>
                        {livePrice > 0 && (
                          <span className="text-sm font-mono font-semibold text-white" data-testid={`price-${pos.id}`}>
                            ${livePrice.toFixed(2)}
                          </span>
                        )}
                        {livePrice > 0 && (
                          <Badge variant="outline" className={`text-[10px] font-mono ${distanceFromShort > 10 ? "text-emerald-400 border-emerald-500/30" : distanceFromShort > 5 ? "text-cyan-400 border-cyan-500/30" : "text-amber-400 border-amber-500/30"}`} data-testid={`distance-${pos.id}`}>
                            {distanceFromShort.toFixed(1)}% OTM
                          </Badge>
                        )}
                      </div>
                      <h3 className="text-xl font-bold">
                        ${pos.shortStrike} / ${pos.longStrike} Put Spread
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        Exp: {pos.expiration} &middot; <span className={`font-mono font-semibold ${Math.max(0, Math.ceil((new Date(pos.expiration).getTime() - Date.now()) / 86400000)) <= 3 ? "text-red-400" : Math.max(0, Math.ceil((new Date(pos.expiration).getTime() - Date.now()) / 86400000)) <= 7 ? "text-amber-400" : "text-cyan-400"}`} data-testid={`dte-${pos.id}`}>{Math.max(0, Math.ceil((new Date(pos.expiration).getTime() - Date.now()) / 86400000))} DTE</span> &middot; Held {held} days
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground">Entry Credit</p>
                      <p className="text-2xl font-bold font-mono text-profit">${pos.credit.toFixed(2)}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-3 mb-3">
                    <Card className="p-3 bg-accent/30 border-border text-center">
                      <p className="text-xs text-muted-foreground">Max Profit</p>
                      <p className="text-lg font-bold font-mono text-profit">${maxProfit.toFixed(0)}</p>
                    </Card>
                    <Card className="p-3 bg-accent/30 border-border text-center">
                      <p className="text-xs text-muted-foreground">50% Target</p>
                      <p className="text-lg font-bold font-mono text-profit-alt">${target50.toFixed(0)}</p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">close @ <span className="text-cyan-400 font-semibold" data-testid={`exit-mark-${pos.id}`}>${(pos.credit * 0.5).toFixed(2)}</span></p>
                    </Card>
                    <Card className="p-3 bg-accent/30 border-border text-center">
                      <p className="text-xs text-muted-foreground">Max Risk</p>
                      <p className="text-lg font-bold font-mono text-destructive">${maxRiskVal.toFixed(0)}</p>
                    </Card>
                    <Card className="p-3 bg-accent/30 border-border text-center" data-testid={`card-breakeven-${pos.id}`}>
                      <p className="text-xs text-muted-foreground">50% Exit Strike</p>
                      <p className="text-lg font-bold font-mono text-cyan-400">${(pos.shortStrike - pos.credit * 0.5).toFixed(2)}</p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">short @ ${pos.shortStrike}</p>
                    </Card>
                  </div>

                  {pos.notes && (
                    <p className="text-xs text-muted-foreground mb-3">{pos.notes}</p>
                  )}

                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      className="flex-1"
                      onClick={() => setCloseModal({ position: pos, exitPrice: (pos.credit * 0.5).toFixed(2) })}
                      data-testid={`button-close-${pos.id}`}
                    >
                      <XCircle className="w-4 h-4" />
                      Close Position
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => deletePosition.mutate(pos.id)}
                      data-testid={`button-delete-${pos.id}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </Card>

      {openPositions.length > 0 && (
        <Card className="glass-panel p-6">
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-chart-1" />
            Portfolio Summary
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="p-4 bg-accent/30 border-border">
              <p className="text-xs text-muted-foreground mb-1">ACTIVE POSITIONS</p>
              <p className="text-2xl font-bold font-mono text-chart-1" data-testid="text-active-count">{openPositions.length}</p>
            </Card>
            <Card className="p-4 bg-accent/30 border-border">
              <p className="text-xs text-muted-foreground mb-1">TOTAL AT RISK</p>
              <p className="text-2xl font-bold font-mono text-destructive" data-testid="text-total-risk">${totalRisk.toFixed(0)}</p>
            </Card>
            <Card className="p-4 bg-accent/30 border-border">
              <p className="text-xs text-muted-foreground mb-1">MAX PROFIT POTENTIAL</p>
              <p className="text-2xl font-bold font-mono text-profit">
                ${openPositions.reduce((s, p) => s + p.credit * 100 * p.contracts, 0).toFixed(0)}
              </p>
            </Card>
            <Card className="p-4 bg-accent/30 border-border">
              <p className="text-xs text-muted-foreground mb-1">AVG CREDIT</p>
              <p className="text-2xl font-bold font-mono text-chart-2">
                ${(openPositions.reduce((s, p) => s + p.credit, 0) / openPositions.length).toFixed(2)}
              </p>
            </Card>
          </div>
        </Card>
      )}

      <Dialog open={showAddModal} onOpenChange={setShowAddModal}>
        <DialogContent className="bg-card border-border max-w-md">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">Add Position</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-xs text-muted-foreground mb-1 block">Ticker</Label>
              <Input placeholder="SPY" value={form.ticker} onChange={e => setForm(f => ({ ...f, ticker: e.target.value }))} className="font-mono" data-testid="input-modal-ticker" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs text-muted-foreground mb-1 block">Short Strike</Label>
                <Input type="number" step="0.50" value={form.shortStrike} onChange={e => setForm(f => ({ ...f, shortStrike: e.target.value }))} className="font-mono" data-testid="input-modal-short" />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground mb-1 block">Long Strike</Label>
                <Input type="number" step="0.50" value={form.longStrike} onChange={e => setForm(f => ({ ...f, longStrike: e.target.value }))} className="font-mono" data-testid="input-modal-long" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs text-muted-foreground mb-1 block">Entry Credit</Label>
                <Input type="number" step="0.01" value={form.credit} onChange={e => setForm(f => ({ ...f, credit: e.target.value }))} className="font-mono" data-testid="input-modal-credit" />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground mb-1 block">Contracts</Label>
                <Input type="number" min="1" value={form.contracts} onChange={e => setForm(f => ({ ...f, contracts: e.target.value }))} className="font-mono" data-testid="input-modal-contracts" />
              </div>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground mb-1 block">Expiration Date</Label>
              <Input type="date" value={form.expiration} onChange={e => setForm(f => ({ ...f, expiration: e.target.value }))} className="font-mono" data-testid="input-modal-expiration" />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground mb-1 block">Notes (optional)</Label>
              <Textarea placeholder="Trade thesis, entry reason..." value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} data-testid="input-modal-notes" />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowAddModal(false)} data-testid="button-cancel-add">Cancel</Button>
            <Button
              onClick={() => addPosition.mutate()}
              disabled={!form.ticker || !form.shortStrike || !form.longStrike || !form.credit || addPosition.isPending}
              data-testid="button-save-position"
            >
              <Plus className="w-4 h-4" />
              Add Position
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!closeModal} onOpenChange={() => setCloseModal(null)}>
        <DialogContent className="bg-card border-border max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">Close Position</DialogTitle>
          </DialogHeader>
          {closeModal && (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                {closeModal.position.ticker} ${closeModal.position.shortStrike} / ${closeModal.position.longStrike}
              </p>
              <div>
                <Label className="text-xs text-muted-foreground mb-1 block">Exit Price of Spread</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={closeModal.exitPrice}
                  onChange={e => setCloseModal(prev => prev ? { ...prev, exitPrice: e.target.value } : null)}
                  className="font-mono"
                  data-testid="input-exit-price"
                />
              </div>
              {closeModal.exitPrice && (() => {
                const plValue = (closeModal.position.credit - parseFloat(closeModal.exitPrice)) * 100 * closeModal.position.contracts;
                const isProfit = plValue >= 0;
                return (
                  <Card className="p-3 bg-accent/30 border-border">
                    <p className="text-xs text-muted-foreground mb-1">Estimated P&L</p>
                    <p className={`text-xl font-bold font-mono ${isProfit ? "text-profit" : "text-loss"}`}>
                      {isProfit ? "+" : ""}${plValue.toFixed(2)}
                    </p>
                  </Card>
                );
              })()}
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setCloseModal(null)}>Cancel</Button>
            <Button
              onClick={() => closeModal && closePosition.mutate({ id: closeModal.position.id, exitPrice: parseFloat(closeModal.exitPrice) })}
              disabled={!closeModal?.exitPrice || closePosition.isPending}
              data-testid="button-confirm-close"
            >
              Close Position
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
