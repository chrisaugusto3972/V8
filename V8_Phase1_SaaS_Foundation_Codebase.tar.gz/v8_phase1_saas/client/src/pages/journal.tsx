import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { BookOpen, Download } from "lucide-react";
import type { JournalEntry } from "@shared/schema";

export default function JournalPage() {
  const { data: entries, isLoading } = useQuery<JournalEntry[]>({
    queryKey: ["/api/journal"],
  });

  const journalEntries = entries || [];
  const totalTrades = journalEntries.length;
  const winners = journalEntries.filter(e => e.pl > 0).length;
  const losers = journalEntries.filter(e => e.pl < 0).length;
  const winRate = totalTrades > 0 ? (winners / totalTrades * 100) : 0;
  const netPL = journalEntries.reduce((sum, e) => sum + e.pl, 0);

  const exportCSV = () => {
    if (journalEntries.length === 0) return;
    const headers = ["Ticker", "Short Strike", "Long Strike", "Credit", "Contracts", "Entry Date", "Exit Date", "Exit Price", "P&L", "P&L %"];
    const rows = journalEntries.map(e => [
      e.ticker, e.shortStrike, e.longStrike, e.credit, e.contracts, e.entryDate, e.exitDate, e.exitPrice, e.pl.toFixed(2), e.plPercent.toFixed(1)
    ]);
    const csv = [headers, ...rows].map(r => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "trade-journal.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  if (isLoading) {
    return (
      <Card className="glass-panel p-6">
        <Skeleton className="h-8 w-48 mb-6" />
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
          {[1, 2, 3, 4, 5].map(i => <Skeleton key={i} className="h-20" />)}
        </div>
        <div className="space-y-3">
          {[1, 2, 3].map(i => <Skeleton key={i} className="h-24" />)}
        </div>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="glass-panel p-6">
        <div className="flex flex-wrap justify-between items-center gap-4 mb-6">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-chart-1" />
            Trade Journal
          </h2>
          <Button variant="outline" onClick={exportCSV} disabled={journalEntries.length === 0} data-testid="button-export-csv">
            <Download className="w-4 h-4" />
            Export CSV
          </Button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
          <Card className="p-4 bg-accent/30 border-border">
            <p className="text-xs text-muted-foreground mb-1">TOTAL TRADES</p>
            <p className="text-2xl font-bold font-mono" data-testid="text-journal-total">{totalTrades}</p>
          </Card>
          <Card className="p-4 bg-accent/30 border-border">
            <p className="text-xs text-muted-foreground mb-1">WINNERS</p>
            <p className="text-2xl font-bold font-mono text-profit" data-testid="text-journal-wins">{winners}</p>
          </Card>
          <Card className="p-4 bg-accent/30 border-border">
            <p className="text-xs text-muted-foreground mb-1">LOSERS</p>
            <p className="text-2xl font-bold font-mono text-destructive" data-testid="text-journal-losses">{losers}</p>
          </Card>
          <Card className="p-4 bg-accent/30 border-border">
            <p className="text-xs text-muted-foreground mb-1">WIN RATE</p>
            <p className="text-2xl font-bold font-mono text-chart-1" data-testid="text-journal-winrate">{winRate.toFixed(0)}%</p>
          </Card>
          <Card className="p-4 bg-accent/30 border-border">
            <p className="text-xs text-muted-foreground mb-1">NET P&L</p>
            <p className={`text-2xl font-bold font-mono ${netPL >= 0 ? "text-profit" : "text-loss"}`} data-testid="text-journal-netpl">
              ${netPL.toFixed(2)}
            </p>
          </Card>
        </div>

        {journalEntries.length === 0 ? (
          <div className="text-center py-12">
            <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-lg text-muted-foreground mb-1">No trade history</p>
            <p className="text-sm text-muted-foreground">Closed trades will appear here automatically</p>
          </div>
        ) : (
          <div className="space-y-3">
            {[...journalEntries].reverse().map(entry => {
              const isProfitable = entry.pl >= 0;
              const daysHeld = Math.floor((new Date(entry.exitDate).getTime() - new Date(entry.entryDate).getTime()) / (1000 * 60 * 60 * 24));

              return (
                <Card
                  key={entry.id}
                  className="p-4 bg-card"
                  data-testid={`card-journal-${entry.id}`}
                >
                  <div className="flex flex-wrap justify-between items-start gap-4">
                    <div>
                      <div className="flex flex-wrap items-center gap-2 mb-2">
                        <Badge className="bg-gradient-to-r from-chart-2 to-chart-3 text-white border-0 font-bold px-4">
                          {entry.ticker}
                        </Badge>
                        <Badge variant={isProfitable ? "default" : "destructive"} className="text-xs">
                          {isProfitable ? "WIN" : "LOSS"}
                        </Badge>
                        <span className="text-xs text-muted-foreground">{entry.contracts}x</span>
                        <span className="text-xs text-muted-foreground">{daysHeld}d</span>
                      </div>
                      <h3 className="text-base font-bold">
                        ${entry.shortStrike} / ${entry.longStrike}
                      </h3>
                      <p className="text-xs text-muted-foreground">
                        Entry: {entry.entryDate} &middot; Closed: {new Date(entry.exitDate).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className={`text-2xl font-bold font-mono ${isProfitable ? "text-profit" : "text-loss"}`}>
                        {entry.pl >= 0 ? "+" : ""}${entry.pl.toFixed(2)}
                      </p>
                      <p className="text-sm text-muted-foreground">{entry.plPercent.toFixed(1)}%</p>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </Card>
    </div>
  );
}
