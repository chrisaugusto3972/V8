import { useState, useCallback, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Loader2, Search, RefreshCw, Plus, Target, BarChart3, ShieldAlert, AlertTriangle, CheckCircle, Download } from "lucide-react";
import type { ScannerSettings } from "@shared/schema";

interface ScanPick {
  ticker: string;
  sector: string;
  price: number;
  expiration: string;
  dte: number | null;

  spreadType: string;
  shortPut: number;
  longPut: number;
  width: number;

  shortBid: number;
  longAsk: number;

  credit: number;
  creditPctWidth: number;
  distancePct: number;
  shortDeltaAbs: number;

  maxLoss: number;
  rorPct: number;

  contracts: number;
  tradeRisk: number;

  optimisticCredit: number;
  conservativeCredit: number;
  slippageRatio: number;

  confidence: number;

  // V7 engine label (CORE / BOOST). Present when mode=v7.
  engine?: string;
}

interface ScanResponse {
  ok: boolean;
  mode: string;
  defaultsUsed: any;
  deployedRisk: number;
  maxPortfolioRisk: number;
  reject: Record<string, number>;
  picks: ScanPick[];
  error?: string;
}

const TICKER_SECTOR: Record<string, string> = {
  AAPL: "Technology", MSFT: "Technology", NVDA: "Technology", AMD: "Technology", INTC: "Technology",
  ORCL: "Technology", CRM: "Technology",
  GOOGL: "Communication", META: "Communication", NFLX: "Communication", DIS: "Communication",
  AMZN: "Consumer Discretionary", TSLA: "Consumer Discretionary", MCD: "Consumer Discretionary",
  WMT: "Consumer Staples", KO: "Consumer Staples", PG: "Consumer Staples", COST: "Consumer Staples", PEP: "Consumer Staples",
  JPM: "Financials", BAC: "Financials", GS: "Financials",
  XOM: "Energy", CVX: "Energy",
  UNH: "Healthcare", JNJ: "Healthcare",
  SPY: "ETF", QQQ: "ETF", IWM: "ETF", DIA: "ETF", TLT: "ETF", GLD: "ETF", SLV: "ETF",
  XLE: "ETF", XLF: "ETF", SMH: "ETF", EEM: "ETF", EWZ: "ETF",
  COIN: "Technology", PLTR: "Technology",
};

export default function ScannerPage() {
  const { toast } = useToast();
  const [isScanning, setIsScanning] = useState(false);
  const [scanResults, setScanResults] = useState<ScanPick[]>([]);
  const [hasScanned, setHasScanned] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [loadingStatus, setLoadingStatus] = useState("");
  const [scanMeta, setScanMeta] = useState<{ deployedRisk: number; maxPortfolioRisk: number; reject: Record<string, number>; mode: string } | null>(null);

  const { data: settings } = useQuery<ScannerSettings>({
    queryKey: ["/api/settings"],
  });

  const [localSettings, setLocalSettings] = useState({
    tickers: "SPY,QQQ,IWM,DIA,EEM,EWZ,XLE,XLF,SMH,TLT,GLD,SLV,AAPL,MSFT,GOOGL,AMZN,META,TSLA,NVDA,JPM,BAC,WMT,DIS,NFLX,AMD,CRM,ORCL,INTC,COIN,PLTR,KO,PG,JNJ,PEP,MCD,XOM,CVX,GS,UNH,COST",
    dteRange: "14-45",
    deltaRange: "0.15-0.25",
    accountSize: "micro",
    accountValue: "3000",
    riskPerTradePct: "4",
    maxPortfolioRiskPct: "12",
    minCreditPct: "12",
    minDistancePct: "7",
    minOI: "25",
    maxSpread: "0.75",
    maxSlippageRatio: "1.5",
    maxResults: "12",
    topNPerSector: "2",
  });

  useEffect(() => {
    if (settings) {
      setLocalSettings(prev => ({
        ...prev,
        tickers: settings.tickers,
        dteRange: settings.dteRange,
        deltaRange: settings.deltaRange,
        accountSize: settings.accountSize,
        minCreditPct: String(settings.minCreditPct),
        minDistancePct: String(settings.minDistancePct),
        minOI: String(settings.minOI),
        maxSpread: String(settings.maxSpread),
        maxSlippageRatio: String(settings.maxSlippageRatio),
      }));
    }
  }, [settings]);

  const updateSetting = (key: string, value: string | boolean) => {
    setLocalSettings(prev => ({ ...prev, [key]: value }));
  };

  const runScan = useCallback(async () => {
    setIsScanning(true);
    setHasScanned(false);
    setScanResults([]);
    setScanMeta(null);
    setLoadingStatus("Initializing scanner...");

    try {
      const tickerStrings = localSettings.tickers.split(",").map(t => t.trim().toUpperCase()).filter(Boolean);
      const tickers = tickerStrings.map(t => ({ ticker: t, sector: TICKER_SECTOR[t] || "Other" }));
      setLoadingStatus(`Scanning ${tickers.length} ticker(s)...`);

      const [minDTE, maxDTE] = localSettings.dteRange.split("-").map(Number);
      const [deltaMin, deltaMax] = localSettings.deltaRange.split("-").map(Number);

      // Default micro accounts to V7 hybrid mode.
      const modeMap: Record<string, string> = { micro: "v7", small: "standard", standard: "standard", all: "micro" };
      const mode = modeMap[localSettings.accountSize] || "micro";

      const widthsMap: Record<string, number[]> = {
        micro: [1, 2],
        small: [3, 5],
        standard: [5, 10],
        all: [1, 2, 3, 5],
      };

      const res = await apiRequest("POST", "/api/scan", {
        tickers,
        mode,
        accountSize: parseFloat(localSettings.accountValue),
        riskPerTradePct: parseFloat(localSettings.riskPerTradePct) / 100,
        maxPortfolioRiskPct: parseFloat(localSettings.maxPortfolioRiskPct) / 100,
        topNPerSector: parseInt(localSettings.topNPerSector),
        maxTradesTotal: parseInt(localSettings.maxResults),
        minDTE,
        maxDTE,
        deltaMin,
        deltaMax,
        microWidths: widthsMap[localSettings.accountSize] || [1, 2],
        minCreditPctWidth: parseFloat(localSettings.minCreditPct) / 100,
        minDistancePct: parseFloat(localSettings.minDistancePct) / 100,
        minOI: parseInt(localSettings.minOI),
        maxLegBidAskAbs: parseFloat(localSettings.maxSpread),
        maxSlippageRatio: parseFloat(localSettings.maxSlippageRatio),
      });

      const data: ScanResponse = await res.json();

      if (!data.ok) {
        throw new Error(data.error || "Scan failed");
      }

      setScanResults(data.picks || []);
      setScanMeta({
        deployedRisk: data.deployedRisk,
        maxPortfolioRisk: data.maxPortfolioRisk,
        reject: data.reject,
        mode: data.mode,
      });
      setHasScanned(true);
    } catch (err: any) {
      toast({ title: "Scan failed", description: err.message, variant: "destructive" });
    } finally {
      setIsScanning(false);
    }
  }, [localSettings, toast]);

  const addToPositions = useMutation({
    mutationFn: async (result: ScanPick) => {
      // IMPORTANT: store maxRisk consistently as *per-share* risk (width - credit),
      // not total $ risk. The Positions page multiplies by 100 * contracts.
      // (Previously we stored tradeRisk in dollars, which then got multiplied again.)
      const maxRiskPerShare = (result.width - result.credit);
      const res = await apiRequest("POST", "/api/positions", {
        ticker: result.ticker,
        shortStrike: result.shortPut,
        longStrike: result.longPut,
        credit: result.credit,
        contracts: result.contracts,
        expiration: result.expiration,
        entryDate: new Date().toISOString().split("T")[0],
        maxRisk: maxRiskPerShare,
        notes: `Scanner add. ${result.width}w, ${result.creditPctWidth.toFixed(1)}% credit/width, ${result.distancePct.toFixed(1)}% OTM. Est $risk=${(maxRiskPerShare * 100 * result.contracts).toFixed(0)}. Slippage x${result.slippageRatio.toFixed(2)}.`,
        status: "open",
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/positions"] });
      toast({ title: "Position added", description: "Trade added to your positions" });
    },
    onError: (err: Error) => {
      toast({ title: "Failed to add position", description: err.message, variant: "destructive" });
    },
  });

  const exportScanCSV = () => {
    if (scanResults.length === 0) return;
    const headers = ["Ticker", "Sector", "Price", "Expiration", "DTE", "Engine", "Short Put", "Long Put", "Width", "Short Bid", "Long Ask", "Credit", "Credit % Width", "Distance % OTM", "Delta", "Confidence", "Max Loss", "ROR %", "Contracts", "Trade Risk", "Optimistic Credit", "Conservative Credit", "Slippage Ratio"];
    const rows = scanResults.map(r => [
      r.ticker, r.sector, r.price.toFixed(2), r.expiration, r.dte ?? "", (r.engine || ""), r.shortPut, r.longPut, r.width, r.shortBid.toFixed(2), r.longAsk.toFixed(2), r.credit.toFixed(2), r.creditPctWidth.toFixed(1), r.distancePct.toFixed(1), r.shortDeltaAbs.toFixed(3), r.confidence, r.maxLoss.toFixed(2), r.rorPct.toFixed(1), r.contracts, r.tradeRisk.toFixed(2), r.optimisticCredit.toFixed(2), r.conservativeCredit.toFixed(2), r.slippageRatio.toFixed(2)
    ]);
    const csv = [headers, ...rows].map(r => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `scan-results-${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <Card className="glass-panel p-6">
        <div className="flex flex-wrap justify-between items-center gap-4 mb-6">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <span className="pulse-dot" />
            Scanner Configuration
          </h2>
          <div className="flex gap-2 flex-wrap items-center">
            <Badge variant="outline" className="text-xs font-mono gap-1" data-testid="badge-api-status">
              <span className="pulse-dot" />
              API Connected
            </Badge>
            <Button
              variant={autoRefresh ? "default" : "outline"}
              onClick={() => setAutoRefresh(!autoRefresh)}
              data-testid="button-auto-refresh"
            >
              <RefreshCw className={`w-4 h-4 ${autoRefresh ? "animate-spin" : ""}`} />
              Auto-Refresh: {autoRefresh ? "ON" : "OFF"}
            </Button>
          </div>
        </div>

        <Card className="p-4 mb-6 bg-chart-4/5 border-chart-4/30">
          <p className="text-xs font-semibold text-chart-4 mb-2">MICRO-FIRST SCANNER:</p>
          <ul className="text-xs text-muted-foreground space-y-1">
            <li className="flex items-center gap-2"><CheckCircle className="w-3 h-3 text-profit shrink-0" /> Conservative pricing: Uses BID for short, ASK for long (realistic fills)</li>
            <li className="flex items-center gap-2"><CheckCircle className="w-3 h-3 text-profit shrink-0" /> Quality gates: Minimum credit-to-width ratio, OTM distance required</li>
            <li className="flex items-center gap-2"><CheckCircle className="w-3 h-3 text-profit shrink-0" /> Slippage detector: Rejects if optimistic/conservative ratio exceeds limit</li>
            <li className="flex items-center gap-2"><CheckCircle className="w-3 h-3 text-profit shrink-0" /> Open interest checks: Both legs verified for liquidity</li>
            <li className="flex items-center gap-2"><CheckCircle className="w-3 h-3 text-profit shrink-0" /> Bid-ask spread validation on both legs</li>
            <li className="flex items-center gap-2"><CheckCircle className="w-3 h-3 text-profit shrink-0" /> Sector diversification and portfolio risk caps</li>
          </ul>
        </Card>

        <div className="mb-4">
          <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">Tickers (comma-separated)</Label>
          <Textarea
            placeholder="SPY, QQQ, IWM, DIA, AAPL, MSFT..."
            value={localSettings.tickers}
            onChange={e => updateSetting("tickers", e.target.value)}
            className="font-mono text-xs resize-none"
            rows={3}
            data-testid="input-tickers"
          />
          <p className="text-xs text-muted-foreground/60 mt-1">{localSettings.tickers.split(",").filter(t => t.trim()).length} tickers loaded</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
          <div>
            <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">Account Size</Label>
            <Select value={localSettings.accountSize} onValueChange={v => updateSetting("accountSize", v)}>
              <SelectTrigger data-testid="select-account-size">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="micro">Micro ($1-2 spreads)</SelectItem>
                <SelectItem value="small">Small ($3-5 spreads)</SelectItem>
                <SelectItem value="standard">Standard ($5-10 spreads)</SelectItem>
                <SelectItem value="all">All Sizes</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">Days to Expiration</Label>
            <Select value={localSettings.dteRange} onValueChange={v => updateSetting("dteRange", v)}>
              <SelectTrigger data-testid="select-dte">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="14-45">14-45 days (Default)</SelectItem>
                <SelectItem value="30-45">30-45 days</SelectItem>
                <SelectItem value="21-35">21-35 days</SelectItem>
                <SelectItem value="45-60">45-60 days</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">Delta Target</Label>
            <Select value={localSettings.deltaRange} onValueChange={v => updateSetting("deltaRange", v)}>
              <SelectTrigger data-testid="select-delta">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="0.10-0.16">0.10-0.16 (85%+ Win)</SelectItem>
                <SelectItem value="0.15-0.25">0.15-0.25 (Default)</SelectItem>
                <SelectItem value="0.16-0.25">0.16-0.25 (75-80% Win)</SelectItem>
                <SelectItem value="0.18-0.25">0.18-0.25 (Micro Optimal)</SelectItem>
                <SelectItem value="0.25-0.35">0.25-0.35 (65-70% Win)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">Max Results</Label>
            <Select value={localSettings.maxResults} onValueChange={v => updateSetting("maxResults", v)}>
              <SelectTrigger data-testid="select-max-results">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="6">Top 6</SelectItem>
                <SelectItem value="12">Top 12</SelectItem>
                <SelectItem value="20">Top 20</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="border-t border-border pt-4 mt-4">
          <h3 className="text-base font-bold mb-4 text-muted-foreground">Quality Gates</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <div>
              <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Min Credit % of Width</Label>
              <Input type="number" min="5" max="50" value={localSettings.minCreditPct} onChange={e => updateSetting("minCreditPct", e.target.value)} className="font-mono" data-testid="input-min-credit-pct" />
              <p className="text-xs text-muted-foreground/60 mt-1">Must collect this % of spread width</p>
            </div>
            <div>
              <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Min Distance OTM (%)</Label>
              <Input type="number" min="1" max="20" value={localSettings.minDistancePct} onChange={e => updateSetting("minDistancePct", e.target.value)} className="font-mono" data-testid="input-min-distance" />
              <p className="text-xs text-muted-foreground/60 mt-1">Short strike must be this % OTM</p>
            </div>
            <div>
              <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Min Open Interest</Label>
              <Input type="number" min="10" value={localSettings.minOI} onChange={e => updateSetting("minOI", e.target.value)} className="font-mono" data-testid="input-min-oi" />
              <p className="text-xs text-muted-foreground/60 mt-1">Both legs checked for liquidity</p>
            </div>
            <div>
              <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Max Leg Bid-Ask ($)</Label>
              <Input type="number" step="0.05" min="0.05" value={localSettings.maxSpread} onChange={e => updateSetting("maxSpread", e.target.value)} className="font-mono" data-testid="input-max-spread" />
              <p className="text-xs text-muted-foreground/60 mt-1">Both legs must have tight spreads</p>
            </div>
            <div>
              <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Max Slippage Ratio</Label>
              <Input type="number" step="0.1" min="1.1" max="2.0" value={localSettings.maxSlippageRatio} onChange={e => updateSetting("maxSlippageRatio", e.target.value)} className="font-mono" data-testid="input-max-slippage" />
              <p className="text-xs text-muted-foreground/60 mt-1">Optimistic/Conservative limit</p>
            </div>
          </div>
        </div>

        <div className="border-t border-border pt-4 mt-4">
          <h3 className="text-base font-bold mb-4 text-muted-foreground">Risk Controls</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Account Value ($)</Label>
              <Input type="number" min="500" step="100" value={localSettings.accountValue} onChange={e => updateSetting("accountValue", e.target.value)} className="font-mono" data-testid="input-account-value" />
              <p className="text-xs text-muted-foreground/60 mt-1">Used for contract sizing</p>
            </div>
            <div>
              <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Risk / Trade (%)</Label>
              <Input type="number" min="0.5" max="10" step="0.5" value={localSettings.riskPerTradePct} onChange={e => updateSetting("riskPerTradePct", e.target.value)} className="font-mono" data-testid="input-risk-per-trade" />
              <p className="text-xs text-muted-foreground/60 mt-1">2% is typical</p>
            </div>
            <div>
              <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Max Portfolio Risk (%)</Label>
              <Input type="number" min="5" max="50" step="1" value={localSettings.maxPortfolioRiskPct} onChange={e => updateSetting("maxPortfolioRiskPct", e.target.value)} className="font-mono" data-testid="input-max-portfolio-risk" />
              <p className="text-xs text-muted-foreground/60 mt-1">Caps total deployed risk</p>
            </div>
            <div>
              <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Top N / Sector</Label>
              <Input type="number" min="1" max="10" step="1" value={localSettings.topNPerSector} onChange={e => updateSetting("topNPerSector", e.target.value)} className="font-mono" data-testid="input-topn-sector" />
              <p className="text-xs text-muted-foreground/60 mt-1">Diversification cap</p>
            </div>
          </div>
        </div>

        <Button
          className="w-full mt-6 font-bold tracking-wider uppercase"
          size="lg"
          onClick={runScan}
          disabled={isScanning}
          data-testid="button-scan"
        >
          {isScanning ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              SCANNING...
            </>
          ) : (
            <>
              <Search className="w-5 h-5" />
              INITIATE SCAN
            </>
          )}
        </Button>
      </Card>

      {isScanning && (
        <div className="text-center py-16">
          <div className="loading-spinner mx-auto mb-4" />
          <p className="text-lg font-semibold mb-2">Analyzing Options...</p>
          <p className="text-sm text-muted-foreground font-mono" data-testid="text-loading-status">{loadingStatus}</p>
        </div>
      )}

      {hasScanned && (
        <div>
          <Card className="p-4 mb-6 border-chart-5/30 bg-chart-5/5">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-bold text-scan-complete">Scan Complete (Conservative Pricing)</h3>
                <p className="text-sm text-muted-foreground">
                  Found {scanResults.length} trades passing all quality gates.
                  {scanMeta && ` Mode: ${scanMeta.mode}. Deployed risk: $${scanMeta.deployedRisk.toFixed(0)} / $${scanMeta.maxPortfolioRisk.toFixed(0)} max.`}
                </p>
              </div>
              <div className="flex items-center gap-4">
                <Button variant="outline" onClick={exportScanCSV} disabled={scanResults.length === 0} data-testid="button-export-scan-csv">
                  <Download className="w-4 h-4" />
                  Export CSV
                </Button>
                <div className="text-right">
                  <p className="text-3xl font-bold font-mono text-scan-complete" data-testid="text-total-results">{scanResults.length}</p>
                  <p className="text-xs text-muted-foreground uppercase tracking-wider">Qualified Trades</p>
                </div>
              </div>
            </div>
          </Card>

          {scanMeta && Object.values(scanMeta.reject).some(v => v > 0) && (
            <Card className="p-4 mb-6 bg-accent/30 border-border">
              <p className="text-xs font-semibold text-muted-foreground mb-2">REJECTION BREAKDOWN (Debug)</p>
              <div className="flex flex-wrap gap-3 text-xs font-mono">
                {Object.entries(scanMeta.reject).filter(([, v]) => v > 0).map(([k, v]) => (
                  <span key={k} className="text-muted-foreground">{k}: <span className="text-chart-5 font-bold">{v}</span></span>
                ))}
              </div>
            </Card>
          )}

          {scanResults.length === 0 ? (
            <Card className="glass-panel p-12 text-center">
              <Target className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-lg text-muted-foreground">No opportunities met quality gates</p>
              <p className="text-sm text-muted-foreground mt-1">Try adjusting your filters or scanning different tickers</p>
            </Card>
          ) : (
            <div className="space-y-6">
              {scanResults.map((result, index) => (
                <Card
                  key={`${result.ticker}-${result.shortPut}-${result.longPut}-${result.width}-${index}`}
                  className="gradient-border-top p-6 bg-card border-border"
                  data-testid={`card-trade-${index}`}
                >
                  <div className="flex flex-wrap justify-between items-start gap-4 mb-4">
                    <div>
                      <div className="flex flex-wrap items-center gap-3 mb-2">
                        <Badge className="bg-gradient-to-r from-chart-2 to-chart-3 text-white border-0 font-bold px-4" data-testid={`badge-ticker-${index}`}>
                          {result.ticker}
                        </Badge>
                        {result.width <= 2 && (
                          <span className="micro-badge" data-testid={`badge-micro-${index}`}>MICRO</span>
                        )}
                        <Badge variant="outline" className="text-xs">{result.sector}</Badge>
                        <span className="text-xs text-muted-foreground font-mono">#{index + 1}</span>
                      </div>
                      <h3 className="text-2xl font-bold mb-1">
                        ${result.shortPut} / ${result.longPut} Put Spread
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {result.sector} · Exp: {result.expiration} · {result.dte !== null ? `${result.dte} DTE · ` : ""}${result.width} wide · Price: ${result.price.toFixed(2)}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground mb-1">ROR</p>
                      <p className="text-4xl font-bold text-chart-1 font-mono" data-testid={`text-ror-${index}`}>{result.rorPct.toFixed(0)}%</p>
                    </div>
                  </div>

                  <Card className="p-3 mb-4 bg-chart-4/10 border-chart-4/30">
                    <p className="text-xs font-semibold text-chart-4">CONSERVATIVE PRICING APPLIED</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Credit shows realistic fill: Short @ BID (${result.shortBid.toFixed(2)}), Long @ ASK (${result.longAsk.toFixed(2)}). Net credit: ${result.credit.toFixed(2)} ({result.creditPctWidth.toFixed(1)}% of width)
                    </p>
                    <p className={`text-xs mt-1 font-semibold ${result.slippageRatio < 1.2 ? "text-profit" : result.slippageRatio < 1.4 ? "text-chart-4" : "text-chart-5"}`} data-testid={`text-slippage-${index}`}>
                      Slippage Check: {result.slippageRatio.toFixed(2)}x {result.slippageRatio < 1.2 ? "(Excellent - Tight market)" : result.slippageRatio < 1.4 ? "(Good - Acceptable slippage)" : "(Marginal - Watch execution)"}
                    </p>
                  </Card>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                    <Card className="p-3 bg-accent/30 border-border">
                      <p className="text-xs text-muted-foreground mb-1">NET CREDIT</p>
                      <p className="text-xl font-bold font-mono text-profit">${result.credit.toFixed(2)}</p>
                      <p className="text-xs text-muted-foreground mt-1">{result.creditPctWidth.toFixed(1)}% of width</p>
                    </Card>
                    <Card className="p-3 bg-accent/30 border-border">
                      <p className="text-xs text-muted-foreground mb-1">MAX LOSS</p>
                      <p className="text-xl font-bold font-mono text-destructive">${result.maxLoss.toFixed(0)}</p>
                      <p className="text-xs text-muted-foreground mt-1">Per contract</p>
                    </Card>
                    <Card className="p-3 bg-accent/30 border-border">
                      <p className="text-xs text-muted-foreground mb-1">RETURN/RISK</p>
                      <p className="text-xl font-bold font-mono text-chart-1">{result.rorPct.toFixed(1)}%</p>
                    </Card>
                    <Card className="p-3 bg-accent/30 border-border">
                      <p className="text-xs text-muted-foreground mb-1">DISTANCE OTM</p>
                      <p className="text-xl font-bold font-mono text-chart-3">{result.distancePct.toFixed(1)}%</p>
                    </Card>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs font-mono mb-3">
                    <div><span className="text-muted-foreground">Contracts:</span> <span className="font-bold">{result.contracts}</span></div>
                    <div><span className="text-muted-foreground">Trade Risk:</span> <span>${result.tradeRisk.toFixed(0)}</span></div>
                    <div><span className="text-muted-foreground">Buying Power:</span> <span>${(result.width * 100 * result.contracts).toFixed(0)}</span></div>
                    <div><span className="text-muted-foreground">Credit (est):</span> <span>${(result.credit * 100 * result.contracts).toFixed(0)}</span></div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-5 gap-2 text-xs font-mono border-t border-border pt-3 mb-3">
                    <div><span className="text-muted-foreground">Delta:</span> <span>{result.shortDeltaAbs.toFixed(3)}</span></div>
                    <div><span className="text-muted-foreground">OTM Prob:</span> <span>{((1 - result.shortDeltaAbs) * 100).toFixed(1)}%</span></div>
                    <div><span className="text-muted-foreground">Confidence:</span> <span className={result.confidence >= 75 ? "text-profit font-bold" : result.confidence >= 60 ? "text-chart-4 font-bold" : "text-chart-5 font-bold"}>{result.confidence}</span></div>
                    <div><span className="text-muted-foreground">Opt Credit:</span> <span>${result.optimisticCredit.toFixed(2)}</span></div>
                    <div><span className="text-muted-foreground">Cons Credit:</span> <span>${result.conservativeCredit.toFixed(2)}</span></div>
                  </div>

                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => addToPositions.mutate(result)}
                    disabled={addToPositions.isPending}
                    data-testid={`button-add-position-${index}`}
                  >
                    <Plus className="w-4 h-4" />
                    Add to Positions
                  </Button>
                </Card>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
