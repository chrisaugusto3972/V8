import { useState } from "react";
import { useLocation } from "wouter";
import { useLogin, useRegister } from "@/hooks/use-auth";

export default function LoginPage() {
  const [, setLocation] = useLocation();
  const login = useLogin();
  const register = useRegister();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("demo@v8saas.local");
  const [password, setPassword] = useState("demo123");
  const [name, setName] = useState("Chris");
  const [workspaceName, setWorkspaceName] = useState("My V8 Workspace");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    try {
      if (mode === "login") {
        await login.mutateAsync({ email, password });
      } else {
        await register.mutateAsync({ name, email, password, workspaceName });
      }
      setLocation("/");
    } catch {}
  }

  const error = (login.error as Error)?.message || (register.error as Error)?.message;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center px-4">
      <div className="w-full max-w-md rounded-2xl border border-slate-800 bg-slate-900/80 p-8 shadow-2xl">
        <div className="text-[11px] uppercase tracking-[0.24em] text-slate-400">V8 SaaS Phase 1</div>
        <h1 className="mt-2 text-3xl font-semibold text-white">Institutional Options OS</h1>
        <p className="mt-2 text-sm text-slate-300">Multi-tenant SaaS foundation with Paper Account and Tastytrade-ready scaffolding.</p>

        <div className="mt-6 flex gap-2 rounded-xl bg-slate-950/80 p-1">
          <button onClick={() => setMode("login")} className={`flex-1 rounded-lg px-3 py-2 text-sm ${mode === "login" ? "bg-slate-800 text-white" : "text-slate-400"}`}>Sign in</button>
          <button onClick={() => setMode("register")} className={`flex-1 rounded-lg px-3 py-2 text-sm ${mode === "register" ? "bg-slate-800 text-white" : "text-slate-400"}`}>Create account</button>
        </div>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          {mode === "register" ? (
            <>
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm" />
              <input value={workspaceName} onChange={(e) => setWorkspaceName(e.target.value)} placeholder="Workspace name" className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm" />
            </>
          ) : null}
          <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm" />
          <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" placeholder="Password" className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm" />
          {error ? <div className="text-sm text-rose-300">{error}</div> : null}
          <button type="submit" className="w-full rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-500">
            {mode === "login" ? (login.isPending ? "Signing in..." : "Sign in") : (register.isPending ? "Creating account..." : "Create account")}
          </button>
        </form>

        <div className="mt-6 rounded-xl border border-slate-800 bg-slate-950/70 p-4 text-xs text-slate-400">
          Demo login: demo@v8saas.local / demo123
        </div>
      </div>
    </div>
  );
}
