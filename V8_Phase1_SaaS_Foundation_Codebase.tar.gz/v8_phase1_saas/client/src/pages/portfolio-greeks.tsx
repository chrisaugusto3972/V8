import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import {
  Activity,
  TrendingDown,
  TrendingUp,
  Shield,
  Zap,
  BarChart3,
  AlertTriangle,
  RefreshCw,
  Clock,
  Target,
  Download,
} from "lucide-react";

function StatCard({
  label,
  value,
  subtitle,
  icon: Icon,
  color = "cyan",
  testId,
}: {
  label: string;
  value: string | number;
  subtitle?: string;
  icon: any;
  color?: string;
  testId: string;
}) {
  const colorMap: Record<string, string> = {
    cyan: "text-cyan-400 border-cyan-500/30 bg-cyan-500/5",
    green: "text-green-400 border-green-500/30 bg-green-500/5",
    red: "text-red-400 border-red-500/30 bg-red-500/5",
    amber: "text-amber-400 border-amber-500/30 bg-amber-500/5",
    purple: "text-purple-400 border-purple-500/30 bg-purple-500/5",
    blue: "text-blue-400 border-blue-500/30 bg-blue-500/5",
  };
  const cls = colorMap[color] ?? colorMap.cyan;

  return (
    <Card className={`p-4 border ${cls}`} data-testid={testId}>
      <div className="flex items-center gap-2 mb-1">
        <Icon className="w-4 h-4 opacity-70" />
        <span className="text-xs uppercase tracking-wider opacity-70">{label}</span>
      </div>
      <div className="text-2xl font-mono font-bold" data-testid={`${testId}-value`}>
        {value}
      </div>
      {subtitle && <div className="text-xs opacity-50 mt-1">{subtitle}</div>}
    </Card>
  );
}

function SectorBar({
  sectors,
  total,
  label,
}: {
  sectors: Record<string, number>;
  total: number;
  label: string;
}) {
  const sorted = Object.entries(sectors).sort((a, b) => Math.abs(b[1]) - Math.abs(a[1]));
  const sectorColors = [
    "bg-cyan-500",
    "bg-purple-500",
    "bg-green-500",
    "bg-amber-500",
    "bg-red-500",
    "bg-blue-500",
    "bg-pink-500",
    "bg-indigo-500",
  ];

  return (
    <div data-testid={`sector-bar-${label.toLowerCase().replace(/\s+/g, "-")}`}>
      <div className="text-xs uppercase tracking-wider opacity-70 mb-2">{label}</div>
      <div className="h-3 rounded-full overflow-hidden flex bg-muted/30 mb-2">
        {sorted.map(([sector, val], i) => {
          const pct = total > 0 ? (Math.abs(val) / total) * 100 : 0;
          if (pct < 1) return null;
          return (
            <div
              key={sector}
              className={`${sectorColors[i % sectorColors.length]} opacity-80`}
              style={{ width: `${pct}%` }}
              title={`${sector}: $${Math.abs(val).toFixed(0)} (${pct.toFixed(1)}%)`}
            />
          );
        })}
      </div>
      <div className="flex flex-wrap gap-2">
        {sorted.slice(0, 6).map(([sector, val], i) => (
          <Badge
            key={sector}
            variant="outline"
            className="text-xs font-mono"
            data-testid={`sector-badge-${sector.toLowerCase().replace(/\s+/g, "-")}`}
          >
            <span
              className={`inline-block w-2 h-2 rounded-full mr-1 ${sectorColors[i % sectorColors.length]}`}
            />
            {sector}: ${Math.abs(val).toFixed(0)}
          </Badge>
        ))}
      </div>
    </div>
  );
}

function StressTable({ stress }: { stress: any }) {
  if (!stress) return null;
  const scenarios = stress.scenarios ?? [];

  return (
    <div className="space-y-1" data-testid="stress-test-table">
      {scenarios.map((s: any) => (
        <div
          key={s.label}
          className="flex justify-between items-center py-1.5 px-3 rounded bg-muted/20 hover:bg-muted/30 transition-colors"
          data-testid={`stress-row-${s.label.toLowerCase().replace(/\s+/g, "-")}`}
        >
          <span className="text-sm font-mono opacity-80">{s.label}</span>
          <span
            className={`text-sm font-mono font-bold ${s.estimatedPnl >= 0 ? "text-green-400" : "text-red-400"}`}
          >
            {s.estimatedPnl >= 0 ? "+" : ""}${s.estimatedPnl.toFixed(2)}
          </span>
        </div>
      ))}
    </div>
  );
}

function TopContributors({
  contributors,
  type,
}: {
  contributors: { ticker: string; netDelta?: number; netTheta?: number }[];
  type: "delta" | "theta";
}) {
  if (!contributors?.length) return null;

  return (
    <div className="space-y-1" data-testid={`top-${type}-contributors`}>
      {contributors.map((c, i) => {
        const val = type === "delta" ? c.netDelta ?? 0 : c.netTheta ?? 0;
        return (
          <div
            key={`${c.ticker}-${i}`}
            className="flex justify-between items-center py-1 px-2 rounded bg-muted/10"
          >
            <Badge variant="outline" className="font-mono text-xs">
              {c.ticker}
            </Badge>
            <span
              className={`text-xs font-mono ${val >= 0 ? "text-green-400" : "text-red-400"}`}
            >
              {val >= 0 ? "+" : ""}
              {val.toFixed(3)}
            </span>
          </div>
        );
      })}
    </div>
  );
}

function ExecutionQualitySection() {
  const { data, isLoading } = useQuery<{ ok: boolean; summary: any }>({
    queryKey: ["/api/execution/quality"],
  });

  if (isLoading) {
    return (
      <div className="space-y-3">
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-24 w-full" />
      </div>
    );
  }

  const summary = data?.summary;
  if (!summary || summary.totalOrders === 0) {
    return (
      <Card className="p-6 border border-muted/30 text-center" data-testid="execution-empty">
        <Zap className="w-8 h-8 mx-auto mb-2 opacity-30" />
        <p className="text-sm opacity-50">No execution data yet</p>
        <p className="text-xs opacity-30 mt-1">Fill analytics will appear after trades execute</p>
      </Card>
    );
  }

  return (
    <div className="space-y-4" data-testid="execution-quality-section">
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <StatCard
          label="Total Fills"
          value={summary.totalOrders}
          icon={Target}
          color="cyan"
          testId="stat-total-fills"
        />
        <StatCard
          label="Fill vs Mid"
          value={`${summary.avgFillVsMidpoint >= 0 ? "+" : ""}${summary.avgFillVsMidpoint.toFixed(2)}%`}
          icon={TrendingUp}
          color={summary.avgFillVsMidpoint >= 0 ? "green" : "red"}
          testId="stat-fill-vs-mid"
        />
        <StatCard
          label="Fill vs Spread"
          value={`${summary.avgFillVsBidAsk.toFixed(1)}%`}
          icon={BarChart3}
          color="purple"
          testId="stat-fill-vs-spread"
        />
        <StatCard
          label="Avg Time"
          value={`${summary.avgTimeToFill}s`}
          icon={Clock}
          color="blue"
          testId="stat-avg-time"
        />
        <StatCard
          label="Avg Reprices"
          value={summary.avgReprices.toFixed(1)}
          icon={RefreshCw}
          color="amber"
          testId="stat-avg-reprices"
        />
      </div>

      {Object.keys(summary.byRegime).length > 0 && (
        <Card className="p-4 border border-muted/30" data-testid="execution-by-regime">
          <div className="text-xs uppercase tracking-wider opacity-70 mb-2">Fill Quality by Regime</div>
          <div className="space-y-1">
            {Object.entries(summary.byRegime).map(([regime, stats]: [string, any]) => (
              <div key={regime} className="flex justify-between items-center py-1 px-2 rounded bg-muted/10">
                <Badge variant="outline" className="text-xs">{regime}</Badge>
                <div className="flex gap-4 text-xs font-mono">
                  <span className="opacity-60">{stats.count} fills</span>
                  <span className={stats.avgFillVsMidpoint >= 0 ? "text-green-400" : "text-red-400"}>
                    {stats.avgFillVsMidpoint >= 0 ? "+" : ""}{stats.avgFillVsMidpoint.toFixed(2)}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}

export default function PortfolioGreeksPage() {
  const { toast } = useToast();

  const { data: greeksData, isLoading: greeksLoading } = useQuery<{
    ok: boolean;
    summary: any;
    positions: any[];
  }>({
    queryKey: ["/api/portfolio/greeks"],
  });

  const { data: stressData, isLoading: stressLoading } = useQuery<{
    ok: boolean;
    stress: any;
    market: any;
  }>({
    queryKey: ["/api/portfolio/stress"],
  });

  const { data: exposureData } = useQuery<{ ok: boolean; [key: string]: any }>({
    queryKey: ["/api/portfolio/exposure"],
  });

  const snapshotMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/portfolio/snapshot");
    },
    onSuccess: () => {
      toast({ title: "Snapshot captured", description: "Portfolio snapshot saved" });
      queryClient.invalidateQueries({ queryKey: ["/api/portfolio/snapshots"] });
    },
    onError: (e: any) => {
      toast({ title: "Snapshot failed", description: e?.message, variant: "destructive" });
    },
  });

  const summary = greeksData?.summary;
  const stress = stressData?.stress;
  const market = stressData?.market;
  const sourceSummary = greeksData?.analyticsSourceSummary;
  const liveCount = sourceSummary?.liveGreeksCount ?? 0;
  const approxCount = sourceSummary?.approxGreeksCount ?? 0;
  const greeksLabel =
    liveCount > 0 && approxCount === 0
      ? "Live Greeks"
      : liveCount > 0 && approxCount > 0
        ? "Mixed Live / Estimated Greeks"
        : "Estimated Greeks";

  return (
    <div className="space-y-6" data-testid="portfolio-greeks-page">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold flex items-center gap-2" data-testid="text-page-title">
            <Shield className="w-5 h-5 text-cyan-400" />
            Portfolio Greeks Dashboard
          </h2>
          <p className="text-xs text-muted-foreground mt-1 flex items-center gap-2">
            Aggregate risk exposure, stress tests, and execution quality
            {summary && (
              <Badge variant="outline" className="text-[10px]" data-testid="badge-greeks-source">
                {greeksLabel} ({liveCount}L / {approxCount}E)
              </Badge>
            )}
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => snapshotMutation.mutate()}
          disabled={snapshotMutation.isPending}
          data-testid="button-capture-snapshot"
        >
          <RefreshCw className={`w-4 h-4 mr-1 ${snapshotMutation.isPending ? "animate-spin" : ""}`} />
          Capture Snapshot
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            const a = document.createElement("a");
            a.href = "/api/portfolio/snapshots/csv";
            a.download = `portfolio_snapshots_${new Date().toISOString().slice(0, 10)}.csv`;
            a.click();
          }}
          data-testid="button-download-snapshots"
        >
          <Download className="w-4 h-4 mr-1" />
          Download CSV
        </Button>
      </div>

      {greeksLoading || stressLoading ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
      ) : !summary || summary.openPositionsCount === 0 ? (
        <Card className="p-8 text-center border border-muted/30" data-testid="greeks-empty">
          <Activity className="w-10 h-10 mx-auto mb-3 opacity-30" />
          <p className="text-muted-foreground">No open positions found</p>
          <p className="text-xs text-muted-foreground/60 mt-1">
            Greeks data will populate when you have active spreads
          </p>
        </Card>
      ) : (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <StatCard
              label="Net Delta"
              value={summary.totalNetDelta.toFixed(3)}
              subtitle={`β-weighted: ${summary.betaWeightedDelta.toFixed(3)}`}
              icon={TrendingDown}
              color={Math.abs(summary.totalNetDelta) > 1 ? "red" : "green"}
              testId="stat-net-delta"
            />
            <StatCard
              label="Net Theta"
              value={`$${summary.totalNetTheta.toFixed(2)}`}
              subtitle="Daily decay (est.)"
              icon={TrendingUp}
              color={summary.totalNetTheta > 0 ? "green" : "red"}
              testId="stat-net-theta"
            />
            <StatCard
              label="Total Risk"
              value={`$${summary.totalMaxRisk.toFixed(0)}`}
              subtitle={`${summary.openPositionsCount} open positions`}
              icon={Shield}
              color="amber"
              testId="stat-total-risk"
            />
            <StatCard
              label="High-Beta Risk"
              value={`$${summary.highBetaRisk.toFixed(0)}`}
              subtitle={`ETF: $${summary.etfRisk.toFixed(0)} | Stock: $${summary.singleStockRisk.toFixed(0)}`}
              icon={AlertTriangle}
              color={summary.highBetaRisk > summary.totalMaxRisk * 0.15 ? "red" : "blue"}
              testId="stat-high-beta"
            />
          </div>

          {market && (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <StatCard
                label="SPY"
                value={`$${Number(market.spyPrice ?? 0).toFixed(2)}`}
                icon={BarChart3}
                color="cyan"
                testId="stat-spy-price"
              />
              <StatCard
                label="VIX"
                value={Number(market.vix ?? 0).toFixed(2)}
                icon={Activity}
                color={Number(market.vix ?? 0) > 25 ? "red" : "green"}
                testId="stat-vix"
              />
              <StatCard
                label="Regime"
                value={market.regime ?? "UNKNOWN"}
                icon={Shield}
                color="purple"
                testId="stat-regime"
              />
            </div>
          )}

          <div className="grid md:grid-cols-2 gap-4">
            <Card className="p-4 border border-muted/30" data-testid="card-stress-test">
              <div className="flex items-center gap-2 mb-3">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                <span className="text-sm font-semibold">Stress Test Scenarios</span>
              </div>
              <StressTable stress={stress} />
            </Card>

            <Card className="p-4 border border-muted/30" data-testid="card-top-contributors">
              <div className="flex items-center gap-2 mb-3">
                <BarChart3 className="w-4 h-4 text-cyan-400" />
                <span className="text-sm font-semibold">Top Delta Contributors</span>
              </div>
              <TopContributors contributors={summary.topDeltaContributors} type="delta" />
              <div className="flex items-center gap-2 mt-4 mb-2">
                <Zap className="w-4 h-4 text-green-400" />
                <span className="text-sm font-semibold">Top Theta Contributors</span>
              </div>
              <TopContributors contributors={summary.topThetaContributors} type="theta" />
            </Card>
          </div>

          {exposureData && exposureData.sectorExposure && (
            <Card className="p-4 border border-muted/30" data-testid="card-sector-exposure">
              <div className="flex items-center gap-2 mb-3">
                <BarChart3 className="w-4 h-4 text-purple-400" />
                <span className="text-sm font-semibold">Sector Risk Exposure</span>
              </div>
              <SectorBar
                sectors={exposureData.sectorExposure}
                total={summary.totalMaxRisk}
                label="Risk by Sector"
              />
            </Card>
          )}
        </>
      )}

      <div>
        <div className="flex items-center gap-2 mb-3">
          <Zap className="w-5 h-5 text-purple-400" />
          <h3 className="text-lg font-bold" data-testid="text-execution-title">Execution Quality</h3>
        </div>
        <ExecutionQualitySection />
      </div>
    </div>
  );
}
