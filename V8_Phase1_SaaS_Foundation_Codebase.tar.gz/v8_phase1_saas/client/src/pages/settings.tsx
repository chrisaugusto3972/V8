import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Settings, Save, DollarSign, Calendar, Clock, Target, Layers, CreditCard, Droplets, PieChart, ShieldAlert, LogOut, Cpu, RefreshCw, Bell } from "lucide-react";
import type { ScannerSettings } from "@shared/schema";

type V8Profile = {
  profileName: string;
  account: {
    mode: string;
    startingAccountSize: number;
    riskPerTradePct: number;
    maxRiskPerTradeHardCap: number;
    targetDeploymentPct: number;
    hardMaxDeploymentPct: number;
    maxTradesPerDay: number;
    warmModeMaxTradesPerDay: number;
  };
  dte: {
    primaryMin: number;
    primaryMax: number;
    secondaryMin: number;
    secondaryMax: number;
    fallbackMin: number;
    fallbackMax: number;
  };
  schedule: {
    mondayDefenseUntil: string;
    fridayNoNewEntriesAfter: string;
    fridaySweepTime: string;
    timezone: string;
  };
  strikes: {
    deltaTargetMin: number;
    deltaTargetMax: number;
    hardRejectDeltaAbove: number;
    minDistanceOtmPct: number;
    expectedMoveMultiplier: number;
    betaAdjustedDistanceEnabled: boolean;
    gammaDteFloorEnabled: boolean;
  };
  spreads: {
    preferredWidthMin: number;
    preferredWidthMax: number;
    maxWidth: number;
    allowWidth3: boolean;
    enginePriority: string;
  };
  credit: {
    minAbsoluteCreditWidth1: number;
    minAbsoluteCreditWidth2: number;
    minCreditPctOfWidth: number;
    useOptimisticCredit: boolean;
    useConservativeCredit: boolean;
  };
  liquidity: {
    minOpenInterest: number;
    maxBidAskSpread: number;
    maxSlippageRatio: number;
    liquidityScoringEnabled: boolean;
    rejectLegWideAbs: boolean;
    rejectNoQuote: boolean;
    rejectChainFail: boolean;
  };
  portfolio: {
    sectorCapPct: number;
    subIndustryTwinBlocking: boolean;
    highBetaCapPct: number;
    correlationBlocking: boolean;
    opportunityBudgeting: boolean;
    breadthProtection: boolean;
    preferEtfs: boolean;
    allowHighBetaStocks: boolean;
  };
  risk: {
    dailyLossPausePct: number;
    totalDrawdownHaltPct: number;
    lossClusterPauseAfterConsecutiveLosses: number;
    warmModeHoursAfterRestart: number;
    warmModeSizeReductionPct: number;
    reconciliationMismatchAction: string;
    killSwitchEnabled: boolean;
  };
  exits: {
    mode: string;
    takeProfitPct: number;
    hybridHoldMaxDelta: number;
    hardExitDelta: number;
    hardExitDte: number;
    assignmentProtectionEnabled: boolean;
    fridayCloseEnforcement: boolean;
  };
  instruments: {
    etfFirst: boolean;
    preferredTickers: string[];
  };
};

function SectionHeader({ icon: Icon, title, color = "text-chart-1" }: { icon: any; title: string; color?: string }) {
  return (
    <h3 className="text-sm font-bold mb-4 flex items-center gap-2 uppercase tracking-wider">
      <Icon className={`w-4 h-4 ${color}`} />
      {title}
    </h3>
  );
}

function FieldLabel({ label, hint }: { label: string; hint?: string }) {
  return (
    <div>
      <Label className="text-xs font-semibold text-muted-foreground mb-1.5 block">{label}</Label>
      {hint && <p className="text-[10px] text-muted-foreground/50 mb-1">{hint}</p>}
    </div>
  );
}

function NumberField({ label, hint, value, onChange, step, min, max, testId }: {
  label: string; hint?: string; value: string; onChange: (v: string) => void;
  step?: string; min?: string; max?: string; testId: string;
}) {
  return (
    <div>
      <FieldLabel label={label} hint={hint} />
      <Input type="number" step={step || "1"} min={min} max={max} value={value}
        onChange={e => onChange(e.target.value)} className="font-mono text-sm h-9" data-testid={testId} />
    </div>
  );
}

function ToggleField({ label, checked, onChange, testId }: {
  label: string; checked: boolean; onChange: (v: boolean) => void; testId: string;
}) {
  return (
    <div className="flex items-center justify-between py-1">
      <Label className="text-sm">{label}</Label>
      <Switch checked={checked} onCheckedChange={onChange} data-testid={testId} />
    </div>
  );
}

export default function SettingsPage() {
  const { toast } = useToast();

  const { data: settings } = useQuery<ScannerSettings>({
    queryKey: ["/api/settings"],
  });

  const { data: v8Profile } = useQuery<V8Profile>({
    queryKey: ["/api/v8-profile"],
  });

  const [profile, setProfile] = useState<V8Profile | null>(null);
  const [tickers, setTickers] = useState("");
  const [refreshInterval, setRefreshInterval] = useState("5");
  const [notifyNewTrades, setNotifyNewTrades] = useState(true);
  const [notifyProfitTargets, setNotifyProfitTargets] = useState(true);
  const [useVixRegime, setUseVixRegime] = useState(true);

  useEffect(() => {
    if (settings?.profileJson) {
      try {
        setProfile(JSON.parse(settings.profileJson));
      } catch { /* use default */ }
    }
    if (v8Profile && !profile) {
      setProfile(v8Profile);
    }
  }, [settings, v8Profile]);

  useEffect(() => {
    if (settings) {
      setTickers(settings.tickers);
      setRefreshInterval(String(settings.refreshInterval));
      setNotifyNewTrades(settings.notifyNewTrades);
      setNotifyProfitTargets(settings.notifyProfitTargets);
      setUseVixRegime(settings.useVixRegime);
    }
  }, [settings]);

  const p = profile || v8Profile;

  function updateProfile(section: string, field: string, value: any) {
    if (!p) return;
    setProfile({ ...p, [section]: { ...(p as any)[section], [field]: value } });
  }

  const saveSettings = useMutation({
    mutationFn: async () => {
      const profileToSave = profile || v8Profile;
      const res = await apiRequest("PUT", "/api/settings", {
        tickers,
        dteRange: profileToSave ? `${profileToSave.dte.primaryMin}-${profileToSave.dte.fallbackMax}` : "8-21",
        deltaRange: profileToSave ? `${profileToSave.strikes.deltaTargetMin}-${profileToSave.strikes.deltaTargetMax}` : "0.10-0.15",
        accountSize: profileToSave?.account.mode || "small",
        minCredit: profileToSave?.credit.minAbsoluteCreditWidth1 ?? 0.18,
        maxSpread: profileToSave?.liquidity.maxBidAskSpread ?? 0.15,
        maxResults: 20,
        minCreditPct: (profileToSave?.credit.minCreditPctOfWidth ?? 0.25) * 100,
        minDistancePct: profileToSave?.strikes.minDistanceOtmPct ?? 5,
        minOI: profileToSave?.liquidity.minOpenInterest ?? 100,
        maxSlippageRatio: profileToSave?.liquidity.maxSlippageRatio ?? 1.5,
        refreshInterval: parseInt(refreshInterval),
        notifyNewTrades,
        notifyProfitTargets,
        maxPositionSize: profileToSave?.account.maxRiskPerTradeHardCap ? profileToSave.account.maxRiskPerTradeHardCap * 20 : 1500,
        maxPortfolioRisk: (profileToSave?.account.hardMaxDeploymentPct ?? 0.5) * 100,
        maxRiskPerTrade: profileToSave?.account.maxRiskPerTradeHardCap ?? 75,
        vixLowThreshold: 15,
        vixHighThreshold: 25,
        useVixRegime,
        profileJson: JSON.stringify(profileToSave),
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({ title: "Settings saved", description: "V8 profile updated successfully" });
    },
    onError: (err: Error) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  if (!p) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <Card className="glass-panel p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Settings className="w-5 h-5 text-chart-1" />
            V8 Production Settings
          </h2>
          <span className="text-xs font-mono px-2 py-1 rounded bg-chart-1/10 text-chart-1" data-testid="text-profile-name">
            {p.profileName}
          </span>
        </div>

        <div className="space-y-6">

          <div className="border border-border/50 rounded-lg p-4">
            <SectionHeader icon={DollarSign} title="Account & Sizing" />
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <FieldLabel label="Account Mode" />
                <Select value={p.account.mode} onValueChange={v => updateProfile("account", "mode", v)}>
                  <SelectTrigger data-testid="select-account-mode" className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="small">Small ($3k)</SelectItem>
                    <SelectItem value="standard">Standard ($10k+)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <NumberField label="Account Size ($)" value={String(p.account.startingAccountSize)}
                onChange={v => updateProfile("account", "startingAccountSize", Number(v))}
                step="500" min="1000" testId="input-account-size" />
              <NumberField label="Risk/Trade (%)" hint={`$${Math.round(p.account.startingAccountSize * p.account.riskPerTradePct)} per trade`}
                value={String(p.account.riskPerTradePct * 100)}
                onChange={v => updateProfile("account", "riskPerTradePct", Number(v) / 100)}
                step="0.5" min="0.5" max="5" testId="input-risk-per-trade" />
              <NumberField label="Max Risk/Trade ($)" value={String(p.account.maxRiskPerTradeHardCap)}
                onChange={v => updateProfile("account", "maxRiskPerTradeHardCap", Number(v))}
                step="25" min="25" testId="input-max-risk-cap" />
              <NumberField label="Target Deployment (%)" value={String(p.account.targetDeploymentPct * 100)}
                onChange={v => updateProfile("account", "targetDeploymentPct", Number(v) / 100)}
                step="5" min="10" max="80" testId="input-target-deployment" />
              <NumberField label="Hard Max Deploy (%)" value={String(p.account.hardMaxDeploymentPct * 100)}
                onChange={v => updateProfile("account", "hardMaxDeploymentPct", Number(v) / 100)}
                step="5" min="20" max="90" testId="input-hard-max-deploy" />
              <NumberField label="Max Trades/Day" value={String(p.account.maxTradesPerDay)}
                onChange={v => updateProfile("account", "maxTradesPerDay", Number(v))}
                min="1" max="10" testId="input-max-trades-day" />
              <NumberField label="Warm Mode Trades/Day" value={String(p.account.warmModeMaxTradesPerDay)}
                onChange={v => updateProfile("account", "warmModeMaxTradesPerDay", Number(v))}
                min="0" max="5" testId="input-warm-trades-day" />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border border-border/50 rounded-lg p-4">
              <SectionHeader icon={Calendar} title="DTE Windows" />
              <div className="grid grid-cols-2 gap-3">
                <NumberField label="Primary Min" value={String(p.dte.primaryMin)}
                  onChange={v => updateProfile("dte", "primaryMin", Number(v))} min="1" testId="input-dte-pri-min" />
                <NumberField label="Primary Max" value={String(p.dte.primaryMax)}
                  onChange={v => updateProfile("dte", "primaryMax", Number(v))} min="1" testId="input-dte-pri-max" />
                <NumberField label="Secondary Min" value={String(p.dte.secondaryMin)}
                  onChange={v => updateProfile("dte", "secondaryMin", Number(v))} min="1" testId="input-dte-sec-min" />
                <NumberField label="Secondary Max" value={String(p.dte.secondaryMax)}
                  onChange={v => updateProfile("dte", "secondaryMax", Number(v))} min="1" testId="input-dte-sec-max" />
                <NumberField label="Fallback Min" value={String(p.dte.fallbackMin)}
                  onChange={v => updateProfile("dte", "fallbackMin", Number(v))} min="1" testId="input-dte-fb-min" />
                <NumberField label="Fallback Max" value={String(p.dte.fallbackMax)}
                  onChange={v => updateProfile("dte", "fallbackMax", Number(v))} min="1" testId="input-dte-fb-max" />
              </div>
            </div>

            <div className="border border-border/50 rounded-lg p-4">
              <SectionHeader icon={Clock} title="Schedule" />
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <FieldLabel label="Mon Defense Until" hint="ET time" />
                  <Input value={p.schedule.mondayDefenseUntil}
                    onChange={e => updateProfile("schedule", "mondayDefenseUntil", e.target.value)}
                    className="font-mono text-sm h-9" data-testid="input-mon-defense" />
                </div>
                <div>
                  <FieldLabel label="Fri No Entries After" hint="ET time" />
                  <Input value={p.schedule.fridayNoNewEntriesAfter}
                    onChange={e => updateProfile("schedule", "fridayNoNewEntriesAfter", e.target.value)}
                    className="font-mono text-sm h-9" data-testid="input-fri-cutoff" />
                </div>
                <div>
                  <FieldLabel label="Fri Sweep Time" hint="ET time" />
                  <Input value={p.schedule.fridaySweepTime}
                    onChange={e => updateProfile("schedule", "fridaySweepTime", e.target.value)}
                    className="font-mono text-sm h-9" data-testid="input-fri-sweep" />
                </div>
                <div>
                  <FieldLabel label="Timezone" />
                  <Input value={p.schedule.timezone} disabled className="font-mono text-sm h-9 opacity-60" data-testid="input-timezone" />
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border border-border/50 rounded-lg p-4">
              <SectionHeader icon={Target} title="Strike Selection" />
              <div className="grid grid-cols-2 gap-3">
                <NumberField label="Delta Target Min" value={String(p.strikes.deltaTargetMin)}
                  onChange={v => updateProfile("strikes", "deltaTargetMin", Number(v))}
                  step="0.01" min="0.05" max="0.30" testId="input-delta-min" />
                <NumberField label="Delta Target Max" value={String(p.strikes.deltaTargetMax)}
                  onChange={v => updateProfile("strikes", "deltaTargetMax", Number(v))}
                  step="0.01" min="0.05" max="0.40" testId="input-delta-max" />
                <NumberField label="Hard Reject Delta" hint="Above this = auto-reject"
                  value={String(p.strikes.hardRejectDeltaAbove)}
                  onChange={v => updateProfile("strikes", "hardRejectDeltaAbove", Number(v))}
                  step="0.01" min="0.10" max="0.50" testId="input-hard-reject-delta" />
                <NumberField label="Min Distance OTM (%)" value={String(p.strikes.minDistanceOtmPct)}
                  onChange={v => updateProfile("strikes", "minDistanceOtmPct", Number(v))}
                  step="0.5" min="1" max="20" testId="input-min-dist-otm" />
                <NumberField label="Exp Move Multiplier" value={String(p.strikes.expectedMoveMultiplier)}
                  onChange={v => updateProfile("strikes", "expectedMoveMultiplier", Number(v))}
                  step="0.05" min="1.0" max="2.0" testId="input-exp-move-mult" />
              </div>
              <div className="mt-3 space-y-1">
                <ToggleField label="Beta-adjusted distance" checked={p.strikes.betaAdjustedDistanceEnabled}
                  onChange={v => updateProfile("strikes", "betaAdjustedDistanceEnabled", v)} testId="switch-beta-dist" />
                <ToggleField label="Gamma DTE floor" checked={p.strikes.gammaDteFloorEnabled}
                  onChange={v => updateProfile("strikes", "gammaDteFloorEnabled", v)} testId="switch-gamma-dte" />
              </div>
            </div>

            <div className="border border-border/50 rounded-lg p-4">
              <SectionHeader icon={Layers} title="Spread Construction" />
              <div className="grid grid-cols-2 gap-3">
                <NumberField label="Preferred Width Min ($)" value={String(p.spreads.preferredWidthMin)}
                  onChange={v => updateProfile("spreads", "preferredWidthMin", Number(v))}
                  min="1" max="10" testId="input-width-min" />
                <NumberField label="Preferred Width Max ($)" value={String(p.spreads.preferredWidthMax)}
                  onChange={v => updateProfile("spreads", "preferredWidthMax", Number(v))}
                  min="1" max="10" testId="input-width-max" />
                <NumberField label="Max Width ($)" value={String(p.spreads.maxWidth)}
                  onChange={v => updateProfile("spreads", "maxWidth", Number(v))}
                  min="1" max="10" testId="input-max-width" />
                <div>
                  <FieldLabel label="Engine Priority" />
                  <Select value={p.spreads.enginePriority} onValueChange={v => updateProfile("spreads", "enginePriority", v)}>
                    <SelectTrigger data-testid="select-engine-priority" className="h-9"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="CORE_FIRST">Core First</SelectItem>
                      <SelectItem value="BOOST_FIRST">Boost First</SelectItem>
                      <SelectItem value="BALANCED">Balanced</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="mt-3">
                <ToggleField label="Allow $3 wide spreads" checked={p.spreads.allowWidth3}
                  onChange={v => updateProfile("spreads", "allowWidth3", v)} testId="switch-allow-width3" />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border border-border/50 rounded-lg p-4">
              <SectionHeader icon={CreditCard} title="Credit Requirements" color="text-chart-4" />
              <div className="grid grid-cols-2 gap-3">
                <NumberField label="Min Credit $1-Wide" value={String(p.credit.minAbsoluteCreditWidth1)}
                  onChange={v => updateProfile("credit", "minAbsoluteCreditWidth1", Number(v))}
                  step="0.01" min="0.05" testId="input-min-credit-w1" />
                <NumberField label="Min Credit $2-Wide" value={String(p.credit.minAbsoluteCreditWidth2)}
                  onChange={v => updateProfile("credit", "minAbsoluteCreditWidth2", Number(v))}
                  step="0.01" min="0.10" testId="input-min-credit-w2" />
                <NumberField label="Min Credit % of Width" hint={`${(p.credit.minCreditPctOfWidth * 100).toFixed(0)}% of spread width`}
                  value={String(p.credit.minCreditPctOfWidth * 100)}
                  onChange={v => updateProfile("credit", "minCreditPctOfWidth", Number(v) / 100)}
                  step="1" min="5" max="50" testId="input-min-credit-pct" />
              </div>
              <div className="mt-3 space-y-1">
                <ToggleField label="Conservative credit (use bid)" checked={p.credit.useConservativeCredit}
                  onChange={v => updateProfile("credit", "useConservativeCredit", v)} testId="switch-conservative" />
                <ToggleField label="Optimistic credit (use mid)" checked={p.credit.useOptimisticCredit}
                  onChange={v => updateProfile("credit", "useOptimisticCredit", v)} testId="switch-optimistic" />
              </div>
            </div>

            <div className="border border-border/50 rounded-lg p-4">
              <SectionHeader icon={Droplets} title="Liquidity Filters" color="text-chart-2" />
              <div className="grid grid-cols-2 gap-3">
                <NumberField label="Min Open Interest" value={String(p.liquidity.minOpenInterest)}
                  onChange={v => updateProfile("liquidity", "minOpenInterest", Number(v))}
                  min="0" testId="input-min-oi" />
                <NumberField label="Max Bid-Ask Spread ($)" value={String(p.liquidity.maxBidAskSpread)}
                  onChange={v => updateProfile("liquidity", "maxBidAskSpread", Number(v))}
                  step="0.01" min="0.01" testId="input-max-ba-spread" />
                <NumberField label="Max Slippage Ratio" value={String(p.liquidity.maxSlippageRatio)}
                  onChange={v => updateProfile("liquidity", "maxSlippageRatio", Number(v))}
                  step="0.1" min="1.0" max="3.0" testId="input-max-slippage" />
              </div>
              <div className="mt-3 space-y-1">
                <ToggleField label="Liquidity scoring" checked={p.liquidity.liquidityScoringEnabled}
                  onChange={v => updateProfile("liquidity", "liquidityScoringEnabled", v)} testId="switch-liq-scoring" />
                <ToggleField label="Reject wide leg spreads" checked={p.liquidity.rejectLegWideAbs}
                  onChange={v => updateProfile("liquidity", "rejectLegWideAbs", v)} testId="switch-reject-wide" />
                <ToggleField label="Reject no-quote legs" checked={p.liquidity.rejectNoQuote}
                  onChange={v => updateProfile("liquidity", "rejectNoQuote", v)} testId="switch-reject-noquote" />
                <ToggleField label="Reject chain failures" checked={p.liquidity.rejectChainFail}
                  onChange={v => updateProfile("liquidity", "rejectChainFail", v)} testId="switch-reject-chainfail" />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border border-border/50 rounded-lg p-4">
              <SectionHeader icon={PieChart} title="Portfolio Controls" color="text-chart-3" />
              <div className="grid grid-cols-2 gap-3">
                <NumberField label="Sector Cap (%)" value={String(p.portfolio.sectorCapPct * 100)}
                  onChange={v => updateProfile("portfolio", "sectorCapPct", Number(v) / 100)}
                  step="5" min="5" max="50" testId="input-sector-cap" />
                <NumberField label="High Beta Cap (%)" value={String(p.portfolio.highBetaCapPct * 100)}
                  onChange={v => updateProfile("portfolio", "highBetaCapPct", Number(v) / 100)}
                  step="5" min="5" max="30" testId="input-hb-cap" />
              </div>
              <div className="mt-3 space-y-1">
                <ToggleField label="Sub-industry twin blocking" checked={p.portfolio.subIndustryTwinBlocking}
                  onChange={v => updateProfile("portfolio", "subIndustryTwinBlocking", v)} testId="switch-twin-block" />
                <ToggleField label="Correlation blocking" checked={p.portfolio.correlationBlocking}
                  onChange={v => updateProfile("portfolio", "correlationBlocking", v)} testId="switch-corr-block" />
                <ToggleField label="Opportunity budgeting" checked={p.portfolio.opportunityBudgeting}
                  onChange={v => updateProfile("portfolio", "opportunityBudgeting", v)} testId="switch-opp-budget" />
                <ToggleField label="Breadth protection" checked={p.portfolio.breadthProtection}
                  onChange={v => updateProfile("portfolio", "breadthProtection", v)} testId="switch-breadth" />
                <ToggleField label="Prefer ETFs" checked={p.portfolio.preferEtfs}
                  onChange={v => updateProfile("portfolio", "preferEtfs", v)} testId="switch-prefer-etfs" />
                <ToggleField label="Allow high-beta stocks" checked={p.portfolio.allowHighBetaStocks}
                  onChange={v => updateProfile("portfolio", "allowHighBetaStocks", v)} testId="switch-allow-hb" />
              </div>
            </div>

            <div className="border border-border/50 rounded-lg p-4">
              <SectionHeader icon={ShieldAlert} title="Risk Management" color="text-chart-5" />
              <div className="grid grid-cols-2 gap-3">
                <NumberField label="Daily Loss Pause (%)" hint={`$${Math.round(p.account.startingAccountSize * p.risk.dailyLossPausePct)} trigger`}
                  value={String(p.risk.dailyLossPausePct * 100)}
                  onChange={v => updateProfile("risk", "dailyLossPausePct", Number(v) / 100)}
                  step="0.5" min="1" max="10" testId="input-daily-loss" />
                <NumberField label="Total Drawdown Halt (%)" hint={`$${Math.round(p.account.startingAccountSize * p.risk.totalDrawdownHaltPct)} trigger`}
                  value={String(p.risk.totalDrawdownHaltPct * 100)}
                  onChange={v => updateProfile("risk", "totalDrawdownHaltPct", Number(v) / 100)}
                  step="1" min="3" max="20" testId="input-total-dd" />
                <NumberField label="Consecutive Loss Pause" value={String(p.risk.lossClusterPauseAfterConsecutiveLosses)}
                  onChange={v => updateProfile("risk", "lossClusterPauseAfterConsecutiveLosses", Number(v))}
                  min="2" max="10" testId="input-consec-loss" />
                <NumberField label="Warm Mode Hours" value={String(p.risk.warmModeHoursAfterRestart)}
                  onChange={v => updateProfile("risk", "warmModeHoursAfterRestart", Number(v))}
                  min="1" max="72" testId="input-warm-hours" />
                <NumberField label="Warm Size Reduction (%)" value={String(p.risk.warmModeSizeReductionPct * 100)}
                  onChange={v => updateProfile("risk", "warmModeSizeReductionPct", Number(v) / 100)}
                  step="10" min="10" max="90" testId="input-warm-reduction" />
                <div>
                  <FieldLabel label="Recon Mismatch Action" />
                  <Select value={p.risk.reconciliationMismatchAction}
                    onValueChange={v => updateProfile("risk", "reconciliationMismatchAction", v)}>
                    <SelectTrigger data-testid="select-recon-action" className="h-9"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="PAUSE">Pause</SelectItem>
                      <SelectItem value="ALERT">Alert Only</SelectItem>
                      <SelectItem value="HALT">Full Halt</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="mt-3">
                <ToggleField label="Kill switch enabled" checked={p.risk.killSwitchEnabled}
                  onChange={v => updateProfile("risk", "killSwitchEnabled", v)} testId="switch-kill-switch" />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border border-border/50 rounded-lg p-4">
              <SectionHeader icon={LogOut} title="Exit Strategy" color="text-orange" />
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <FieldLabel label="Exit Mode" />
                  <Select value={p.exits.mode} onValueChange={v => updateProfile("exits", "mode", v)}>
                    <SelectTrigger data-testid="select-exit-mode" className="h-9"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="HYBRID_SMART_EXIT">Hybrid Smart Exit</SelectItem>
                      <SelectItem value="FIXED_PCT">Fixed Percentage</SelectItem>
                      <SelectItem value="DELTA_BASED">Delta Based</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <NumberField label="Take Profit (%)" hint={`Close at ${(p.exits.takeProfitPct * 100).toFixed(0)}% of max profit`}
                  value={String(p.exits.takeProfitPct * 100)}
                  onChange={v => updateProfile("exits", "takeProfitPct", Number(v) / 100)}
                  step="5" min="25" max="90" testId="input-take-profit" />
                <NumberField label="Hybrid Hold Max Delta" value={String(p.exits.hybridHoldMaxDelta)}
                  onChange={v => updateProfile("exits", "hybridHoldMaxDelta", Number(v))}
                  step="0.01" min="0.05" max="0.30" testId="input-hybrid-delta" />
                <NumberField label="Hard Exit Delta" value={String(p.exits.hardExitDelta)}
                  onChange={v => updateProfile("exits", "hardExitDelta", Number(v))}
                  step="0.01" min="0.15" max="0.50" testId="input-hard-exit-delta" />
                <NumberField label="Hard Exit DTE" value={String(p.exits.hardExitDte)}
                  onChange={v => updateProfile("exits", "hardExitDte", Number(v))}
                  min="0" max="5" testId="input-hard-exit-dte" />
              </div>
              <div className="mt-3 space-y-1">
                <ToggleField label="Assignment protection" checked={p.exits.assignmentProtectionEnabled}
                  onChange={v => updateProfile("exits", "assignmentProtectionEnabled", v)} testId="switch-assign-protect" />
                <ToggleField label="Friday close enforcement" checked={p.exits.fridayCloseEnforcement}
                  onChange={v => updateProfile("exits", "fridayCloseEnforcement", v)} testId="switch-fri-close" />
              </div>
            </div>

            <div className="border border-border/50 rounded-lg p-4">
              <SectionHeader icon={Cpu} title="Instruments & Preferences" />
              <div className="mb-3">
                <FieldLabel label="Default Tickers" hint="Comma-separated list" />
                <Input value={tickers} onChange={e => setTickers(e.target.value)}
                  className="font-mono text-xs h-9" data-testid="input-default-tickers" />
              </div>
              <div className="mb-3">
                <FieldLabel label="Preferred Tickers" hint="Priority scanning order" />
                <Input value={p.instruments.preferredTickers.join(", ")}
                  onChange={e => updateProfile("instruments", "preferredTickers", e.target.value.split(",").map((s: string) => s.trim()).filter(Boolean))}
                  className="font-mono text-sm h-9" data-testid="input-preferred-tickers" />
              </div>
              <div className="space-y-1">
                <ToggleField label="ETFs first in scan order" checked={p.instruments.etfFirst}
                  onChange={v => updateProfile("instruments", "etfFirst", v)} testId="switch-etf-first" />
                <ToggleField label="VIX regime adjustments" checked={useVixRegime}
                  onChange={setUseVixRegime} testId="switch-vix-regime" />
              </div>

              <div className="border-t border-border/30 mt-4 pt-4">
                <SectionHeader icon={Bell} title="Notifications" color="text-chart-4" />
                <div className="space-y-1">
                  <ToggleField label="New trade alerts" checked={notifyNewTrades}
                    onChange={setNotifyNewTrades} testId="switch-notify-trades" />
                  <ToggleField label="Profit target alerts" checked={notifyProfitTargets}
                    onChange={setNotifyProfitTargets} testId="switch-notify-profits" />
                </div>
              </div>

              <div className="border-t border-border/30 mt-4 pt-4">
                <SectionHeader icon={RefreshCw} title="Auto-Refresh" />
                <Select value={refreshInterval} onValueChange={setRefreshInterval}>
                  <SelectTrigger data-testid="select-refresh-interval" className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 minute</SelectItem>
                    <SelectItem value="3">3 minutes</SelectItem>
                    <SelectItem value="5">5 minutes</SelectItem>
                    <SelectItem value="15">15 minutes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <Button
            className="w-full font-bold tracking-wider uppercase"
            size="lg"
            onClick={() => saveSettings.mutate()}
            disabled={saveSettings.isPending}
            data-testid="button-save-settings"
          >
            <Save className="w-5 h-5" />
            SAVE V8 PROFILE
          </Button>
        </div>
      </Card>
    </div>
  );
}
