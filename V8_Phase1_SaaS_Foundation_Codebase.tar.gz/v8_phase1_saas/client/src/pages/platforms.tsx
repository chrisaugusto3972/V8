import { useQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/app-shell";
import { PageHero } from "@/components/page-hero";
import { SectionCard } from "@/components/section-card";

export default function PlatformsPage() {
  const { data } = useQuery({
    queryKey: ["/api/saas/platforms"],
    queryFn: async () => {
      const res = await fetch("/api/saas/platforms", { credentials: "include" });
      return res.json();
    },
  });

  return (
    <AppShell title="Platforms">
      <PageHero
        eyebrow="Broker Choice"
        title="Supported Trading Platforms"
        description="Users choose from a controlled compatibility list. Paper Account and Tastytrade launch first; more brokers come later behind one broker abstraction layer."
      />

      <SectionCard title="Compatibility List">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-slate-400 border-b border-slate-800">
              <tr>
                <th className="py-3 text-left">Platform</th>
                <th className="py-3 text-left">Status</th>
                <th className="py-3 text-left">Read-only Sync</th>
                <th className="py-3 text-left">Assisted Execution</th>
                <th className="py-3 text-left">Paper Autopilot</th>
                <th className="py-3 text-left">Live Autopilot</th>
              </tr>
            </thead>
            <tbody>
              {(data?.platforms || []).map((p: any) => (
                <tr key={p.id} className="border-b border-slate-900 text-slate-200">
                  <td className="py-3">{p.name}</td>
                  <td className="py-3">{p.status}</td>
                  <td className="py-3">{p.readOnlySync ? "Yes" : "No"}</td>
                  <td className="py-3">{p.assistedExecution ? "Yes" : "No"}</td>
                  <td className="py-3">{p.paperAutopilotCompatible ? "Yes" : "No"}</td>
                  <td className="py-3">{p.liveAutopilotCompatible ? "Yes" : "No"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </AppShell>
  );
}
