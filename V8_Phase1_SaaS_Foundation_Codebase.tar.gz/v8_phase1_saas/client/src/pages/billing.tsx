import { AppShell } from "@/components/app-shell";
import { PageHero } from "@/components/page-hero";
import { SectionCard } from "@/components/section-card";

const plans = [
  { name: "Starter", price: "$39", features: ["Scanner", "Basic analytics", "Paper only"] },
  { name: "Pro", price: "$99", features: ["Full scanner", "Risk dashboard", "Portfolio analytics"] },
  { name: "Elite", price: "$179", features: ["Paper autopilot", "Broker sync", "Execution analytics"] },
];

export default function BillingPage() {
  return (
    <AppShell title="Billing">
      <PageHero
        eyebrow="Monetization"
        title="Plans and Entitlements"
        description="Phase 1 scaffolds the subscription model so V8 can layer billing and plan gating in later phases without reworking the product structure."
      />
      <div className="grid gap-6 md:grid-cols-3">
        {plans.map((plan) => (
          <SectionCard key={plan.name} title={plan.name} subtitle={`${plan.price}/month`}>
            <ul className="space-y-2 text-sm text-slate-300 list-disc pl-5">
              {plan.features.map((f) => <li key={f}>{f}</li>)}
            </ul>
          </SectionCard>
        ))}
      </div>
    </AppShell>
  );
}
