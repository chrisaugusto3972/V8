import { Link } from "wouter";
import { AppShell } from "@/components/app-shell";
import { PageHero } from "@/components/page-hero";
import { StatCard } from "@/components/stat-card";
import { SectionCard } from "@/components/section-card";
import { useAuth } from "@/hooks/use-auth";

export default function DashboardPage() {
  const { data } = useAuth();

  return (
    <AppShell title="Dashboard">
      <PageHero
        eyebrow="Phase 1"
        title="V8 SaaS Foundation"
        description="Paper-first SaaS shell with workspace and account scaffolding. This phase prepares V8 for multi-account, broker-choice growth without changing the trading core."
      />

      <div className="grid gap-4 md:grid-cols-4 mb-6">
        <StatCard label="Workspace" value={data?.currentWorkspace?.name || "—"} hint="Current active workspace" />
        <StatCard label="Account" value={data?.currentAccount?.name || "—"} hint="Selected trading account" />
        <StatCard label="Platform" value={data?.currentAccount?.platform || "paper"} hint="Paper first, Tastytrade ready" />
        <StatCard label="Mode" value={data?.currentAccount?.mode || "manual"} hint="Manual / assisted / paper autopilot" />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <SectionCard title="Phase 1 Delivered" subtitle="What this foundation adds without changing V8 engine logic">
          <ul className="space-y-2 text-sm text-slate-300 list-disc pl-5">
            <li>Authentication scaffolding</li>
            <li>Workspace model</li>
            <li>Account model</li>
            <li>Paper Account first-class support</li>
            <li>Broker choice architecture</li>
            <li>SaaS navigation shell</li>
          </ul>
        </SectionCard>

        <SectionCard title="Next Product Areas" subtitle="Continue the roadmap from this base">
          <div className="space-y-3 text-sm">
            <Link href="/scanner"><a className="block rounded-lg border border-slate-800 px-4 py-3 hover:bg-slate-900">Scanner productization</a></Link>
            <Link href="/greeks"><a className="block rounded-lg border border-slate-800 px-4 py-3 hover:bg-slate-900">Portfolio risk cockpit</a></Link>
            <Link href="/platforms"><a className="block rounded-lg border border-slate-800 px-4 py-3 hover:bg-slate-900">Broker compatibility list</a></Link>
            <Link href="/billing"><a className="block rounded-lg border border-slate-800 px-4 py-3 hover:bg-slate-900">Plans and billing layer</a></Link>
          </div>
        </SectionCard>
      </div>
    </AppShell>
  );
}
