import { useQuery, useMutation } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Activity, Brain, TrendingUp, AlertTriangle, Clock, Shield, Pause, Play, XCircle, Zap, Ban, Check, Download, Power, Square, Crosshair, ArrowUpDown } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

type StrategyHealth = {
  score: number;
  mode: string;
  participationThrottle: number;
  riskThrottle: number;
  trades: number;
  winRate: number;
  profitFactor: number;
};

type FillSummary = {
  ticker: string;
  trades: number;
  avgEntrySlippagePct: number;
  avgExitSlippagePct: number;
  avgFillMinutes: number;
  poorFill: boolean;
};

type SystemEvent = {
  id: string;
  severity: string;
  eventType: string;
  message: string;
  payload: string | null;
  createdAt: string;
};

type HealthReport = {
  ok: boolean;
  state: any;
  strategy: StrategyHealth;
  fills: FillSummary[];
  feedback: any;
};

function modeColor(mode: string) {
  switch (mode) {
    case "normal": return "bg-emerald-500/20 text-emerald-400 border-emerald-500/30";
    case "reduced": return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30";
    case "defensive": return "bg-orange-500/20 text-orange-400 border-orange-500/30";
    case "paused": return "bg-red-500/20 text-red-400 border-red-500/30";
    default: return "bg-muted text-muted-foreground";
  }
}

function severityColor(severity: string) {
  switch (severity) {
    case "info": return "text-blue-400";
    case "warn": return "text-yellow-400";
    case "critical": return "text-red-400";
    case "error": return "text-red-400";
    default: return "text-muted-foreground";
  }
}

function severityBadge(severity: string) {
  switch (severity) {
    case "info": return "bg-blue-500/20 text-blue-400 border-blue-500/30";
    case "warn": return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30";
    case "critical": return "bg-red-500/20 text-red-400 border-red-500/30";
    default: return "bg-muted text-muted-foreground";
  }
}

const EVENT_TYPES_OF_INTEREST = [
  "broker_mismatch",
  "health_degraded",
  "loss_cluster_pause",
  "fill_analytics_snapshot",
  "health_loop_summary",
  "performance_feedback_snapshot",
  "warm_mode_active",
  "position_created_from_fill",
  "broker_order_rejected",
  "live_order_sync_failed",
  "reconciliation_failed",
  "mismatch_flatten_symbol",
  "strategy_health_paused",
  "execution_loop_failed",
  "scan_loop_failed",
  "position_loop_failed",
  "health_loop_failed",
];

function ActiveTradesSection() {
  const { data, isLoading } = useQuery<{
    ok: boolean;
    positions: any[];
    intents: any[];
    quotes: Record<string, number>;
  }>({
    queryKey: ["/api/autopilot/active-trades"],
    refetchInterval: 15000,
  });

  const openPositions = data?.positions ?? [];
  const intents = data?.intents ?? [];
  const quotes = data?.quotes ?? {};

  function stateColor(state: string) {
    switch (state) {
      case "FILLED": return "bg-emerald-500/20 text-emerald-400 border-emerald-500/30";
      case "ORDER_SUBMITTED": return "bg-blue-500/20 text-blue-400 border-blue-500/30";
      case "RISK_APPROVED": return "bg-cyan-500/20 text-cyan-400 border-cyan-500/30";
      case "REJECTED": case "FAILED": return "bg-red-500/20 text-red-400 border-red-500/30";
      case "EXPIRED": return "bg-gray-500/20 text-gray-400 border-gray-500/30";
      default: return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30";
    }
  }

  return (
    <div className="space-y-4" data-testid="active-trades-section">
      <Card className="glass-panel p-4" data-testid="card-open-positions">
        <div className="flex items-center gap-2 mb-3">
          <Crosshair className="w-4 h-4 text-emerald-400" />
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
            Open Positions ({openPositions.length})
          </h3>
        </div>
        {isLoading ? (
          <div className="space-y-2">
            {[1, 2, 3].map(i => <div key={i} className="h-10 bg-muted/30 rounded animate-pulse" />)}
          </div>
        ) : openPositions.length === 0 ? (
          <p className="text-muted-foreground text-sm">No open positions</p>
        ) : (
          <div className="space-y-2 max-h-80 overflow-y-auto">
            {openPositions.map((p: any) => {
              const meta = (() => { try { return JSON.parse(p.notes || "{}"); } catch { return {}; } })();
              const daysHeld = p.entryDate ? Math.floor((Date.now() - new Date(p.entryDate).getTime()) / 86400000) : 0;
              return (
                <div
                  key={p.id}
                  className="flex items-center justify-between p-2.5 rounded-lg bg-muted/10 border border-muted/20 hover:border-cyan-500/30 transition-colors"
                  data-testid={`position-row-${p.ticker}`}
                >
                  <div className="flex items-center gap-3">
                    <div>
                      <span className="font-mono font-bold text-cyan-400">{p.ticker}</span>
                      <span className="text-xs text-muted-foreground ml-2">
                        {p.shortStrike}/{p.longStrike}p
                      </span>
                    </div>
                    {quotes[p.ticker] > 0 && (
                      <span className="text-xs font-mono font-semibold text-white" data-testid={`quote-${p.ticker}`}>
                        ${quotes[p.ticker].toFixed(2)}
                      </span>
                    )}
                    {quotes[p.ticker] > 0 && (() => {
                      const dist = ((quotes[p.ticker] - p.shortStrike) / quotes[p.ticker] * 100);
                      return <Badge variant="outline" className={`text-[10px] font-mono ${dist > 10 ? "text-emerald-400 border-emerald-500/30" : dist > 5 ? "text-cyan-400 border-cyan-500/30" : "text-amber-400 border-amber-500/30"}`}>{dist.toFixed(1)}% OTM</Badge>;
                    })()}
                    <Badge variant="outline" className="text-[10px] font-mono">
                      {p.contracts}x · ${(p.credit * 100).toFixed(0)} cr
                    </Badge>
                    {p.sector && (
                      <Badge className="text-[10px] px-1.5 py-0 bg-purple-500/10 text-purple-400 border-purple-500/20">
                        {p.sector}
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-3 text-xs font-mono">
                    {(() => { const dte = Math.max(0, Math.ceil((new Date(p.expiration).getTime() - Date.now()) / 86400000)); return <span className={`font-semibold ${dte <= 3 ? "text-red-400" : dte <= 7 ? "text-amber-400" : "text-cyan-400"}`} data-testid={`dte-${p.ticker}`}>{dte} DTE</span>; })()}
                    <span className="text-muted-foreground">{daysHeld}d held</span>
                    <span className="text-amber-400">${p.maxRisk} risk</span>
                    {p.entryDelta && <span className="text-cyan-400">Δ{p.entryDelta}</span>}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Card>

      <Card className="glass-panel p-4" data-testid="card-order-intents">
        <div className="flex items-center gap-2 mb-3">
          <ArrowUpDown className="w-4 h-4 text-cyan-400" />
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
            Recent Order Intents ({intents.length})
          </h3>
        </div>
        {isLoading ? (
          <div className="space-y-2">
            {[1, 2, 3].map(i => <div key={i} className="h-8 bg-muted/30 rounded animate-pulse" />)}
          </div>
        ) : intents.length === 0 ? (
          <p className="text-muted-foreground text-sm">No order intents yet</p>
        ) : (
          <div className="space-y-1.5 max-h-72 overflow-y-auto">
            {intents.map((intent: any) => {
              const meta = (() => { try { return JSON.parse(intent.metadata || "{}"); } catch { return {}; } })();
              return (
                <div
                  key={intent.id}
                  className="flex items-center justify-between py-1.5 px-2.5 rounded bg-muted/10 hover:bg-muted/20 transition-colors"
                  data-testid={`intent-row-${intent.id}`}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground w-16 shrink-0">
                      {new Date(intent.createdAt).toLocaleTimeString()}
                    </span>
                    <span className="font-mono font-semibold text-cyan-400 text-sm">{intent.ticker}</span>
                    <span className="text-xs text-muted-foreground font-mono">
                      {intent.shortStrike}/{intent.longStrike}p
                    </span>
                    <Badge className={`text-[10px] px-1.5 py-0 ${stateColor(intent.state)}`}>
                      {intent.state}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground">
                    {intent.sector && <span className="text-purple-400">{intent.sector}</span>}
                    <span>exp {intent.expiration}</span>
                    {meta.confidence && <span className="text-emerald-400">{meta.confidence}%</span>}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Card>
    </div>
  );
}

export default function AutopilotDashboard() {
  const { data: report, isLoading: reportLoading } = useQuery<HealthReport>({
    queryKey: ["/api/autopilot/health-report"],
    refetchInterval: 30000,
  });

  const { data: eventsData, isLoading: eventsLoading } = useQuery<{ ok: boolean; events: SystemEvent[] }>({
    queryKey: ["/api/autopilot/events"],
    refetchInterval: 15000,
  });

  const { data: controlState, isLoading: controlLoading } = useQuery<{
    ok: boolean;
    state: any;
    settings: any;
    recentManualActions: any[];
  }>({
    queryKey: ["/api/autopilot/control-state"],
    refetchInterval: 15000,
  });

  const { toast } = useToast();

  const invalidateControl = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/autopilot/control-state"] });
    queryClient.invalidateQueries({ queryKey: ["/api/autopilot/health-report"] });
    queryClient.invalidateQueries({ queryKey: ["/api/autopilot/events"] });
  };

  const startMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/autopilot/start"),
    onSuccess: () => { invalidateControl(); toast({ title: "Autopilot started" }); },
    onError: (e: any) => toast({ title: "Start failed", description: String(e?.message || e), variant: "destructive" }),
  });

  const stopMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/autopilot/stop", { reason: "manual" }),
    onSuccess: () => { invalidateControl(); toast({ title: "Autopilot stopped" }); },
    onError: (e: any) => toast({ title: "Stop failed", description: String(e?.message || e), variant: "destructive" }),
  });

  const pauseMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/autopilot/pause", { reason: "manual_pause" }),
    onSuccess: () => { invalidateControl(); toast({ title: "Autopilot paused" }); },
    onError: (e: any) => toast({ title: "Pause failed", description: String(e?.message || e), variant: "destructive" }),
  });

  const resumeMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/autopilot/resume"),
    onSuccess: () => { invalidateControl(); toast({ title: "Autopilot resumed" }); },
    onError: (e: any) => toast({ title: "Resume failed", description: String(e?.message || e), variant: "destructive" }),
  });

  const cancelOrdersMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/autopilot/cancel-all-orders"),
    onSuccess: () => { invalidateControl(); toast({ title: "All orders canceled" }); },
    onError: (e: any) => toast({ title: "Cancel failed", description: String(e?.message || e), variant: "destructive" }),
  });

  const flattenMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/autopilot/flatten-all"),
    onSuccess: () => { invalidateControl(); toast({ title: "All positions flattened" }); },
    onError: (e: any) => toast({ title: "Flatten failed", description: String(e?.message || e), variant: "destructive" }),
  });

  const resetForLiveMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/autopilot/reset-for-live"),
    onSuccess: async (res) => {
      const data = await res.json();
      invalidateControl();
      queryClient.invalidateQueries({ queryKey: ["/api/positions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/autopilot/active-trades"] });
      toast({ title: "Reset complete", description: `Cleared ${data.positionsCleared} positions, ${data.intentsCleared} intents. Mode set to LIVE (paused).` });
    },
    onError: (e: any) => toast({ title: "Reset failed", description: String(e?.message || e), variant: "destructive" }),
  });

  const exitModeMutation = useMutation({
    mutationFn: (mode: string) => apiRequest("POST", "/api/autopilot/exit-mode", { mode }),
    onSuccess: () => { invalidateControl(); toast({ title: "Exit mode updated" }); },
    onError: (e: any) => toast({ title: "Update failed", description: String(e?.message || e), variant: "destructive" }),
  });

  const disableTickerMutation = useMutation({
    mutationFn: (ticker: string) => apiRequest("POST", "/api/autopilot/disable-ticker", { ticker }),
    onSuccess: () => { invalidateControl(); setTickerInput(""); toast({ title: "Ticker disabled" }); },
    onError: (e: any) => toast({ title: "Disable failed", description: String(e?.message || e), variant: "destructive" }),
  });

  const enableTickerMutation = useMutation({
    mutationFn: (ticker: string) => apiRequest("POST", "/api/autopilot/enable-ticker", { ticker }),
    onSuccess: () => { invalidateControl(); toast({ title: "Ticker enabled" }); },
    onError: (e: any) => toast({ title: "Enable failed", description: String(e?.message || e), variant: "destructive" }),
  });

  const setModeMutation = useMutation({
    mutationFn: (mode: string) => apiRequest("POST", "/api/autopilot/set-mode", { mode }),
    onSuccess: () => { invalidateControl(); toast({ title: "Runtime mode updated" }); },
    onError: (e: any) => toast({ title: "Mode change failed", description: String(e?.message || e), variant: "destructive" }),
  });

  const [tickerInput, setTickerInput] = useState("");
  const [logDate, setLogDate] = useState(new Date().toISOString().slice(0, 10));

  const strategy = report?.strategy;
  const fills = report?.fills ?? [];
  const feedback = report?.feedback;
  const state = report?.state;
  const poorFills = fills.filter(f => f.poorFill);

  const ctrlState = controlState?.state;
  const ctrlSettings = controlState?.settings;
  const recentActions = controlState?.recentManualActions ?? [];
  const disabledTickers: string[] = (() => {
    try { return JSON.parse(ctrlSettings?.disabledTickersJson || "[]"); } catch { return []; }
  })();
  const activeModifiers: string[] = (() => {
    try { return JSON.parse(ctrlState?.activeModifiersJson || "[]"); } catch { return []; }
  })();

  const events = (eventsData?.events ?? []).filter(e =>
    EVENT_TYPES_OF_INTEREST.includes(e.eventType)
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 mb-2">
        <Activity className="w-6 h-6 text-cyan-400" />
        <h2 className="text-2xl font-bold" data-testid="text-dashboard-title">Autopilot Dashboard</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="glass-panel p-4" data-testid="card-strategy-score">
          <div className="flex items-center gap-2 mb-2">
            <Brain className="w-4 h-4 text-purple-400" />
            <span className="text-xs text-muted-foreground uppercase tracking-wider">Strategy Score</span>
          </div>
          {reportLoading ? (
            <div className="h-8 bg-muted/30 rounded animate-pulse" />
          ) : (
            <>
              <div className="text-3xl font-bold font-mono" data-testid="text-strategy-score">
                {strategy ? (strategy.score * 100).toFixed(1) : "—"}
              </div>
              {strategy && strategy.trades === 0 && (
                <span className="text-[10px] text-amber-400/70 font-mono">BASELINE · no closed trades</span>
              )}
              {strategy && strategy.trades > 0 && (
                <span className="text-[10px] text-muted-foreground font-mono">{strategy.trades} closed trades</span>
              )}
            </>
          )}
        </Card>

        <Card className="glass-panel p-4" data-testid="card-strategy-mode">
          <div className="flex items-center gap-2 mb-2">
            <Shield className="w-4 h-4 text-cyan-400" />
            <span className="text-xs text-muted-foreground uppercase tracking-wider">Mode</span>
          </div>
          {reportLoading ? (
            <div className="h-8 bg-muted/30 rounded animate-pulse" />
          ) : (
            <>
              <Badge className={`text-sm px-3 py-1 ${modeColor(strategy?.mode ?? "")}`} data-testid="badge-strategy-mode">
                {strategy?.mode?.toUpperCase() ?? "—"}
              </Badge>
              {strategy && (
                <span className="text-[10px] text-muted-foreground font-mono mt-1 block">
                  {strategy.mode === "normal" ? "Full participation" : strategy.mode === "reduced" ? `${(strategy.participationThrottle * 100).toFixed(0)}% participation` : strategy.mode === "defensive" ? `${(strategy.participationThrottle * 100).toFixed(0)}% throttle` : "Halted"}
                </span>
              )}
            </>
          )}
        </Card>

        <Card className="glass-panel p-4" data-testid="card-win-rate">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <span className="text-xs text-muted-foreground uppercase tracking-wider">Win Rate</span>
          </div>
          {reportLoading ? (
            <div className="h-8 bg-muted/30 rounded animate-pulse" />
          ) : (
            <>
              <div className="text-3xl font-bold font-mono" data-testid="text-win-rate">
                {strategy ? (strategy.winRate * 100).toFixed(1) + "%" : "—"}
              </div>
              {strategy && strategy.trades === 0 && (
                <span className="text-[10px] text-amber-400/70 font-mono">DEFAULT · awaiting results</span>
              )}
              {strategy && strategy.trades > 0 && (
                <span className="text-[10px] text-muted-foreground font-mono">from {strategy.trades} trades</span>
              )}
            </>
          )}
        </Card>

        <Card className="glass-panel p-4" data-testid="card-profit-factor">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-4 h-4 text-yellow-400" />
            <span className="text-xs text-muted-foreground uppercase tracking-wider">Profit Factor</span>
          </div>
          {reportLoading ? (
            <div className="h-8 bg-muted/30 rounded animate-pulse" />
          ) : (
            <>
              <div className="text-3xl font-bold font-mono" data-testid="text-profit-factor">
                {strategy ? strategy.profitFactor.toFixed(2) : "—"}
              </div>
              {strategy && strategy.trades === 0 && (
                <span className="text-[10px] text-amber-400/70 font-mono">DEFAULT · awaiting results</span>
              )}
              {strategy && strategy.trades > 0 && (
                <span className="text-[10px] text-muted-foreground font-mono">gross P / gross L</span>
              )}
            </>
          )}
        </Card>
      </div>

      <ActiveTradesSection />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="glass-panel p-4" data-testid="card-operator-controls">
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Operator Controls</h3>
          {controlLoading ? (
            <div className="space-y-2">
              {[1,2,3,4].map(i => <div key={i} className="h-8 bg-muted/30 rounded animate-pulse" />)}
            </div>
          ) : (
            <div className="space-y-4">
              <div className="space-y-2 text-sm font-mono">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Paused</span>
                  <span className={ctrlState?.isPaused ? "text-red-400" : "text-emerald-400"} data-testid="text-ctrl-paused">
                    {ctrlState?.isPaused ? "YES" : "NO"}
                  </span>
                </div>
                {ctrlState?.pauseReason && (
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Reason</span>
                    <span className="text-yellow-400 text-xs" data-testid="text-ctrl-pause-reason">{ctrlState.pauseReason}</span>
                  </div>
                )}
                {ctrlState?.warmModeUntil && (
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Warm Until</span>
                    <span className="text-orange-400 text-xs" data-testid="text-ctrl-warm-until">
                      {new Date(ctrlState.warmModeUntil).toLocaleString()}
                    </span>
                  </div>
                )}
                {activeModifiers.length > 0 && (
                  <div className="flex justify-between items-start">
                    <span className="text-muted-foreground">Modifiers</span>
                    <div className="flex flex-wrap gap-1 justify-end max-w-[60%]" data-testid="text-ctrl-modifiers">
                      {activeModifiers.map((m: string, i: number) => (
                        <Badge key={i} className="text-[10px] px-1.5 py-0 bg-purple-500/20 text-purple-400 border-purple-500/30">{m}</Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div>
                <label className="text-xs text-muted-foreground mb-1 block">Runtime Mode</label>
                <Select
                  value={ctrlState?.mode || "DRY_RUN"}
                  onValueChange={(val) => {
                    if (val === "LIVE" && !confirm("Switch to LIVE mode? This will execute real trades with real money.")) return;
                    setModeMutation.mutate(val);
                  }}
                  disabled={setModeMutation.isPending}
                >
                  <SelectTrigger className="w-full bg-muted/20 border-muted" data-testid="select-runtime-mode">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="DRY_RUN">DRY RUN</SelectItem>
                    <SelectItem value="PAPER">PAPER TRADE</SelectItem>
                    <SelectItem value="LIVE">LIVE</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-[10px] text-muted-foreground mt-1">
                  {ctrlState?.mode === "DRY_RUN" && "Simulated — no orders sent to broker"}
                  {ctrlState?.mode === "PAPER" && "Paper trading — orders simulated with broker quotes"}
                  {ctrlState?.mode === "LIVE" && "Live trading — real orders sent to broker"}
                  {!ctrlState?.mode && "Simulated — no orders sent to broker"}
                </p>
              </div>

              <div className="flex flex-wrap gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  className="border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/10"
                  onClick={() => startMutation.mutate()}
                  disabled={startMutation.isPending || ctrlState?.isEnabled}
                  data-testid="button-start"
                >
                  <Power className="w-3 h-3 mr-1" />
                  Start
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-red-500/30 text-red-400 hover:bg-red-500/10"
                  onClick={() => { if (confirm("Stop the autopilot engine?")) stopMutation.mutate(); }}
                  disabled={stopMutation.isPending || !ctrlState?.isEnabled}
                  data-testid="button-stop"
                >
                  <Square className="w-3 h-3 mr-1" />
                  Stop
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/10"
                  onClick={() => pauseMutation.mutate()}
                  disabled={pauseMutation.isPending || ctrlState?.isPaused || !ctrlState?.isEnabled}
                  data-testid="button-pause"
                >
                  <Pause className="w-3 h-3 mr-1" />
                  Pause
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/10"
                  onClick={() => resumeMutation.mutate()}
                  disabled={resumeMutation.isPending || !ctrlState?.isPaused}
                  data-testid="button-resume"
                >
                  <Play className="w-3 h-3 mr-1" />
                  Resume
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-orange-500/30 text-orange-400 hover:bg-orange-500/10"
                  onClick={() => { if (confirm("Cancel all open orders?")) cancelOrdersMutation.mutate(); }}
                  disabled={cancelOrdersMutation.isPending}
                  data-testid="button-cancel-orders"
                >
                  <XCircle className="w-3 h-3 mr-1" />
                  Cancel Orders
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-red-500/30 text-red-400 hover:bg-red-500/10"
                  onClick={() => { if (confirm("FLATTEN all open positions? This cannot be undone.")) flattenMutation.mutate(); }}
                  disabled={flattenMutation.isPending}
                  data-testid="button-flatten-all"
                >
                  <Zap className="w-3 h-3 mr-1" />
                  Flatten All
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10"
                  onClick={() => { if (confirm("RESET FOR LIVE TRADING?\n\nThis will:\n• Delete all paper/simulated positions\n• Clear all order intents and broker orders\n• Set mode to LIVE (paused)\n\nOnly do this when ready to trade with real money.")) resetForLiveMutation.mutate(); }}
                  disabled={resetForLiveMutation.isPending || ctrlState?.isEnabled}
                  data-testid="button-reset-for-live"
                >
                  <Crosshair className="w-3 h-3 mr-1" />
                  Reset for Live
                </Button>
              </div>

              <div className="mt-3 pt-3 border-t border-muted/30">
                <label className="text-xs text-muted-foreground mb-1.5 block">Download Daily Pick Log</label>
                <div className="flex items-center gap-2">
                  <Input
                    type="date"
                    value={logDate}
                    onChange={(e) => setLogDate(e.target.value)}
                    className="bg-muted/20 border-muted w-40 text-xs"
                    data-testid="input-log-date"
                  />
                  <Button
                    size="sm"
                    variant="outline"
                    className="border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10"
                    onClick={() => {
                      window.open(`/api/autopilot/daily-log?date=${logDate}&format=csv`, "_blank");
                    }}
                    data-testid="button-download-csv"
                  >
                    <Download className="w-3 h-3 mr-1" />
                    CSV
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="border-purple-500/30 text-purple-400 hover:bg-purple-500/10"
                    onClick={() => {
                      window.open(`/api/autopilot/daily-log?date=${logDate}&format=json`, "_blank");
                    }}
                    data-testid="button-download-json"
                  >
                    <Download className="w-3 h-3 mr-1" />
                    JSON
                  </Button>
                </div>
              </div>
            </div>
          )}
        </Card>

        <Card className="glass-panel p-4" data-testid="card-exit-settings">
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Exit Strategy & Settings</h3>
          {controlLoading ? (
            <div className="space-y-2">
              {[1,2,3].map(i => <div key={i} className="h-5 bg-muted/30 rounded animate-pulse" />)}
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">Exit Mode</label>
                <Select
                  value={ctrlSettings?.exitStrategyMode || "HYBRID_SMART_EXIT"}
                  onValueChange={(val) => exitModeMutation.mutate(val)}
                  disabled={exitModeMutation.isPending}
                >
                  <SelectTrigger className="w-full bg-muted/20 border-muted" data-testid="select-exit-mode">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="TAKE_50_ALWAYS">TAKE_50_ALWAYS</SelectItem>
                    <SelectItem value="HOLD_TO_EXPIRATION">HOLD_TO_EXPIRATION</SelectItem>
                    <SelectItem value="HYBRID_SMART_EXIT">HYBRID_SMART_EXIT</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-xs text-muted-foreground mb-1 block">Disable Ticker</label>
                <div className="flex gap-2">
                  <Input
                    className="bg-muted/20 border-muted h-8 text-xs font-mono uppercase"
                    placeholder="e.g. NVDA"
                    value={tickerInput}
                    onChange={(e) => setTickerInput(e.target.value.toUpperCase())}
                    onKeyDown={(e) => { if (e.key === "Enter" && tickerInput.trim()) disableTickerMutation.mutate(tickerInput.trim()); }}
                    data-testid="input-disable-ticker"
                  />
                  <Button
                    size="sm"
                    variant="outline"
                    className="border-red-500/30 text-red-400 hover:bg-red-500/10 h-8 px-3"
                    onClick={() => { if (tickerInput.trim()) disableTickerMutation.mutate(tickerInput.trim()); }}
                    disabled={!tickerInput.trim() || disableTickerMutation.isPending}
                    data-testid="button-disable-ticker"
                  >
                    <Ban className="w-3 h-3 mr-1" />
                    Disable
                  </Button>
                </div>
              </div>

              {disabledTickers.length > 0 && (
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">Disabled Tickers (click to re-enable)</label>
                  <div className="flex flex-wrap gap-1" data-testid="text-disabled-tickers">
                    {disabledTickers.map((t: string) => (
                      <Badge
                        key={t}
                        className="text-[10px] px-1.5 py-0 bg-red-500/20 text-red-400 border-red-500/30 cursor-pointer hover:bg-emerald-500/20 hover:text-emerald-400 hover:border-emerald-500/30 transition-colors"
                        onClick={() => { if (confirm(`Re-enable ${t}?`)) enableTickerMutation.mutate(t); }}
                        data-testid={`badge-disabled-ticker-${t}`}
                      >
                        {t} ×
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </Card>

        <Card className="glass-panel p-4" data-testid="card-recent-actions">
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Recent Manual Actions</h3>
          {controlLoading ? (
            <div className="space-y-2">
              {[1,2,3].map(i => <div key={i} className="h-5 bg-muted/30 rounded animate-pulse" />)}
            </div>
          ) : recentActions.length > 0 ? (
            <div className="space-y-1 max-h-48 overflow-y-auto">
              {recentActions.slice(0, 15).map((a: any, i: number) => (
                <div key={a.id || i} className="flex items-center gap-2 text-xs font-mono py-1" data-testid={`action-row-${i}`}>
                  <span className="text-muted-foreground shrink-0 w-16">
                    {a.createdAt ? new Date(a.createdAt).toLocaleTimeString() : "—"}
                  </span>
                  <Badge className="text-[10px] px-1.5 py-0 bg-cyan-500/20 text-cyan-400 border-cyan-500/30">{a.actionType}</Badge>
                  {a.target && <span className="text-yellow-400 truncate">{a.target}</span>}
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground text-sm">No manual actions yet</p>
          )}
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="glass-panel p-4" data-testid="card-autopilot-state">
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Autopilot State</h3>
          {reportLoading ? (
            <div className="space-y-2">
              {[1,2,3,4].map(i => <div key={i} className="h-5 bg-muted/30 rounded animate-pulse" />)}
            </div>
          ) : state ? (
            <div className="space-y-2 text-sm font-mono">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Enabled</span>
                <span data-testid="text-state-enabled">{state.isEnabled ? "YES" : "NO"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Paused</span>
                <span className={state.isPaused ? "text-red-400" : "text-emerald-400"} data-testid="text-state-paused">
                  {state.isPaused ? "YES" : "NO"}
                </span>
              </div>
              {state.pauseReason && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Reason</span>
                  <span className="text-yellow-400 text-xs" data-testid="text-pause-reason">{state.pauseReason}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-muted-foreground">Mode</span>
                <span data-testid="text-state-mode">{state.mode}</span>
              </div>
              {state.lastScanAt && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Last Scan</span>
                  <span className="text-xs" data-testid="text-last-scan">{new Date(state.lastScanAt).toLocaleTimeString()}</span>
                </div>
              )}
              {state.lastHealthAt && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Last Health</span>
                  <span className="text-xs" data-testid="text-last-health">{new Date(state.lastHealthAt).toLocaleTimeString()}</span>
                </div>
              )}
            </div>
          ) : (
            <p className="text-muted-foreground text-sm">No autopilot state found</p>
          )}
        </Card>

        <Card className="glass-panel p-4" data-testid="card-feedback-summary">
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Performance (60d)</h3>
          {reportLoading ? (
            <div className="space-y-2">
              {[1,2,3].map(i => <div key={i} className="h-5 bg-muted/30 rounded animate-pulse" />)}
            </div>
          ) : feedback ? (
            <div className="space-y-2 text-sm font-mono">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Trades</span>
                <span data-testid="text-total-trades">{feedback.totalTrades}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total P&L</span>
                <span className={feedback.totalPnl >= 0 ? "text-emerald-400" : "text-red-400"} data-testid="text-total-pnl">
                  ${feedback.totalPnl?.toFixed(2) ?? "0.00"}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Win Rate</span>
                <span data-testid="text-feedback-winrate">{(feedback.winRate * 100).toFixed(1)}%</span>
              </div>
              {strategy && (
                <>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Part. Throttle</span>
                    <span data-testid="text-participation-throttle">{(strategy.participationThrottle * 100).toFixed(0)}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Risk Throttle</span>
                    <span data-testid="text-risk-throttle">{(strategy.riskThrottle * 100).toFixed(0)}%</span>
                  </div>
                </>
              )}
            </div>
          ) : (
            <p className="text-muted-foreground text-sm">No feedback data</p>
          )}
        </Card>

        <Card className="glass-panel p-4" data-testid="card-poor-fills">
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle className="w-4 h-4 text-orange-400" />
            <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Poor Fill Tickers</h3>
          </div>
          {reportLoading ? (
            <div className="space-y-2">
              {[1,2,3].map(i => <div key={i} className="h-5 bg-muted/30 rounded animate-pulse" />)}
            </div>
          ) : poorFills.length > 0 ? (
            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              {poorFills.slice(0, 10).map(f => (
                <div key={f.ticker} className="flex justify-between items-center text-xs font-mono" data-testid={`poor-fill-${f.ticker}`}>
                  <span className="text-orange-400 font-semibold">{f.ticker}</span>
                  <div className="flex gap-3 text-muted-foreground">
                    <span>slip: {(f.avgEntrySlippagePct * 100).toFixed(1)}%</span>
                    <span>{f.avgFillMinutes.toFixed(1)}m</span>
                    <span>{f.trades} trades</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-emerald-400 text-sm">No poor fills detected</p>
          )}
        </Card>
      </div>

      <Card className="glass-panel p-4" data-testid="card-system-events">
        <div className="flex items-center gap-2 mb-3">
          <Clock className="w-4 h-4 text-blue-400" />
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Recent System Events</h3>
          <span className="text-xs text-muted-foreground ml-auto">{events.length} events</span>
        </div>
        {eventsLoading ? (
          <div className="space-y-2">
            {[1,2,3,4,5].map(i => <div key={i} className="h-8 bg-muted/30 rounded animate-pulse" />)}
          </div>
        ) : events.length > 0 ? (
          <div className="space-y-1 max-h-96 overflow-y-auto">
            {events.slice(0, 50).map((ev, i) => (
              <div
                key={ev.id || i}
                className="flex items-start gap-3 py-1.5 px-2 rounded hover:bg-muted/20 transition-colors text-xs font-mono"
                data-testid={`event-row-${i}`}
              >
                <Badge className={`text-[10px] px-1.5 py-0 shrink-0 ${severityBadge(ev.severity)}`}>
                  {ev.severity}
                </Badge>
                <span className="text-muted-foreground shrink-0 w-16">
                  {ev.createdAt ? new Date(ev.createdAt).toLocaleTimeString() : "—"}
                </span>
                <span className="text-cyan-400 shrink-0 w-44 truncate">{ev.eventType}</span>
                <span className={`truncate ${severityColor(ev.severity)}`}>{ev.message}</span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-muted-foreground text-sm">No recent events</p>
        )}
      </Card>
    </div>
  );
}
