import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calculator, Target, TrendingUp, ShieldAlert } from "lucide-react";

export default function CalculatorPage() {
  const [form, setForm] = useState({
    shortStrike: "",
    longStrike: "",
    credit: "",
    currentPrice: "",
    contracts: "1",
  });
  const [showResults, setShowResults] = useState(false);

  const update = (key: string, value: string) => setForm(prev => ({ ...prev, [key]: value }));

  const shortStrike = parseFloat(form.shortStrike);
  const longStrike = parseFloat(form.longStrike);
  const credit = parseFloat(form.credit);
  const currentPrice = parseFloat(form.currentPrice);
  const contracts = parseInt(form.contracts);

  const valid = !isNaN(shortStrike) && !isNaN(longStrike) && !isNaN(credit) && !isNaN(currentPrice) && !isNaN(contracts);

  const width = shortStrike - longStrike;
  const maxRisk = width - credit;
  const maxProfit = credit;
  const currentPL = valid ? (credit - currentPrice) * 100 * contracts : 0;
  const plPercent = valid ? ((credit - currentPrice) / credit) * 100 : 0;

  const target25 = credit * 0.25;
  const target50 = credit * 0.5;
  const target75 = credit * 0.75;
  const target90 = credit * 0.9;

  const exit25Price = credit - target25;
  const exit50Price = credit - target50;
  const exit75Price = credit - target75;
  const exit90Price = credit - target90;

  const calculate = () => {
    if (!valid) return;
    setShowResults(true);
  };

  return (
    <div className="space-y-6">
      <Card className="glass-panel p-6">
        <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
          <Calculator className="w-5 h-5 text-chart-1" />
          Exit Price Calculator
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <div>
            <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Short Strike</Label>
            <Input type="number" placeholder="450" step="0.50" value={form.shortStrike} onChange={e => update("shortStrike", e.target.value)} className="font-mono" data-testid="input-calc-short" />
          </div>
          <div>
            <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Long Strike</Label>
            <Input type="number" placeholder="445" step="0.50" value={form.longStrike} onChange={e => update("longStrike", e.target.value)} className="font-mono" data-testid="input-calc-long" />
          </div>
          <div>
            <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Entry Credit</Label>
            <Input type="number" placeholder="1.50" step="0.01" value={form.credit} onChange={e => update("credit", e.target.value)} className="font-mono" data-testid="input-calc-credit" />
          </div>
          <div>
            <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Current Price of Spread</Label>
            <Input type="number" placeholder="0.75" step="0.01" value={form.currentPrice} onChange={e => update("currentPrice", e.target.value)} className="font-mono" data-testid="input-calc-current" />
          </div>
          <div>
            <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Contracts</Label>
            <Input type="number" min="1" value={form.contracts} onChange={e => update("contracts", e.target.value)} className="font-mono" data-testid="input-calc-contracts" />
          </div>
        </div>

        <Button
          className="w-full font-bold tracking-wider uppercase"
          size="lg"
          onClick={calculate}
          disabled={!valid}
          data-testid="button-calculate"
        >
          <Calculator className="w-5 h-5" />
          CALCULATE EXIT
        </Button>

        {showResults && valid && (
          <div className="border-t border-border pt-6 mt-6">
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
              <Target className="w-5 h-5 text-chart-1" />
              Exit Analysis
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <Card className="p-4 bg-accent/30 border-border">
                <p className="text-xs text-muted-foreground mb-1">CURRENT P&L</p>
                <p className={`text-3xl font-bold font-mono ${currentPL >= 0 ? "text-profit" : "text-loss"}`} data-testid="text-current-pl">
                  {currentPL >= 0 ? "+" : ""}${currentPL.toFixed(2)}
                </p>
                <p className="text-sm text-muted-foreground mt-1">{plPercent.toFixed(1)}% Return</p>
              </Card>
              <Card className="p-4 bg-accent/30 border-border">
                <p className="text-xs text-muted-foreground mb-1">50% TARGET</p>
                <p className="text-2xl font-bold font-mono text-profit">
                  ${(target50 * 100 * contracts).toFixed(2)}
                </p>
                <p className="text-sm text-muted-foreground mt-1">Exit at: ${exit50Price.toFixed(2)}</p>
              </Card>
              <Card className="p-4 bg-accent/30 border-border">
                <p className="text-xs text-muted-foreground mb-1">75% TARGET</p>
                <p className="text-2xl font-bold font-mono text-profit-alt">
                  ${(target75 * 100 * contracts).toFixed(2)}
                </p>
                <p className="text-sm text-muted-foreground mt-1">Exit at: ${exit75Price.toFixed(2)}</p>
              </Card>
            </div>

            <div className="mb-6">
              <h4 className="text-base font-bold mb-3 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-chart-5" />
                Profit Targets
              </h4>
              <div className="space-y-2">
                {[
                  { label: "25% Profit", value: target25, exitAt: exit25Price, colorClass: "text-chart-1" },
                  { label: "50% Profit (Recommended)", value: target50, exitAt: exit50Price, colorClass: "text-profit" },
                  { label: "75% Profit", value: target75, exitAt: exit75Price, colorClass: "text-profit-alt" },
                  { label: "90% Profit", value: target90, exitAt: exit90Price, colorClass: "text-chart-2" },
                ].map(t => (
                  <Card key={t.label} className="flex flex-wrap justify-between items-center gap-2 p-3 bg-accent/30 border-border">
                    <span className="text-sm">{t.label}</span>
                    <span className={`font-bold font-mono text-sm ${t.colorClass}`}>
                      ${(t.value * 100 * contracts).toFixed(2)} @ ${t.exitAt.toFixed(2)}
                    </span>
                  </Card>
                ))}
              </div>
            </div>

            <div>
              <h4 className="text-base font-bold mb-3 flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-destructive" />
                Risk Metrics
              </h4>
              <div className="grid grid-cols-2 gap-3">
                <div className="text-sm">
                  <span className="text-muted-foreground">Max Risk: </span>
                  <span className="font-bold font-mono text-destructive" data-testid="text-max-risk">${(maxRisk * 100 * contracts).toFixed(2)}</span>
                </div>
                <div className="text-sm">
                  <span className="text-muted-foreground">Max Profit: </span>
                  <span className="font-bold font-mono text-profit" data-testid="text-max-profit">${(maxProfit * 100 * contracts).toFixed(2)}</span>
                </div>
                <div className="text-sm">
                  <span className="text-muted-foreground">Breakeven: </span>
                  <span className="font-bold font-mono" data-testid="text-breakeven">${(shortStrike - credit).toFixed(2)}</span>
                </div>
                <div className="text-sm">
                  <span className="text-muted-foreground">Return on Risk: </span>
                  <span className="font-bold font-mono text-chart-1" data-testid="text-ror">{((credit / maxRisk) * 100).toFixed(1)}%</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}
