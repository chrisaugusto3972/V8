
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

type AuthPayload = {
  ok: boolean;
  authenticated: boolean;
  user?: {
    id: string;
    email: string;
    name: string;
  } | null;
  currentWorkspace?: {
    id: string;
    name: string;
  } | null;
  currentAccount?: {
    id: string;
    name: string;
    platform: "paper" | "tastytrade";
    mode: "manual" | "assisted" | "paper_autopilot";
  } | null;
};

async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers || {}),
    },
    ...init,
  });
  const json = await res.json();
  if (!res.ok) {
    throw new Error(json?.message || "Request failed");
  }
  return json;
}

export function useAuth() {
  return useQuery<AuthPayload>({
    queryKey: ["/api/auth/me"],
    queryFn: () => api<AuthPayload>("/api/auth/me"),
  });
}

export function useLogin() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (payload: { email: string; password: string }) =>
      api<AuthPayload>("/api/auth/login", {
        method: "POST",
        body: JSON.stringify(payload),
      }),
    onSuccess: (data) => {
      qc.setQueryData(["/api/auth/me"], data);
    },
  });
}

export function useRegister() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (payload: { name: string; email: string; password: string; workspaceName?: string }) =>
      api<AuthPayload>("/api/auth/register", {
        method: "POST",
        body: JSON.stringify(payload),
      }),
    onSuccess: (data) => {
      qc.setQueryData(["/api/auth/me"], data);
    },
  });
}

export function useLogout() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () =>
      api<{ ok: boolean }>("/api/auth/logout", {
        method: "POST",
      }),
    onSuccess: () => {
      qc.setQueryData(["/api/auth/me"], { ok: true, authenticated: false });
    },
  });
}
