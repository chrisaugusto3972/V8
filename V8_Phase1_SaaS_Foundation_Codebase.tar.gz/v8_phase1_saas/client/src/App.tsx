import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import ScannerPage from "@/pages/scanner";
import PositionsPage from "@/pages/positions";
import CalculatorPage from "@/pages/calculator";
import JournalPage from "@/pages/journal";
import SettingsPage from "@/pages/settings";
import AutopilotDashboard from "@/pages/autopilot-dashboard";
import PortfolioGreeksPage from "@/pages/portfolio-greeks";
import NotFound from "@/pages/not-found";
import LoginPage from "@/pages/login";
import DashboardPage from "@/pages/dashboard";
import PlatformsPage from "@/pages/platforms";
import BillingPage from "@/pages/billing";
import { useAuth } from "@/hooks/use-auth";
import { AppShell } from "@/components/app-shell";

function ShellPage({ title, children }: { title: string; children: React.ReactNode }) {
  return <AppShell title={title}>{children}</AppShell>;
}

function AuthenticatedRoutes() {
  return (
    <Switch>
      <Route path="/" component={DashboardPage} />
      <Route path="/scanner">
        {() => (
          <ShellPage title="Scanner">
            <ScannerPage />
          </ShellPage>
        )}
      </Route>
      <Route path="/positions">
        {() => (
          <ShellPage title="Positions">
            <PositionsPage />
          </ShellPage>
        )}
      </Route>
      <Route path="/greeks">
        {() => (
          <ShellPage title="Risk">
            <PortfolioGreeksPage />
          </ShellPage>
        )}
      </Route>
      <Route path="/calculator">
        {() => (
          <ShellPage title="Exit Calculator">
            <CalculatorPage />
          </ShellPage>
        )}
      </Route>
      <Route path="/journal">
        {() => (
          <ShellPage title="Journal">
            <JournalPage />
          </ShellPage>
        )}
      </Route>
      <Route path="/autopilot">
        {() => (
          <ShellPage title="Autopilot">
            <AutopilotDashboard />
          </ShellPage>
        )}
      </Route>
      <Route path="/settings">
        {() => (
          <ShellPage title="Settings">
            <SettingsPage />
          </ShellPage>
        )}
      </Route>
      <Route path="/platforms" component={PlatformsPage} />
      <Route path="/billing" component={BillingPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function AppContent() {
  const { data, isLoading } = useAuth();

  if (isLoading) {
    return <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center">Loading V8 SaaS...</div>;
  }

  if (!data?.authenticated) {
    return <LoginPage />;
  }

  return <AuthenticatedRoutes />;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <AppContent />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
