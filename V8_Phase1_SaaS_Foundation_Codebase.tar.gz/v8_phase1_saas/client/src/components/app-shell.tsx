import React from "react";
import { Link, useLocation } from "wouter";
import { LayoutDashboard, Search, Briefcase, Shield, Activity, BookOpen, Settings, CreditCard, Plug } from "lucide-react";
import { useAuth, useLogout } from "@/hooks/use-auth";

const navItems = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/scanner", label: "Scanner", icon: Search },
  { href: "/positions", label: "Positions", icon: Briefcase },
  { href: "/greeks", label: "Risk", icon: Shield },
  { href: "/autopilot", label: "Autopilot", icon: Activity },
  { href: "/journal", label: "Journal", icon: BookOpen },
  { href: "/platforms", label: "Platforms", icon: Plug },
  { href: "/billing", label: "Billing", icon: CreditCard },
  { href: "/settings", label: "Settings", icon: Settings },
] as const;

export function AppShell({ title, children }: { title: string; children: React.ReactNode }) {
  const [location] = useLocation();
  const { data } = useAuth();
  const logout = useLogout();

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <div className="flex min-h-screen">
        <aside className="hidden md:flex w-72 shrink-0 flex-col border-r border-slate-800 bg-slate-925">
          <div className="px-6 py-5 border-b border-slate-800">
            <div className="text-[11px] uppercase tracking-[0.22em] text-slate-400">V8 SaaS</div>
            <div className="mt-1 text-lg font-semibold text-white">Institutional Options OS</div>
          </div>
          <nav className="flex-1 px-3 py-4 space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = location === item.href;
              return (
                <Link key={item.href} href={item.href}>
                  <a className={[
                    "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors",
                    active ? "bg-slate-800 text-white" : "text-slate-300 hover:bg-slate-900 hover:text-white",
                  ].join(" ")}>
                    <Icon className="h-4 w-4" />
                    <span>{item.label}</span>
                  </a>
                </Link>
              );
            })}
          </nav>
          <div className="border-t border-slate-800 p-4 text-xs text-slate-400">
            <div>{data?.user?.name || "Guest"}</div>
            <div className="mt-1">{data?.currentWorkspace?.name || "No Workspace"}</div>
            <button onClick={() => logout.mutate()} className="mt-3 rounded-md border border-slate-700 px-3 py-2 text-slate-300 hover:bg-slate-900">
              Sign out
            </button>
          </div>
        </aside>
        <div className="flex-1 min-w-0">
          <header className="border-b border-slate-800 bg-slate-950/90 backdrop-blur">
            <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-4">
              <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
                <div>
                  <div className="text-[11px] uppercase tracking-[0.22em] text-slate-400">Workspace</div>
                  <h1 className="text-xl font-semibold text-white">{title}</h1>
                </div>
                <div className="flex flex-wrap items-center gap-3 text-sm">
                  <div className="rounded-full border border-emerald-700/40 bg-emerald-900/20 px-3 py-1 text-emerald-300">
                    {data?.currentAccount?.platform === "tastytrade" ? "Tastytrade" : "Paper Account"}
                  </div>
                  <div className="rounded-full border border-blue-700/40 bg-blue-900/20 px-3 py-1 text-blue-300">
                    {data?.currentAccount?.mode || "manual"}
                  </div>
                </div>
              </div>
            </div>
          </header>
          <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-6">{children}</main>
        </div>
      </div>
    </div>
  );
}
