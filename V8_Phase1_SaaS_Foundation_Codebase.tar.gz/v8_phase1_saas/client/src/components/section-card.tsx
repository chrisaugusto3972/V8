import React from "react";

export function SectionCard({ title, subtitle, children }: { title?: string; subtitle?: string; children: React.ReactNode }) {
  return (
    <section className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5">
      {title ? (
        <div className="mb-4">
          <div className="text-base font-semibold text-white">{title}</div>
          {subtitle ? <div className="mt-1 text-sm text-slate-400">{subtitle}</div> : null}
        </div>
      ) : null}
      {children}
    </section>
  );
}
