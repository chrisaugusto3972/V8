# TastyTrade Broker Setup (OAuth2)

TastyTrade uses OAuth2 authentication with separate production and sandbox environments.

## Required Secrets (Replit Secrets tab)

| Secret | Description |
|--------|-------------|
| `TASTYTRADE_ENV` | `sandbox` or `production` (defaults to `sandbox`) |
| `TASTYTRADE_ACCOUNT_NUMBER` | Your TastyTrade account number (e.g., `5WT12345`) |
| `TASTYTRADE_CLIENT_ID` | OAuth2 client ID from TastyTrade developer portal |
| `TASTYTRADE_CLIENT_SECRET` | OAuth2 client secret |
| `TASTYTRADE_REFRESH_TOKEN` | OAuth2 refresh token (long-lived) |

### Optional

| Secret | Description |
|--------|-------------|
| `TASTYTRADE_BASE_URL` | Override API base URL (auto-set from `TASTYTRADE_ENV` if not provided) |

### Auto-resolved URLs

| Environment | API Base URL |
|-------------|-------------|
| `sandbox` | `https://api.cert.tastyworks.com` |
| `production` | `https://api.tastyworks.com` |

## Already configured (no action needed)

| Secret | Description |
|--------|-------------|
| `DATABASE_URL` | PostgreSQL connection (auto-provisioned by Replit) |
| `SESSION_SECRET` | Express session secret |

## How OAuth2 works in this app

1. You provide a long-lived **refresh token** along with your client ID and secret
2. The app automatically exchanges the refresh token for a short-lived access token
3. Access tokens are cached in memory and auto-refreshed when they expire
4. If a request gets a 401, the app automatically retries with a fresh token

## Verifying your setup

After adding secrets, hit this endpoint to check:

```
GET /api/broker/status
```

Response when not configured:
```json
{
  "ok": true,
  "env": "sandbox",
  "credentialsConfigured": false,
  "missingSecrets": ["TASTYTRADE_ACCOUNT_NUMBER", "TASTYTRADE_CLIENT_ID", ...]
}
```

Response when configured and healthy:
```json
{
  "ok": true,
  "env": "sandbox",
  "credentialsConfigured": true,
  "health": { "ok": true, "env": "sandbox", "balances": {...} }
}
```

## Recommended rollout

1. **DRY_RUN** — Set autopilot mode to DRY_RUN (no broker calls made)
2. **PAPER** — Connect sandbox credentials, set mode to PAPER
3. **LIVE** — Switch `TASTYTRADE_ENV` to `production`, use production credentials, set mode to LIVE with 1 contract max
