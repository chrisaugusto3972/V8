import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, boolean, serial, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const positions = pgTable("positions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  ticker: text("ticker").notNull(),
  expiration: text("expiration").notNull(),
  shortStrike: real("short_strike").notNull(),
  longStrike: real("long_strike").notNull(),
  contracts: integer("contracts").notNull().default(1),
  width: real("width").notNull().default(0),

  credit: real("credit").notNull().default(0),
  entryCredit: real("entry_credit").notNull().default(0),
  currentMark: real("current_mark").notNull().default(0),
  maxRisk: real("max_risk").notNull().default(0),

  entryDate: text("entry_date").notNull().default(sql`CURRENT_TIMESTAMP`),
  openedAt: text("opened_at"),
  closedAt: text("closed_at"),

  status: text("status").notNull().default("open"),
  notes: text("notes"),

  sector: text("sector"),
  subIndustry: text("sub_industry"),
  confidence: real("confidence"),
  liquidityScore: real("liquidity_score"),
  entryDelta: real("entry_delta"),
  entryDte: integer("entry_dte"),
  beta: real("beta"),
  brokerOrderId: text("broker_order_id"),

  entryWidth: real("entry_width"),
  entryConfidence: integer("entry_confidence"),
  entryLiquidityScore: integer("entry_liquidity_score"),
  entryRegime: text("entry_regime"),
  exitStrategyMode: text("exit_strategy_mode").default("HYBRID_SMART_EXIT"),
  maxLoss: real("max_loss"),

  realizedPnl: real("realized_pnl"),
  realizedPnlPct: real("realized_pnl_pct"),

  updatedAt: text("updated_at"),
  createdAt: text("created_at"),

  engineVersion: varchar("engine_version", { length: 64 }),
  selectionVersion: varchar("selection_version", { length: 64 }),

  underlyingPrice: real("underlying_price"),
  shortDelta: real("short_delta"),
  longDelta: real("long_delta"),
  netDelta: real("net_delta"),
  shortTheta: real("short_theta"),
  longTheta: real("long_theta"),
  netTheta: real("net_theta"),
  betaWeightedDelta: real("beta_weighted_delta"),
  entryMidpoint: real("entry_midpoint"),
  entryBid: real("entry_bid"),
  entryAsk: real("entry_ask"),
  exitMidpoint: real("exit_midpoint"),
  exitBid: real("exit_bid"),
  exitAsk: real("exit_ask"),
});

export const journalEntries = pgTable("journal_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  ticker: text("ticker").notNull(),
  shortStrike: real("short_strike").notNull(),
  longStrike: real("long_strike").notNull(),
  credit: real("credit").notNull(),
  contracts: integer("contracts").notNull().default(1),
  expiration: text("expiration").notNull(),
  entryDate: text("entry_date").notNull(),
  exitDate: text("exit_date").notNull(),
  exitPrice: real("exit_price").notNull(),
  pl: real("pl").notNull(),
  plPercent: real("pl_percent").notNull(),
  maxRisk: real("max_risk").notNull(),
  notes: text("notes"),
  entryDelta: real("entry_delta"),
  entryDte: integer("entry_dte"),
  entryWidth: real("entry_width"),
  entryConfidence: integer("entry_confidence"),
  entryLiquidityScore: integer("entry_liquidity_score"),
  entryRegime: text("entry_regime"),
});

export const scannerSettings = pgTable("scanner_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tickers: text("tickers").notNull().default("SPY,QQQ,IWM,DIA,EEM,EWZ,XLE,XLF,SMH,TLT,GLD,SLV,AAPL,MSFT,GOOGL,AMZN,META,TSLA,NVDA,JPM,BAC,WMT,DIS,NFLX,AMD,CRM,ORCL,INTC,COIN,PLTR,KO,PG,JNJ,PEP,MCD,XOM,CVX,GS,UNH,COST"),
  dteRange: text("dte_range").notNull().default("8-21"),
  deltaRange: text("delta_range").notNull().default("0.10-0.15"),
  spreadWidth: integer("spread_width").notNull().default(2),
  minCredit: real("min_credit").notNull().default(0.18),
  minVolume: integer("min_volume").notNull().default(0),
  maxSpread: real("max_spread").notNull().default(0.15),
  minIVPercentile: integer("min_iv_percentile").notNull().default(25),
  maxResults: integer("max_results").notNull().default(20),
  refreshInterval: integer("refresh_interval").notNull().default(5),
  notifyNewTrades: boolean("notify_new_trades").notNull().default(true),
  notifyProfitTargets: boolean("notify_profit_targets").notNull().default(true),
  maxPositionSize: integer("max_position_size").notNull().default(1500),
  maxPortfolioRisk: integer("max_portfolio_risk").notNull().default(50),
  accountSize: text("account_size").notNull().default("small"),
  minCreditPct: real("min_credit_pct").notNull().default(25),
  minDistancePct: real("min_distance_pct").notNull().default(5),
  minOI: integer("min_oi").notNull().default(100),
  vixLowThreshold: real("vix_low_threshold").notNull().default(15),
  vixHighThreshold: real("vix_high_threshold").notNull().default(25),
  useVixRegime: boolean("use_vix_regime").notNull().default(true),
  maxRiskPerTrade: integer("max_risk_per_trade").notNull().default(75),
  maxSlippageRatio: real("max_slippage_ratio").notNull().default(1.5),
  exitStrategyMode: text("exit_strategy_mode").notNull().default("HYBRID_SMART_EXIT"),
  profileJson: text("profile_json"),
});

export const orderIntents = pgTable("order_intents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  dedupeKey: text("dedupe_key").notNull(),
  ticker: text("ticker").notNull(),
  sector: text("sector").notNull().default("Unknown"),
  expiration: text("expiration").notNull(),
  shortStrike: real("short_strike").notNull(),
  longStrike: real("long_strike").notNull(),
  width: real("width").notNull(),
  intendedCredit: real("intended_credit").notNull(),
  contracts: integer("contracts").notNull().default(1),
  confidence: integer("confidence").notNull().default(0),
  liquidityScore: integer("liquidity_score").notNull().default(0),
  state: text("state").notNull().default("SCANNED"),
  mode: text("mode").notNull().default("v8"),
  metadata: text("metadata"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  engineVersion: varchar("engine_version", { length: 64 }),
  selectionVersion: varchar("selection_version", { length: 64 }),
});

export const brokerOrders = pgTable("broker_orders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orderIntentId: varchar("order_intent_id"),
  positionId: varchar("position_id"),
  brokerOrderId: text("broker_order_id"),
  ticker: text("ticker"),
  side: text("side"),
  accountNumber: text("account_number"),
  status: text("status").notNull().default("created"),
  requestedPrice: real("requested_price"),
  fillPrice: real("fill_price"),
  filledQuantity: integer("filled_quantity"),
  rawResponse: text("raw_response"),
  rawJson: text("raw_json"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  engineVersion: varchar("engine_version", { length: 64 }),
  selectionVersion: varchar("selection_version", { length: 64 }),
  executionPolicy: text("execution_policy"),
  initialLimit: real("initial_limit"),
  lastLimit: real("last_limit"),
  repriceCount: integer("reprice_count"),
  intentType: text("intent_type"),
});

export const systemEvents = pgTable("system_events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  severity: text("severity").notNull().default("info"),
  eventType: text("event_type").notNull(),
  message: text("message").notNull(),
  payload: text("payload"),
  resolved: boolean("resolved").notNull().default(false),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  engineVersion: varchar("engine_version", { length: 64 }),
});

export const autopilotState = pgTable("autopilot_state", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  mode: text("mode").notNull().default("DRY_RUN"),
  isEnabled: boolean("is_enabled").notNull().default(false),
  isPaused: boolean("is_paused").notNull().default(true),
  pauseReason: text("pause_reason"),
  pausedUntil: text("paused_until"),
  lastHeartbeatAt: text("last_heartbeat_at"),
  lastScanAt: text("last_scan_at"),
  lastReconAt: text("last_recon_at"),
  lastHealthAt: text("last_health_at"),
  warmModeUntil: text("warm_mode_until"),
  configJson: text("config_json"),
  activeModifiersJson: text("active_modifiers_json"),
});

export const appSettings = pgTable("app_settings", {
  id: serial("id").primaryKey(),
  exitStrategyMode: text("exit_strategy_mode").default("HYBRID_SMART_EXIT"),
  disabledTickersJson: text("disabled_tickers_json").default("[]"),
  disabledSectorsJson: text("disabled_sectors_json").default("[]"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const manualActions = pgTable("manual_actions", {
  id: serial("id").primaryKey(),
  actionType: text("action_type").notNull(),
  target: text("target"),
  notes: text("notes"),
  payload: text("payload"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const portfolioSnapshots = pgTable("portfolio_snapshots", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  engineVersion: varchar("engine_version", { length: 64 }),
  selectionVersion: varchar("selection_version", { length: 64 }),
  openPositionsCount: integer("open_positions_count"),
  totalMaxRisk: real("total_max_risk"),
  totalNetDelta: real("total_net_delta"),
  totalNetTheta: real("total_net_theta"),
  betaWeightedDelta: real("beta_weighted_delta"),
  highBetaRisk: real("high_beta_risk"),
  singleStockRisk: real("single_stock_risk"),
  etfRisk: real("etf_risk"),
  sectorExposureJson: text("sector_exposure_json"),
  tickerExposureJson: text("ticker_exposure_json"),
  stressSpyDown1pct: real("stress_spy_down_1pct"),
  stressSpyDown2pct: real("stress_spy_down_2pct"),
  stressSpyDown3pct: real("stress_spy_down_3pct"),
  stressVolUp5: real("stress_vol_up_5"),
  stressVolUp10: real("stress_vol_up_10"),
});

export const executionAnalytics = pgTable("execution_analytics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  brokerOrderId: text("broker_order_id"),
  positionId: varchar("position_id"),
  ticker: text("ticker"),
  side: text("side"),
  intentType: text("intent_type"),
  bidAtSubmit: real("bid_at_submit"),
  askAtSubmit: real("ask_at_submit"),
  midpointAtSubmit: real("midpoint_at_submit"),
  initialLimit: real("initial_limit"),
  finalFillPrice: real("final_fill_price"),
  bestPossiblePriceProxy: real("best_possible_price_proxy"),
  worstPossiblePriceProxy: real("worst_possible_price_proxy"),
  fillQualityVsMidpoint: real("fill_quality_vs_midpoint"),
  fillQualityVsBidAsk: real("fill_quality_vs_bid_ask"),
  timeToFillSeconds: real("time_to_fill_seconds"),
  repriceCount: integer("reprice_count"),
  regime: text("regime"),
  engineVersion: varchar("engine_version", { length: 64 }),
  selectionVersion: varchar("selection_version", { length: 64 }),
});

export const insertPositionSchema = createInsertSchema(positions).omit({ id: true });
export const insertJournalEntrySchema = createInsertSchema(journalEntries).omit({ id: true });
export const insertScannerSettingsSchema = createInsertSchema(scannerSettings).omit({ id: true });
export const insertOrderIntentSchema = createInsertSchema(orderIntents).omit({ id: true });
export const insertBrokerOrderSchema = createInsertSchema(brokerOrders).omit({ id: true });
export const insertSystemEventSchema = createInsertSchema(systemEvents).omit({ id: true });
export const insertAutopilotStateSchema = createInsertSchema(autopilotState).omit({ id: true });

export type Position = typeof positions.$inferSelect;
export type InsertPosition = z.infer<typeof insertPositionSchema>;
export type JournalEntry = typeof journalEntries.$inferSelect;
export type InsertJournalEntry = z.infer<typeof insertJournalEntrySchema>;
export type ScannerSettings = typeof scannerSettings.$inferSelect;
export type InsertScannerSettings = z.infer<typeof insertScannerSettingsSchema>;
export type OrderIntent = typeof orderIntents.$inferSelect;
export type InsertOrderIntent = z.infer<typeof insertOrderIntentSchema>;
export type BrokerOrder = typeof brokerOrders.$inferSelect;
export type InsertBrokerOrder = z.infer<typeof insertBrokerOrderSchema>;
export type SystemEvent = typeof systemEvents.$inferSelect;
export type InsertSystemEvent = z.infer<typeof insertSystemEventSchema>;
export type AutopilotState = typeof autopilotState.$inferSelect;
export type InsertAutopilotState = z.infer<typeof insertAutopilotStateSchema>;
