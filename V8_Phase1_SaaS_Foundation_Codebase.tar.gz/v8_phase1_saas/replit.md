# Institutional Scanner Pro

## Overview
A full-stack professional options trading suite for scanning, managing, and analyzing put credit spread positions. Uses TastyTrade API for real-time options data, VIX regime detection, and confidence scoring. PostgreSQL for persistent positions, journal, and settings.

## Pages
1. **Scanner** (`/`) — Scan for put spread opportunities with configurable parameters
2. **Positions** (`/positions`) — Track open positions with CRUD and close-to-journal flow
3. **Portfolio Greeks** (`/greeks`) — Aggregate delta/theta, stress tests, sector exposure, execution quality
4. **Exit Calculator** (`/calculator`) — Calculate profit targets at 25/50/75/90% exit levels
5. **Trade Journal** (`/journal`) — Review closed trades with win rate, net P&L, CSV export
6. **Autopilot Dashboard** (`/autopilot`) — Autopilot engine controls, runtime mode, exit strategy
7. **Settings** (`/settings`) — Configure scanner defaults, VIX regime, risk limits, notifications

## Architecture
- **Frontend**: React 18 + TypeScript + Tailwind CSS + shadcn/ui + wouter routing
- **Backend**: Express 5 + TypeScript via tsx
- **Database**: PostgreSQL via Drizzle ORM
- **Theme**: Dark cyberpunk (permanently dark, no light mode toggle)
- **Fonts**: Outfit (sans), JetBrains Mono (monospace)

## Key Files
- `client/src/App.tsx` — Tab navigation + route definitions
- `client/src/pages/scanner.tsx` — Scanner page with scan form, results, add-to-positions
- `client/src/pages/positions.tsx` — Open positions management, close modal
- `client/src/pages/calculator.tsx` — Exit price calculator
- `client/src/pages/journal.tsx` — Trade journal with stats and CSV export
- `client/src/pages/settings.tsx` — All scanner/risk settings
- `client/src/pages/autopilot-dashboard.tsx` — Autopilot engine controls
- `client/src/pages/portfolio-greeks.tsx` — Portfolio Greeks + Execution Quality dashboard
- `server/services/v8/portfolio-greeks.ts` — Greeks aggregation (delta/theta/beta-weighted)
- `server/services/v8/portfolio-stress.ts` — Stress test scenarios (SPY drops, VIX spikes)
- `server/services/v8/portfolio-snapshots.ts` — Periodic portfolio snapshot capture
- `server/services/v8/execution-policy.ts` — Adaptive execution policies (4 types)
- `server/services/v8/execution-alpha.ts` — Adaptive entry/exit, working order monitor
- `server/services/v8/execution-analytics.ts` — Fill quality analytics and tracking
- `client/src/index.css` — Custom CSS classes: glass-panel, text-profit, text-loss, score-S/A/B/C, regime-low/normal/high
- `server/routes.ts` — API routes + full scan engine (VIX regime, confidence scoring, sector diversification)
- `server/brokers/tastytrade.ts` — TastyTrade broker integration (OAuth2, market data, option chains)
- `server/storage.ts` — DatabaseStorage class implementing IStorage interface
- `server/db.ts` — Drizzle ORM + pg pool setup
- `server/seed.ts` — Seeds default scanner settings on first run
- `shared/schema.ts` — Drizzle schema for positions, journal_entries, scanner_settings tables

## Database Tables
- `positions` — Open put spread positions (ticker, strikes, credit, contracts, expiration, status, Greeks fields)
- `journal_entries` — Closed trades with P&L data
- `scanner_settings` — User preferences for scanner configuration and risk limits
- `portfolio_snapshots` — Periodic snapshots of portfolio Greeks, stress tests, sector/ticker exposure
- `execution_analytics` — Fill quality tracking (bid/ask/midpoint at submit, fill price, time-to-fill, reprices)

## External APIs
- **TastyTrade** — All market data (equity quotes, option chains, option greeks, VIX index) + broker integration for order execution, position sync (OAuth2)
- **FMP (FinancialModelingPrep)** — Earnings calendar data (optional, via `FMP_API_KEY`)

## Environment Secrets
- `DATABASE_URL` — PostgreSQL connection string (auto-provisioned)
- `SESSION_SECRET` — Express session secret
- `TASTYTRADE_ENV` — `sandbox` or `production` (default: production)
- `TASTYTRADE_ACCOUNT_NUMBER` — Broker account number
- `TASTYTRADE_CLIENT_ID` — OAuth2 client ID
- `TASTYTRADE_CLIENT_SECRET` — OAuth2 client secret
- `TASTYTRADE_REFRESH_TOKEN` — OAuth2 refresh token (long-lived)
- `TASTYTRADE_BASE_URL` — Optional API base URL override (auto-resolved from ENV)
- `FMP_API_KEY` — FinancialModelingPrep API key (optional, for earnings calendar)

## Broker Integration
- OAuth2 token refresh with request deduplication and 5s failure cooldown
- `GET /api/broker/status` — Check credentials and broker health
- Sandbox: `https://api.cert.tastyworks.com`
- Production: `https://api.tastyworks.com`
- See `docs/TASTYTRADE_SETUP.md` for full setup guide

## Autopilot Engine
- Auto-starts on server boot if DB state has `isEnabled: true` (no `AUTOPILOT_AUTO_START` env var needed)
- Initial scan delayed 10s after start to let Express bind port
- Token warmup (3 retries, 3s delay) before each scan cycle
- Scan fetch has AbortController timeout to prevent hanging
- Scan loop logs: scan_loop_start → scan_loop_throttle → scan_loop_token_warmup → scan_loop_fetch_start → scan_loop_fetch_done → scan_loop_candidates → candidate_evaluated
- Token refresh: single in-flight request shared across callers, 5s cooldown on failure
- DxLink WebSocket fallback has hard timeouts (10-15s) to prevent indefinite hangs
- Bulk REST quote prefetch before per-ticker scan loop (breaks out on first failure)

## V8 Production Profile
- Default profile: `V8_SMALL_ACCOUNT_PRODUCTION` in `server/services/v8/default-settings.ts`
- Single source of truth for all scanner, risk, and exit strategy parameters
- Profile values flow into v7 engine CORE/BOOST configs, `applyDefaults()`, `buildWidthCandidates()`, `minAbsoluteCreditForWidth()`
- Stored as `profileJson` in `scanner_settings` table, editable via Settings UI
- Key defaults: $3k account, 2% risk/trade, $75 max risk cap, 8-21 DTE, 0.10-0.15 delta, 25% min credit/width, OI>=100, $0.15 max bid-ask, 50% take profit

## Scan Engine Features
- VIX regime detection (low/normal/high volatility adjustments)
- Confidence scoring 0-100 (distance, delta, slippage, credit/width, pricing realism, OI, DTE)
- V8 hybrid engine mode (CORE primary DTE window + BOOST secondary/fallback window)
- Sector diversification (topNPerSector cap, sector/high-beta caps)
- Micro realism guards (minLongAsk, maxCreditPctWidth)
- 2-minute API response cache
- TastyTrade nested option chain with batch option quotes for greeks/bid/ask/OI

## Market Data Flow (TastyTrade)
- **Primary**: REST API (`/market-data/by-type`) for equity, index, option quotes
- **Fallback**: DxLink WebSocket streaming (used when REST returns 503, e.g. sandbox)
- DxLink uses persistent connection via `dxlink-client.ts` with COMPACT data format
- Equity quotes: Quote + Trade + Summary events
- Option quotes: Quote + Greeks + Summary + Trade events (uses `put-streamer-symbol` from chain)
- VIX: Fetched via `getIndexQuote("VIX")` (REST or DxLink)
- Option chains: `GET /option-chains/{ticker}/nested` → put symbols + streamer symbols
- `server/brokers/dxlink-client.ts` — Persistent DxLink WebSocket client for streaming market data
