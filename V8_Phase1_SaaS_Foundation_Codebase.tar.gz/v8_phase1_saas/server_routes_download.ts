import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertPositionSchema, insertJournalEntrySchema } from "@shared/schema";
import { z } from "zod";

const closePositionSchema = z.object({
  exitPrice: z.number().positive(),
});

const updateSettingsSchema = z.object({
  tickers: z.string().optional(),
  dteRange: z.string().optional(),
  deltaRange: z.string().optional(),
  minCredit: z.number().min(0).optional(),
  maxSpread: z.number().min(0).optional(),
  maxResults: z.number().int().min(1).max(50).optional(),
  refreshInterval: z.number().int().min(1).optional(),
  notifyNewTrades: z.boolean().optional(),
  notifyProfitTargets: z.boolean().optional(),
  maxPositionSize: z.number().int().min(0).optional(),
  maxPortfolioRisk: z.number().int().min(1).max(100).optional(),
  accountSize: z.string().optional(),
  minCreditPct: z.number().min(0).max(100).optional(),
  minDistancePct: z.number().min(0).max(100).optional(),
  minOI: z.number().int().min(0).optional(),
  vixLowThreshold: z.number().min(0).optional(),
  vixHighThreshold: z.number().min(0).optional(),
  useVixRegime: z.boolean().optional(),
  maxRiskPerTrade: z.number().int().min(0).optional(),
  maxSlippageRatio: z.number().min(1).max(3).optional(),
});

const BASE_URL = "https://api.marketdata.app/v1";

// Modes:
// - micro/standard/aggressive: legacy V6-style single-engine scan
// - v7: hybrid two-engine scan (High-Probability Core + Premium Optimizer)
type Mode = "micro" | "standard" | "aggressive" | "v7";

// Ticker normalization for data providers that use dashes instead of dots.
// (Reduces noPrice failures for tickers like BRK.B, BF.B, etc.)
function normalizeTicker(raw: string): string {
  const map: Record<string, string> = {
    "BRK.B": "BRK-B",
    "BF.B": "BF-B",
  };
  const t = String(raw || "").toUpperCase().trim();
  return map[t] || t.replaceAll(".", "-");
}

type ScanRequest = {
  tickers?: Array<{ ticker: string; sector?: string }>;
  mode?: Mode;
  accountSize?: number;
  riskPerTradePct?: number;
  maxPortfolioRiskPct?: number;
  topNPerSector?: number;
  maxTradesTotal?: number;

  minDTE?: number;
  maxDTE?: number;
  deltaMin?: number;
  deltaMax?: number;

  microWidths?: number[];
  standardWidths?: number[];
  aggressiveWidths?: number[];

  minCreditPctWidth?: number;
  minDistancePct?: number;
  minOI?: number;
  maxLegBidAskAbs?: number;
  maxLegBidAskPctUnderlying?: number;
  maxLegBidAskPctPremium?: number; // (ask-bid)/ask
  minShortBid?: number;
  maxSlippageRatio?: number;

  // Regime controls (optional; if omitted, server defaults are used)
  useVixRegime?: boolean;
  vixLowThreshold?: number;
  vixHighThreshold?: number;

  // Micro realism / safety guards
  minLongAsk?: number;
  maxCreditPctWidth?: number;
};

type ChainRow = {
  strike: number;
  bid: number;
  ask: number;
  deltaAbs: number;
  oi: number | null;
  dte: number | null;
  expiration: string | null;
};

type Pick = {
  ticker: string;
  sector: string;
  price: number;
  expiration: string;
  dte: number | null;

  // V7 hybrid engine label (CORE vs BOOST). For legacy modes this is "LEGACY".
  engine: "CORE" | "BOOST" | "LEGACY";

  spreadType: "PUT_CREDIT_SPREAD_MICRO";
  shortPut: number;
  longPut: number;
  width: number;

  shortBid: number;
  longAsk: number;

  credit: number;
  creditPctWidth: number;
  distancePct: number;
  shortDeltaAbs: number;

  maxLoss: number;
  rorPct: number;

  contracts: number;
  tradeRisk: number;

  optimisticCredit: number;
  conservativeCredit: number;
  slippageRatio: number;

  confidence: number;
};

const RECENT_SURVIVOR_BONUS: Record<string, number> = {
  "TSLA": 1.0,
  "NVDA": 1.0,
  "AMD": 1.0,
  "AMZN": 1.0,
};

function getPersistenceBonus(ticker: string): number {
  return RECENT_SURVIVOR_BONUS[ticker] ?? 0;
}

function getToken(): string {
  const t = (process.env.MARKETDATA_API_TOKEN || process.env.MARKETDATA_TOKEN || process.env.MARKETDATAAPP_TOKEN || "").trim();
  if (!t) throw new Error("Missing MARKETDATA_API_TOKEN (set in Replit Secrets).");
  return t;
}

function authHeadersBearer() {
  return { Accept: "application/json", Authorization: `Bearer ${getToken()}` };
}
function authHeadersToken() {
  return { Accept: "application/json", Authorization: `Token ${getToken()}` };
}

type CacheEntry<T> = { ts: number; data: T };
const CACHE_TTL_MS = 2 * 60 * 1000;

const quoteCache = new Map<string, CacheEntry<number>>();
const chainCache = new Map<string, CacheEntry<any>>();
const vixCache = new Map<string, CacheEntry<number>>();

function cacheGet<T>(m: Map<string, CacheEntry<T>>, k: string): T | null {
  const e = m.get(k);
  if (!e) return null;
  if (Date.now() - e.ts > CACHE_TTL_MS) return null;
  return e.data;
}

function cacheSet<T>(m: Map<string, CacheEntry<T>>, k: string, data: T) {
  m.set(k, { ts: Date.now(), data });
}

async function fetchWithTimeout(url: string, headers: Record<string, string>, timeoutMs: number): Promise<globalThis.Response> {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), timeoutMs);

  try {
    return await fetch(url, { headers, signal: controller.signal });
  } finally {
    clearTimeout(t);
  }
}

async function apiGet(path: string, params?: Record<string, string>) {
  const url = new URL(`${BASE_URL}${path}`);
  if (params) for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);

  const attemptFetch = async (headers: Record<string, string>): Promise<globalThis.Response> => {
    for (let attempt = 0; attempt < 4; attempt++) {
      let r: globalThis.Response;
      try {
        r = await fetchWithTimeout(url.toString(), headers, 8000);
      } catch (e: any) {
        if (attempt === 3) throw e;
        await new Promise((resolve) => setTimeout(resolve, 400 * (attempt + 1)));
        continue;
      }

      if ([429, 500, 502, 503, 504].includes(r.status)) {
        if (attempt === 3) return r;
        await new Promise((resolve) => setTimeout(resolve, 600 * (attempt + 1)));
        continue;
      }

      return r;
    }
    return fetchWithTimeout(url.toString(), headers, 8000);
  };

  let r = await attemptFetch(authHeadersToken());
  if (r.status === 401 || r.status === 403) {
    r = await attemptFetch(authHeadersBearer());
  }

  if (!r.ok) {
    const txt = await r.text().catch(() => "");
    throw new Error(`MarketData ${r.status} ${r.statusText} ${path} ${txt}`);
  }

  return (await r.json()) as any;
}

function sf(x: any, d = 0): number {
  const n = Number(x);
  return Number.isFinite(n) ? n : d;
}
function si(x: any, d: number | null = null): number | null {
  const n = Number(x);
  if (!Number.isFinite(n)) return d;
  return Math.trunc(n);
}
function round2(n: number): number {
  return Math.round(n * 100) / 100;
}
function clamp(n: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, n));
}

function nowISODateUTC(): string {
  const d = new Date();
  const yyyy = d.getUTCFullYear();
  const mm = String(d.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(d.getUTCDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}
function dteFromYMD(expYmd: string): number {
  const today = new Date(`${nowISODateUTC()}T00:00:00Z`);
  const exp = new Date(`${expYmd}T00:00:00Z`);
  const ms = exp.getTime() - today.getTime();
  return Math.floor(ms / (24 * 3600 * 1000));
}

function unique<T>(arr: T[]): T[] {
  return Array.from(new Set(arr));
}

function resolveBestExpiration(
  puts: ChainRow[],
  engMinDTE: number,
  engMaxDTE: number,
  reject: Record<string, number>
): { exp: string | null; dte: number | null } {
  const exps = unique(
    puts.map(p => p.expiration).filter((x): x is string => !!x && x !== "unknown")
  );

  if (!exps.length) {
    return { exp: null, dte: null };
  }

  const expWithDte = exps
    .map(exp => ({ exp, dte: dteFromYMD(exp) }))
    .filter(x => Number.isFinite(x.dte));

  const inWindow = expWithDte
    .filter(x => x.dte >= engMinDTE && x.dte <= engMaxDTE)
    .sort((a, b) => a.dte - b.dte);

  if (inWindow.length) return { exp: inWindow[0].exp, dte: inWindow[0].dte };

  const usable = expWithDte
    .filter(x => x.dte >= 10)
    .sort((a, b) => a.dte - b.dte);

  if (usable.length) {
    reject.dteFiltered++;
    return { exp: usable[0].exp, dte: usable[0].dte };
  }

  reject.dteFiltered++;
  return { exp: null, dte: null };
}

async function getVix(): Promise<number> {
  const cached = cacheGet(vixCache, "VIX");
  if (cached !== null) return cached;
  try {
    const d = await apiGet("/indices/quotes/VIX/");
    const pick = (k: string) => {
      const v = d?.[k];
      if (Array.isArray(v) && v.length) return sf(v[v.length - 1], 0);
      return sf(v, 0);
    };
    const v = pick("last") || pick("mid") || pick("price") || pick("close");
    const out = v > 0 ? v : 20;
    cacheSet(vixCache, "VIX", out);
    return out;
  } catch {
    const out = 20;
    cacheSet(vixCache, "VIX", out);
    return out;
  }
}

function applyVixRegime(cfg: Required<ScanRequest>, vix: number) {
  // Crash-aware but trade-producing micro defaults.
  // - High vol: tighten delta, require more distance, slightly raise min credit/width, reduce portfolio risk.
  // - Low vol: allow slightly higher delta to keep credits reasonable.
  const low = cfg.vixLowThreshold;
  const high = cfg.vixHighThreshold;

  let deltaMin = cfg.deltaMin;
  let deltaMax = cfg.deltaMax;
  let minDistancePct = cfg.minDistancePct;
  let minCreditPctWidth = cfg.minCreditPctWidth;
  let maxPortfolioRiskPct = cfg.maxPortfolioRiskPct;

  if (vix >= high) {
    deltaMin = Math.max(0.10, Math.min(deltaMin, 0.16));
    deltaMax = Math.max(deltaMin + 0.04, Math.min(deltaMax, 0.22));
    minDistancePct = clamp(minDistancePct + 0.02, 0.06, 0.20);
    minCreditPctWidth = clamp(minCreditPctWidth + 0.02, 0.08, 0.35);
    maxPortfolioRiskPct = clamp(maxPortfolioRiskPct * 0.75, 0.04, 0.25);
  } else if (vix <= low) {
    // Low vol: premiums thin; let delta drift up a bit to keep fills viable.
    deltaMin = clamp(Math.min(deltaMin, 0.18), 0.08, 0.30);
    deltaMax = clamp(Math.max(deltaMax, 0.25), deltaMin + 0.04, 0.35);
    minCreditPctWidth = clamp(minCreditPctWidth - 0.01, 0.06, 0.25);
  }

  return { deltaMin, deltaMax, minDistancePct, minCreditPctWidth, maxPortfolioRiskPct };
}

function scoreConfidence(p: {
  creditPctWidth: number;   // percent
  distancePct: number;      // percent
  shortDeltaAbs: number;
  slippageRatio: number;
  shortBid: number;
  longAsk: number;
  width: number;
  oiShort?: number | null;
  oiLong?: number | null;
  dte?: number | null;

  relativeStrengthPct?: number | null;
  persistenceBonus?: number;
}): number {
  const creditPct = clamp(p.creditPctWidth, 0, 100);
  const dist = clamp(p.distancePct, 0, 50);
  const delta = clamp(p.shortDeltaAbs, 0, 1);
  const slip = clamp(p.slippageRatio, 1, 3);

  let distScore = 0;
  if (dist < 8) distScore = 0;
  else if (dist >= 9 && dist <= 12) distScore = 1.0;
  else if (dist > 12) distScore = 0.9;
  else distScore = 0.75;

  let deltaScore = 0;
  if (delta < 0.08) deltaScore = 0.65;
  else if (delta <= 0.16) deltaScore = 1.0;
  else if (delta <= 0.22) deltaScore = 0.75;
  else deltaScore = 0.35;

  const slipScore = clamp((1.6 - slip) / 0.6, 0, 1);

  let creditScore = 0;
  if (creditPct < 8) creditScore = 0;
  else if (creditPct >= 9 && creditPct <= 35) creditScore = 1.0;
  else if (creditPct <= 45) creditScore = 0.8;
  else if (creditPct <= 60) creditScore = 0.45;
  else creditScore = 0.15;

  const oiShort = p.oiShort ?? 0;
  const oiLong = p.oiLong ?? 0;
  const minOI = Math.min(oiShort, oiLong);
  const oiScore = clamp(minOI / 50, 0, 1);

  const dte = p.dte ?? 0;
  let dteScore = 0.5;
  if (dte >= 10 && dte <= 21) dteScore = 1.0;
  else if (dte >= 22 && dte <= 35) dteScore = 0.8;
  else if (dte >= 7 && dte < 10) dteScore = 0.65;

  const rs = p.relativeStrengthPct ?? 0;
  let rsScore = 0.5;
  if (rs >= 1.0) rsScore = 1.0;
  else if (rs >= 0.3) rsScore = 0.8;
  else if (rs >= 0) rsScore = 0.65;
  else if (rs >= -0.5) rsScore = 0.45;
  else rsScore = 0.2;

  const persistenceScore = clamp(p.persistenceBonus ?? 0, 0, 1);

  const pricingScore =
    (p.longAsk >= 0.02 ? 0.5 : 0) +
    (p.shortBid >= 0.05 ? 0.5 : 0);

  const raw =
    0.30 * distScore +
    0.20 * rsScore +
    0.15 * slipScore +
    0.15 * oiScore +
    0.10 * persistenceScore +
    0.05 * creditScore +
    0.03 * deltaScore +
    0.02 * dteScore +
    0.00 * pricingScore;

  let penalty = 0;
  if (creditPct > 55) penalty += 0.15;
  if (slip > 1.45) penalty += 0.10;
  if (dist < 8) penalty += 0.20;
  if (minOI < 5) penalty += 0.12;
  if (rs < -1.0) penalty += 0.12;

  return Math.round(clamp(raw - penalty, 0, 1) * 100);
}

async function getStockPrice(ticker: string): Promise<number | null> {
  const paths = [`/stocks/quotes/${ticker}/`, `/stocks/quotes/${ticker}`];

  for (const p of paths) {
    try {
      const d = await apiGet(p);

      if (d?.s && d.s !== "ok") {
        console.log("[QUOTE_BAD_STATUS]", ticker, p, d?.s);
        continue;
      }

      for (const k of ["last", "mid", "price", "close"]) {
        const v = d?.[k];
        if (Array.isArray(v) && v.length) {
          const n = sf(v[v.length - 1], 0);
          if (n > 0) return n;
        }
        const n = sf(v, 0);
        if (n > 0) return n;
      }

      console.log("[QUOTE_NO_FIELDS]", ticker, p, Object.keys(d ?? {}));
    } catch (e: any) {
      console.log("[QUOTE_FAIL]", ticker, p, e?.message || e);
    }
  }

  return null;
}

async function getDailyChangePct(ticker: string): Promise<number | null> {
  const paths = [`/stocks/quotes/${ticker}/`, `/stocks/quotes/${ticker}`];

  for (const p of paths) {
    try {
      const d = await apiGet(p);

      if (d?.s && d.s !== "ok") continue;

      for (const k of ["changepct", "changePercent", "percentChange"]) {
        const v = d?.[k];
        if (Array.isArray(v) && v.length) {
          const n = sf(v[v.length - 1], NaN);
          if (Number.isFinite(n)) return n;
        }
        const n = sf(v, NaN);
        if (Number.isFinite(n)) return n;
      }
    } catch {
      continue;
    }
  }

  return null;
}

function normalizeChainArrays(data: any): ChainRow[] {
  const strikeArr = data?.strike;
  if (!Array.isArray(strikeArr) || strikeArr.length === 0) return [];

  const bidArr = data?.bid;
  const askArr = data?.ask;
  const deltaArr = data?.delta;
  const oiArr = data?.openInterest ?? data?.open_interest ?? data?.oi;
  const dteArr = data?.dte;
  const expArr = data?.expiration;

  const rows: ChainRow[] = [];
  for (let i = 0; i < strikeArr.length; i++) {
    const strike = sf(strikeArr[i], 0);
    const bid = sf(Array.isArray(bidArr) ? bidArr[i] : null, 0);
    const ask = sf(Array.isArray(askArr) ? askArr[i] : null, 0);
    const deltaAbs = Math.abs(sf(Array.isArray(deltaArr) ? deltaArr[i] : null, 0));
    const oi = Array.isArray(oiArr) ? si(oiArr[i], null) : null;
    const dte = Array.isArray(dteArr) ? si(dteArr[i], null) : null;

    let exp: string | null = null;
    const rawExp = Array.isArray(expArr) ? expArr[i] : null;
    if (typeof rawExp === "string" && rawExp.length >= 10) exp = rawExp.slice(0, 10);
    else if (typeof rawExp === "number" && Number.isFinite(rawExp) && rawExp > 0) {
      const dt = new Date(rawExp * 1000);
      exp = dt.toISOString().slice(0, 10);
    }

    if (strike > 0) rows.push({ strike, bid, ask, deltaAbs, oi, dte, expiration: exp });
  }
  return rows;
}

function legSanity(
  row: ChainRow,
  underlying: number,
  minOI: number,
  maxLegBidAskAbs: number,
  maxLegBidAskPctUnderlying: number,
  maxLegBidAskPctPremium: number,
  minShortBid: number,
  reject: Record<string, number>,
  isShortLeg: boolean
): boolean {
  if (!(row.strike > 0)) return (reject.badStrike++, false);
  if (!(row.bid > 0 && row.ask > 0 && row.ask >= row.bid)) return (reject.noQuote++, false);
  if (isShortLeg && row.bid < minShortBid) return (reject.shortBidTooLow++, false);

  const spread = row.ask - row.bid;

  const pctUnderlying = underlying > 0 ? spread / underlying : 0;
  const pctPremium = row.ask > 0 ? spread / row.ask : 1;

  if (underlying > 0 && pctUnderlying > maxLegBidAskPctUnderlying) {
    return (reject.legWidePct++, false);
  }

  if (spread > maxLegBidAskAbs && pctPremium > maxLegBidAskPctPremium) {
    return (reject.legWideAbs++, false);
  }

  if (row.deltaAbs <= 0) return (reject.noDelta++, false);

  if (row.oi !== null && row.oi < minOI && row.bid < 0.05) {
    return (reject.lowOI++, false);
  }

  return true;
}

function pickShortPut(
  puts: ChainRow[],
  price: number,
  deltaMin: number,
  deltaMax: number,
  minOI: number,
  maxLegBidAskAbs: number,
  maxLegBidAskPctUnderlying: number,
  maxLegBidAskPctPremium: number,
  minShortBid: number,
  reject: Record<string, number>
): ChainRow | null {
  const target = (deltaMin + deltaMax) / 2;
  let best: ChainRow | null = null;
  let bestKey: [number, number] | null = null;

  for (const r of puts) {
    if (r.strike >= price) continue;
    if (r.deltaAbs < deltaMin || r.deltaAbs > deltaMax) continue;
    if (!legSanity(r, price, minOI, maxLegBidAskAbs, maxLegBidAskPctUnderlying, maxLegBidAskPctPremium, minShortBid, reject, true)) continue;

    const key: [number, number] = [Math.abs(r.deltaAbs - target), -r.bid];
    if (!best || !bestKey || key[0] < bestKey[0] || (key[0] === bestKey[0] && key[1] < bestKey[1])) {
      best = r;
      bestKey = key;
    }
  }
  return best;
}

function findLongLeg(
  puts: ChainRow[],
  longStrike: number,
  price: number,
  minOI: number,
  maxLegBidAskAbs: number,
  maxLegBidAskPctUnderlying: number,
  maxLegBidAskPctPremium: number,
  reject: Record<string, number>
): ChainRow | null {
  for (const r of puts) {
    if (Math.abs(r.strike - longStrike) < 1e-9) {
      if (legSanity(r, price, minOI, maxLegBidAskAbs, maxLegBidAskPctUnderlying, maxLegBidAskPctPremium, 0, reject, false)) return r;
    }
  }
  let best: ChainRow | null = null;
  let bestDist = Infinity;
  for (const r of puts) {
    if (r.strike > longStrike) continue;
    if (!legSanity(r, price, minOI, maxLegBidAskAbs, maxLegBidAskPctUnderlying, maxLegBidAskPctPremium, 0, reject, false)) continue;
    const dist = Math.abs(r.strike - longStrike);
    if (dist < bestDist) {
      bestDist = dist;
      best = r;
    }
  }
  return best;
}

function inferExpirationAndDTE(shortLeg: ChainRow): { exp: string; dte: number | null } {
  let exp = shortLeg.expiration ?? "unknown";
  let dte: number | null = shortLeg.dte ?? null;
  if ((dte === null || dte === undefined) && exp !== "unknown") {
    try {
      dte = dteFromYMD(exp);
    } catch {
      dte = null;
    }
  }
  return { exp, dte };
}

function defaultUniverse(): Array<{ ticker: string; sector: string }> {
  return [
    { ticker: "SPY", sector: "Index ETF" },
    { ticker: "QQQ", sector: "Index ETF" },
    { ticker: "IWM", sector: "Index ETF" },
    { ticker: "DIA", sector: "Index ETF" },
    { ticker: "TLT", sector: "Rates ETF" },
    { ticker: "GLD", sector: "Commodity ETF" },
    { ticker: "SLV", sector: "Commodity ETF" },
    { ticker: "EEM", sector: "International ETF" },
    { ticker: "XLF", sector: "Financials ETF" },
    { ticker: "XLK", sector: "Technology ETF" },
    { ticker: "XLV", sector: "Healthcare ETF" },
    { ticker: "XLE", sector: "Energy ETF" },
    { ticker: "XLY", sector: "Consumer Discretionary ETF" },
    { ticker: "XLP", sector: "Consumer Staples ETF" },
    { ticker: "XLI", sector: "Industrials ETF" },
    { ticker: "XLU", sector: "Utilities ETF" },
    { ticker: "XLB", sector: "Materials ETF" },
    { ticker: "SMH", sector: "Semiconductor ETF" },
    { ticker: "KRE", sector: "Regional Banks ETF" },
    { ticker: "GDX", sector: "Gold Miners ETF" },

    { ticker: "AAPL", sector: "Technology" },
    { ticker: "MSFT", sector: "Technology" },
    { ticker: "NVDA", sector: "Technology" },
    { ticker: "AMD", sector: "Technology" },
    { ticker: "AVGO", sector: "Technology" },
    { ticker: "QCOM", sector: "Technology" },
    { ticker: "MU", sector: "Technology" },
    { ticker: "INTC", sector: "Technology" },
    { ticker: "ORCL", sector: "Technology" },
    { ticker: "CRM", sector: "Technology" },
    { ticker: "ADBE", sector: "Technology" },
    { ticker: "NOW", sector: "Technology" },
    { ticker: "CSCO", sector: "Technology" },
    { ticker: "IBM", sector: "Technology" },
    { ticker: "ANET", sector: "Technology" },
    { ticker: "META", sector: "Communication" },
    { ticker: "GOOGL", sector: "Communication" },
    { ticker: "GOOG", sector: "Communication" },
    { ticker: "NFLX", sector: "Communication" },
    { ticker: "DIS", sector: "Communication" },

    { ticker: "TSLA", sector: "High Beta" },
    { ticker: "PLTR", sector: "High Beta" },
    { ticker: "CRWD", sector: "High Beta" },
    { ticker: "COIN", sector: "High Beta" },
    { ticker: "SQ", sector: "High Beta" },
    { ticker: "UBER", sector: "High Beta" },
    { ticker: "SNOW", sector: "High Beta" },
    { ticker: "SHOP", sector: "High Beta" },

    { ticker: "JPM", sector: "Financials" },
    { ticker: "BAC", sector: "Financials" },
    { ticker: "WFC", sector: "Financials" },
    { ticker: "C", sector: "Financials" },
    { ticker: "GS", sector: "Financials" },
    { ticker: "MS", sector: "Financials" },
    { ticker: "V", sector: "Financials" },
    { ticker: "MA", sector: "Financials" },
    { ticker: "SCHW", sector: "Financials" },
    { ticker: "AXP", sector: "Financials" },
    { ticker: "BK", sector: "Financials" },
    { ticker: "BLK", sector: "Financials" },

    { ticker: "UNH", sector: "Healthcare" },
    { ticker: "JNJ", sector: "Healthcare" },
    { ticker: "LLY", sector: "Healthcare" },
    { ticker: "ABBV", sector: "Healthcare" },
    { ticker: "MRK", sector: "Healthcare" },
    { ticker: "PFE", sector: "Healthcare" },
    { ticker: "ABT", sector: "Healthcare" },
    { ticker: "TMO", sector: "Healthcare" },
    { ticker: "ISRG", sector: "Healthcare" },
    { ticker: "DHR", sector: "Healthcare" },
    { ticker: "BMY", sector: "Healthcare" },
    { ticker: "AMGN", sector: "Healthcare" },

    { ticker: "WMT", sector: "Consumer Staples" },
    { ticker: "COST", sector: "Consumer Staples" },
    { ticker: "PG", sector: "Consumer Staples" },
    { ticker: "KO", sector: "Consumer Staples" },
    { ticker: "PEP", sector: "Consumer Staples" },
    { ticker: "PM", sector: "Consumer Staples" },
    { ticker: "MO", sector: "Consumer Staples" },
    { ticker: "CL", sector: "Consumer Staples" },
    { ticker: "KMB", sector: "Consumer Staples" },
    { ticker: "GIS", sector: "Consumer Staples" },

    { ticker: "AMZN", sector: "Consumer Discretionary" },
    { ticker: "HD", sector: "Consumer Discretionary" },
    { ticker: "LOW", sector: "Consumer Discretionary" },
    { ticker: "MCD", sector: "Consumer Discretionary" },
    { ticker: "SBUX", sector: "Consumer Discretionary" },
    { ticker: "NKE", sector: "Consumer Discretionary" },
    { ticker: "BKNG", sector: "Consumer Discretionary" },
    { ticker: "TJX", sector: "Consumer Discretionary" },
    { ticker: "CMG", sector: "Consumer Discretionary" },
    { ticker: "MAR", sector: "Consumer Discretionary" },

    { ticker: "XOM", sector: "Energy" },
    { ticker: "CVX", sector: "Energy" },
    { ticker: "COP", sector: "Energy" },
    { ticker: "SLB", sector: "Energy" },
    { ticker: "EOG", sector: "Energy" },
    { ticker: "OXY", sector: "Energy" },

    { ticker: "BA", sector: "Industrials" },
    { ticker: "CAT", sector: "Industrials" },
    { ticker: "GE", sector: "Industrials" },
    { ticker: "HON", sector: "Industrials" },
    { ticker: "UNP", sector: "Industrials" },
    { ticker: "RTX", sector: "Industrials" },
    { ticker: "UPS", sector: "Industrials" },
    { ticker: "DE", sector: "Industrials" },
    { ticker: "LMT", sector: "Industrials" },
    { ticker: "NOC", sector: "Industrials" },
    { ticker: "ETN", sector: "Industrials" },
    { ticker: "PH", sector: "Industrials" },

    { ticker: "FCX", sector: "Materials" },
    { ticker: "NUE", sector: "Materials" },
    { ticker: "LIN", sector: "Materials" },
    { ticker: "APD", sector: "Materials" },
    { ticker: "DOW", sector: "Materials" },
    { ticker: "DD", sector: "Materials" },

    { ticker: "NEE", sector: "Utilities" },
    { ticker: "SO", sector: "Utilities" },
    { ticker: "DUK", sector: "Utilities" },
    { ticker: "AEP", sector: "Utilities" },

    { ticker: "AMT", sector: "Real Estate" },
    { ticker: "PLD", sector: "Real Estate" },
    { ticker: "O", sector: "Real Estate" },
    { ticker: "SPG", sector: "Real Estate" },

    { ticker: "PYPL", sector: "Financials" },
    { ticker: "ADP", sector: "Technology" },
    { ticker: "MDT", sector: "Healthcare" },
    { ticker: "FDX", sector: "Industrials" },
    { ticker: "GM", sector: "Consumer Discretionary" },
    { ticker: "F", sector: "Consumer Discretionary" },
  ];
}

function applyDefaults(body: ScanRequest): Required<ScanRequest> {
  const mode: Mode = (body.mode as Mode) || "micro";

  const microWidths = body.microWidths?.length ? body.microWidths : [1, 2];
  const standardWidths = body.standardWidths?.length ? body.standardWidths : [5, 10];
  const aggressiveWidths = body.aggressiveWidths?.length ? body.aggressiveWidths : [2, 5];

  return {
    tickers: body.tickers ?? defaultUniverse(),
    mode,
    accountSize: sf(body.accountSize, 3000),
    // Micro accounts often can't size at 2% due to $1-wide max loss; default to 4% as requested.
    // Hard-cap at 8% to prevent accidental over-leverage.
    riskPerTradePct: clamp(sf(body.riskPerTradePct, 0.04), 0.0025, 0.08),
    maxPortfolioRiskPct: clamp(sf(body.maxPortfolioRiskPct, 0.12), 0.02, 0.5),
    topNPerSector: Math.max(1, Math.trunc(sf(body.topNPerSector, 2))),
    maxTradesTotal: Math.max(1, Math.trunc(sf(body.maxTradesTotal, 12))),

    minDTE: Math.trunc(sf(body.minDTE, 3)),
    maxDTE: Math.trunc(sf(body.maxDTE, 21)),

    deltaMin: clamp(sf(body.deltaMin, 0.10), 0.05, 0.5),
    deltaMax: clamp(sf(body.deltaMax, 0.30), 0.05, 0.6),

    microWidths,
    standardWidths,
    aggressiveWidths,

    minCreditPctWidth: clamp(sf(body.minCreditPctWidth, mode === "micro" ? 0.05 : 0.08), 0.02, 0.5),
    minDistancePct: clamp(sf(body.minDistancePct, mode === "micro" ? 0.05 : 0.06), 0.0, 0.5),

    minOI: Math.trunc(sf(body.minOI, 0)),
    maxLegBidAskAbs: sf(body.maxLegBidAskAbs, mode === "micro" ? 1.00 : 0.45),
    maxLegBidAskPctUnderlying: sf(body.maxLegBidAskPctUnderlying, mode === "micro" ? 0.01 : 0.02),
    maxLegBidAskPctPremium: sf(body.maxLegBidAskPctPremium, 0.70),
    minShortBid: sf(body.minShortBid, 0.03),
    maxSlippageRatio: sf(body.maxSlippageRatio, 1.5),

    useVixRegime: body.useVixRegime ?? true,
    vixLowThreshold: sf(body.vixLowThreshold, 15),
    vixHighThreshold: sf(body.vixHighThreshold, 25),

    minLongAsk: sf(body.minLongAsk, 0.02),
    maxCreditPctWidth: sf(body.maxCreditPctWidth, mode === "micro" ? 0.80 : 0.65),
  };
}

function mid(bid: number, ask: number): number {
  if (!(bid > 0 && ask > 0 && ask >= bid)) return 0;
  return (bid + ask) / 2;
}

function calcContracts(accountSize: number, riskPerTradePct: number, maxLossPerContract: number): number {
  const maxRisk = accountSize * riskPerTradePct;
  const c = Math.floor(maxRisk / maxLossPerContract);
  return Math.max(0, c);
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.get("/api/positions", async (_req, res) => {
    try {
      const positions = await storage.getPositions();
      res.json(positions);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/positions", async (req, res) => {
    try {
      const parsed = insertPositionSchema.parse(req.body);
      const position = await storage.createPosition(parsed);
      res.json(position);
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "Invalid position data", details: err.errors });
      }
      res.status(500).json({ error: err.message });
    }
  });

  app.delete("/api/positions/:id", async (req, res) => {
    try {
      await storage.deletePosition(req.params.id);
      res.json({ ok: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/positions/:id/close", async (req, res) => {
    try {
      const { exitPrice } = closePositionSchema.parse(req.body);
      const position = await storage.getPosition(req.params.id);
      if (!position) return res.status(404).json({ error: "Position not found" });

      const pl = (position.credit - exitPrice) * 100 * position.contracts;
      const plPercent = ((position.credit - exitPrice) / position.credit) * 100;

      const journalEntry = await storage.createJournalEntry({
        ticker: position.ticker,
        shortStrike: position.shortStrike,
        longStrike: position.longStrike,
        credit: position.credit,
        contracts: position.contracts,
        expiration: position.expiration,
        entryDate: position.entryDate,
        exitDate: new Date().toISOString().split("T")[0],
        exitPrice,
        pl,
        plPercent,
        maxRisk: position.maxRisk,
        notes: position.notes,
      });

      await storage.deletePosition(position.id);
      res.json(journalEntry);
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "Invalid close data", details: err.errors });
      }
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/journal", async (_req, res) => {
    try {
      const entries = await storage.getJournalEntries();
      res.json(entries);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/settings", async (_req, res) => {
    try {
      let settings = await storage.getSettings();
      if (!settings) {
        settings = await storage.upsertSettings({});
      }
      res.json(settings);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.put("/api/settings", async (req, res) => {
    try {
      const parsed = updateSettingsSchema.parse(req.body);
      const settings = await storage.upsertSettings(parsed);
      res.json(settings);
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "Invalid settings data", details: err.errors });
      }
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/scan", async (req: Request, res: Response) => {
    const reject = {
      noPrice: 0,
      chainFail: 0,
      noRows: 0,
      noQuote: 0,
      noDelta: 0,
      lowOI: 0,
      badStrike: 0,
      shortBidTooLow: 0,
      legWideAbs: 0,
      legWidePct: 0,
      noShort: 0,
      noLong: 0,
      dteFiltered: 0,
      creditPctTooLow: 0,
      distanceTooLow: 0,
      slippageTooHigh: 0,
      portfolioCap: 0,
      sectorCap: 0,
      sizingTooSmall: 0,
    };

    try {
      const cfg = applyDefaults((req.body ?? {}) as ScanRequest);

      // VIX regime (optional): adapt filters for volatility conditions.
      // Goal: improve survivability in sell-side strategies while still producing micro candidates.
      const vix = cfg.useVixRegime ? await getVix() : 20;
      const adj = cfg.useVixRegime ? applyVixRegime(cfg, vix) : null;
      const deltaMin = adj?.deltaMin ?? cfg.deltaMin;
      const deltaMax = adj?.deltaMax ?? cfg.deltaMax;
      const minDistancePct = adj?.minDistancePct ?? cfg.minDistancePct;
      const minCreditPctWidth = adj?.minCreditPctWidth ?? cfg.minCreditPctWidth;
      const maxPortfolioRiskPct = adj?.maxPortfolioRiskPct ?? cfg.maxPortfolioRiskPct;

      // Crash guard: when volatility is extreme, throttle risk automatically.
      // We still return picks (so you can review), but sizing is reduced.
      const crashMode = cfg.useVixRegime && vix >= 35;
      const riskPerTradePctEff = crashMode ? Math.min(cfg.riskPerTradePct, 0.02) : cfg.riskPerTradePct;
      const maxPortfolioRiskPctEff = crashMode ? Math.min(maxPortfolioRiskPct, 0.08) : maxPortfolioRiskPct;

      const universe = (cfg.tickers ?? []).map((t: any) => {
        if (typeof t === "string") return { ticker: t, sector: "Unknown" };
        if (Array.isArray(t)) return { ticker: t[0], sector: t[1] ?? "Unknown" };
        return { ticker: t.ticker, sector: t.sector ?? "Unknown" };
      });

      console.log("DEBUG_UNIVERSE_SAMPLE:", universe.slice(0, 10));

      const widths =
        cfg.mode === "micro" || cfg.mode === "v7"
          ? cfg.microWidths
          : cfg.mode === "aggressive"
            ? cfg.aggressiveWidths
            : cfg.standardWidths;

      // V7 hybrid engines: try a high-probability core first, then a premium optimizer pass.
      // This increases daily trade count without abandoning survivability.
      const v7Engines =
        cfg.mode !== "v7"
          ? null
          : ([
              {
                engine: "CORE" as const,
                minDTE: 3,
                maxDTE: 21,
                deltaMin: 0.10,
                deltaMax: 0.18,
                minDistancePct: 0.04,
                minCreditPctWidth: 0.03,
                minOI: 0,
              },
              {
                engine: "BOOST" as const,
                minDTE: 3,
                maxDTE: 28,
                deltaMin: 0.12,
                deltaMax: 0.35,
                minDistancePct: 0.03,
                minCreditPctWidth: 0.02,
                minOI: 0,
              },
            ]);

      const candidates: Pick[] = [];

      const spyChangePct = await getDailyChangePct("SPY");

      for (const u of universe) {
        const ticker = normalizeTicker(String(u.ticker));
        const sector = String(u.sector || "Unknown");
        console.log("DEBUG_TICKER:", ticker, "len=", ticker.length);

        let price: number | null = null;
        try {
          price = await getStockPrice(ticker);
        } catch {
          price = null;
        }
        if (!price || price <= 0) {
          reject.noPrice++;
          continue;
        }

        const stockChangePct = await getDailyChangePct(ticker);
        const relativeStrengthPct =
          stockChangePct !== null && spyChangePct !== null
            ? stockChangePct - spyChangePct
            : 0;

        const persistenceBonus = getPersistenceBonus(ticker);

        let chainData = cacheGet(chainCache, ticker);
        if (!chainData) {
          try {
            let pulled: any = null;

            try {
              pulled = await apiGet(`/options/chain/${ticker}/`, {
                side: "put",
                range: "otm",
                delta: "0.05-0.35",
              });
            } catch {
              pulled = null;
            }

            if (!pulled || (pulled?.s && pulled.s !== "ok")) {
              pulled = await apiGet(`/options/chain/${ticker}/`, { side: "put", range: "all" });
            }

            chainData = pulled;
            if (chainData?.s && chainData.s !== "ok") {
              reject.chainFail++;
              continue;
            }
            cacheSet(chainCache, ticker, chainData);
          } catch {
            reject.chainFail++;
            continue;
          }
        }

        const chain = normalizeChainArrays(chainData);
        if (!chain.length) {
          reject.noRows++;
          continue;
        }

        // Keep only practical OTM strikes; extremely deep ITM strikes tend to have missing/odd quotes.
        const puts = chain.filter((r) => r.strike > 0 && r.strike < price! && r.strike > price! * 0.4);

        let bestForTicker: Pick | null = null;

        const enginesToTry = v7Engines ?? [
          {
            engine: "LEGACY" as const,
            minDTE: cfg.minDTE,
            maxDTE: cfg.maxDTE,
            deltaMin,
            deltaMax,
            minDistancePct,
            minCreditPctWidth,
            minOI: cfg.minOI,
          },
        ];

        const attemptEngine = (eng: (typeof enginesToTry)[number]) => {
          let best: Pick | null = null;

          const chosen = resolveBestExpiration(puts, eng.minDTE, eng.maxDTE, reject);
          const putsForExp = chosen.exp ? puts.filter(r => r.expiration === chosen.exp) : puts;
          if (chosen.exp && putsForExp.length === 0) {
            reject.noRows++;
            return null;
          }

          for (const width of widths) {
            const short = pickShortPut(
              putsForExp,
              price,
              eng.deltaMin,
              eng.deltaMax,
              eng.minOI,
              cfg.maxLegBidAskAbs,
              cfg.maxLegBidAskPctUnderlying,
              cfg.maxLegBidAskPctPremium,
              cfg.minShortBid,
              reject
            );
            if (!short) {
              reject.noShort++;
              continue;
            }

            const longStrike = short.strike - width;
            const long = findLongLeg(
              putsForExp,
              longStrike,
              price,
              eng.minOI,
              cfg.maxLegBidAskAbs,
              cfg.maxLegBidAskPctUnderlying,
              cfg.maxLegBidAskPctPremium,
              reject
            );
            if (!long) {
              reject.noLong++;
              continue;
            }

            // Micro realism: reject stale/unfillable long legs (near-zero asks create fake huge credits).
            if (long.ask < cfg.minLongAsk) {
              reject.noLong++;
              continue;
            }

            const conservativeCredit = short.bid - long.ask;
            const optimisticCredit = mid(short.bid, short.ask) - mid(long.bid, long.ask);

            if (!(conservativeCredit > 0)) continue;

            const credit = round2(conservativeCredit);
            const creditPctWidth = credit / width;
            if (creditPctWidth < eng.minCreditPctWidth) {
              reject.creditPctTooLow++;
              continue;
            }

            // Guardrail: extremely high credit/width is usually stale long pricing on micro spreads.
            if (creditPctWidth > cfg.maxCreditPctWidth) {
              reject.creditPctTooLow++;
              continue;
            }

            const distancePct = (price - short.strike) / price;
            if (distancePct < eng.minDistancePct) {
              reject.distanceTooLow++;
              continue;
            }

            const slippageRatio = optimisticCredit > 0 ? optimisticCredit / conservativeCredit : 999;

            const allowedSlippage =
              creditPctWidth <= 0.05 ? Math.max(cfg.maxSlippageRatio, 1.9) :
              creditPctWidth <= 0.08 ? Math.max(cfg.maxSlippageRatio, 1.7) :
              cfg.maxSlippageRatio;

            if (slippageRatio > allowedSlippage) {
              reject.slippageTooHigh++;
              continue;
            }

            const maxLoss = round2((width - credit) * 100);
            const contracts = calcContracts(cfg.accountSize, riskPerTradePctEff, maxLoss);
            if (contracts < 1) {
              reject.sizingTooSmall++;
              continue;
            }

            const tradeRisk = round2(maxLoss * contracts);

            const exp = chosen.exp ?? (short.expiration ?? "unknown");
            const dte =
              chosen.dte ??
              (short.dte ?? (exp !== "unknown" ? (() => { try { return dteFromYMD(exp); } catch { return null; } })() : null));

            const pick: Pick = {
              ticker,
              sector,
              price: round2(price),
              expiration: exp,
              dte: dte ?? null,

              engine: eng.engine,
              spreadType: "PUT_CREDIT_SPREAD_MICRO",
              shortPut: short.strike,
              longPut: longStrike,
              width,
              shortBid: round2(short.bid),
              longAsk: round2(long.ask),
              credit,
              creditPctWidth: round2(creditPctWidth * 100),
              distancePct: round2(distancePct * 100),
              shortDeltaAbs: round2(short.deltaAbs),
              maxLoss,
              rorPct: round2((credit * 100) / maxLoss * 100),
              contracts,
              tradeRisk,
              optimisticCredit: round2(optimisticCredit),
              conservativeCredit: round2(conservativeCredit),
              slippageRatio: round2(slippageRatio),

              confidence: scoreConfidence({
                creditPctWidth: creditPctWidth * 100,
                distancePct: distancePct * 100,
                shortDeltaAbs: short.deltaAbs,
                slippageRatio,
                shortBid: short.bid,
                longAsk: long.ask,
                width,
                oiShort: short.oi,
                oiLong: long.oi,
                dte: dte ?? null,
                relativeStrengthPct,
                persistenceBonus,
              }),
            };

            if (!best) best = pick;
            else {
              const a = pick;
              const b = best;
              const keyA = [a.confidence, a.distancePct, -a.shortDeltaAbs, a.creditPctWidth, a.credit];
              const keyB = [b.confidence, b.distancePct, -b.shortDeltaAbs, b.creditPctWidth, b.credit];
              if (
                keyA[0] > keyB[0] ||
                (keyA[0] === keyB[0] && keyA[1] > keyB[1]) ||
                (keyA[0] === keyB[0] && keyA[1] === keyB[1] && keyA[2] > keyB[2]) ||
                (keyA[0] === keyB[0] && keyA[1] === keyB[1] && keyA[2] === keyB[2] && keyA[3] > keyB[3]) ||
                (keyA[0] === keyB[0] && keyA[1] === keyB[1] && keyA[2] === keyB[2] && keyA[3] === keyB[3] && keyA[4] > keyB[4])
              ) {
                best = pick;
              }
            }
          }

          return best;
        };

        for (const eng of enginesToTry) {
          const bestForEngine = attemptEngine(eng);
          if (bestForEngine) {
            bestForTicker = bestForEngine;
            // If we found a CORE trade, don't relax further.
            if (cfg.mode !== "v7" || bestForEngine.engine === "CORE") break;
          }
        }

        if (bestForTicker) candidates.push(bestForTicker);
      }

      candidates.sort((a, b) => {
        if (b.confidence !== a.confidence) return b.confidence - a.confidence;
        if (b.distancePct !== a.distancePct) return b.distancePct - a.distancePct;
        if (a.shortDeltaAbs !== b.shortDeltaAbs) return a.shortDeltaAbs - b.shortDeltaAbs;
        if (b.creditPctWidth !== a.creditPctWidth) return b.creditPctWidth - a.creditPctWidth;
        return b.credit - a.credit;
      });

      const picks: Pick[] = [];
      const sectorCounts = new Map<string, number>();
      const maxPortfolioRisk = cfg.accountSize * maxPortfolioRiskPctEff;
      let deployed = 0;

      for (const p of candidates) {
        if (picks.length >= cfg.maxTradesTotal) break;

        if (p.sector === "High Beta" && (sectorCounts.get("High Beta") ?? 0) >= 1) {
          reject.sectorCap++;
          continue;
        }

        const count = sectorCounts.get(p.sector) ?? 0;
        if (count >= cfg.topNPerSector) {
          reject.sectorCap++;
          continue;
        }
        if (deployed + p.tradeRisk > maxPortfolioRisk) {
          reject.portfolioCap++;
          continue;
        }

        picks.push(p);
        deployed += p.tradeRisk;
        sectorCounts.set(p.sector, count + 1);
      }

      console.log("SCAN DEBUG reject counts:", reject);
      console.log(
        "SCAN DEBUG candidates:",
        candidates.length,
        "final picks:",
        picks.length,
        "deployedRisk:",
        deployed,
        "maxPortfolioRisk:",
        maxPortfolioRisk
      );

      res.json({
        ok: true,
        mode: cfg.mode,
        defaultsUsed: {
          vix,
          crashMode,
          delta: [deltaMin, deltaMax],
          dte: [cfg.minDTE, cfg.maxDTE],
          minCreditPctWidth,
          minDistancePct,
          minOI: cfg.minOI,
          widths,
          minLongAsk: cfg.minLongAsk,
          maxCreditPctWidth: cfg.maxCreditPctWidth,
          useVixRegime: cfg.useVixRegime,
          vixLowThreshold: cfg.vixLowThreshold,
          vixHighThreshold: cfg.vixHighThreshold,
          sizing: {
            riskPerTradePct: riskPerTradePctEff,
            maxPortfolioRiskPct: maxPortfolioRiskPctEff,
          },
        },
        deployedRisk: round2(deployed),
        maxPortfolioRisk: round2(maxPortfolioRisk),
        reject,
        picks,
      });
    } catch (e: any) {
      console.error("SCAN ERROR:", e?.message || e);
      res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  });

  return httpServer;
}