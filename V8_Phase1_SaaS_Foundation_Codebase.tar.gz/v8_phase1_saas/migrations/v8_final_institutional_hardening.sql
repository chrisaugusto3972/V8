alter table broker_orders alter column order_intent_id drop not null;

alter table broker_orders add column if not exists engine_version varchar(64);
alter table broker_orders add column if not exists selection_version varchar(64);

alter table positions add column if not exists engine_version varchar(64);
alter table positions add column if not exists selection_version varchar(64);

alter table order_intents add column if not exists engine_version varchar(64);
alter table order_intents add column if not exists selection_version varchar(64);

alter table system_events add column if not exists engine_version varchar(64);
