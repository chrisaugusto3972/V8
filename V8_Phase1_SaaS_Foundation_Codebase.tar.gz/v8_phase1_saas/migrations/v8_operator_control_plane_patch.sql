-- V8 Operator Control Plane Patch
-- Adds columns and tables required by the V8 autopilot operator control plane:
--   - positions: live sync, performance tracking, and risk management fields
--   - app_settings: operator-level configuration (exit modes, disabled tickers/sectors)
--   - manual_actions: audit log for operator manual interventions

-- ============================================================
-- 1. positions — live sync & performance columns
-- ============================================================
ALTER TABLE positions ADD COLUMN IF NOT EXISTS current_mark       REAL;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS broker_order_id    TEXT;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS opened_at          TEXT;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS closed_at          TEXT;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS liquidity_score    REAL;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS confidence         REAL;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS max_loss           REAL;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS sector             TEXT;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS sub_industry       TEXT;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS entry_credit       REAL;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS width              REAL;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS updated_at         TEXT;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS created_at         TEXT;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS realized_pnl       REAL;

-- ============================================================
-- 2. autopilot_state — control plane fields
-- ============================================================
ALTER TABLE autopilot_state ADD COLUMN IF NOT EXISTS is_paused              BOOLEAN DEFAULT false;
ALTER TABLE autopilot_state ADD COLUMN IF NOT EXISTS pause_reason           TEXT;
ALTER TABLE autopilot_state ADD COLUMN IF NOT EXISTS paused_until           TEXT;
ALTER TABLE autopilot_state ADD COLUMN IF NOT EXISTS warm_mode_until        TEXT;
ALTER TABLE autopilot_state ADD COLUMN IF NOT EXISTS active_modifiers_json  TEXT;
ALTER TABLE autopilot_state ADD COLUMN IF NOT EXISTS last_heartbeat_at      TEXT;
ALTER TABLE autopilot_state ADD COLUMN IF NOT EXISTS last_recon_at          TEXT;
ALTER TABLE autopilot_state ADD COLUMN IF NOT EXISTS last_scan_at           TEXT;
ALTER TABLE autopilot_state ADD COLUMN IF NOT EXISTS last_health_at         TEXT;

-- ============================================================
-- 3. app_settings — operator configuration
-- ============================================================
CREATE TABLE IF NOT EXISTS app_settings (
  id                    SERIAL PRIMARY KEY,
  exit_strategy_mode    TEXT DEFAULT 'HYBRID_SMART_EXIT',
  disabled_tickers_json TEXT DEFAULT '[]',
  disabled_sectors_json TEXT DEFAULT '[]',
  created_at            TIMESTAMP DEFAULT NOW(),
  updated_at            TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- 4. manual_actions — operator audit log
-- ============================================================
CREATE TABLE IF NOT EXISTS manual_actions (
  id          SERIAL PRIMARY KEY,
  action_type TEXT NOT NULL,
  target      TEXT,
  notes       TEXT,
  payload     TEXT,
  created_at  TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- 5. Seed default app_settings row if empty
-- ============================================================
INSERT INTO app_settings (exit_strategy_mode, disabled_tickers_json, disabled_sectors_json)
SELECT 'HYBRID_SMART_EXIT', '[]', '[]'
WHERE NOT EXISTS (SELECT 1 FROM app_settings LIMIT 1);
