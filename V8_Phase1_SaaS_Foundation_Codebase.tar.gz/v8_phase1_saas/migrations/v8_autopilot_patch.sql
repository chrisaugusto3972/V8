CREATE TABLE IF NOT EXISTS order_intents (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  dedupe_key text NOT NULL,
  ticker text NOT NULL,
  sector text NOT NULL DEFAULT 'Unknown',
  expiration text NOT NULL,
  short_strike real NOT NULL,
  long_strike real NOT NULL,
  width real NOT NULL,
  intended_credit real NOT NULL,
  contracts integer NOT NULL DEFAULT 1,
  confidence integer NOT NULL DEFAULT 0,
  liquidity_score integer NOT NULL DEFAULT 0,
  state text NOT NULL DEFAULT 'SCANNED',
  mode text NOT NULL DEFAULT 'v8',
  metadata text,
  created_at text NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at text NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS broker_orders (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  order_intent_id varchar NOT NULL,
  broker_order_id text,
  account_number text,
  status text NOT NULL DEFAULT 'created',
  requested_price real,
  fill_price real,
  raw_response text,
  created_at text NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at text NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS system_events (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  severity text NOT NULL DEFAULT 'info',
  event_type text NOT NULL,
  message text NOT NULL,
  payload text,
  created_at text NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS autopilot_state (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  mode text NOT NULL DEFAULT 'DRY_RUN',
  is_enabled boolean NOT NULL DEFAULT false,
  is_paused boolean NOT NULL DEFAULT true,
  pause_reason text,
  last_heartbeat_at text,
  last_scan_at text,
  last_recon_at text,
  last_health_at text,
  warm_mode_until text,
  config_json text
);
