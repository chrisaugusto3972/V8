alter table broker_orders
  alter column order_intent_id drop not null;
