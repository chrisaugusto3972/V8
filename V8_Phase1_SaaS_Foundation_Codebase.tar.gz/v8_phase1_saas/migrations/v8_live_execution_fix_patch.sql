-- V8 Live Execution Fix Patch
-- Ensures positions defaults and broker_orders columns are present for live fill sync

alter table positions
  alter column credit set default 0,
  alter column entry_credit set default 0,
  alter column current_mark set default 0,
  alter column max_risk set default 0;

alter table positions
  alter column entry_date set default now();

alter table broker_orders
  add column if not exists broker_order_id text,
  add column if not exists ticker text,
  add column if not exists side text,
  add column if not exists fill_price real,
  add column if not exists filled_quantity integer,
  add column if not exists raw_json text;
