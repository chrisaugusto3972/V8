alter table broker_orders
  add column if not exists position_id integer;

create index if not exists idx_broker_orders_position_id
  on broker_orders(position_id);

create index if not exists idx_broker_orders_broker_order_id
  on broker_orders(broker_order_id);

create index if not exists idx_positions_status
  on positions(status);
