import { Switch, Route, useLocation, Link } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import { Search, Briefcase, Calculator, BookOpen, Settings } from "lucide-react";
import ScannerPage from "@/pages/scanner";
import PositionsPage from "@/pages/positions";
import CalculatorPage from "@/pages/calculator";
import JournalPage from "@/pages/journal";
import SettingsPage from "@/pages/settings";
import NotFound from "@/pages/not-found";

const tabs = [
  { id: "/", label: "Scanner", icon: Search },
  { id: "/positions", label: "Positions", icon: Briefcase },
  { id: "/calculator", label: "Exit Calculator", icon: Calculator },
  { id: "/journal", label: "Trade Journal", icon: BookOpen },
  { id: "/settings", label: "Settings", icon: Settings },
] as const;

function Navigation() {
  const [location] = useLocation();

  return (
    <div className="glass-panel p-2 mb-6">
      <div className="flex gap-1 flex-wrap">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = location === tab.id;
          return (
            <Link key={tab.id} href={tab.id}>
              <Button
                variant={isActive ? "default" : "ghost"}
                className={`flex-shrink-0 gap-2 ${isActive ? "" : "text-muted-foreground"}`}
                data-testid={`tab-${tab.label.toLowerCase().replace(/\s+/g, "-")}`}
              >
                <Icon className="w-4 h-4" />
                <span className="hidden sm:inline">{tab.label}</span>
              </Button>
            </Link>
          );
        })}
      </div>
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={ScannerPage} />
      <Route path="/positions" component={PositionsPage} />
      <Route path="/calculator" component={CalculatorPage} />
      <Route path="/journal" component={JournalPage} />
      <Route path="/settings" component={SettingsPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function AppContent() {
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto p-4 md:p-6">
        <div className="text-center mb-6">
          <h1 className="text-3xl md:text-5xl font-extrabold mb-2 gradient-text" data-testid="text-title">
            INSTITUTIONAL SCANNER PRO
          </h1>
          <p className="text-muted-foreground text-base">Professional Options Trading Suite</p>
          <p className="text-muted-foreground/60 text-xs mt-1">
            Advanced Analytics &middot; Position Tracking &middot; Exit Calculator &middot; Trade Journal
          </p>
        </div>

        <Navigation />

        <Router />
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <AppContent />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
