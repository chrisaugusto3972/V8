import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Settings, RefreshCw, Bell, Shield, Save, BarChart3, Search } from "lucide-react";
import type { ScannerSettings } from "@shared/schema";

export default function SettingsPage() {
  const { toast } = useToast();

  const { data: settings } = useQuery<ScannerSettings>({
    queryKey: ["/api/settings"],
  });

  const [form, setForm] = useState({
    tickers: "SPY,QQQ,IWM,DIA,EEM,EWZ,XLE,XLF,SMH,TLT,GLD,SLV,AAPL,MSFT,GOOGL,AMZN,META,TSLA,NVDA,JPM,BAC,WMT,DIS,NFLX,AMD,CRM,ORCL,INTC,COIN,PLTR,KO,PG,JNJ,PEP,MCD,XOM,CVX,GS,UNH,COST",
    dteRange: "14-45",
    deltaRange: "0.15-0.25",
    accountSize: "micro",
    minCredit: "0.30",
    maxSpread: "0.75",
    maxResults: "20",
    minCreditPct: "12",
    minDistancePct: "7",
    minOI: "25",
    maxSlippageRatio: "1.5",
    refreshInterval: "5",
    notifyNewTrades: true,
    notifyProfitTargets: true,
    maxPositionSize: "5000",
    maxPortfolioRisk: "5",
    maxRiskPerTrade: "500",
    vixLowThreshold: "15",
    vixHighThreshold: "25",
    useVixRegime: true,
  });

  useEffect(() => {
    if (settings) {
      setForm({
        tickers: settings.tickers,
        dteRange: settings.dteRange,
        deltaRange: settings.deltaRange,
        accountSize: settings.accountSize,
        minCredit: String(settings.minCredit),
        maxSpread: String(settings.maxSpread),
        maxResults: String(settings.maxResults),
        minCreditPct: String(settings.minCreditPct),
        minDistancePct: String(settings.minDistancePct),
        minOI: String(settings.minOI),
        maxSlippageRatio: String(settings.maxSlippageRatio),
        refreshInterval: String(settings.refreshInterval),
        notifyNewTrades: settings.notifyNewTrades,
        notifyProfitTargets: settings.notifyProfitTargets,
        maxPositionSize: String(settings.maxPositionSize),
        maxPortfolioRisk: String(settings.maxPortfolioRisk),
        maxRiskPerTrade: String(settings.maxRiskPerTrade),
        vixLowThreshold: String(settings.vixLowThreshold),
        vixHighThreshold: String(settings.vixHighThreshold),
        useVixRegime: settings.useVixRegime,
      });
    }
  }, [settings]);

  const saveSettings = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("PUT", "/api/settings", {
        tickers: form.tickers,
        dteRange: form.dteRange,
        deltaRange: form.deltaRange,
        accountSize: form.accountSize,
        minCredit: parseFloat(form.minCredit),
        maxSpread: parseFloat(form.maxSpread),
        maxResults: parseInt(form.maxResults),
        minCreditPct: parseFloat(form.minCreditPct),
        minDistancePct: parseFloat(form.minDistancePct),
        minOI: parseInt(form.minOI),
        maxSlippageRatio: parseFloat(form.maxSlippageRatio),
        refreshInterval: parseInt(form.refreshInterval),
        notifyNewTrades: form.notifyNewTrades,
        notifyProfitTargets: form.notifyProfitTargets,
        maxPositionSize: parseInt(form.maxPositionSize),
        maxPortfolioRisk: parseInt(form.maxPortfolioRisk),
        maxRiskPerTrade: parseInt(form.maxRiskPerTrade),
        vixLowThreshold: parseFloat(form.vixLowThreshold),
        vixHighThreshold: parseFloat(form.vixHighThreshold),
        useVixRegime: form.useVixRegime,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({ title: "Settings saved" });
    },
    onError: (err: Error) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  return (
    <div className="space-y-6">
      <Card className="glass-panel p-6">
        <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
          <Settings className="w-5 h-5 text-chart-1" />
          Settings
        </h2>

        <div className="space-y-8">
          <div>
            <h3 className="text-base font-bold mb-4 flex items-center gap-2">
              <Search className="w-4 h-4 text-chart-1" />
              Scanner Defaults
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div className="md:col-span-2">
                <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Default Tickers</Label>
                <Input
                  value={form.tickers}
                  onChange={e => setForm(f => ({ ...f, tickers: e.target.value }))}
                  className="font-mono text-sm"
                  data-testid="input-default-tickers"
                />
              </div>
              <div>
                <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Account Size</Label>
                <Select value={form.accountSize} onValueChange={v => setForm(f => ({ ...f, accountSize: v }))}>
                  <SelectTrigger data-testid="select-account-size-settings">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="micro">Micro ($1-2 spreads)</SelectItem>
                    <SelectItem value="small">Small ($3-5 spreads)</SelectItem>
                    <SelectItem value="standard">Standard ($5-10 spreads)</SelectItem>
                    <SelectItem value="all">All Sizes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs font-semibold text-muted-foreground mb-2 block">DTE Range</Label>
                <Select value={form.dteRange} onValueChange={v => setForm(f => ({ ...f, dteRange: v }))}>
                  <SelectTrigger data-testid="select-dte-settings">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="14-45">14-45 days (Default)</SelectItem>
                    <SelectItem value="30-45">30-45 days</SelectItem>
                    <SelectItem value="21-35">21-35 days</SelectItem>
                    <SelectItem value="45-60">45-60 days</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Delta Target</Label>
                <Select value={form.deltaRange} onValueChange={v => setForm(f => ({ ...f, deltaRange: v }))}>
                  <SelectTrigger data-testid="select-delta-settings">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0.10-0.16">0.10-0.16 (85%+ Win)</SelectItem>
                    <SelectItem value="0.15-0.25">0.15-0.25 (Default)</SelectItem>
                    <SelectItem value="0.16-0.25">0.16-0.25 (75-80% Win)</SelectItem>
                    <SelectItem value="0.18-0.25">0.18-0.25 (Micro Optimal)</SelectItem>
                    <SelectItem value="0.25-0.35">0.25-0.35 (65-70% Win)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Min Credit ($)</Label>
                <Input type="number" step="0.05" min="0.10" value={form.minCredit} onChange={e => setForm(f => ({ ...f, minCredit: e.target.value }))} className="font-mono" data-testid="input-min-credit-settings" />
              </div>
              <div>
                <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Max Bid-Ask Spread ($)</Label>
                <Input type="number" step="0.05" min="0.05" value={form.maxSpread} onChange={e => setForm(f => ({ ...f, maxSpread: e.target.value }))} className="font-mono" data-testid="input-max-spread-settings" />
              </div>
              <div>
                <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Max Results</Label>
                <Select value={form.maxResults} onValueChange={v => setForm(f => ({ ...f, maxResults: v }))}>
                  <SelectTrigger data-testid="select-max-results-settings">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10">Top 10</SelectItem>
                    <SelectItem value="20">Top 20</SelectItem>
                    <SelectItem value="50">Top 50</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <h4 className="text-sm font-bold mb-3 text-muted-foreground">Quality Gates</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Min Credit % of Width</Label>
                <Input type="number" min="10" max="50" value={form.minCreditPct} onChange={e => setForm(f => ({ ...f, minCreditPct: e.target.value }))} className="font-mono" data-testid="input-min-credit-pct-settings" />
              </div>
              <div>
                <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Min Distance OTM (%)</Label>
                <Input type="number" min="1" max="20" value={form.minDistancePct} onChange={e => setForm(f => ({ ...f, minDistancePct: e.target.value }))} className="font-mono" data-testid="input-min-distance-settings" />
              </div>
              <div>
                <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Min Open Interest</Label>
                <Input type="number" min="0" value={form.minOI} onChange={e => setForm(f => ({ ...f, minOI: e.target.value }))} className="font-mono" data-testid="input-min-oi-settings" />
              </div>
              <div>
                <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Max Slippage Ratio</Label>
                <Input type="number" step="0.1" min="1.1" max="2.0" value={form.maxSlippageRatio} onChange={e => setForm(f => ({ ...f, maxSlippageRatio: e.target.value }))} className="font-mono" data-testid="input-max-slippage-settings" />
              </div>
            </div>
          </div>

          <div className="border-t border-border pt-6">
            <h3 className="text-base font-bold mb-4 flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-chart-1" />
              VIX Regime Rules
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Low VIX Threshold</Label>
                <Input type="number" step="1" value={form.vixLowThreshold} onChange={e => setForm(f => ({ ...f, vixLowThreshold: e.target.value }))} className="font-mono" data-testid="input-vix-low" />
                <p className="text-xs text-muted-foreground/60 mt-1">Below this = conservative regime</p>
              </div>
              <div>
                <Label className="text-xs font-semibold text-muted-foreground mb-2 block">High VIX Threshold</Label>
                <Input type="number" step="1" value={form.vixHighThreshold} onChange={e => setForm(f => ({ ...f, vixHighThreshold: e.target.value }))} className="font-mono" data-testid="input-vix-high" />
                <p className="text-xs text-muted-foreground/60 mt-1">Above this = defensive regime</p>
              </div>
              <div className="flex items-center gap-3 mt-6">
                <Switch checked={form.useVixRegime} onCheckedChange={v => setForm(f => ({ ...f, useVixRegime: v }))} data-testid="switch-vix-regime" />
                <Label className="text-sm">Enable VIX regime adjustments</Label>
              </div>
            </div>
          </div>

          <div className="border-t border-border pt-6">
            <h3 className="text-base font-bold mb-4 flex items-center gap-2">
              <RefreshCw className="w-4 h-4 text-chart-1" />
              Auto-Refresh
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Refresh Interval</Label>
                <Select value={form.refreshInterval} onValueChange={v => setForm(f => ({ ...f, refreshInterval: v }))}>
                  <SelectTrigger data-testid="select-refresh-interval">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 minute</SelectItem>
                    <SelectItem value="5">5 minutes</SelectItem>
                    <SelectItem value="15">15 minutes</SelectItem>
                    <SelectItem value="30">30 minutes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <div className="border-t border-border pt-6">
            <h3 className="text-base font-bold mb-4 flex items-center gap-2">
              <Bell className="w-4 h-4 text-chart-4" />
              Notifications
            </h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label className="text-sm">Notify when new elite trades found</Label>
                <Switch checked={form.notifyNewTrades} onCheckedChange={v => setForm(f => ({ ...f, notifyNewTrades: v }))} data-testid="switch-notify-trades" />
              </div>
              <div className="flex items-center justify-between">
                <Label className="text-sm">Notify when positions hit 50% profit</Label>
                <Switch checked={form.notifyProfitTargets} onCheckedChange={v => setForm(f => ({ ...f, notifyProfitTargets: v }))} data-testid="switch-notify-profits" />
              </div>
            </div>
          </div>

          <div className="border-t border-border pt-6">
            <h3 className="text-base font-bold mb-4 flex items-center gap-2">
              <Shield className="w-4 h-4 text-chart-5" />
              Position Sizing & Risk
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Max Risk Per Trade ($)</Label>
                <Input type="number" step="100" value={form.maxRiskPerTrade} onChange={e => setForm(f => ({ ...f, maxRiskPerTrade: e.target.value }))} className="font-mono" data-testid="input-max-risk-trade" />
              </div>
              <div>
                <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Max Position Size ($)</Label>
                <Input type="number" step="100" value={form.maxPositionSize} onChange={e => setForm(f => ({ ...f, maxPositionSize: e.target.value }))} className="font-mono" data-testid="input-max-position" />
              </div>
              <div>
                <Label className="text-xs font-semibold text-muted-foreground mb-2 block">Max Portfolio Risk (%)</Label>
                <Input type="number" step="1" min="1" max="20" value={form.maxPortfolioRisk} onChange={e => setForm(f => ({ ...f, maxPortfolioRisk: e.target.value }))} className="font-mono" data-testid="input-max-risk" />
              </div>
            </div>
          </div>

          <Button
            className="w-full font-bold tracking-wider uppercase"
            size="lg"
            onClick={() => saveSettings.mutate()}
            disabled={saveSettings.isPending}
            data-testid="button-save-settings"
          >
            <Save className="w-5 h-5" />
            SAVE SETTINGS
          </Button>
        </div>
      </Card>
    </div>
  );
}
