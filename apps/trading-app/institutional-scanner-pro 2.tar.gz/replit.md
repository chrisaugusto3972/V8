# Institutional Scanner Pro

## Overview
A full-stack professional options trading suite for scanning, managing, and analyzing put credit spread positions. Uses MarketData.app API for real-time options data, VIX regime detection, and confidence scoring. PostgreSQL for persistent positions, journal, and settings.

## Pages
1. **Scanner** (`/`) — Scan for put spread opportunities with configurable parameters
2. **Positions** (`/positions`) — Track open positions with CRUD and close-to-journal flow
3. **Exit Calculator** (`/calculator`) — Calculate profit targets at 25/50/75/90% exit levels
4. **Trade Journal** (`/journal`) — Review closed trades with win rate, net P&L, CSV export
5. **Settings** (`/settings`) — Configure scanner defaults, VIX regime, risk limits, notifications

## Architecture
- **Frontend**: React 18 + TypeScript + Tailwind CSS + shadcn/ui + wouter routing
- **Backend**: Express 5 + TypeScript via tsx
- **Database**: PostgreSQL via Drizzle ORM
- **Theme**: Dark cyberpunk (permanently dark, no light mode toggle)
- **Fonts**: Outfit (sans), JetBrains Mono (monospace)

## Key Files
- `client/src/App.tsx` — Tab navigation + route definitions
- `client/src/pages/scanner.tsx` — Scanner page with scan form, results, add-to-positions
- `client/src/pages/positions.tsx` — Open positions management, close modal
- `client/src/pages/calculator.tsx` — Exit price calculator
- `client/src/pages/journal.tsx` — Trade journal with stats and CSV export
- `client/src/pages/settings.tsx` — All scanner/risk settings
- `client/src/index.css` — Custom CSS classes: glass-panel, text-profit, text-loss, score-S/A/B/C, regime-low/normal/high
- `server/routes.ts` — API routes + full scan engine (VIX regime, confidence scoring, sector diversification)
- `server/storage.ts` — DatabaseStorage class implementing IStorage interface
- `server/db.ts` — Drizzle ORM + pg pool setup
- `server/seed.ts` — Seeds default scanner settings on first run
- `shared/schema.ts` — Drizzle schema for positions, journal_entries, scanner_settings tables

## Database Tables
- `positions` — Open put spread positions (ticker, strikes, credit, contracts, expiration, status)
- `journal_entries` — Closed trades with P&L data
- `scanner_settings` — User preferences for scanner configuration and risk limits

## External APIs
- **MarketData.app** — Stock quotes, options chains, VIX index (via `MARKETDATA_API_TOKEN` secret)

## Environment Secrets
- `MARKETDATA_API_TOKEN` — MarketData.app API key (required for scanner)
- `DATABASE_URL` — PostgreSQL connection string (auto-provisioned)
- `SESSION_SECRET` — Express session secret

## Scan Engine Features
- VIX regime detection (low/normal/high volatility adjustments)
- Confidence scoring 0-100 (distance, delta, slippage, credit/width, pricing realism, OI, DTE)
- V7 hybrid engine mode (CORE high-probability + BOOST premium optimizer)
- Sector diversification (topNPerSector cap)
- Micro realism guards (minLongAsk, maxCreditPctWidth)
- 2-minute API response cache
- Retry with Token/Bearer auth fallback
