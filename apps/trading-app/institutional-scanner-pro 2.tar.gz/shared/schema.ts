import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const positions = pgTable("positions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  ticker: text("ticker").notNull(),
  shortStrike: real("short_strike").notNull(),
  longStrike: real("long_strike").notNull(),
  credit: real("credit").notNull(),
  contracts: integer("contracts").notNull().default(1),
  expiration: text("expiration").notNull(),
  entryDate: text("entry_date").notNull(),
  maxRisk: real("max_risk").notNull(),
  notes: text("notes"),
  status: text("status").notNull().default("open"),
});

export const journalEntries = pgTable("journal_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  ticker: text("ticker").notNull(),
  shortStrike: real("short_strike").notNull(),
  longStrike: real("long_strike").notNull(),
  credit: real("credit").notNull(),
  contracts: integer("contracts").notNull().default(1),
  expiration: text("expiration").notNull(),
  entryDate: text("entry_date").notNull(),
  exitDate: text("exit_date").notNull(),
  exitPrice: real("exit_price").notNull(),
  pl: real("pl").notNull(),
  plPercent: real("pl_percent").notNull(),
  maxRisk: real("max_risk").notNull(),
  notes: text("notes"),
});

export const scannerSettings = pgTable("scanner_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tickers: text("tickers").notNull().default("SPY,QQQ,IWM,DIA,EEM,EWZ,XLE,XLF,SMH,TLT,GLD,SLV,AAPL,MSFT,GOOGL,AMZN,META,TSLA,NVDA,JPM,BAC,WMT,DIS,NFLX,AMD,CRM,ORCL,INTC,COIN,PLTR,KO,PG,JNJ,PEP,MCD,XOM,CVX,GS,UNH,COST"),
  // Micro-first defaults that actually produce trades with realistic micro liquidity constraints.
  dteRange: text("dte_range").notNull().default("14-45"),
  deltaRange: text("delta_range").notNull().default("0.15-0.25"),
  // Micro-first defaults for small accounts.
  // Note: the scanner derives widths from accountSize, but we keep a sensible default here
  // for legacy UI pieces and future expansion.
  spreadWidth: integer("spread_width").notNull().default(2),
  minCredit: real("min_credit").notNull().default(0.3),
  // Volume is less reliable intraday than Open Interest. Keep as legacy field.
  minVolume: integer("min_volume").notNull().default(0),
  // For micro spreads, absolute leg markets can be wider; the scanner separately enforces
  // a percentage-of-underlying cap + slippage ratio.
  maxSpread: real("max_spread").notNull().default(0.45),
  minIVPercentile: integer("min_iv_percentile").notNull().default(25),
  maxResults: integer("max_results").notNull().default(20),
  refreshInterval: integer("refresh_interval").notNull().default(5),
  notifyNewTrades: boolean("notify_new_trades").notNull().default(true),
  notifyProfitTargets: boolean("notify_profit_targets").notNull().default(true),
  maxPositionSize: integer("max_position_size").notNull().default(5000),
  // Default to 12% deployable risk (micro: survive drawdowns).
  maxPortfolioRisk: integer("max_portfolio_risk").notNull().default(12),
  accountSize: text("account_size").notNull().default("micro"),
  // Feb trade log: most winners clustered around ~10% buffer; losers increased below ~7%.
  minCreditPct: real("min_credit_pct").notNull().default(12),
  minDistancePct: real("min_distance_pct").notNull().default(7),
  minOI: integer("min_oi").notNull().default(25),
  vixLowThreshold: real("vix_low_threshold").notNull().default(15),
  vixHighThreshold: real("vix_high_threshold").notNull().default(25),
  useVixRegime: boolean("use_vix_regime").notNull().default(true),
  maxRiskPerTrade: integer("max_risk_per_trade").notNull().default(500),
  maxSlippageRatio: real("max_slippage_ratio").notNull().default(1.5),
});

export const insertPositionSchema = createInsertSchema(positions).omit({ id: true });
export const insertJournalEntrySchema = createInsertSchema(journalEntries).omit({ id: true });
export const insertScannerSettingsSchema = createInsertSchema(scannerSettings).omit({ id: true });

export type Position = typeof positions.$inferSelect;
export type InsertPosition = z.infer<typeof insertPositionSchema>;
export type JournalEntry = typeof journalEntries.$inferSelect;
export type InsertJournalEntry = z.infer<typeof insertJournalEntrySchema>;
export type ScannerSettings = typeof scannerSettings.$inferSelect;
export type InsertScannerSettings = z.infer<typeof insertScannerSettingsSchema>;
