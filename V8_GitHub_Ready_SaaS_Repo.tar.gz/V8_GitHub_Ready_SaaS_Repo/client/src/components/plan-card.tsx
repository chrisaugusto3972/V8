import React from "react";

export default function PlanCard({ name, price, features }: { name: string; price: string; features: string[] }) {
  return (
    <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6">
      <div className="text-xl font-semibold text-white">{name}</div>
      <div className="mt-2 text-3xl font-bold text-white">{price}</div>
      <ul className="mt-6 space-y-2">
        {features.map((f) => <li key={f} className="text-sm text-slate-300">• {f}</li>)}
      </ul>
    </div>
  );
}
