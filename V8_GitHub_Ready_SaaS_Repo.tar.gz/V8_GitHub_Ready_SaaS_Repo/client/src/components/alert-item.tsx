import React from "react";

export default function AlertItem({ title, message }: { title: string; message: string }) {
  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
      <div className="font-semibold text-white">{title}</div>
      <div className="mt-1 text-sm text-slate-300">{message}</div>
    </div>
  );
}
