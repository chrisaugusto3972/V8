import React from "react";

type Props = {
  name: string;
  status: "supported" | "beta" | "coming_soon";
  description: string;
};

export default function BrokerCard({ name, status, description }: Props) {
  return (
    <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-xl font-semibold text-white">{name}</div>
          <p className="mt-2 text-sm text-slate-300">{description}</p>
        </div>
        <div className="rounded-full border border-slate-700 bg-slate-800 px-3 py-1 text-xs text-slate-300">
          {status}
        </div>
      </div>
    </div>
  );
}
