import React from "react";
import AlertItem from "../components/alert-item";

export default function NotificationsCenterPage() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-6">
      <div className="mx-auto max-w-7xl">
        <h1 className="text-3xl font-semibold text-white">Notifications Center</h1>
        <div className="mt-6 space-y-4">
          <AlertItem title="Approval Needed" message="SPY trade requires approval in assisted mode." />
          <AlertItem title="Concentration Warning" message="Technology exposure exceeds configured threshold." />
        </div>
      </div>
    </div>
  );
}
