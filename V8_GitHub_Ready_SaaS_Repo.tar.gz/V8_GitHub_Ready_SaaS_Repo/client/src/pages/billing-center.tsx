import React from "react";
import PlanCard from "../components/plan-card";

export default function BillingCenterPage() {
  const plans = [
    { name: "Starter", price: "$39/mo", features: ["Daily scanner", "Basic picks review", "Paper account support"] },
    { name: "Pro", price: "$99/mo", features: ["Full scanner", "Portfolio risk cockpit", "Full analytics"] },
    { name: "Elite", price: "$179/mo", features: ["Paper autopilot", "Broker sync", "Execution intelligence"] },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-6">
      <div className="mx-auto max-w-7xl">
        <h1 className="text-3xl font-semibold text-white">Billing Center</h1>
        <div className="mt-6 grid gap-6 lg:grid-cols-3">
          {plans.map((p) => <PlanCard key={p.name} name={p.name} price={p.price} features={p.features} />)}
        </div>
      </div>
    </div>
  );
}
