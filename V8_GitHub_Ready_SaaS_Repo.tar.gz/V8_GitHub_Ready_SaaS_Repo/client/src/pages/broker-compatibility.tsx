import React from "react";
import BrokerCard from "../components/broker-card";

export default function BrokerCompatibilityPage() {
  const brokers = [
    { name: "Paper Account", status: "supported" as const, description: "Simulated account for onboarding and paper autopilot." },
    { name: "Tastytrade", status: "supported" as const, description: "Primary broker integration for balances and assisted execution." },
    { name: "Interactive Brokers", status: "beta" as const, description: "Broker expansion target for advanced workflows." },
    { name: "Tradier", status: "coming_soon" as const, description: "Planned lightweight broker integration." },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-6">
      <div className="mx-auto max-w-7xl">
        <h1 className="text-3xl font-semibold text-white">Broker Compatibility</h1>
        <div className="mt-6 grid gap-6 xl:grid-cols-2">
          {brokers.map((b) => <BrokerCard key={b.name} name={b.name} status={b.status} description={b.description} />)}
        </div>
      </div>
    </div>
  );
}
