import React from "react";

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-6">
      <div className="mx-auto max-w-7xl">
        <h1 className="text-3xl font-semibold text-white">V8 Dashboard</h1>
        <p className="mt-2 text-sm text-slate-300">GitHub-ready SaaS dashboard scaffold with merged phase architecture.</p>
      </div>
    </div>
  );
}
