import { Router } from "express";
import { listPlans, getCurrentSubscription } from "../services/saas/billing-service";

const router = Router();

router.get("/api/billing/plans", async (_req, res) => {
  res.json({ ok: true, plans: listPlans() });
});

router.get("/api/billing/subscription", async (_req, res) => {
  res.json({ ok: true, subscription: getCurrentSubscription() });
});

export default router;
