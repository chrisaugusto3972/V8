import { Router } from "express";
import { createInAppNotification } from "../services/v8/notification-engine";

const router = Router();

router.get("/api/notifications", async (_req, res) => {
  res.json({
    ok: true,
    notifications: [
      createInAppNotification("approval_needed", "warning", { ticker: "SPY" }),
      createInAppNotification("concentration_warning", "danger", { sector: "Technology" }),
    ],
  });
});

export default router;
