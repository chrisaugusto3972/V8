import { Router } from "express";
import { listBrokerDescriptors, getBrokerAdapter } from "../services/brokers/broker-registry";

const router = Router();

router.get("/api/brokers/compatibility", async (_req, res) => {
  res.json({ ok: true, brokers: listBrokerDescriptors() });
});

router.post("/api/brokers/:key/connect", async (req, res) => {
  const adapter = getBrokerAdapter(String(req.params.key ?? ""));
  if (!adapter) {
    res.status(404).json({ ok: false, error: "Broker not found" });
    return;
  }
  res.json({ ok: true, result: await adapter.connect() });
});

export default router;
