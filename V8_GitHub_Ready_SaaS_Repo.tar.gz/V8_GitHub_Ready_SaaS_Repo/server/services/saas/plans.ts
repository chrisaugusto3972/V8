export type PlanCode = "starter" | "pro" | "elite";

export const SAAS_PLANS = [
  { code: "starter", name: "Starter", monthlyPrice: 39, yearlyPrice: 390 },
  { code: "pro", name: "Pro", monthlyPrice: 99, yearlyPrice: 990 },
  { code: "elite", name: "Elite", monthlyPrice: 179, yearlyPrice: 1790 },
];

export function getPlanByCode(code: string | null | undefined) {
  return SAAS_PLANS.find((p) => p.code === code) ?? SAAS_PLANS[0];
}
