export function hasEntitlement(input: { planCode: "starter" | "pro" | "elite"; feature: string }) {
  if (input.planCode === "elite") return true;
  if (input.planCode === "pro") return input.feature !== "autopilot";
  return input.feature === "notifications";
}
