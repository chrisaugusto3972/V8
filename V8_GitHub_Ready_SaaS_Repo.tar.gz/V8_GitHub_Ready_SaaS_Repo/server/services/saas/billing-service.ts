import { SAAS_PLANS } from "./plans";

export function listPlans() {
  return SAAS_PLANS;
}

export function getCurrentSubscription() {
  return {
    workspaceId: "default-workspace",
    planCode: "pro",
    status: "active",
    billingCycle: "monthly",
    currentPeriodEnd: new Date(Date.now() + 1000 * 60 * 60 * 24 * 22).toISOString(),
  };
}
