import type { BrokerAdapter } from "./broker-types";

export const tradierAdapter: BrokerAdapter = {
  key: "tradier",
  async connect() {
    return { ok: true, broker: "tradier", message: "Tradier scaffold registered as coming soon." };
  },
  async getAccountMetadata() {
    return {
      broker: "tradier",
      status: "coming_soon",
      supports: { balances: true, positions: true, liveOrders: true, assistedExecution: false, replaceOrders: false },
    };
  },
};
