import type { BrokerAdapter } from "./broker-types";

export const tastytradeAdapter: BrokerAdapter = {
  key: "tastytrade",
  async connect() {
    return { ok: true, broker: "tastytrade", message: "Tastytrade adapter scaffold connected." };
  },
  async getBalances() {
    return { ok: true, balances: {} };
  },
  async getPositions() {
    return { ok: true, positions: [] };
  },
  async listLiveOrders() {
    return { ok: true, orders: [] };
  },
  async submitOrder(order: any) {
    return { ok: true, status: "submitted", order };
  },
  async cancelOrder(orderId: string) {
    return { ok: true, canceledOrderId: orderId };
  },
  async replaceOrder(orderId: string, patch: any) {
    return { ok: true, orderId, patch };
  },
  async getQuotes(symbol: string) {
    return { ok: true, symbol };
  },
  async getAccountMetadata() {
    return {
      broker: "tastytrade",
      status: "supported",
      supports: { balances: true, positions: true, liveOrders: true, assistedExecution: true, replaceOrders: true },
    };
  },
};
