import type { BrokerAdapter, BrokerDescriptor } from "./broker-types";
import { paperBrokerAdapter } from "./paper-broker";
import { tastytradeAdapter } from "./tastytrade-adapter";
import { interactiveBrokersAdapter } from "./interactive-brokers-adapter";
import { tradierAdapter } from "./tradier-adapter";

export const BROKER_REGISTRY: BrokerDescriptor[] = [
  {
    key: "paper",
    name: "Paper Account",
    status: "supported",
    description: "Simulated account for onboarding, testing, and paper autopilot.",
    capabilities: {
      readOnlySync: false,
      assistedExecution: false,
      paperAutopilotCompatible: true,
      liveAutopilotCompatible: false,
      quotesSupported: true,
      replaceOrderSupported: true,
    },
  },
  {
    key: "tastytrade",
    name: "Tastytrade",
    status: "supported",
    description: "Primary broker integration for balances, positions, and assisted execution workflows.",
    capabilities: {
      readOnlySync: true,
      assistedExecution: true,
      paperAutopilotCompatible: true,
      liveAutopilotCompatible: false,
      quotesSupported: true,
      replaceOrderSupported: true,
    },
  },
  {
    key: "interactive_brokers",
    name: "Interactive Brokers",
    status: "beta",
    description: "Broker expansion target with broader professional workflows.",
    capabilities: {
      readOnlySync: true,
      assistedExecution: true,
      paperAutopilotCompatible: true,
      liveAutopilotCompatible: false,
      quotesSupported: true,
      replaceOrderSupported: true,
    },
  },
  {
    key: "tradier",
    name: "Tradier",
    status: "coming_soon",
    description: "Planned lightweight broker integration.",
    capabilities: {
      readOnlySync: true,
      assistedExecution: false,
      paperAutopilotCompatible: true,
      liveAutopilotCompatible: false,
      quotesSupported: true,
      replaceOrderSupported: false,
    },
  },
];

export const BROKER_ADAPTERS: Record<string, BrokerAdapter> = {
  paper: paperBrokerAdapter,
  tastytrade: tastytradeAdapter,
  interactive_brokers: interactiveBrokersAdapter,
  tradier: tradierAdapter,
};

export function listBrokerDescriptors() {
  return BROKER_REGISTRY;
}

export function getBrokerAdapter(key: string) {
  return BROKER_ADAPTERS[key] ?? null;
}
