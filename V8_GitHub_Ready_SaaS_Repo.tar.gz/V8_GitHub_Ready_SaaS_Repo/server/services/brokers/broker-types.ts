export type BrokerSupportStatus = "supported" | "beta" | "coming_soon";

export type BrokerKey =
  | "paper"
  | "tastytrade"
  | "interactive_brokers"
  | "tradier";

export type BrokerCapabilities = {
  readOnlySync: boolean;
  assistedExecution: boolean;
  paperAutopilotCompatible: boolean;
  liveAutopilotCompatible: boolean;
  quotesSupported: boolean;
  replaceOrderSupported: boolean;
};

export type BrokerDescriptor = {
  key: BrokerKey;
  name: string;
  status: BrokerSupportStatus;
  description: string;
  capabilities: BrokerCapabilities;
};

export type BrokerAdapter = {
  key: BrokerKey;
  connect: () => Promise<any>;
  disconnect?: () => Promise<any>;
  getBalances?: () => Promise<any>;
  getPositions?: () => Promise<any>;
  listLiveOrders?: () => Promise<any>;
  submitOrder?: (order: any) => Promise<any>;
  cancelOrder?: (orderId: string) => Promise<any>;
  replaceOrder?: (orderId: string, patch: any) => Promise<any>;
  getQuotes?: (symbol: string) => Promise<any>;
  getAccountMetadata?: () => Promise<any>;
};
