import type { BrokerAdapter } from "./broker-types";

export const paperBrokerAdapter: BrokerAdapter = {
  key: "paper",
  async connect() {
    return { ok: true, broker: "paper", message: "Paper account connected." };
  },
  async getBalances() {
    return { ok: true, balances: { accountValue: 3000, buyingPower: 3000, cash: 3000 } };
  },
  async getPositions() {
    return { ok: true, positions: [] };
  },
  async listLiveOrders() {
    return { ok: true, orders: [] };
  },
  async submitOrder(order: any) {
    return { ok: true, status: "filled_simulated", order };
  },
  async getQuotes(symbol: string) {
    return { ok: true, symbol, bid: 1.0, ask: 1.1, midpoint: 1.05 };
  },
  async getAccountMetadata() {
    return {
      broker: "paper",
      status: "supported",
      supports: { balances: true, positions: true, liveOrders: true, assistedExecution: false, replaceOrders: true },
    };
  },
};
