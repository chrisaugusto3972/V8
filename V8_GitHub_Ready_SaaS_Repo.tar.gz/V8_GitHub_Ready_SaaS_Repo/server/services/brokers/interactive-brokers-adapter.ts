import type { BrokerAdapter } from "./broker-types";

export const interactiveBrokersAdapter: BrokerAdapter = {
  key: "interactive_brokers",
  async connect() {
    return { ok: true, broker: "interactive_brokers", message: "Interactive Brokers scaffold connected in beta mode." };
  },
  async getAccountMetadata() {
    return {
      broker: "interactive_brokers",
      status: "beta",
      supports: { balances: true, positions: true, liveOrders: true, assistedExecution: true, replaceOrders: true },
    };
  },
};
