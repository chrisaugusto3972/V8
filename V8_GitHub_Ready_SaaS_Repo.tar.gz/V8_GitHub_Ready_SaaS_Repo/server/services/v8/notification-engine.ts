import { renderNotificationSubject, type NotificationTemplateType } from "./notification-templates";

export type NotificationSeverity = "info" | "warning" | "danger" | "success";

export function createInAppNotification(
  type: NotificationTemplateType,
  severity: NotificationSeverity,
  payload: Record<string, any> = {},
) {
  return {
    id: Math.random().toString(36).slice(2, 10),
    type,
    severity,
    title: renderNotificationSubject(type),
    message: JSON.stringify(payload),
    channel: "in_app",
    createdAt: new Date().toISOString(),
    acknowledged: false,
  };
}
