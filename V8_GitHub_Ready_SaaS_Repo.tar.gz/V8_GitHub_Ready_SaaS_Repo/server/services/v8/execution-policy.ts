export type ExecutionIntentType =
  | "entry"
  | "profit_exit"
  | "defensive_exit"
  | "emergency_exit";

export type ExecutionPolicyInput = {
  side: "entry" | "exit";
  intentType: ExecutionIntentType;
  bid: number;
  ask: number;
  midpoint: number;
  slippageRatio?: number;
  liquidityScore?: number;
  regime?: string;
};

export type ExecutionPolicy = {
  policyName: string;
  initialLimit: number;
  minAcceptableLimit: number;
  maxWaitSeconds: number;
  repriceIntervalSeconds: number;
  maxReprices: number;
  priceStep: number;
};

function safeNum(v: any, fallback = 0): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function roundPrice(n: number): number {
  return Math.round(n * 100) / 100;
}

export function getExecutionPolicy(input: ExecutionPolicyInput): ExecutionPolicy {
  const bid = safeNum(input.bid, 0);
  const ask = safeNum(input.ask, 0);
  const midpoint = safeNum(input.midpoint, (bid + ask) / 2);
  const spread = Math.max(ask - bid, 0.01);

  if (input.intentType === "emergency_exit") {
    return {
      policyName: "emergency_exit",
      initialLimit: roundPrice(ask),
      minAcceptableLimit: roundPrice(ask),
      maxWaitSeconds: 10,
      repriceIntervalSeconds: 5,
      maxReprices: 0,
      priceStep: 0,
    };
  }

  if (input.intentType === "defensive_exit") {
    return {
      policyName: "defensive_exit",
      initialLimit: roundPrice(midpoint + spread * 0.25),
      minAcceptableLimit: roundPrice(ask),
      maxWaitSeconds: 45,
      repriceIntervalSeconds: 15,
      maxReprices: 2,
      priceStep: roundPrice(Math.max(0.01, spread * 0.2)),
    };
  }

  if (input.intentType === "profit_exit") {
    return {
      policyName: "profit_exit",
      initialLimit: roundPrice(midpoint),
      minAcceptableLimit: roundPrice(midpoint + spread * 0.5),
      maxWaitSeconds: 90,
      repriceIntervalSeconds: 20,
      maxReprices: 2,
      priceStep: roundPrice(Math.max(0.01, spread * 0.15)),
    };
  }

  return {
    policyName: "entry_adaptive",
    initialLimit: roundPrice(midpoint),
    minAcceptableLimit: roundPrice(Math.max(bid, midpoint - spread * 0.35)),
    maxWaitSeconds: 120,
    repriceIntervalSeconds: 20,
    maxReprices: 3,
    priceStep: roundPrice(Math.max(0.01, spread * 0.15)),
  };
}
