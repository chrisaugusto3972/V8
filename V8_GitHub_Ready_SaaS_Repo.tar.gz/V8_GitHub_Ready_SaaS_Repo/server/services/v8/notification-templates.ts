export type NotificationTemplateType =
  | "daily_picks_digest"
  | "daily_risk_digest"
  | "fill_update"
  | "exit_update"
  | "approval_needed"
  | "broker_disconnect"
  | "autopilot_warning"
  | "concentration_warning";

export function renderNotificationSubject(type: NotificationTemplateType): string {
  const subjects: Record<string, string> = {
    daily_picks_digest: "V8 Daily Picks Digest",
    daily_risk_digest: "V8 Daily Risk Summary",
    fill_update: "V8 Fill Update",
    exit_update: "V8 Exit Update",
    approval_needed: "V8 Approval Needed",
    broker_disconnect: "V8 Broker Connection Warning",
    autopilot_warning: "V8 Autopilot Warning",
    concentration_warning: "V8 Portfolio Concentration Warning",
  };
  return subjects[type] ?? "V8 Notification";
}
