export type ExecutionAnalyticsRecord = {
  ticker: string;
  side: "entry" | "exit";
  intentType: "entry" | "profit_exit" | "defensive_exit" | "emergency_exit";
  bidAtSubmit: number;
  askAtSubmit: number;
  midpointAtSubmit: number;
  initialLimit: number;
  finalFillPrice?: number | null;
  repriceCount?: number | null;
  createdAt?: string | Date | null;
  filledAt?: string | Date | null;
};

function safeNum(v: any, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function round2(n: number) {
  return Math.round(n * 100) / 100;
}

export function computeExecutionQuality(record: ExecutionAnalyticsRecord) {
  const bid = safeNum(record.bidAtSubmit, 0);
  const ask = safeNum(record.askAtSubmit, 0);
  const mid = safeNum(record.midpointAtSubmit, 0);
  const fill = safeNum(record.finalFillPrice, mid);
  const spread = Math.max(ask - bid, 0.0001);
  const entry = record.side === "entry";

  return {
    fillVsMidpointPct: round2(entry ? ((fill - mid) / Math.max(mid, 0.0001)) * 100 : ((mid - fill) / Math.max(mid, 0.0001)) * 100),
    fillVsBidAskPct: round2(entry ? ((fill - bid) / spread) * 100 : ((ask - fill) / spread) * 100),
  };
}
