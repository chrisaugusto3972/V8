# V8 SaaS Phases Included

## Phase 1
- SaaS shell structure
- app layout direction
- workspace/account concept scaffolding

## Phase 2
- dashboard, scanner, picks, portfolio, risk, journal, analytics page scaffolds

## Phase 3
- risk cockpit concept
- concentration warning structures
- pre-trade portfolio impact foundation

## Phase 4
- broker abstraction types
- paper broker scaffold
- Tastytrade scaffold

## Phase 5
- execution policy engine
- execution analytics helpers
- execution page scaffold

## Phase 6
- notifications engine
- notification templates
- notification center and settings pages

## Phase 7
- plans
- entitlements
- billing service scaffold
- billing pages

## Phase 8
- interactive brokers scaffold
- tradier scaffold
- broker compatibility registry and page
