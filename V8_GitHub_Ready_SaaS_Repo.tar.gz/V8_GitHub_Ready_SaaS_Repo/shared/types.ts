export type Workspace = {
  id: string;
  name: string;
};

export type TradingAccount = {
  id: string;
  workspaceId: string;
  name: string;
  mode: "paper" | "assisted" | "live";
  broker: "paper" | "tastytrade" | "interactive_brokers" | "tradier";
};

export type DailyPick = {
  ticker: string;
  engine: string;
  confidence: number;
  delta: number;
  distanceOtmPct: number;
  creditPctOfWidth: number;
  dte: number;
};
